package androidx.activity;

/* JADX INFO: loaded from: classes17.dex */
public final class R {

    public static final class id {
        public static int report_drawn = 0x7f0801ac;
        public static int view_tree_on_back_pressed_dispatcher_owner = 0x7f080241;

        private id() {
        }
    }

    private R() {
    }
}
