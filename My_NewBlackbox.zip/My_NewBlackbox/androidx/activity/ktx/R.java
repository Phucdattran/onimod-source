package androidx.activity.ktx;

/* JADX INFO: loaded from: classes17.dex */
public final class R {
    private R() {
    }
}
