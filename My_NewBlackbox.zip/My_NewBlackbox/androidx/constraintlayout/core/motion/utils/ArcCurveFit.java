package androidx.constraintlayout.core.motion.utils;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public class ArcCurveFit extends CurveFit {
    public static final int ARC_ABOVE = 5;
    public static final int ARC_BELOW = 4;
    public static final int ARC_START_FLIP = 3;
    public static final int ARC_START_HORIZONTAL = 2;
    public static final int ARC_START_LINEAR = 0;
    public static final int ARC_START_VERTICAL = 1;
    private static final int DOWN_ARC = 4;
    private static final int START_HORIZONTAL = 2;
    private static final int START_LINEAR = 3;
    private static final int START_VERTICAL = 1;
    private static final int UP_ARC = 5;
    Arc[] mArcs;
    private boolean mExtrapolate = true;
    private final double[] mTime;

    @Override // androidx.constraintlayout.core.motion.utils.CurveFit
    public void getPos(double t, double[] v) {
        if (!this.mExtrapolate) {
            if (t < this.mArcs[0].mTime1) {
                t = this.mArcs[0].mTime1;
            }
            if (t > this.mArcs[this.mArcs.length - 1].mTime2) {
                t = this.mArcs[this.mArcs.length - 1].mTime2;
            }
        } else {
            if (t < this.mArcs[0].mTime1) {
                double t0 = this.mArcs[0].mTime1;
                double dt = t - this.mArcs[0].mTime1;
                if (this.mArcs[0].mLinear) {
                    v[0] = this.mArcs[0].getLinearX(t0) + (this.mArcs[0].getLinearDX(t0) * dt);
                    v[1] = this.mArcs[0].getLinearY(t0) + (this.mArcs[0].getLinearDY(t0) * dt);
                    return;
                } else {
                    this.mArcs[0].setPoint(t0);
                    v[0] = this.mArcs[0].getX() + (this.mArcs[0].getDX() * dt);
                    v[1] = this.mArcs[0].getY() + (this.mArcs[0].getDY() * dt);
                    return;
                }
            }
            if (t > this.mArcs[this.mArcs.length - 1].mTime2) {
                double t1 = this.mArcs[this.mArcs.length - 1].mTime2;
                double dt2 = t - t1;
                int p = this.mArcs.length - 1;
                if (this.mArcs[p].mLinear) {
                    v[0] = this.mArcs[p].getLinearX(t1) + (this.mArcs[p].getLinearDX(t1) * dt2);
                    v[1] = this.mArcs[p].getLinearY(t1) + (this.mArcs[p].getLinearDY(t1) * dt2);
                    return;
                } else {
                    this.mArcs[p].setPoint(t);
                    v[0] = this.mArcs[p].getX() + (this.mArcs[p].getDX() * dt2);
                    v[1] = this.mArcs[p].getY() + (this.mArcs[p].getDY() * dt2);
                    return;
                }
            }
        }
        for (int i = 0; i < this.mArcs.length; i++) {
            if (t <= this.mArcs[i].mTime2) {
                if (this.mArcs[i].mLinear) {
                    v[0] = this.mArcs[i].getLinearX(t);
                    v[1] = this.mArcs[i].getLinearY(t);
                    return;
                } else {
                    this.mArcs[i].setPoint(t);
                    v[0] = this.mArcs[i].getX();
                    v[1] = this.mArcs[i].getY();
                    return;
                }
            }
        }
    }

    @Override // androidx.constraintlayout.core.motion.utils.CurveFit
    public void getPos(double t, float[] v) {
        if (this.mExtrapolate) {
            if (t < this.mArcs[0].mTime1) {
                double t0 = this.mArcs[0].mTime1;
                double dt = t - this.mArcs[0].mTime1;
                if (this.mArcs[0].mLinear) {
                    v[0] = (float) (this.mArcs[0].getLinearX(t0) + (this.mArcs[0].getLinearDX(t0) * dt));
                    v[1] = (float) (this.mArcs[0].getLinearY(t0) + (this.mArcs[0].getLinearDY(t0) * dt));
                    return;
                } else {
                    this.mArcs[0].setPoint(t0);
                    v[0] = (float) (this.mArcs[0].getX() + (this.mArcs[0].getDX() * dt));
                    v[1] = (float) (this.mArcs[0].getY() + (this.mArcs[0].getDY() * dt));
                    return;
                }
            }
            if (t > this.mArcs[this.mArcs.length - 1].mTime2) {
                double t1 = this.mArcs[this.mArcs.length - 1].mTime2;
                double dt2 = t - t1;
                int p = this.mArcs.length - 1;
                if (this.mArcs[p].mLinear) {
                    v[0] = (float) (this.mArcs[p].getLinearX(t1) + (this.mArcs[p].getLinearDX(t1) * dt2));
                    v[1] = (float) (this.mArcs[p].getLinearY(t1) + (this.mArcs[p].getLinearDY(t1) * dt2));
                    return;
                } else {
                    this.mArcs[p].setPoint(t);
                    v[0] = (float) this.mArcs[p].getX();
                    v[1] = (float) this.mArcs[p].getY();
                    return;
                }
            }
        } else if (t < this.mArcs[0].mTime1) {
            t = this.mArcs[0].mTime1;
        } else if (t > this.mArcs[this.mArcs.length - 1].mTime2) {
            t = this.mArcs[this.mArcs.length - 1].mTime2;
        }
        for (int i = 0; i < this.mArcs.length; i++) {
            if (t <= this.mArcs[i].mTime2) {
                if (this.mArcs[i].mLinear) {
                    v[0] = (float) this.mArcs[i].getLinearX(t);
                    v[1] = (float) this.mArcs[i].getLinearY(t);
                    return;
                } else {
                    this.mArcs[i].setPoint(t);
                    v[0] = (float) this.mArcs[i].getX();
                    v[1] = (float) this.mArcs[i].getY();
                    return;
                }
            }
        }
    }

    @Override // androidx.constraintlayout.core.motion.utils.CurveFit
    public void getSlope(double t, double[] v) {
        if (t < this.mArcs[0].mTime1) {
            t = this.mArcs[0].mTime1;
        } else if (t > this.mArcs[this.mArcs.length - 1].mTime2) {
            t = this.mArcs[this.mArcs.length - 1].mTime2;
        }
        for (int i = 0; i < this.mArcs.length; i++) {
            if (t <= this.mArcs[i].mTime2) {
                if (this.mArcs[i].mLinear) {
                    v[0] = this.mArcs[i].getLinearDX(t);
                    v[1] = this.mArcs[i].getLinearDY(t);
                    return;
                } else {
                    this.mArcs[i].setPoint(t);
                    v[0] = this.mArcs[i].getDX();
                    v[1] = this.mArcs[i].getDY();
                    return;
                }
            }
        }
    }

    @Override // androidx.constraintlayout.core.motion.utils.CurveFit
    public double getPos(double t, int j) {
        if (this.mExtrapolate) {
            if (t < this.mArcs[0].mTime1) {
                double t0 = this.mArcs[0].mTime1;
                double dt = t - this.mArcs[0].mTime1;
                if (this.mArcs[0].mLinear) {
                    return j == 0 ? this.mArcs[0].getLinearX(t0) + (this.mArcs[0].getLinearDX(t0) * dt) : this.mArcs[0].getLinearY(t0) + (this.mArcs[0].getLinearDY(t0) * dt);
                }
                this.mArcs[0].setPoint(t0);
                return j == 0 ? this.mArcs[0].getX() + (this.mArcs[0].getDX() * dt) : this.mArcs[0].getY() + (this.mArcs[0].getDY() * dt);
            }
            if (t > this.mArcs[this.mArcs.length - 1].mTime2) {
                double t1 = this.mArcs[this.mArcs.length - 1].mTime2;
                double dt2 = t - t1;
                int p = this.mArcs.length - 1;
                if (j == 0) {
                    return this.mArcs[p].getLinearX(t1) + (this.mArcs[p].getLinearDX(t1) * dt2);
                }
                return this.mArcs[p].getLinearY(t1) + (this.mArcs[p].getLinearDY(t1) * dt2);
            }
        } else if (t < this.mArcs[0].mTime1) {
            t = this.mArcs[0].mTime1;
        } else if (t > this.mArcs[this.mArcs.length - 1].mTime2) {
            t = this.mArcs[this.mArcs.length - 1].mTime2;
        }
        for (int i = 0; i < this.mArcs.length; i++) {
            if (t <= this.mArcs[i].mTime2) {
                if (this.mArcs[i].mLinear) {
                    if (j == 0) {
                        return this.mArcs[i].getLinearX(t);
                    }
                    return this.mArcs[i].getLinearY(t);
                }
                this.mArcs[i].setPoint(t);
                if (j == 0) {
                    return this.mArcs[i].getX();
                }
                return this.mArcs[i].getY();
            }
        }
        return Double.NaN;
    }

    @Override // androidx.constraintlayout.core.motion.utils.CurveFit
    public double getSlope(double t, int j) {
        if (t < this.mArcs[0].mTime1) {
            t = this.mArcs[0].mTime1;
        }
        if (t > this.mArcs[this.mArcs.length - 1].mTime2) {
            t = this.mArcs[this.mArcs.length - 1].mTime2;
        }
        for (int i = 0; i < this.mArcs.length; i++) {
            if (t <= this.mArcs[i].mTime2) {
                if (this.mArcs[i].mLinear) {
                    if (j == 0) {
                        return this.mArcs[i].getLinearDX(t);
                    }
                    return this.mArcs[i].getLinearDY(t);
                }
                this.mArcs[i].setPoint(t);
                if (j == 0) {
                    return this.mArcs[i].getDX();
                }
                return this.mArcs[i].getDY();
            }
        }
        return Double.NaN;
    }

    @Override // androidx.constraintlayout.core.motion.utils.CurveFit
    public double[] getTimePoints() {
        return this.mTime;
    }

    public ArcCurveFit(int[] arcModes, double[] time, double[][] y) {
        this.mTime = time;
        this.mArcs = new Arc[time.length - 1];
        int mode = 1;
        int last = 1;
        int i = 0;
        while (i < this.mArcs.length) {
            int mode2 = 2;
            switch (arcModes[i]) {
                case 0:
                    mode2 = 3;
                    break;
                case 1:
                    last = 1;
                    mode2 = 1;
                    break;
                case 2:
                    last = 2;
                    break;
                case 3:
                    mode2 = last != 1 ? 1 : 2;
                    last = mode2;
                    break;
                case 4:
                    mode2 = 4;
                    break;
                case 5:
                    mode2 = 5;
                    break;
                default:
                    mode2 = mode;
                    break;
            }
            this.mArcs[i] = new Arc(mode2, time[i], time[i + 1], y[i][0], y[i][1], y[i + 1][0], y[i + 1][1]);
            i++;
            mode = mode2;
        }
    }

    private static class Arc {
        private static final double EPSILON = 0.001d;
        private static final String TAG = "Arc";
        private static double[] sOurPercent = new double[91];
        double mArcDistance;
        double mArcVelocity;
        double mEllipseA;
        double mEllipseB;
        double mEllipseCenterX;
        double mEllipseCenterY;
        boolean mLinear;
        double[] mLut;
        double mOneOverDeltaTime;
        double mTime1;
        double mTime2;
        double mTmpCosAngle;
        double mTmpSinAngle;
        boolean mVertical;
        double mX1;
        double mX2;
        double mY1;
        double mY2;

        Arc(int mode, double t1, double t2, double x1, double y1, double x2, double y2) {
            this.mLinear = false;
            double dx = x2 - x1;
            double dy = y2 - y1;
            switch (mode) {
                case 1:
                    this.mVertical = true;
                    break;
                case 2:
                case 3:
                default:
                    this.mVertical = false;
                    break;
                case 4:
                    this.mVertical = dy > 0.0d;
                    break;
                case 5:
                    this.mVertical = dy < 0.0d;
                    break;
            }
            this.mTime1 = t1;
            this.mTime2 = t2;
            this.mOneOverDeltaTime = 1.0d / (this.mTime2 - this.mTime1);
            if (3 == mode) {
                this.mLinear = true;
            }
            if (!this.mLinear && Math.abs(dx) >= EPSILON && Math.abs(dy) >= EPSILON) {
                this.mLut = new double[101];
                this.mEllipseA = ((double) (this.mVertical ? -1 : 1)) * dx;
                this.mEllipseB = ((double) (this.mVertical ? 1 : -1)) * dy;
                this.mEllipseCenterX = this.mVertical ? x2 : x1;
                this.mEllipseCenterY = this.mVertical ? y1 : y2;
                buildTable(x1, y1, x2, y2);
                this.mArcVelocity = this.mOneOverDeltaTime * this.mArcDistance;
                return;
            }
            this.mLinear = true;
            this.mX1 = x1;
            this.mX2 = x2;
            this.mY1 = y1;
            this.mY2 = y2;
            this.mArcDistance = Math.hypot(dy, dx);
            this.mArcVelocity = this.mOneOverDeltaTime * this.mArcDistance;
            this.mEllipseCenterX = dx / (this.mTime2 - this.mTime1);
            this.mEllipseCenterY = dy / (this.mTime2 - this.mTime1);
        }

        void setPoint(double time) {
            double percent = (this.mVertical ? this.mTime2 - time : time - this.mTime1) * this.mOneOverDeltaTime;
            double angle = lookup(percent) * 1.5707963267948966d;
            this.mTmpSinAngle = Math.sin(angle);
            this.mTmpCosAngle = Math.cos(angle);
        }

        double getX() {
            return this.mEllipseCenterX + (this.mEllipseA * this.mTmpSinAngle);
        }

        double getY() {
            return this.mEllipseCenterY + (this.mEllipseB * this.mTmpCosAngle);
        }

        double getDX() {
            double vx = this.mEllipseA * this.mTmpCosAngle;
            double vy = (-this.mEllipseB) * this.mTmpSinAngle;
            double norm = this.mArcVelocity / Math.hypot(vx, vy);
            return this.mVertical ? (-vx) * norm : vx * norm;
        }

        double getDY() {
            double vx = this.mEllipseA * this.mTmpCosAngle;
            double vy = (-this.mEllipseB) * this.mTmpSinAngle;
            double norm = this.mArcVelocity / Math.hypot(vx, vy);
            return this.mVertical ? (-vy) * norm : vy * norm;
        }

        public double getLinearX(double t) {
            double t2 = (t - this.mTime1) * this.mOneOverDeltaTime;
            double t3 = this.mX1;
            return t3 + ((this.mX2 - this.mX1) * t2);
        }

        public double getLinearY(double t) {
            double t2 = (t - this.mTime1) * this.mOneOverDeltaTime;
            double t3 = this.mY1;
            return t3 + ((this.mY2 - this.mY1) * t2);
        }

        public double getLinearDX(double t) {
            return this.mEllipseCenterX;
        }

        public double getLinearDY(double t) {
            return this.mEllipseCenterY;
        }

        double lookup(double v) {
            if (v <= 0.0d) {
                return 0.0d;
            }
            if (v >= 1.0d) {
                return 1.0d;
            }
            double pos = ((double) (this.mLut.length - 1)) * v;
            int iv = (int) pos;
            double off = pos - ((double) ((int) pos));
            return this.mLut[iv] + ((this.mLut[iv + 1] - this.mLut[iv]) * off);
        }

        private void buildTable(double x1, double y1, double x2, double y2) {
            int i;
            double a = x2 - x1;
            double b = y1 - y2;
            double lx = 0.0d;
            double ly = 0.0d;
            double dist = 0.0d;
            int i2 = 0;
            while (i2 < sOurPercent.length) {
                double angle = Math.toRadians((((double) i2) * 90.0d) / ((double) (sOurPercent.length - 1)));
                double s = Math.sin(angle);
                double c = Math.cos(angle);
                double px = a * s;
                double py = b * c;
                if (i2 > 0) {
                    double a2 = px - lx;
                    double b2 = py - ly;
                    dist += Math.hypot(a2, b2);
                    sOurPercent[i2] = dist;
                }
                lx = px;
                ly = py;
                i2++;
                a = a;
                b = b;
            }
            this.mArcDistance = dist;
            for (int i3 = 0; i3 < sOurPercent.length; i3++) {
                double[] dArr = sOurPercent;
                dArr[i3] = dArr[i3] / dist;
            }
            int i4 = 0;
            while (i4 < this.mLut.length) {
                double pos = ((double) i4) / ((double) (this.mLut.length - 1));
                int index = Arrays.binarySearch(sOurPercent, pos);
                if (index >= 0) {
                    this.mLut[i4] = ((double) index) / ((double) (sOurPercent.length - 1));
                    i = i4;
                } else if (index == -1) {
                    this.mLut[i4] = 0.0d;
                    i = i4;
                } else {
                    int p1 = (-index) - 2;
                    int p2 = (-index) - 1;
                    i = i4;
                    double ans = (((double) p1) + ((pos - sOurPercent[p1]) / (sOurPercent[p2] - sOurPercent[p1]))) / ((double) (sOurPercent.length - 1));
                    this.mLut[i] = ans;
                }
                i4 = i + 1;
            }
        }
    }
}
