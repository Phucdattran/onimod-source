package android.content;

import android.os.IInterface;

/* JADX INFO: loaded from: classes15.dex */
public interface IContentProvider extends IInterface {
}
