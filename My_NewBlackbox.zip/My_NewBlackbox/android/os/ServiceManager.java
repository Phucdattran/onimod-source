package android.os;

/* JADX INFO: loaded from: classes12.dex */
public class ServiceManager {
    public static IBinder getService(String name) {
        throw new UnsupportedOperationException("STUB");
    }
}
