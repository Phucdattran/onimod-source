package android.os;

/* JADX INFO: loaded from: classes12.dex */
public class SELinux {
    public static final String getContext() {
        throw new UnsupportedOperationException("STUB");
    }

    public static final boolean isSELinuxEnabled() {
        throw new UnsupportedOperationException("STUB");
    }

    public static final boolean isSELinuxEnforced() {
        throw new UnsupportedOperationException("STUB");
    }
}
