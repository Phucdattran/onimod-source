package android.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ProviderInfo;
import android.os.Handler;
import android.os.IBinder;
import android.util.ArrayMap;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: classes12.dex */
public class ActivityThread {
    public Map<IBinder, ActivityClientRecord> mActivities;
    public AppBindData mBoundApplication;
    public H mH = null;
    public Application mInitialApplication;
    public Instrumentation mInstrumentation;
    public Map<String, WeakReference<?>> mPackages;
    public ArrayMap<ProviderKey, Object> mProviderMap;

    public static final class ActivityClientRecord {
        public Activity activity;
        public ActivityInfo activityInfo;
        public Intent intent;
        public IBinder token;
    }

    static class H extends Handler {
        H() {
        }
    }

    public static ActivityThread currentActivityThread() {
        throw new RuntimeException();
    }

    public String getProcessName() {
        throw new RuntimeException();
    }

    public Handler getHandler() {
        throw new RuntimeException();
    }

    public ContentProviderHolder installProvider(Context context, ContentProviderHolder holder, ProviderInfo info, boolean noisy, boolean noReleaseNeeded, boolean stable) {
        throw new RuntimeException();
    }

    static final class AppBindData {
        AppBindData() {
        }
    }

    public static final class ProviderKey {
        public final String authority;
        public final int userId;

        public ProviderKey(String authority, int userId) {
            this.authority = authority;
            this.userId = userId;
        }

        public boolean equals(Object o) {
            if (!(o instanceof ProviderKey)) {
                return false;
            }
            ProviderKey other = (ProviderKey) o;
            return Objects.equals(this.authority, other.authority) && this.userId == other.userId;
        }

        public int hashCode() {
            return (this.authority != null ? this.authority.hashCode() : 0) ^ this.userId;
        }
    }
}
