package android.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ProviderInfo;
import android.os.Handler;
import android.os.IBinder;
import android.util.ArrayMap;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public class ActivityThread {
    public Map<IBinder, ActivityClientRecord> mActivities;
    public AppBindData mBoundApplication;
    public H mH = null;
    public Application mInitialApplication;
    public Instrumentation mInstrumentation;
    public Map<String, WeakReference<?>> mPackages;
    public ArrayMap<ProviderKey, Object> mProviderMap;

    public static final class ActivityClientRecord {
        public Activity activity;
        public ActivityInfo activityInfo;
        public Intent intent;
        public IBinder token;
    }

    public static final class AppBindData {
    }

    public static class H extends Handler {
    }

    public static final class ProviderKey {
        public final String authority;
        public final int userId;

        public ProviderKey(String str, int i3) {
            this.authority = str;
            this.userId = i3;
        }

        public boolean equals(Object obj) {
            if (obj instanceof ProviderKey) {
                ProviderKey providerKey = (ProviderKey) obj;
                if (Objects.equals(this.authority, providerKey.authority) && this.userId == providerKey.userId) {
                    return true;
                }
            }
            return false;
        }

        public int hashCode() {
            String str = this.authority;
            return (str != null ? str.hashCode() : 0) ^ this.userId;
        }
    }

    public static ActivityThread currentActivityThread() {
        throw new RuntimeException();
    }

    public Handler getHandler() {
        throw new RuntimeException();
    }

    public String getProcessName() {
        throw new RuntimeException();
    }

    public ContentProviderHolder installProvider(Context context, ContentProviderHolder contentProviderHolder, ProviderInfo providerInfo, boolean z4, boolean z5, boolean z6) {
        throw new RuntimeException();
    }
}
