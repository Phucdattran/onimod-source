package android.app.job;

import android.app.NotificationChannel;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class a {
    public static /* synthetic */ NotificationChannel b() {
        return new NotificationChannel("blackbox_main", "BlackBox Core", 4);
    }

    public static /* synthetic */ NotificationChannel c(String str) {
        return new NotificationChannel(str, "blackbox_core", 4);
    }

    public static /* bridge */ /* synthetic */ JobWorkItem d(Object obj) {
        return (JobWorkItem) obj;
    }

    public static /* synthetic */ NotificationChannel r() {
        return new NotificationChannel("blackbox_background", "BlackBox Background", 2);
    }

    public static /* synthetic */ NotificationChannel v() {
        return new NotificationChannel("onimod_core_channel", "Onimod", 2);
    }
}
