package android.content;

import android.os.IInterface;

/* JADX INFO: loaded from: classes.dex */
public interface IContentProvider extends IInterface {
}
