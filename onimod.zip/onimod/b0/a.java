package b0;

import android.R;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f1031a = {R.attr.color, R.attr.alpha, R.attr.lStar, top.niunaijun.blackbox.R.attr.alpha, top.niunaijun.blackbox.R.attr.lStar};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int[] f1032b = {top.niunaijun.blackbox.R.attr.fontProviderAuthority, top.niunaijun.blackbox.R.attr.fontProviderCerts, top.niunaijun.blackbox.R.attr.fontProviderFallbackQuery, top.niunaijun.blackbox.R.attr.fontProviderFetchStrategy, top.niunaijun.blackbox.R.attr.fontProviderFetchTimeout, top.niunaijun.blackbox.R.attr.fontProviderPackage, top.niunaijun.blackbox.R.attr.fontProviderQuery, top.niunaijun.blackbox.R.attr.fontProviderSystemFontFamily};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int[] f1033c = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, top.niunaijun.blackbox.R.attr.font, top.niunaijun.blackbox.R.attr.fontStyle, top.niunaijun.blackbox.R.attr.fontVariationSettings, top.niunaijun.blackbox.R.attr.fontWeight, top.niunaijun.blackbox.R.attr.ttcIndex};

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int[] f1034d = {R.attr.startColor, R.attr.endColor, R.attr.type, R.attr.centerX, R.attr.centerY, R.attr.gradientRadius, R.attr.tileMode, R.attr.centerColor, R.attr.startX, R.attr.startY, R.attr.endX, R.attr.endY};

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final int[] f1035e = {R.attr.color, R.attr.offset};
}
