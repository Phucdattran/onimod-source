package a0;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.fragment.app.v;
import e1.i1;
import l.e3;
import n1.n;
import top.niunaijun.blackbox.entity.location.BCell;
import v2.z;

/* JADX INFO: loaded from: classes.dex */
public final class h implements Parcelable.ClassLoaderCreator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f20a;

    public /* synthetic */ h(int i3) {
        this.f20a = i3;
    }

    @Override // android.os.Parcelable.ClassLoaderCreator
    public final Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        switch (this.f20a) {
            case 0:
                return new i(parcel, classLoader);
            case 1:
                return new a2.h(parcel, classLoader);
            case 2:
                return new v(parcel, classLoader);
            case 3:
                return new b2.b(parcel, classLoader);
            case 4:
                return new i1(parcel, classLoader);
            case 5:
                return new k2.a(parcel, classLoader);
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                return new e3(parcel, classLoader);
            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                if (Build.VERSION.SDK_INT >= 24) {
                    return new n(parcel, classLoader);
                }
                n nVar = new n(parcel);
                nVar.f3430a = parcel.readInt();
                nVar.f3431b = parcel.readInt();
                nVar.f3432c = parcel.readParcelable(null);
                return nVar;
            case 8:
                if (parcel.readParcelable(classLoader) == null) {
                    return s0.b.f3826b;
                }
                throw new IllegalStateException("superState must be null");
            case 9:
                return new t2.c(parcel, classLoader);
            default:
                return new z(parcel, classLoader);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i3) {
        switch (this.f20a) {
            case 0:
                return new i[i3];
            case 1:
                return new a2.h[i3];
            case 2:
                return new v[i3];
            case 3:
                return new b2.b[i3];
            case 4:
                return new i1[i3];
            case 5:
                return new k2.a[i3];
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                return new e3[i3];
            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                return new n[i3];
            case 8:
                return new s0.b[i3];
            case 9:
                return new t2.c[i3];
            default:
                return new z[i3];
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f20a) {
            case 0:
                return new i(parcel, null);
            case 1:
                return new a2.h(parcel, null);
            case 2:
                return new v(parcel, null);
            case 3:
                return new b2.b(parcel, null);
            case 4:
                return new i1(parcel, null);
            case 5:
                return new k2.a(parcel, null);
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                return new e3(parcel, null);
            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                if (Build.VERSION.SDK_INT >= 24) {
                    return new n(parcel, null);
                }
                n nVar = new n(parcel);
                nVar.f3430a = parcel.readInt();
                nVar.f3431b = parcel.readInt();
                nVar.f3432c = parcel.readParcelable(null);
                return nVar;
            case 8:
                if (parcel.readParcelable(null) == null) {
                    return s0.b.f3826b;
                }
                throw new IllegalStateException("superState must be null");
            case 9:
                return new t2.c(parcel, null);
            default:
                return new z(parcel, null);
        }
    }
}
