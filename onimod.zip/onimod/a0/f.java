package a0;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class f extends ViewGroup.MarginLayoutParams {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public c f5a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f6b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f7c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f8d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f9e;
    public final int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f10g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f11h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f12i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f13j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public View f14k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public View f15l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f16m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f17n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Rect f18o;

    public f() {
        super(-2, -2);
        this.f6b = false;
        this.f7c = 0;
        this.f8d = 0;
        this.f9e = -1;
        this.f = -1;
        this.f10g = 0;
        this.f11h = 0;
        this.f18o = new Rect();
    }

    public final boolean a(int i3) {
        if (i3 == 0) {
            return this.f16m;
        }
        if (i3 != 1) {
            return false;
        }
        return this.f17n;
    }

    public f(Context context, AttributeSet attributeSet) {
        c cVar;
        super(context, attributeSet);
        this.f6b = false;
        this.f7c = 0;
        this.f8d = 0;
        this.f9e = -1;
        this.f = -1;
        this.f10g = 0;
        this.f11h = 0;
        this.f18o = new Rect();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, z.a.f4956b);
        this.f7c = typedArrayObtainStyledAttributes.getInteger(0, 0);
        this.f = typedArrayObtainStyledAttributes.getResourceId(1, -1);
        this.f8d = typedArrayObtainStyledAttributes.getInteger(2, 0);
        this.f9e = typedArrayObtainStyledAttributes.getInteger(6, -1);
        this.f10g = typedArrayObtainStyledAttributes.getInt(5, 0);
        this.f11h = typedArrayObtainStyledAttributes.getInt(4, 0);
        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(3);
        this.f6b = zHasValue;
        if (zHasValue) {
            String string = typedArrayObtainStyledAttributes.getString(3);
            String str = CoordinatorLayout.f445t;
            if (TextUtils.isEmpty(string)) {
                cVar = null;
            } else {
                if (string.startsWith(".")) {
                    string = context.getPackageName() + string;
                } else if (string.indexOf(46) < 0) {
                    String str2 = CoordinatorLayout.f445t;
                    if (!TextUtils.isEmpty(str2)) {
                        string = str2 + '.' + string;
                    }
                }
                try {
                    ThreadLocal threadLocal = CoordinatorLayout.f447v;
                    Map map = (Map) threadLocal.get();
                    if (map == null) {
                        map = new HashMap();
                        threadLocal.set(map);
                    }
                    Constructor<?> constructor = (Constructor) map.get(string);
                    if (constructor == null) {
                        constructor = Class.forName(string, false, context.getClassLoader()).getConstructor(CoordinatorLayout.f446u);
                        constructor.setAccessible(true);
                        map.put(string, constructor);
                    }
                    cVar = (c) constructor.newInstance(context, attributeSet);
                } catch (Exception e4) {
                    throw new RuntimeException(g0.e.h("Could not inflate Behavior subclass ", string), e4);
                }
            }
            this.f5a = cVar;
        }
        typedArrayObtainStyledAttributes.recycle();
        c cVar2 = this.f5a;
        if (cVar2 != null) {
            cVar2.c(this);
        }
    }

    public f(f fVar) {
        super((ViewGroup.MarginLayoutParams) fVar);
        this.f6b = false;
        this.f7c = 0;
        this.f8d = 0;
        this.f9e = -1;
        this.f = -1;
        this.f10g = 0;
        this.f11h = 0;
        this.f18o = new Rect();
    }

    public f(ViewGroup.MarginLayoutParams marginLayoutParams) {
        super(marginLayoutParams);
        this.f6b = false;
        this.f7c = 0;
        this.f8d = 0;
        this.f9e = -1;
        this.f = -1;
        this.f10g = 0;
        this.f11h = 0;
        this.f18o = new Rect();
    }

    public f(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f6b = false;
        this.f7c = 0;
        this.f8d = 0;
        this.f9e = -1;
        this.f = -1;
        this.f10g = 0;
        this.f11h = 0;
        this.f18o = new Rect();
    }
}
