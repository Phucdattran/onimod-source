package a0;

import android.R;
import android.content.Context;
import android.graphics.Typeface;
import android.util.SparseArray;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.emoji2.text.a0;
import androidx.emoji2.text.x;
import androidx.fragment.app.o0;
import androidx.fragment.app.q0;
import androidx.fragment.app.u0;
import androidx.fragment.app.w;
import androidx.fragment.app.z0;
import androidx.viewpager2.widget.ViewPager2;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import k.b0;
import k.m;
import k.t;
import o0.h0;

/* JADX INFO: loaded from: classes.dex */
public final class k implements k0.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f23a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f24b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f25c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f26d;

    public /* synthetic */ k(View view, View view2, Object obj, Object obj2) {
        this.f23a = view;
        this.f24b = view2;
        this.f25c = obj;
        this.f26d = obj2;
    }

    public void a(w wVar) {
        if (((ArrayList) this.f25c).contains(wVar)) {
            throw new IllegalStateException("Fragment already added: " + wVar);
        }
        synchronized (((ArrayList) this.f25c)) {
            ((ArrayList) this.f25c).add(wVar);
        }
        wVar.f783k = true;
    }

    public void b(Object obj, ArrayList arrayList, HashSet hashSet) {
        if (arrayList.contains(obj)) {
            return;
        }
        if (hashSet.contains(obj)) {
            throw new RuntimeException("This graph contains cyclic dependencies");
        }
        hashSet.add(obj);
        ArrayList arrayList2 = (ArrayList) ((q.i) this.f24b).get(obj);
        if (arrayList2 != null) {
            int size = arrayList2.size();
            for (int i3 = 0; i3 < size; i3++) {
                b(arrayList2.get(i3), arrayList, hashSet);
            }
        }
        hashSet.remove(obj);
        arrayList.add(obj);
    }

    public w c(String str) {
        u0 u0Var = (u0) ((HashMap) this.f23a).get(str);
        if (u0Var != null) {
            return u0Var.f762c;
        }
        return null;
    }

    public w d(String str) {
        for (u0 u0Var : ((HashMap) this.f23a).values()) {
            if (u0Var != null) {
                w wVarD = u0Var.f762c;
                if (!str.equals(wVarD.f778e)) {
                    wVarD = wVarD.f792t.f687c.d(str);
                }
                if (wVarD != null) {
                    return wVarD;
                }
            }
        }
        return null;
    }

    public j.e e(j.a aVar) {
        ArrayList arrayList = (ArrayList) this.f25c;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            j.e eVar = (j.e) arrayList.get(i3);
            if (eVar != null && eVar.f2490b == aVar) {
                return eVar;
            }
        }
        j.e eVar2 = new j.e((Context) this.f26d, aVar);
        arrayList.add(eVar2);
        return eVar2;
    }

    public ArrayList f() {
        ArrayList arrayList = new ArrayList();
        for (u0 u0Var : ((HashMap) this.f23a).values()) {
            if (u0Var != null) {
                arrayList.add(u0Var);
            }
        }
        return arrayList;
    }

    public ArrayList g() {
        ArrayList arrayList = new ArrayList();
        for (u0 u0Var : ((HashMap) this.f23a).values()) {
            if (u0Var != null) {
                arrayList.add(u0Var.f762c);
            } else {
                arrayList.add(null);
            }
        }
        return arrayList;
    }

    public List h() {
        ArrayList arrayList;
        if (((ArrayList) this.f25c).isEmpty()) {
            return Collections.EMPTY_LIST;
        }
        synchronized (((ArrayList) this.f25c)) {
            arrayList = new ArrayList((ArrayList) this.f25c);
        }
        return arrayList;
    }

    public void i(u0 u0Var) {
        w wVar = u0Var.f762c;
        String str = wVar.f778e;
        HashMap map = (HashMap) this.f23a;
        if (map.get(str) != null) {
            return;
        }
        map.put(wVar.f778e, u0Var);
        if (o0.F(2)) {
            wVar.toString();
        }
    }

    public void j(u0 u0Var) {
        w wVar = u0Var.f762c;
        if (wVar.A) {
            ((q0) this.f26d).e(wVar);
        }
        if (((u0) ((HashMap) this.f23a).put(wVar.f778e, null)) != null && o0.F(2)) {
            wVar.toString();
        }
    }

    public boolean k(j.a aVar, MenuItem menuItem) {
        return ((ActionMode.Callback) this.f23a).onActionItemClicked(e(aVar), new t((Context) this.f26d, (i0.a) menuItem));
    }

    public boolean l(j.a aVar, Menu menu) {
        ActionMode.Callback callback = (ActionMode.Callback) this.f23a;
        j.e eVarE = e(aVar);
        q.i iVar = (q.i) this.f24b;
        Menu b0Var = (Menu) iVar.get(menu);
        if (b0Var == null) {
            b0Var = new b0((Context) this.f26d, (m) menu);
            iVar.put(menu, b0Var);
        }
        return callback.onCreateActionMode(eVarE, b0Var);
    }

    public void m() {
        int iA;
        n1.j jVar = (n1.j) this.f24b;
        n1.j jVar2 = (n1.j) this.f23a;
        ViewPager2 viewPager2 = (ViewPager2) this.f26d;
        int i3 = R.id.accessibilityActionPageLeft;
        h0.m(viewPager2, R.id.accessibilityActionPageLeft);
        h0.i(viewPager2, 0);
        h0.m(viewPager2, R.id.accessibilityActionPageRight);
        h0.i(viewPager2, 0);
        h0.m(viewPager2, R.id.accessibilityActionPageUp);
        h0.i(viewPager2, 0);
        h0.m(viewPager2, R.id.accessibilityActionPageDown);
        h0.i(viewPager2, 0);
        if (viewPager2.getAdapter() == null || (iA = viewPager2.getAdapter().a()) == 0 || !viewPager2.f1026r) {
            return;
        }
        if (viewPager2.getOrientation() != 0) {
            if (viewPager2.f1013d < iA - 1) {
                h0.n(viewPager2, new p0.e(R.id.accessibilityActionPageDown), jVar2);
            }
            if (viewPager2.f1013d > 0) {
                h0.n(viewPager2, new p0.e(R.id.accessibilityActionPageUp), jVar);
                return;
            }
            return;
        }
        boolean z4 = viewPager2.f1015g.G() == 1;
        int i4 = z4 ? R.id.accessibilityActionPageLeft : R.id.accessibilityActionPageRight;
        if (z4) {
            i3 = R.id.accessibilityActionPageRight;
        }
        if (viewPager2.f1013d < iA - 1) {
            h0.n(viewPager2, new p0.e(i4), jVar2);
        }
        if (viewPager2.f1013d > 0) {
            h0.n(viewPager2, new p0.e(i3), jVar);
        }
    }

    @Override // k0.b
    public void onCancel() {
        View view = (View) this.f23a;
        view.clearAnimation();
        ((ViewGroup) this.f24b).endViewTransition(view);
        ((androidx.fragment.app.g) this.f25c).e();
        if (o0.F(2)) {
            Objects.toString((z0) this.f26d);
        }
    }

    public k(int i3) {
        switch (i3) {
            case 3:
                this.f25c = new ArrayList();
                this.f23a = new HashMap();
                this.f24b = new HashMap();
                break;
            case 4:
                this.f23a = new q.e(0);
                this.f24b = new SparseArray();
                this.f25c = new q.g();
                this.f26d = new q.e(0);
                break;
            default:
                this.f23a = new n0.c(10);
                this.f24b = new q.i(0);
                this.f25c = new ArrayList();
                this.f26d = new HashSet();
                break;
        }
    }

    public k(Typeface typeface, v0.b bVar) {
        int i3;
        int i4;
        int i5;
        int i6;
        this.f26d = typeface;
        this.f23a = bVar;
        this.f25c = new x(1024);
        int iA = bVar.a(6);
        if (iA != 0) {
            int i7 = iA + bVar.f3612a;
            i3 = ((ByteBuffer) bVar.f3615d).getInt(((ByteBuffer) bVar.f3615d).getInt(i7) + i7);
        } else {
            i3 = 0;
        }
        this.f24b = new char[i3 * 2];
        int iA2 = bVar.a(6);
        if (iA2 != 0) {
            int i8 = iA2 + bVar.f3612a;
            i4 = ((ByteBuffer) bVar.f3615d).getInt(((ByteBuffer) bVar.f3615d).getInt(i8) + i8);
        } else {
            i4 = 0;
        }
        for (int i9 = 0; i9 < i4; i9++) {
            a0 a0Var = new a0(this, i9);
            v0.a aVarB = a0Var.b();
            int iA3 = aVarB.a(4);
            Character.toChars(iA3 != 0 ? ((ByteBuffer) aVarB.f3615d).getInt(iA3 + aVarB.f3612a) : 0, (char[]) this.f24b, i9 * 2);
            v0.a aVarB2 = a0Var.b();
            int iA4 = aVarB2.a(16);
            if (iA4 != 0) {
                int i10 = iA4 + aVarB2.f3612a;
                i5 = ((ByteBuffer) aVarB2.f3615d).getInt(((ByteBuffer) aVarB2.f3615d).getInt(i10) + i10);
            } else {
                i5 = 0;
            }
            i1.m.f("invalid metadata codepoint length", i5 > 0);
            x xVar = (x) this.f25c;
            v0.a aVarB3 = a0Var.b();
            int iA5 = aVarB3.a(16);
            if (iA5 != 0) {
                int i11 = iA5 + aVarB3.f3612a;
                i6 = ((ByteBuffer) aVarB3.f3615d).getInt(((ByteBuffer) aVarB3.f3615d).getInt(i11) + i11);
            } else {
                i6 = 0;
            }
            xVar.a(a0Var, 0, i6 - 1);
        }
    }

    public k(Context context, ActionMode.Callback callback) {
        this.f26d = context;
        this.f23a = callback;
        this.f25c = new ArrayList();
        this.f24b = new q.i(0);
    }

    public k(ViewPager2 viewPager2) {
        this.f26d = viewPager2;
        this.f23a = new n1.j(this, 0);
        this.f24b = new n1.j(this, 1);
    }
}
