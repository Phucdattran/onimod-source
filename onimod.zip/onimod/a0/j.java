package a0;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import e1.v;
import java.io.File;
import java.util.Comparator;
import java.util.WeakHashMap;
import o0.h0;
import o0.z;
import top.niunaijun.blackbox.entity.location.BCell;

/* JADX INFO: loaded from: classes.dex */
public final class j implements Comparator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f22a;

    public /* synthetic */ j(int i3) {
        this.f22a = i3;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.f22a) {
            case 0:
                WeakHashMap weakHashMap = h0.f3558a;
                float fH = z.h((View) obj);
                float fH2 = z.h((View) obj2);
                if (fH > fH2) {
                    return -1;
                }
                return fH < fH2 ? 1 : 0;
            case 1:
                return a3.a.l(Integer.valueOf(((top.niunaijun.blackboxa.util.g) obj).f4115e), Integer.valueOf(((top.niunaijun.blackboxa.util.g) obj2).f4115e));
            case 2:
                return ((e1.l) obj).f1958a - ((e1.l) obj2).f1958a;
            case 3:
                v vVar = (v) obj;
                v vVar2 = (v) obj2;
                RecyclerView recyclerView = vVar.f2087d;
                if ((recyclerView == null) == (vVar2.f2087d == null)) {
                    boolean z4 = vVar.f2084a;
                    if (z4 == vVar2.f2084a) {
                        int i3 = vVar2.f2085b - vVar.f2085b;
                        if (i3 != 0) {
                            return i3;
                        }
                        int i4 = vVar.f2086c - vVar2.f2086c;
                        if (i4 != 0) {
                            return i4;
                        }
                        return 0;
                    }
                    if (!z4) {
                        return 1;
                    }
                } else if (recyclerView == null) {
                    return 1;
                }
                return -1;
            case 4:
                return ((View) obj).getTop() - ((View) obj2).getTop();
            case 5:
                return ((int[]) obj)[0] - ((int[]) obj2)[0];
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                return ((t.e) obj).f3972b - ((t.e) obj2).f3972b;
            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                return a3.a.l(Long.valueOf(((File) obj2).lastModified()), Long.valueOf(((File) obj).lastModified()));
            default:
                return a3.a.l(Boolean.valueOf(((top.niunaijun.blackboxa.view.list.a) obj2).f4238d), Boolean.valueOf(((top.niunaijun.blackboxa.view.list.a) obj).f4238d));
        }
    }
}
