package a0;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.ContentInfo;
import android.view.GestureDetector;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.widget.ActionMenuView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.emoji2.text.q;
import androidx.emoji2.text.u;
import androidx.fragment.app.y;
import androidx.fragment.app.z0;
import androidx.profileinstaller.ProfileInstallReceiver;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import k.e0;
import k.o;
import k.x;
import l.g2;
import l.l2;
import l.n;
import l.x0;
import l.z2;
import o0.d1;
import o0.f1;
import o0.h0;
import o0.m;

/* JADX INFO: loaded from: classes.dex */
public class b implements m, androidx.emoji2.text.l, k0.b, b2.a, c1.e, g2, x, k.k, x0, o0.c, o0.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f2a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f3b;

    public /* synthetic */ b(int i3, Object obj) {
        this.f2a = i3;
        this.f3b = obj;
    }

    @Override // o0.e
    public ClipData a() {
        return ((ContentInfo) this.f3b).getClip();
    }

    @Override // k.x
    public void b(k.m mVar, boolean z4) {
        if (mVar instanceof e0) {
            ((e0) mVar).f2661z.k().c(false);
        }
        x xVar = ((l.k) this.f3b).f3132e;
        if (xVar != null) {
            xVar.b(mVar, z4);
        }
    }

    @Override // o0.c
    public o0.f build() {
        return new o0.f(new b(((ContentInfo.Builder) this.f3b).build()));
    }

    @Override // androidx.emoji2.text.l
    public void c(a3.a aVar) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new androidx.emoji2.text.a("EmojiCompatInitializer"));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        threadPoolExecutor.execute(new a4.g(1, this, aVar, threadPoolExecutor));
    }

    @Override // o0.m
    public f1 d(View view, f1 f1Var) {
        d1 d1Var = f1Var.f3545a;
        CoordinatorLayout coordinatorLayout = (CoordinatorLayout) this.f3b;
        if (!Objects.equals(coordinatorLayout.f462n, f1Var)) {
            coordinatorLayout.f462n = f1Var;
            boolean z4 = f1Var.d() > 0;
            coordinatorLayout.f463o = z4;
            coordinatorLayout.setWillNotDraw(!z4 && coordinatorLayout.getBackground() == null);
            if (!d1Var.m()) {
                int childCount = coordinatorLayout.getChildCount();
                for (int i3 = 0; i3 < childCount; i3++) {
                    View childAt = coordinatorLayout.getChildAt(i3);
                    WeakHashMap weakHashMap = h0.f3558a;
                    if (childAt.getFitsSystemWindows() && ((f) childAt.getLayoutParams()).f5a != null && d1Var.m()) {
                        break;
                    }
                }
            }
            coordinatorLayout.requestLayout();
        }
        return f1Var;
    }

    @Override // k.x
    public boolean e(k.m mVar) {
        l.k kVar = (l.k) this.f3b;
        if (mVar == kVar.f3130c) {
            return false;
        }
        ((e0) mVar).A.getClass();
        kVar.getClass();
        x xVar = kVar.f3132e;
        if (xVar != null) {
            return xVar.e(mVar);
        }
        return false;
    }

    @Override // k.k
    public boolean f(k.m mVar, MenuItem menuItem) {
        switch (this.f2a) {
            case 16:
                n nVar = ((ActionMenuView) this.f3b).f292z;
                if (nVar != null) {
                    Iterator it = ((CopyOnWriteArrayList) ((z2) nVar).f3320a.G.f563c).iterator();
                    while (it.hasNext()) {
                        if (((androidx.fragment.app.h0) it.next()).f658a.o()) {
                            return true;
                        }
                    }
                }
                return false;
            default:
                l2 l2Var = (l2) ((u) this.f3b).f564d;
                if (l2Var != null) {
                    return l2Var.onMenuItemClick(menuItem);
                }
                return false;
        }
    }

    @Override // c1.e
    public void g(int i3, Object obj) {
        if (i3 == 6 || i3 == 7 || i3 == 8) {
        }
        ((ProfileInstallReceiver) this.f3b).setResultCode(i3);
    }

    @Override // o0.c
    public void h(Uri uri) {
        ((ContentInfo.Builder) this.f3b).setLinkUri(uri);
    }

    @Override // k.k
    public void i(k.m mVar) {
        switch (this.f2a) {
            case 16:
                z2 z2Var = ((ActionMenuView) this.f3b).f287u;
                if (z2Var != null) {
                    z2Var.i(mVar);
                }
                break;
        }
    }

    @Override // o0.c
    public void j(int i3) {
        ((ContentInfo.Builder) this.f3b).setFlags(i3);
    }

    @Override // l.g2
    public void k(k.m mVar, o oVar) {
        k.g gVar = (k.g) this.f3b;
        Handler handler = gVar.f;
        handler.removeCallbacksAndMessages(null);
        ArrayList arrayList = gVar.f2670h;
        int size = arrayList.size();
        int i3 = 0;
        while (true) {
            if (i3 >= size) {
                i3 = -1;
                break;
            } else if (mVar == ((k.f) arrayList.get(i3)).f2663b) {
                break;
            } else {
                i3++;
            }
        }
        if (i3 == -1) {
            return;
        }
        int i4 = i3 + 1;
        handler.postAtTime(new k.e(this, i4 < arrayList.size() ? (k.f) arrayList.get(i4) : null, oVar, mVar), mVar, SystemClock.uptimeMillis() + 200);
    }

    @Override // l.g2
    public void l(k.m mVar, MenuItem menuItem) {
        ((k.g) this.f3b).f.removeCallbacksAndMessages(mVar);
    }

    @Override // o0.e
    public int n() {
        return ((ContentInfo) this.f3b).getFlags();
    }

    @Override // o0.e
    public ContentInfo o() {
        return (ContentInfo) this.f3b;
    }

    @Override // k0.b
    public void onCancel() {
        ((z0) this.f3b).a();
    }

    @Override // o0.e
    public int q() {
        return ((ContentInfo) this.f3b).getSource();
    }

    public p0.f s(int i3) {
        return null;
    }

    @Override // o0.c
    public void setExtras(Bundle bundle) {
        ((ContentInfo.Builder) this.f3b).setExtras(bundle);
    }

    public p0.f t(int i3) {
        return null;
    }

    public String toString() {
        switch (this.f2a) {
            case 21:
                return "ContentInfoCompat{" + ((ContentInfo) this.f3b) + "}";
            default:
                return super.toString();
        }
    }

    public void u() {
        ((y) this.f3b).f809r.M();
    }

    public boolean w(int i3, int i4, Bundle bundle) {
        return false;
    }

    public b(int i3) {
        this.f2a = i3;
        switch (i3) {
            case 23:
                if (Build.VERSION.SDK_INT < 26) {
                    this.f3b = new p0.g(this);
                } else {
                    this.f3b = new p0.h(this);
                }
                break;
            case 25:
                this.f3b = new LinkedHashMap(0, 0.75f, true);
                break;
        }
    }

    public b(Context context, GestureDetector.OnGestureListener onGestureListener) {
        this.f2a = 22;
        this.f3b = new GestureDetector(context, onGestureListener, null);
    }

    public b(EditText editText) {
        this.f2a = 29;
        this.f3b = new q(editText);
    }

    public b(Context context) {
        this.f2a = 1;
        this.f3b = context.getApplicationContext();
    }

    public b(Uri uri, ClipDescription clipDescription, Uri uri2) {
        this.f2a = 24;
        if (Build.VERSION.SDK_INT >= 25) {
            this.f3b = new q0.f(uri, clipDescription, uri2);
        } else {
            this.f3b = new u(9, uri, clipDescription, uri2);
        }
    }

    public b(ContentInfo contentInfo) {
        this.f2a = 21;
        contentInfo.getClass();
        this.f3b = a2.b.g(contentInfo);
    }

    public b(ClipData clipData, int i3) {
        this.f2a = 20;
        this.f3b = a2.b.e(clipData, i3);
    }

    private final void v(k.m mVar) {
    }

    @Override // l.x0
    public void m(int i3) {
    }

    @Override // l.x0
    public void p(int i3) {
    }

    @Override // l.x0
    public void r(int i3, float f) {
    }
}
