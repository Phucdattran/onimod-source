package b3;

import j3.p;

/* JADX INFO: loaded from: classes.dex */
public abstract class a implements e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f f1069a;

    public a(f fVar) {
        this.f1069a = fVar;
    }

    @Override // b3.g
    public e b(f key) {
        kotlin.jvm.internal.d.f(key, "key");
        if (kotlin.jvm.internal.d.a(getKey(), key)) {
            return this;
        }
        return null;
    }

    @Override // b3.g
    public final Object c(Object obj, p pVar) {
        return a3.a.D(this, obj, pVar);
    }

    @Override // b3.g
    public g g(f fVar) {
        return a3.a.R(this, fVar);
    }

    @Override // b3.e
    public final f getKey() {
        return this.f1069a;
    }

    @Override // b3.g
    public final g h(g gVar) {
        return a3.a.Y(this, gVar);
    }
}
