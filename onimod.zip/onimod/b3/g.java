package b3;

import j3.p;

/* JADX INFO: loaded from: classes.dex */
public interface g {
    e b(f fVar);

    Object c(Object obj, p pVar);

    g g(f fVar);

    g h(g gVar);
}
