package b3;

/* JADX INFO: loaded from: classes.dex */
public interface e extends g {
    f getKey();
}
