package b3;

/* JADX INFO: loaded from: classes.dex */
public interface b {
    void f(Object obj);

    g i();
}
