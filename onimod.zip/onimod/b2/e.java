package b2;

import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.datepicker.MaterialCalendar;
import com.google.android.material.internal.CheckableImageButton;
import com.google.android.material.internal.NavigationMenuItemView;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public final class e extends o0.b {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1062d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f1063e;

    public /* synthetic */ e(int i3, Object obj) {
        this.f1062d = i3;
        this.f1063e = obj;
    }

    @Override // o0.b
    public void c(View view, AccessibilityEvent accessibilityEvent) {
        switch (this.f1062d) {
            case 2:
                super.c(view, accessibilityEvent);
                accessibilityEvent.setChecked(((CheckableImageButton) this.f1063e).f1411d);
                break;
            default:
                super.c(view, accessibilityEvent);
                break;
        }
    }

    @Override // o0.b
    public final void d(View view, p0.f fVar) {
        int i3;
        int i4 = this.f1062d;
        Object obj = this.f1063e;
        View.AccessibilityDelegate accessibilityDelegate = this.f3530a;
        switch (i4) {
            case 0:
                AccessibilityNodeInfo accessibilityNodeInfo = fVar.f3692a;
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
                MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) obj;
                int i5 = MaterialButtonToggleGroup.f1294k;
                if (view instanceof MaterialButton) {
                    int i6 = 0;
                    for (int i7 = 0; i7 < materialButtonToggleGroup.getChildCount(); i7++) {
                        if (materialButtonToggleGroup.getChildAt(i7) == view) {
                            i3 = i6;
                        } else {
                            if ((materialButtonToggleGroup.getChildAt(i7) instanceof MaterialButton) && materialButtonToggleGroup.c(i7)) {
                                i6++;
                            }
                        }
                    }
                    i3 = -1;
                } else {
                    i3 = -1;
                }
                accessibilityNodeInfo.setCollectionItemInfo(AccessibilityNodeInfo.CollectionItemInfo.obtain(0, 1, i3, 1, false, ((MaterialButton) view).f1291o));
                break;
            case 1:
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, fVar.f3692a);
                MaterialCalendar materialCalendar = (MaterialCalendar) obj;
                fVar.i(materialCalendar.f1340g0.getVisibility() == 0 ? materialCalendar.m(R.string.mtrl_picker_toggle_to_year_selection) : materialCalendar.m(R.string.mtrl_picker_toggle_to_day_selection));
                break;
            case 2:
                AccessibilityNodeInfo accessibilityNodeInfo2 = fVar.f3692a;
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo2);
                CheckableImageButton checkableImageButton = (CheckableImageButton) obj;
                accessibilityNodeInfo2.setCheckable(checkableImageButton.f1412e);
                accessibilityNodeInfo2.setChecked(checkableImageButton.f1411d);
                break;
            default:
                AccessibilityNodeInfo accessibilityNodeInfo3 = fVar.f3692a;
                accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo3);
                accessibilityNodeInfo3.setCheckable(((NavigationMenuItemView) obj).f1415x);
                break;
        }
    }
}
