package b2;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final s2.a f1064e = new s2.a(0.0f);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final s2.c f1065a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final s2.c f1066b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final s2.c f1067c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final s2.c f1068d;

    public f(s2.c cVar, s2.c cVar2, s2.c cVar3, s2.c cVar4) {
        this.f1065a = cVar;
        this.f1066b = cVar3;
        this.f1067c = cVar4;
        this.f1068d = cVar2;
    }
}
