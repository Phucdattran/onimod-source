package b2;

import android.content.pm.ApplicationInfo;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import java.text.Collator;
import java.util.Comparator;
import java.util.List;
import kotlin.Pair;

/* JADX INFO: loaded from: classes.dex */
public final class d implements Comparator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1060a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f1061b;

    public /* synthetic */ d(int i3, Object obj) {
        this.f1060a = i3;
        this.f1061b = obj;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.f1060a) {
            case 0:
                MaterialButton materialButton = (MaterialButton) obj;
                MaterialButton materialButton2 = (MaterialButton) obj2;
                MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) this.f1061b;
                int iCompareTo = Boolean.valueOf(materialButton.f1291o).compareTo(Boolean.valueOf(materialButton2.f1291o));
                if (iCompareTo != 0) {
                    return iCompareTo;
                }
                int iCompareTo2 = Boolean.valueOf(materialButton.isPressed()).compareTo(Boolean.valueOf(materialButton2.isPressed()));
                return iCompareTo2 != 0 ? iCompareTo2 : Integer.valueOf(materialButtonToggleGroup.indexOfChild(materialButton)).compareTo(Integer.valueOf(materialButtonToggleGroup.indexOfChild(materialButton2)));
            case 1:
                return ((Collator) this.f1061b).compare((String) ((Pair) obj).d(), (String) ((Pair) obj2).d());
            default:
                ApplicationInfo applicationInfo = (ApplicationInfo) obj;
                ApplicationInfo applicationInfo2 = (ApplicationInfo) obj2;
                List list = (List) this.f1061b;
                if (applicationInfo == null || applicationInfo2 == null) {
                    return 0;
                }
                return list.indexOf(applicationInfo.packageName) - list.indexOf(applicationInfo2.packageName);
        }
    }

    public d(List sortedList) {
        this.f1060a = 2;
        kotlin.jvm.internal.d.f(sortedList, "sortedList");
        this.f1061b = sortedList;
    }
}
