package b2;

import a0.h;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class b extends s0.b {
    public static final Parcelable.Creator<b> CREATOR = new h(3);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1038c;

    public b(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        if (classLoader == null) {
            b.class.getClassLoader();
        }
        this.f1038c = parcel.readInt() == 1;
    }

    @Override // s0.b, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i3) {
        super.writeToParcel(parcel, i3);
        parcel.writeInt(this.f1038c ? 1 : 0);
    }
}
