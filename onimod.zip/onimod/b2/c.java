package b2;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import com.google.android.material.button.MaterialButton;
import java.util.WeakHashMap;
import o0.h0;
import s2.g;
import s2.k;
import s2.v;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final boolean f1039u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final boolean f1040v;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final MaterialButton f1041a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public k f1042b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1043c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1044d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1045e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1046g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f1047h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public PorterDuff.Mode f1048i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public ColorStateList f1049j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public ColorStateList f1050k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public ColorStateList f1051l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Drawable f1052m;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f1056q;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public LayerDrawable f1058s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f1059t;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f1053n = false;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f1054o = false;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f1055p = false;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f1057r = true;

    static {
        int i3 = Build.VERSION.SDK_INT;
        f1039u = true;
        f1040v = i3 <= 22;
    }

    public c(MaterialButton materialButton, k kVar) {
        this.f1041a = materialButton;
        this.f1042b = kVar;
    }

    public final v a() {
        LayerDrawable layerDrawable = this.f1058s;
        if (layerDrawable == null || layerDrawable.getNumberOfLayers() <= 1) {
            return null;
        }
        return this.f1058s.getNumberOfLayers() > 2 ? (v) this.f1058s.getDrawable(2) : (v) this.f1058s.getDrawable(1);
    }

    public final g b(boolean z4) {
        LayerDrawable layerDrawable = this.f1058s;
        if (layerDrawable == null || layerDrawable.getNumberOfLayers() <= 0) {
            return null;
        }
        return f1039u ? (g) ((LayerDrawable) ((InsetDrawable) this.f1058s.getDrawable(0)).getDrawable()).getDrawable(!z4 ? 1 : 0) : (g) this.f1058s.getDrawable(!z4 ? 1 : 0);
    }

    public final void c(k kVar) {
        this.f1042b = kVar;
        if (!f1040v || this.f1054o) {
            if (b(false) != null) {
                b(false).setShapeAppearanceModel(kVar);
            }
            if (b(true) != null) {
                b(true).setShapeAppearanceModel(kVar);
            }
            if (a() != null) {
                a().setShapeAppearanceModel(kVar);
                return;
            }
            return;
        }
        WeakHashMap weakHashMap = h0.f3558a;
        MaterialButton materialButton = this.f1041a;
        int paddingStart = materialButton.getPaddingStart();
        int paddingTop = materialButton.getPaddingTop();
        int paddingEnd = materialButton.getPaddingEnd();
        int paddingBottom = materialButton.getPaddingBottom();
        e();
        materialButton.setPaddingRelative(paddingStart, paddingTop, paddingEnd, paddingBottom);
    }

    public final void d(int i3, int i4) {
        WeakHashMap weakHashMap = h0.f3558a;
        MaterialButton materialButton = this.f1041a;
        int paddingStart = materialButton.getPaddingStart();
        int paddingTop = materialButton.getPaddingTop();
        int paddingEnd = materialButton.getPaddingEnd();
        int paddingBottom = materialButton.getPaddingBottom();
        int i5 = this.f1045e;
        int i6 = this.f;
        this.f = i4;
        this.f1045e = i3;
        if (!this.f1054o) {
            e();
        }
        materialButton.setPaddingRelative(paddingStart, (paddingTop + i3) - i5, paddingEnd, (paddingBottom + i4) - i6);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void e() {
        Drawable insetDrawable;
        g gVar = new g(this.f1042b);
        MaterialButton materialButton = this.f1041a;
        gVar.i(materialButton.getContext());
        gVar.setTintList(this.f1049j);
        PorterDuff.Mode mode = this.f1048i;
        if (mode != null) {
            gVar.setTintMode(mode);
        }
        float f = this.f1047h;
        ColorStateList colorStateList = this.f1050k;
        gVar.f3859a.f3851j = f;
        gVar.invalidateSelf();
        s2.f fVar = gVar.f3859a;
        if (fVar.f3846d != colorStateList) {
            fVar.f3846d = colorStateList;
            gVar.onStateChange(gVar.getState());
        }
        g gVar2 = new g(this.f1042b);
        gVar2.setTint(0);
        float f4 = this.f1047h;
        int iF = this.f1053n ? a3.a.F(materialButton, R.attr.colorSurface) : 0;
        gVar2.f3859a.f3851j = f4;
        gVar2.invalidateSelf();
        ColorStateList colorStateListValueOf = ColorStateList.valueOf(iF);
        s2.f fVar2 = gVar2.f3859a;
        if (fVar2.f3846d != colorStateListValueOf) {
            fVar2.f3846d = colorStateListValueOf;
            gVar2.onStateChange(gVar2.getState());
        }
        if (f1039u) {
            g gVar3 = new g(this.f1042b);
            this.f1052m = gVar3;
            gVar3.setTint(-1);
            RippleDrawable rippleDrawable = new RippleDrawable(q2.d.a(this.f1051l), new InsetDrawable((Drawable) new LayerDrawable(new Drawable[]{gVar2, gVar}), this.f1043c, this.f1045e, this.f1044d, this.f), this.f1052m);
            this.f1058s = rippleDrawable;
            insetDrawable = rippleDrawable;
        } else {
            g gVar4 = new g(this.f1042b);
            q2.a aVar = new q2.a();
            aVar.f3757a = gVar4;
            aVar.f3758b = false;
            q2.b bVar = new q2.b(aVar);
            this.f1052m = bVar;
            bVar.setTintList(q2.d.a(this.f1051l));
            LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{gVar2, gVar, this.f1052m});
            this.f1058s = layerDrawable;
            insetDrawable = new InsetDrawable((Drawable) layerDrawable, this.f1043c, this.f1045e, this.f1044d, this.f);
        }
        materialButton.setInternalBackground(insetDrawable);
        g gVarB = b(false);
        if (gVarB != null) {
            gVarB.j(this.f1059t);
            gVarB.setState(materialButton.getDrawableState());
        }
    }

    public final void f() {
        g gVarB = b(false);
        g gVarB2 = b(true);
        if (gVarB != null) {
            float f = this.f1047h;
            ColorStateList colorStateList = this.f1050k;
            gVarB.f3859a.f3851j = f;
            gVarB.invalidateSelf();
            s2.f fVar = gVarB.f3859a;
            if (fVar.f3846d != colorStateList) {
                fVar.f3846d = colorStateList;
                gVarB.onStateChange(gVarB.getState());
            }
            if (gVarB2 != null) {
                float f4 = this.f1047h;
                int iF = this.f1053n ? a3.a.F(this.f1041a, R.attr.colorSurface) : 0;
                gVarB2.f3859a.f3851j = f4;
                gVarB2.invalidateSelf();
                ColorStateList colorStateListValueOf = ColorStateList.valueOf(iF);
                s2.f fVar2 = gVarB2.f3859a;
                if (fVar2.f3846d != colorStateListValueOf) {
                    fVar2.f3846d = colorStateListValueOf;
                    gVarB2.onStateChange(gVarB2.getState());
                }
            }
        }
    }
}
