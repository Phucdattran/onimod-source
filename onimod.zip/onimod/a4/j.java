package a4;

import android.content.Intent;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.sidesheet.SideSheetBehavior;
import l.r;
import top.niunaijun.blackbox.R;
import top.niunaijun.blackbox.app.LauncherActivity;
import top.niunaijun.blackboxa.view.base.BaseActivity;
import top.niunaijun.blackboxa.view.login.GoogleLoginActivity;
import top.niunaijun.blackboxa.view.login.OniBrowserActivity;
import top.niunaijun.blackboxa.view.update.UpdateActivity;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class j implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f92a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f93b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f94c;

    public /* synthetic */ j(int i3, BaseActivity baseActivity, int i4) {
        this.f92a = i4;
        this.f93b = i3;
        this.f94c = baseActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f92a) {
            case 0:
                int i3 = this.f93b;
                GoogleLoginActivity googleLoginActivity = (GoogleLoginActivity) this.f94c;
                if (i3 != googleLoginActivity.B || googleLoginActivity.C) {
                    return;
                }
                googleLoginActivity.o();
                return;
            case 1:
                int i4 = this.f93b;
                OniBrowserActivity this$0 = (OniBrowserActivity) this.f94c;
                kotlin.jvm.internal.d.f(this$0, "this$0");
                if (i4 == this$0.D) {
                    this$0.p();
                    return;
                }
                return;
            case 2:
                ((f0.b) this.f94c).h(this.f93b);
                return;
            case 3:
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) this.f94c;
                int i5 = this.f93b;
                View view = (View) sideSheetBehavior.f1478p.get();
                if (view != null) {
                    sideSheetBehavior.t(view, i5, false);
                    return;
                }
                return;
            case 4:
                LauncherActivity.lambda$launchAppAsync$0((Intent) this.f94c, this.f93b);
                return;
            case 5:
                top.niunaijun.blackboxa.view.setting.g this$1 = (top.niunaijun.blackboxa.view.setting.g) this.f94c;
                int i6 = this.f93b;
                kotlin.jvm.internal.d.f(this$1, "this$0");
                if (this$1.r()) {
                    String strN = i6 > 0 ? this$1.n(new Object[]{Integer.valueOf(i6)}, R.string.set_newdevice_done) : this$1.m(R.string.set_newdevice_fail);
                    kotlin.jvm.internal.d.c(strN);
                    top.niunaijun.blackboxa.util.b.W(strN);
                    return;
                }
                return;
            default:
                int i7 = this.f93b;
                UpdateActivity this$2 = (UpdateActivity) this.f94c;
                kotlin.jvm.internal.d.f(this$2, "this$0");
                if (i7 >= 0 && i7 < 101) {
                    r rVar = this$2.f4354y;
                    if (rVar == null) {
                        kotlin.jvm.internal.d.k("binding");
                        throw null;
                    }
                    ((ProgressBar) rVar.f3220a).setProgress(i7);
                    r rVar2 = this$2.f4354y;
                    if (rVar2 != null) {
                        ((TextView) rVar2.f3224e).setText(i7 >= 100 ? this$2.getString(R.string.update_opening_settings) : this$2.getString(R.string.update_downloading, Integer.valueOf(i7)));
                        return;
                    } else {
                        kotlin.jvm.internal.d.k("binding");
                        throw null;
                    }
                }
                r rVar3 = this$2.f4354y;
                if (rVar3 == null) {
                    kotlin.jvm.internal.d.k("binding");
                    throw null;
                }
                ((MaterialButton) rVar3.f3221b).setEnabled(true);
                r rVar4 = this$2.f4354y;
                if (rVar4 == null) {
                    kotlin.jvm.internal.d.k("binding");
                    throw null;
                }
                ((MaterialButton) rVar4.f3221b).setText(this$2.getString(R.string.update_retry));
                r rVar5 = this$2.f4354y;
                if (rVar5 != null) {
                    ((TextView) rVar5.f3224e).setText(this$2.getString(R.string.update_error));
                    return;
                } else {
                    kotlin.jvm.internal.d.k("binding");
                    throw null;
                }
        }
    }

    public /* synthetic */ j(Object obj, int i3, int i4) {
        this.f92a = i4;
        this.f94c = obj;
        this.f93b = i3;
    }
}
