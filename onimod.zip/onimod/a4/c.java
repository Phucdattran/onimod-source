package a4;

import android.view.View;
import com.github.nukc.stateview.StateView;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class c implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f73a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f74b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f75c;

    public /* synthetic */ c(Object obj, int i3, Object obj2) {
        this.f73a = i3;
        this.f74b = obj;
        this.f75c = obj2;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        int i3 = this.f73a;
        Object obj = this.f75c;
        Object obj2 = this.f74b;
        switch (i3) {
            case 0:
                e this$0 = (e) obj2;
                top.niunaijun.blackboxa.util.g p4 = (top.niunaijun.blackboxa.util.g) obj;
                kotlin.jvm.internal.d.f(this$0, "this$0");
                kotlin.jvm.internal.d.f(p4, "$p");
                this$0.f80b0 = p4;
                this$0.R();
                break;
            case 1:
                top.niunaijun.blackboxa.view.list.c this$1 = (top.niunaijun.blackboxa.view.list.c) obj2;
                top.niunaijun.blackboxa.view.list.a item = (top.niunaijun.blackboxa.view.list.a) obj;
                kotlin.jvm.internal.d.f(this$1, "this$0");
                kotlin.jvm.internal.d.f(item, "$item");
                this$1.f4246d.h(item);
                break;
            case 2:
                boolean[] zArr = (boolean[]) obj2;
                e.k kVar = (e.k) obj;
                int length = zArr.length;
                for (int i4 = 0; i4 < length; i4++) {
                    zArr[i4] = true;
                    kVar.f.f.setItemChecked(i4, true);
                }
                break;
            default:
                View view2 = (View) obj;
                int i5 = StateView.f;
                kotlin.jvm.internal.d.f((StateView) obj2, "this$0");
                kotlin.jvm.internal.d.f(view2, "$view");
                break;
        }
    }
}
