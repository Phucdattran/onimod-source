package a4;

import android.view.View;
import top.niunaijun.blackboxa.view.login.OniConsentActivity;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class o implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f102a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ OniConsentActivity f103b;

    public /* synthetic */ o(OniConsentActivity oniConsentActivity, int i3) {
        this.f102a = i3;
        this.f103b = oniConsentActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i3 = this.f102a;
        OniConsentActivity this$0 = this.f103b;
        switch (i3) {
            case 0:
                int i4 = OniConsentActivity.E;
                if (this$0.isFinishing() || this$0.D) {
                    return;
                }
                View view = this$0.A;
                if (view != null) {
                    view.setVisibility(0);
                    return;
                } else {
                    kotlin.jvm.internal.d.k("root");
                    throw null;
                }
            case 1:
                kotlin.jvm.internal.d.f(this$0, "this$0");
                this$0.finish();
                return;
            case 2:
                OniConsentActivity.m(this$0);
                return;
            default:
                kotlin.jvm.internal.d.f(this$0, "this$0");
                this$0.finish();
                return;
        }
    }
}
