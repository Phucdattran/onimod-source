package a4;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.os.IInterface;
import android.text.Html;
import android.webkit.CookieManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.mod.menu.ModConfig;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Result;
import kotlin.collections.r;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.R;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.core.GmsCore;
import top.niunaijun.blackbox.core.system.JarConfig;
import top.niunaijun.blackbox.core.system.location.BLocationManagerService;
import top.niunaijun.blackbox.entity.am.ReceiverData;
import top.niunaijun.blackbox.entity.location.BCell;
import top.niunaijun.blackbox.entity.location.BLocation;
import top.niunaijun.blackboxa.app.App;
import top.niunaijun.blackboxa.util.z;
import top.niunaijun.blackboxa.view.apps.AppsFragment;
import top.niunaijun.blackboxa.view.login.GoogleLoginActivity;
import top.niunaijun.blackboxa.view.main.MainActivity;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f76a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f77b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f78c;

    public /* synthetic */ d(Object obj, int i3, Object obj2) {
        this.f76a = i3;
        this.f77b = obj;
        this.f78c = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        s2.j jVar;
        Object failure;
        String string;
        int i3 = this.f76a;
        int i4 = 2;
        int i5 = 0;
        Object obj = this.f78c;
        Object obj2 = this.f77b;
        switch (i3) {
            case 0:
                e eVar = (e) obj2;
                top.niunaijun.blackboxa.util.f fVar = (top.niunaijun.blackboxa.util.f) obj;
                if (!eVar.r() || (jVar = eVar.V) == null) {
                    return;
                }
                if (fVar == null) {
                    eVar.T((LinearLayout) jVar.f3882b);
                    return;
                }
                eVar.X = fVar.f4110b;
                eVar.Y = fVar.f4109a;
                eVar.T((ScrollView) jVar.f3886g);
                eVar.R();
                s2.j jVar2 = eVar.V;
                kotlin.jvm.internal.d.c(jVar2);
                ((TextView) jVar2.f3883c).setEnabled(eVar.Y);
                s2.j jVar3 = eVar.V;
                kotlin.jvm.internal.d.c(jVar3);
                ((TextView) jVar3.f3883c).setAlpha(eVar.Y ? 1.0f : 0.4f);
                return;
            case 1:
                GoogleLoginActivity googleLoginActivity = (GoogleLoginActivity) obj2;
                int i6 = GoogleLoginActivity.D;
                Object objH = top.niunaijun.blackboxa.util.b.H(r.S(new Pair("androidId", "0"), new Pair("lang", "en"), new Pair("google_play_services_version", String.valueOf(250932030)), new Pair("sdk_version", String.valueOf(Build.VERSION.SDK_INT)), new Pair("device_country", "us"), new Pair("operatorCountry", "us"), new Pair("service", "ac2dm"), new Pair("get_accountid", "1"), new Pair("ACCESS_TOKEN", "1"), new Pair("callerPkg", GmsCore.GMS_PKG), new Pair("callerSig", "38918a453d07199354f8b19af05ec6562ced5788"), new Pair("add_account", "1"), new Pair("droidguard_results", "null"), new Pair("Token", (String) obj), new Pair("source", "android"), new Pair("accountType", "HOSTED_OR_GOOGLE"), new Pair("has_permission", "1")));
                if (!(objH instanceof Result.Failure)) {
                    try {
                        String str = (String) objH;
                        HashMap mapF = top.niunaijun.blackboxa.util.b.F(str);
                        String str2 = (String) mapF.get("Token");
                        if (str2 == null) {
                            String strK0 = (String) mapF.get("Error");
                            if (strK0 == null) {
                                strK0 = kotlin.text.e.k0(200, str);
                            }
                            throw new IllegalStateException("no master token in response: ".concat(strK0).toString());
                        }
                        String str3 = (String) mapF.get("Email");
                        if (str3 == null) {
                            str3 = ModConfig.PREFIX;
                        }
                        String str4 = str3;
                        String str5 = (String) mapF.get("GoogleUserId");
                        if ((str5 == null || str5.length() == 0) && str2.length() > 0 && str4.length() > 0) {
                            try {
                                failure = top.niunaijun.blackboxa.util.b.p(str2, str4);
                            } catch (Throwable th) {
                                failure = new Result.Failure(th);
                            }
                            if (failure instanceof Result.Failure) {
                                failure = null;
                            }
                            str5 = (String) failure;
                        }
                        objH = new top.niunaijun.blackboxa.util.a(str4, str2, str5, (String) mapF.get("services"), (String) mapF.get("firstName"), (String) mapF.get("lastName"));
                    } catch (Throwable th2) {
                        objH = new Result.Failure(th2);
                    }
                    break;
                }
                Object obj3 = objH;
                if (!(obj3 instanceof Result.Failure)) {
                    top.niunaijun.blackboxa.util.a aVar = (top.niunaijun.blackboxa.util.a) obj3;
                    try {
                        googleLoginActivity.n(aVar);
                        googleLoginActivity.runOnUiThread(new d(googleLoginActivity, 2, aVar));
                    } catch (Throwable th3) {
                        String string2 = googleLoginActivity.getString(R.string.login_google_save_err);
                        kotlin.jvm.internal.d.e(string2, "getString(...)");
                        String message = th3.getMessage();
                        if (message == null) {
                            message = "?";
                        }
                        googleLoginActivity.runOnUiThread(new g(0, googleLoginActivity, string2, message));
                    }
                    break;
                }
                Throwable thA = Result.a(obj3);
                if (thA != null) {
                    String string3 = googleLoginActivity.getString(R.string.login_google_failed);
                    kotlin.jvm.internal.d.e(string3, "getString(...)");
                    String message2 = thA.getMessage();
                    googleLoginActivity.runOnUiThread(new g(0, googleLoginActivity, string3, message2 != null ? message2 : "?"));
                    return;
                }
                return;
            case 2:
                GoogleLoginActivity this$0 = (GoogleLoginActivity) obj2;
                top.niunaijun.blackboxa.util.a mt = (top.niunaijun.blackboxa.util.a) obj;
                int i7 = GoogleLoginActivity.D;
                kotlin.jvm.internal.d.f(this$0, "this$0");
                kotlin.jvm.internal.d.f(mt, "$mt");
                Toast.makeText(this$0, this$0.getString(R.string.login_google_done, mt.f4089a), 0).show();
                this$0.finish();
                return;
            case 3:
                e.r rVar = (e.r) obj2;
                Runnable runnable = (Runnable) obj;
                rVar.getClass();
                try {
                    runnable.run();
                    return;
                } finally {
                    rVar.a();
                }
            case 4:
                ((f0.b) obj2).i((Typeface) obj);
                return;
            case 5:
                ((BActivityThread) obj2).lambda$scheduleReceiver$3((ReceiverData) obj);
                return;
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                BLocationManagerService.lambda$addTask$0((IInterface) obj2, (BLocation) obj);
                return;
            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                ((BLocationManagerService) obj2).lambda$addTask$1((IBinder) obj);
                return;
            case 8:
                MainActivity mainActivity = (MainActivity) obj2;
                String str6 = (String) obj;
                try {
                    String cookie = CookieManager.getInstance().getCookie("https://mbasic.facebook.com");
                    if (cookie == null) {
                        return;
                    }
                    URLConnection uRLConnectionOpenConnection = new URL("https://mbasic.facebook.com/profile.php").openConnection();
                    kotlin.jvm.internal.d.d(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
                    httpURLConnection.setConnectTimeout(8000);
                    httpURLConnection.setReadTimeout(8000);
                    httpURLConnection.setRequestProperty("Cookie", cookie);
                    httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36");
                    InputStream inputStream = httpURLConnection.getInputStream();
                    kotlin.jvm.internal.d.e(inputStream, "getInputStream(...)");
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, kotlin.text.a.f2863a), JarConfig.DEFAULT_BUFFER_SIZE);
                    try {
                        String strA0 = a3.a.a0(bufferedReader);
                        bufferedReader.close();
                        int iA = RegexOption.DOT_MATCHES_ALL.a();
                        if ((iA & 2) != 0) {
                            iA |= 64;
                        }
                        Pattern patternCompile = Pattern.compile("<title>(.*?)</title>", iA);
                        kotlin.jvm.internal.d.e(patternCompile, "compile(...)");
                        kotlin.text.d dVarA = new Regex(patternCompile).a(strA0, 0);
                        if (dVarA != null) {
                            if (dVarA.f2873c == null) {
                                dVarA.f2873c = new kotlin.text.c(dVarA);
                            }
                            kotlin.text.c cVar = dVarA.f2873c;
                            kotlin.jvm.internal.d.c(cVar);
                            String str7 = (String) cVar.get(1);
                            if (str7 != null && (string = kotlin.text.e.l0(str7).toString()) != null) {
                                String string4 = kotlin.text.e.l0(Html.fromHtml(string).toString()).toString();
                                if (string4.length() != 0 && string4.length() <= 80) {
                                    List list = top.niunaijun.blackboxa.util.j.f4125a;
                                    if (!(list != null) || !list.isEmpty()) {
                                        Iterator it = list.iterator();
                                        while (it.hasNext()) {
                                            if (string4.equalsIgnoreCase((String) it.next())) {
                                                return;
                                            }
                                        }
                                    }
                                    mainActivity.getSharedPreferences("oni_fb", 0).edit().putString("name_" + str6, string4).apply();
                                    return;
                                }
                                return;
                            }
                            return;
                        }
                        return;
                    } catch (Throwable th4) {
                        try {
                            throw th4;
                        } catch (Throwable th5) {
                            a3.a.j(bufferedReader, th4);
                            throw th5;
                        }
                    }
                } catch (Throwable unused) {
                    return;
                }
            case 9:
                boolean z4 = true;
                SharedPreferences sharedPreferences = (SharedPreferences) obj2;
                App app = (App) obj;
                List<Pair> list2 = top.niunaijun.blackboxa.util.p.f4140b;
                try {
                    BlackBoxCore blackBoxCore = BlackBoxCore.get();
                    if (sharedPreferences.getInt("microg_ver", 0) >= 5) {
                        if (list2 == null) {
                            z4 = false;
                        }
                        if (z4 && list2.isEmpty()) {
                            return;
                        }
                        Iterator it2 = list2.iterator();
                        while (it2.hasNext()) {
                            if (!blackBoxCore.isInstalled((String) ((Pair) it2.next()).d(), 0)) {
                            }
                        }
                        return;
                    }
                    for (Pair pair : list2) {
                        String str8 = (String) pair.a();
                        try {
                            blackBoxCore.uninstallPackageAsUser((String) pair.b(), 0);
                        } catch (Exception e4) {
                            e4.getMessage();
                        }
                        File file = new File(app.getCacheDir(), str8);
                        InputStream inputStreamOpen = app.getAssets().open(str8);
                        try {
                            FileOutputStream fileOutputStream = new FileOutputStream(file);
                            try {
                                kotlin.jvm.internal.d.c(inputStreamOpen);
                                a3.a.o(inputStreamOpen, fileOutputStream);
                                fileOutputStream.close();
                                inputStreamOpen.close();
                                boolean z5 = blackBoxCore.installPackageAsUser(file, 0).success;
                                file.delete();
                            } catch (Throwable th6) {
                                try {
                                    throw th6;
                                } catch (Throwable th7) {
                                    a3.a.j(fileOutputStream, th6);
                                    throw th7;
                                }
                            }
                        } catch (Throwable th8) {
                            try {
                                throw th8;
                            } catch (Throwable th9) {
                                a3.a.j(inputStreamOpen, th8);
                                throw th9;
                            }
                        }
                        break;
                    }
                    sharedPreferences.edit().putInt("microg_ver", 5).apply();
                    return;
                } catch (Exception e5) {
                    e5.getMessage();
                    return;
                }
            case JarConfig.MAX_CACHE_SIZE /* 10 */:
                Activity activity = (Activity) obj2;
                j3.a onContinue = (j3.a) obj;
                kotlin.jvm.internal.d.f(activity, "$activity");
                kotlin.jvm.internal.d.f(onContinue, "$onContinue");
                activity.runOnUiThread(new z(activity, top.niunaijun.blackboxa.util.b.g(activity), onContinue, i4));
                return;
            case 11:
                androidx.fragment.app.z zVar = (androidx.fragment.app.z) obj2;
                zVar.runOnUiThread(new z(zVar, top.niunaijun.blackboxa.util.b.g(zVar), (j3.l) obj, i5));
                return;
            case 12:
                AppsFragment this$1 = (AppsFragment) obj2;
                top.niunaijun.blackboxa.view.base.c cVar2 = (top.niunaijun.blackboxa.view.base.c) obj;
                kotlin.jvm.internal.d.f(this$1, "this$0");
                if (this$1.f4173a0 == cVar2) {
                    cVar2.b();
                    return;
                }
                return;
            case 13:
                com.afollestad.materialdialogs.a dlg = (com.afollestad.materialdialogs.a) obj2;
                top.niunaijun.blackboxa.view.setting.g this$2 = (top.niunaijun.blackboxa.view.setting.g) obj;
                kotlin.jvm.internal.d.f(dlg, "$dlg");
                kotlin.jvm.internal.d.f(this$2, "this$0");
                dlg.dismiss();
                String strM = this$2.m(R.string.xapk_fail);
                kotlin.jvm.internal.d.e(strM, "getString(...)");
                top.niunaijun.blackboxa.util.b.W(strM);
                return;
            case 14:
                Context context = (Context) obj2;
                top.niunaijun.blackboxa.view.setting.g this$3 = (top.niunaijun.blackboxa.view.setting.g) obj;
                kotlin.jvm.internal.d.f(this$3, "this$0");
                kotlin.jvm.internal.d.c(context);
                Map mapA = top.niunaijun.blackboxa.util.b.a(context);
                Ref$IntRef ref$IntRef = new Ref$IntRef();
                for (Map.Entry entry : mapA.entrySet()) {
                    String str9 = (String) entry.getKey();
                    Boolean boolY = top.niunaijun.blackboxa.util.b.y(str9, (String) entry.getValue(), context);
                    if (boolY != null) {
                        if (boolY.booleanValue()) {
                            ref$IntRef.element++;
                        }
                        context.getSharedPreferences("onimod", 0).edit().remove("key_".concat(str9)).remove("exp_".concat(str9)).remove("sv_".concat(str9)).apply();
                        top.niunaijun.blackboxa.util.b.M(str9);
                    }
                }
                androidx.fragment.app.z zVarG = this$3.g();
                if (zVarG != null) {
                    zVarG.runOnUiThread(new top.niunaijun.blackbox.app.a(this$3, context, ref$IntRef, mapA, 1));
                    return;
                }
                return;
            default:
                top.niunaijun.blackboxa.view.setting.g this$4 = (top.niunaijun.blackboxa.view.setting.g) obj2;
                androidx.fragment.app.z act = (androidx.fragment.app.z) obj;
                kotlin.jvm.internal.d.f(this$4, "this$0");
                kotlin.jvm.internal.d.f(act, "$act");
                if (this$4.r()) {
                    top.niunaijun.blackboxa.view.setting.g.O(this$4, act);
                    return;
                }
                return;
        }
    }
}
