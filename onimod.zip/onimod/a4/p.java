package a4;

import android.webkit.JavascriptInterface;
import top.niunaijun.blackboxa.view.login.OniConsentActivity;

/* JADX INFO: loaded from: classes.dex */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ OniConsentActivity f104a;

    public p(OniConsentActivity oniConsentActivity) {
        this.f104a = oniConsentActivity;
    }

    @JavascriptInterface
    public final void cancel() {
        OniConsentActivity oniConsentActivity = this.f104a;
        oniConsentActivity.runOnUiThread(new o(oniConsentActivity, 1));
    }

    @JavascriptInterface
    public final String getModuleVersion() {
        return "1";
    }

    @JavascriptInterface
    public final void setConsentResult(String result) {
        kotlin.jvm.internal.d.f(result, "result");
        boolean zEquals = result.equals("CAA");
        OniConsentActivity oniConsentActivity = this.f104a;
        if (!zEquals) {
            int i3 = OniConsentActivity.E;
            oniConsentActivity.n(result);
        }
        oniConsentActivity.runOnUiThread(new o(oniConsentActivity, 3));
    }

    @JavascriptInterface
    public final void showView() {
        OniConsentActivity oniConsentActivity = this.f104a;
        oniConsentActivity.runOnUiThread(new o(oniConsentActivity, 2));
    }
}
