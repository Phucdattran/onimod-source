package a4;

import android.app.Dialog;
import android.text.Editable;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import top.niunaijun.blackboxa.view.login.GoogleLoginActivity;
import top.niunaijun.blackboxa.view.login.OniConsentActivity;
import v2.u;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class f implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f81a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f82b;

    public /* synthetic */ f(int i3, Object obj) {
        this.f81a = i3;
        this.f82b = obj;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        int i3 = this.f81a;
        Object obj = this.f82b;
        switch (i3) {
            case 0:
                GoogleLoginActivity this$0 = (GoogleLoginActivity) obj;
                int i4 = GoogleLoginActivity.D;
                kotlin.jvm.internal.d.f(this$0, "this$0");
                this$0.finish();
                return;
            case 1:
                int i5 = OniConsentActivity.E;
                ((OniConsentActivity) obj).finish();
                return;
            case 2:
                ((com.google.android.material.datepicker.n) obj).P();
                throw null;
            case 3:
                Dialog dlg = (Dialog) obj;
                kotlin.jvm.internal.d.f(dlg, "$dlg");
                dlg.dismiss();
                return;
            case 4:
                v2.d dVar = (v2.d) obj;
                EditText editText = dVar.f4551i;
                if (editText == null) {
                    return;
                }
                Editable text = editText.getText();
                if (text != null) {
                    text.clear();
                }
                dVar.p();
                return;
            case 5:
                ((v2.j) obj).t();
                return;
            default:
                u uVar = (u) obj;
                EditText editText2 = uVar.f;
                if (editText2 == null) {
                    return;
                }
                int selectionEnd = editText2.getSelectionEnd();
                EditText editText3 = uVar.f;
                if (editText3 == null || !(editText3.getTransformationMethod() instanceof PasswordTransformationMethod)) {
                    uVar.f.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else {
                    uVar.f.setTransformationMethod(null);
                }
                if (selectionEnd >= 0) {
                    uVar.f.setSelection(selectionEnd);
                }
                uVar.p();
                return;
        }
    }
}
