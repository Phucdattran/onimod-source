package a4;

import top.niunaijun.blackboxa.view.login.OniBrowserActivity;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class m implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f99a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ OniBrowserActivity f100b;

    public /* synthetic */ m(OniBrowserActivity oniBrowserActivity, int i3) {
        this.f99a = i3;
        this.f100b = oniBrowserActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i3 = this.f99a;
        OniBrowserActivity this$0 = this.f100b;
        switch (i3) {
            case 0:
                int i4 = OniBrowserActivity.H;
                kotlin.jvm.internal.d.f(this$0, "this$0");
                this$0.p();
                break;
            default:
                int i5 = OniBrowserActivity.H;
                kotlin.jvm.internal.d.f(this$0, "this$0");
                this$0.finish();
                break;
        }
    }
}
