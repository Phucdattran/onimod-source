package a4;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Trace;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.emoji2.text.v;
import androidx.fragment.app.strictmode.Violation;
import androidx.fragment.app.z;
import androidx.lifecycle.Lifecycle$Event;
import androidx.lifecycle.b0;
import androidx.lifecycle.s;
import com.google.android.material.carousel.CarouselLayoutManager;
import com.google.android.material.sidesheet.SideSheetBehavior;
import com.google.android.material.textfield.TextInputLayout;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.MappedByteBuffer;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
import top.niunaijun.blackbox.R;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.app.LauncherActivity;
import top.niunaijun.blackbox.app.dispatcher.AppServiceDispatcher;
import top.niunaijun.blackbox.core.OniInjector;
import top.niunaijun.blackbox.core.system.JarConfig;
import top.niunaijun.blackbox.core.system.JarManager;
import top.niunaijun.blackbox.entity.ServiceRecord;
import top.niunaijun.blackbox.entity.location.BCell;
import top.niunaijun.blackboxa.view.login.GoogleLoginActivity;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f71a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f72b;

    public /* synthetic */ b(int i3, Object obj) {
        this.f71a = i3;
        this.f72b = obj;
    }

    /* JADX WARN: Code duplicated, block: B:215:0x0349  */
    @Override // java.lang.Runnable
    public final void run() {
        HttpURLConnection httpURLConnection;
        JSONObject jSONObject;
        JSONArray jSONArrayOptJSONArray;
        int i3;
        ArrayList arrayList;
        Object obj;
        Object fVar = null;
        int i4 = 1;
        int i5 = 0;
        switch (this.f71a) {
            case 0:
                e eVar = (e) this.f72b;
                try {
                    URLConnection uRLConnectionOpenConnection = new URL("https://api.onimod.org/buy/catalog").openConnection();
                    kotlin.jvm.internal.d.d(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                    httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.setConnectTimeout(12000);
                    httpURLConnection.setReadTimeout(12000);
                    httpURLConnection.setRequestProperty("User-Agent", "Onimod");
                    try {
                        int responseCode = httpURLConnection.getResponseCode();
                        InputStream errorStream = (200 > responseCode || responseCode >= 300) ? httpURLConnection.getErrorStream() : httpURLConnection.getInputStream();
                        if (errorStream != null) {
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(errorStream, kotlin.text.a.f2863a), JarConfig.DEFAULT_BUFFER_SIZE);
                            try {
                                String strA0 = a3.a.a0(bufferedReader);
                                bufferedReader.close();
                                jSONObject = new JSONObject(strA0);
                            } catch (Throwable th) {
                                try {
                                    throw th;
                                } catch (Throwable th2) {
                                    a3.a.j(bufferedReader, th);
                                    throw th2;
                                }
                            }
                        } else {
                            jSONObject = null;
                        }
                    } catch (Exception unused) {
                        if (httpURLConnection != null) {
                            try {
                                httpURLConnection.disconnect();
                                break;
                            } catch (Exception unused2) {
                            }
                        }
                        jSONObject = null;
                    }
                } catch (Exception unused3) {
                    httpURLConnection = null;
                }
                if (jSONObject == null || !jSONObject.optBoolean("ok", false) || (jSONArrayOptJSONArray = jSONObject.optJSONArray("products")) == null) {
                    i3 = 0;
                } else {
                    ArrayList arrayList2 = new ArrayList(jSONArrayOptJSONArray.length());
                    int length = jSONArrayOptJSONArray.length();
                    int i6 = 0;
                    while (i6 < length) {
                        JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i6);
                        if (jSONObjectOptJSONObject == null) {
                            arrayList = arrayList2;
                        } else {
                            String strOptString = jSONObjectOptJSONObject.optString("code");
                            kotlin.jvm.internal.d.c(strOptString);
                            if (strOptString.length() == 0) {
                                arrayList = arrayList2;
                            } else {
                                String strOptString2 = jSONObjectOptJSONObject.optString("label");
                                kotlin.jvm.internal.d.e(strOptString2, "optString(...)");
                                ArrayList arrayList3 = arrayList2;
                                double dOptDouble = jSONObjectOptJSONObject.optDouble("price", 0.0d);
                                String strOptString3 = jSONObjectOptJSONObject.optString("currency", "USD");
                                kotlin.jvm.internal.d.e(strOptString3, "optString(...)");
                                int iOptInt = jSONObjectOptJSONObject.optInt("qty", i4);
                                String strOptString4 = jSONObjectOptJSONObject.optString("scope");
                                kotlin.jvm.internal.d.e(strOptString4, "optString(...)");
                                String strOptString5 = jSONObjectOptJSONObject.optString("term");
                                kotlin.jvm.internal.d.e(strOptString5, "optString(...)");
                                int iOptInt2 = jSONObjectOptJSONObject.optInt("days", 0);
                                boolean zOptBoolean = jSONObjectOptJSONObject.optBoolean("permanent", false);
                                String strOptString6 = jSONObjectOptJSONObject.optString("note");
                                kotlin.jvm.internal.d.e(strOptString6, "optString(...)");
                                String strOptString7 = jSONObjectOptJSONObject.optString("kofi");
                                kotlin.jvm.internal.d.e(strOptString7, "optString(...)");
                                top.niunaijun.blackboxa.util.g gVar = new top.niunaijun.blackboxa.util.g(strOptString, strOptString2, dOptDouble, strOptString3, iOptInt, strOptString4, strOptString5, iOptInt2, zOptBoolean, strOptString6, strOptString7);
                                arrayList = arrayList3;
                                arrayList.add(gVar);
                            }
                        }
                        i6++;
                        arrayList2 = arrayList;
                        i4 = 1;
                    }
                    ArrayList arrayList4 = arrayList2;
                    if (arrayList4.isEmpty()) {
                        fVar = null;
                        i3 = 0;
                    } else {
                        i3 = 0;
                        fVar = new top.niunaijun.blackboxa.util.f(arrayList4, jSONObject.optBoolean("live", false));
                    }
                }
                eVar.W.post(new d(eVar, i3, fVar));
                return;
            case 1:
                GoogleLoginActivity googleLoginActivity = (GoogleLoginActivity) this.f72b;
                int i7 = GoogleLoginActivity.D;
                if (googleLoginActivity.C) {
                    return;
                }
                googleLoginActivity.o();
                return;
            case 2:
                ((z) this.f72b).invalidateOptionsMenu();
                return;
            case 3:
                androidx.activity.j jVar = (androidx.activity.j) this.f72b;
                Runnable runnable = jVar.f133b;
                if (runnable != null) {
                    runnable.run();
                    jVar.f133b = null;
                    return;
                }
                return;
            case 4:
                androidx.activity.m.a((androidx.activity.m) this.f72b);
                return;
            case 5:
                v vVar = (v) this.f72b;
                synchronized (vVar.f568d) {
                    try {
                        if (vVar.f571h == null) {
                            return;
                        }
                        try {
                            l0.j jVarD = vVar.d();
                            int i8 = jVarD.f3350e;
                            if (i8 == 2) {
                                synchronized (vVar.f568d) {
                                }
                            }
                            if (i8 != 0) {
                                throw new RuntimeException("fetchFonts result is not OK. (" + i8 + ")");
                            }
                            try {
                                int i9 = k0.j.f2785a;
                                Trace.beginSection("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
                                s2.e eVar2 = vVar.f567c;
                                Context context = vVar.f565a;
                                eVar2.getClass();
                                l0.j[] jVarArr = {jVarD};
                                a3.a aVar = g0.g.f2327a;
                                a3.a.d("TypefaceCompat.createFromFontInfo");
                                try {
                                    Typeface typefaceT = g0.g.f2327a.t(context, jVarArr, 0);
                                    Trace.endSection();
                                    MappedByteBuffer mappedByteBufferS = a3.a.S(vVar.f565a, jVarD.f3346a);
                                    if (mappedByteBufferS == null || typefaceT == null) {
                                        throw new RuntimeException("Unable to open file.");
                                    }
                                    try {
                                        Trace.beginSection("EmojiCompat.MetadataRepo.create");
                                        a0.k kVar = new a0.k(typefaceT, a3.a.Z(mappedByteBufferS));
                                        Trace.endSection();
                                        Trace.endSection();
                                        synchronized (vVar.f568d) {
                                            try {
                                                a3.a aVar2 = vVar.f571h;
                                                if (aVar2 != null) {
                                                    aVar2.W(kVar);
                                                }
                                            } catch (Throwable th3) {
                                                throw th3;
                                            }
                                            break;
                                        }
                                        vVar.a();
                                        return;
                                    } catch (Throwable th4) {
                                        int i10 = k0.j.f2785a;
                                        Trace.endSection();
                                        throw th4;
                                    }
                                } catch (Throwable th5) {
                                    Trace.endSection();
                                    throw th5;
                                }
                            } catch (Throwable th6) {
                                int i11 = k0.j.f2785a;
                                Trace.endSection();
                                throw th6;
                            }
                            break;
                        } catch (Throwable th7) {
                            synchronized (vVar.f568d) {
                                try {
                                    a3.a aVar3 = vVar.f571h;
                                    if (aVar3 != null) {
                                        aVar3.T(th7);
                                    }
                                    vVar.a();
                                    return;
                                } catch (Throwable th8) {
                                    throw th8;
                                }
                            }
                        }
                    } catch (Throwable th9) {
                        throw th9;
                    }
                }
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                b0 b0Var = (b0) this.f72b;
                s sVar = b0Var.f;
                if (b0Var.f846b == 0) {
                    b0Var.f847c = true;
                    sVar.d(Lifecycle$Event.ON_PAUSE);
                }
                if (b0Var.f845a == 0 && b0Var.f847c) {
                    sVar.d(Lifecycle$Event.ON_STOP);
                    b0Var.f848d = true;
                    return;
                }
                return;
            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                Activity activity = (Activity) this.f72b;
                if (activity.isFinishing()) {
                    return;
                }
                Handler handler = c0.f.f1084g;
                Method method = c0.f.f;
                int i12 = Build.VERSION.SDK_INT;
                if (i12 >= 28) {
                    activity.recreate();
                    return;
                }
                if (((i12 != 26 && i12 != 27) || method != null) && (c0.f.f1083e != null || c0.f.f1082d != null)) {
                    try {
                        Object obj2 = c0.f.f1081c.get(activity);
                        if (obj2 != null && (obj = c0.f.f1080b.get(activity)) != null) {
                            Application application = activity.getApplication();
                            c0.e eVar3 = new c0.e(activity);
                            application.registerActivityLifecycleCallbacks(eVar3);
                            handler.post(new c0.d(eVar3, i5, obj2));
                            try {
                                if (i12 == 26 || i12 == 27) {
                                    Boolean bool = Boolean.FALSE;
                                    method.invoke(obj, obj2, null, null, 0, bool, null, null, bool, bool);
                                } else {
                                    activity.recreate();
                                }
                                handler.post(new c0.d(application, eVar3, i4, 0 == true ? 1 : 0));
                                return;
                            } catch (Throwable th10) {
                                handler.post(new c0.d(application, eVar3, i4, 0 == true ? 1 : 0));
                                throw th10;
                            }
                        }
                    } catch (Throwable unused4) {
                    }
                }
                activity.recreate();
                return;
            case 8:
                ((com.google.android.material.timepicker.e) this.f72b).m();
                return;
            case 9:
                ((CarouselLayoutManager) this.f72b).s0();
                return;
            case JarConfig.MAX_CACHE_SIZE /* 10 */:
                View view = (View) this.f72b;
                Context context2 = view.getContext();
                int i13 = Build.VERSION.SDK_INT;
                if (i13 >= 23) {
                    fVar = d0.a.f(context2);
                } else {
                    String strG = i13 >= 23 ? d0.a.g(context2) : (String) d0.c.f1619a.get(InputMethodManager.class);
                    if (strG != null) {
                        fVar = context2.getSystemService(strG);
                    }
                }
                ((InputMethodManager) fVar).showSoftInput(view, 1);
                return;
            case 11:
                AppServiceDispatcher.lambda$stopService$0((ServiceRecord) this.f72b);
                return;
            case 12:
                a2.j jVar2 = (a2.j) this.f72b;
                jVar2.f53c = false;
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) jVar2.f55e;
                t0.d dVar = sideSheetBehavior.f1471i;
                if (dVar != null && dVar.f()) {
                    jVar2.a(jVar2.f52b);
                    return;
                } else {
                    if (sideSheetBehavior.f1470h == 2) {
                        sideSheetBehavior.r(jVar2.f52b);
                        return;
                    }
                    return;
                }
            case 13:
                BActivityThread.lambda$finishActivity$1((IBinder) this.f72b);
                return;
            case 14:
                ((LauncherActivity) this.f72b).finish();
                return;
            case 15:
                OniInjector.lambda$wireMenuLifecycle$3((Application) this.f72b);
                return;
            case 16:
                ((JarManager) this.f72b).lambda$initializeAsync$0();
                return;
            case 17:
                j3.a tmp0 = (j3.a) this.f72b;
                kotlin.jvm.internal.d.f(tmp0, "$tmp0");
                tmp0.b();
                return;
            case 18:
                top.niunaijun.blackboxa.view.base.c this$0 = (top.niunaijun.blackboxa.view.base.c) this.f72b;
                kotlin.jvm.internal.d.f(this$0, "this$0");
                this$0.b();
                return;
            case 19:
                com.afollestad.materialdialogs.a.b((com.afollestad.materialdialogs.a) this.f72b, Integer.valueOf(R.string.oni_abi_installing), null, 6);
                return;
            case 20:
                ((v2.d) this.f72b).s(true);
                return;
            case 21:
                v2.j jVar3 = (v2.j) this.f72b;
                boolean zIsPopupShowing = jVar3.f4564h.isPopupShowing();
                jVar3.s(zIsPopupShowing);
                jVar3.f4569m = zIsPopupShowing;
                return;
            case 22:
                ((TextInputLayout) this.f72b).f1498d.requestLayout();
                return;
            default:
                Violation violation = (Violation) this.f72b;
                kotlin.jvm.internal.d.f(violation, "$violation");
                throw violation;
        }
    }

    public /* synthetic */ b(String str, Violation violation) {
        this.f71a = 23;
        this.f72b = violation;
    }
}
