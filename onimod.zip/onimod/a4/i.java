package a4;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.widget.Toast;
import java.util.List;
import top.niunaijun.blackbox.R;
import top.niunaijun.blackbox.utils.ShellUtils;
import top.niunaijun.blackboxa.view.login.GoogleLoginActivity;
import top.niunaijun.blackboxa.view.main.MainActivity;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class i implements DialogInterface.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f88a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f89b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f90c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f91d;

    public /* synthetic */ i(Object obj, String str, Object obj2, int i3) {
        this.f88a = i3;
        this.f90c = obj;
        this.f89b = str;
        this.f91d = obj2;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i3) {
        int i4 = this.f88a;
        Object obj = this.f91d;
        String title = this.f89b;
        Object obj2 = this.f90c;
        switch (i4) {
            case 0:
                GoogleLoginActivity this$0 = (GoogleLoginActivity) obj2;
                String msg = (String) obj;
                int i5 = GoogleLoginActivity.D;
                kotlin.jvm.internal.d.f(this$0, "this$0");
                kotlin.jvm.internal.d.f(title, "$title");
                kotlin.jvm.internal.d.f(msg, "$msg");
                try {
                    Object systemService = this$0.getSystemService("clipboard");
                    kotlin.jvm.internal.d.d(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                    ((ClipboardManager) systemService).setPrimaryClip(ClipData.newPlainText("oni_login", title + ShellUtils.COMMAND_LINE_END + msg));
                    Toast.makeText(this$0, this$0.getString(R.string.copied), 0).show();
                    break;
                } catch (Throwable unused) {
                }
                this$0.finish();
                break;
            default:
                List codes = (List) obj2;
                top.niunaijun.blackboxa.view.setting.g gVar = (top.niunaijun.blackboxa.view.setting.g) obj;
                kotlin.jvm.internal.d.f(codes, "$codes");
                dialogInterface.dismiss();
                if (!kotlin.jvm.internal.d.a(codes.get(i3), title)) {
                    String lang = (String) codes.get(i3);
                    List list = top.niunaijun.blackboxa.util.d.f4106a;
                    Context contextJ = gVar.J();
                    kotlin.jvm.internal.d.f(lang, "lang");
                    if (!top.niunaijun.blackboxa.util.d.f4107b.contains(lang)) {
                        lang = "en";
                    }
                    contextJ.getSharedPreferences("onimod", 0).edit().putString("app_lang", lang).apply();
                    Intent intent = new Intent(gVar.J(), (Class<?>) MainActivity.class);
                    intent.addFlags(268468224);
                    gVar.N(intent);
                    gVar.I().finishAffinity();
                }
                break;
        }
    }
}
