package a4;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.util.Objects;
import kotlin.text.Regex;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.core.env.BEnvironment;
import top.niunaijun.blackboxa.view.base.BaseActivity;
import top.niunaijun.blackboxa.view.login.GoogleLoginActivity;
import top.niunaijun.blackboxa.view.login.OniBrowserActivity;
import top.niunaijun.blackboxa.view.login.OniConsentActivity;

/* JADX INFO: loaded from: classes.dex */
public final class k extends WebViewClient {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f95a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ BaseActivity f96b;

    public /* synthetic */ k(BaseActivity baseActivity, int i3) {
        this.f95a = i3;
        this.f96b = baseActivity;
    }

    @Override // android.webkit.WebViewClient
    public final void onPageFinished(WebView webView, final String str) {
        switch (this.f95a) {
            case 0:
                GoogleLoginActivity googleLoginActivity = (GoogleLoginActivity) this.f96b;
                GoogleLoginActivity.m(googleLoginActivity);
                int i3 = googleLoginActivity.B;
                WebView webView2 = googleLoginActivity.f4284y;
                if (webView2 != null) {
                    webView2.postDelayed(new j(i3, googleLoginActivity, 0), 700L);
                    return;
                } else {
                    kotlin.jvm.internal.d.k("webView");
                    throw null;
                }
            case 1:
                OniBrowserActivity oniBrowserActivity = (OniBrowserActivity) this.f96b;
                if (oniBrowserActivity.C && OniBrowserActivity.n(oniBrowserActivity)) {
                    OniBrowserActivity.m(oniBrowserActivity);
                    return;
                }
                try {
                    WebView webView3 = oniBrowserActivity.f4286y;
                    if (webView3 == null) {
                        kotlin.jvm.internal.d.k("webView");
                        throw null;
                    }
                    webView3.evaluateJavascript("(function(){try{\n  var M=['dành cho Android','Tải Facebook','Get Facebook','Download Facebook'];\n  var cap=0.6*innerWidth*innerHeight;\n  var all=document.querySelectorAll('body *');\n  for(var i=0;i<all.length;i++){\n    var e=all[i];\n    if(e.children.length)continue;\n    var t=e.textContent||'',hit=false;\n    for(var m=0;m<M.length;m++)if(t.indexOf(M[m])>=0){hit=true;break;}\n    if(!hit)continue;\n    for(var k=0;k<6&&e.parentElement;k++){\n      var p=e.parentElement;\n      if(p.querySelector('input,form'))break;\n      e=p;\n    }\n    if(e.querySelector('input,form'))continue;\n    var r=e.getBoundingClientRect();\n    if(r.width*r.height<=cap)e.style.display='none';\n  }\n}catch(_){}})();", null);
                    int i4 = oniBrowserActivity.D;
                    WebView webView4 = oniBrowserActivity.f4286y;
                    if (webView4 != null) {
                        webView4.postDelayed(new j(i4, oniBrowserActivity, 1), 600L);
                        return;
                    } else {
                        kotlin.jvm.internal.d.k("webView");
                        throw null;
                    }
                } catch (Exception e4) {
                    e4.getMessage();
                }
                break;
            default:
                final OniConsentActivity oniConsentActivity = (OniConsentActivity) this.f96b;
                if (webView == null) {
                    OniConsentActivity.m(oniConsentActivity);
                    return;
                }
                try {
                    webView.evaluateJavascript("(document.body && document.body.innerText ? document.body.innerText : '').substring(0,4000)", new ValueCallback() { // from class: a4.q
                        @Override // android.webkit.ValueCallback
                        public final void onReceiveValue(Object obj) {
                            String str2 = (String) obj;
                            int i5 = OniConsentActivity.E;
                            String str3 = str;
                            boolean zX = false;
                            if (str3 != null && kotlin.text.e.X(str3, "error=access_denied", false)) {
                                zX = true;
                            } else if (str2 != null) {
                                zX = kotlin.text.e.X(str2, "access_denied", false);
                            }
                            OniConsentActivity oniConsentActivity2 = oniConsentActivity;
                            if (zX) {
                                oniConsentActivity2.finish();
                            } else {
                                OniConsentActivity.m(oniConsentActivity2);
                            }
                        }
                    });
                    return;
                } catch (Throwable unused) {
                    OniConsentActivity.m(oniConsentActivity);
                    return;
                }
        }
    }

    @Override // android.webkit.WebViewClient
    public final void onPageStarted(WebView webView, String str, Bitmap bitmap) {
        switch (this.f95a) {
            case 0:
                ((GoogleLoginActivity) this.f96b).B++;
                break;
            case 1:
                OniBrowserActivity oniBrowserActivity = (OniBrowserActivity) this.f96b;
                oniBrowserActivity.D++;
                if (oniBrowserActivity.C && top.niunaijun.blackboxa.util.j.a() != null && !OniBrowserActivity.o(str)) {
                    OniBrowserActivity.m(oniBrowserActivity);
                    break;
                }
                break;
        }
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
        switch (this.f95a) {
            case 2:
                break;
            default:
                super.onReceivedError(webView, webResourceRequest, webResourceError);
                break;
        }
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedHttpError(WebView webView, WebResourceRequest webResourceRequest, WebResourceResponse webResourceResponse) {
        switch (this.f95a) {
            case 2:
                break;
            default:
                super.onReceivedHttpError(webView, webResourceRequest, webResourceResponse);
                break;
        }
    }

    @Override // android.webkit.WebViewClient
    public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
        int i3 = this.f95a;
        BaseActivity baseActivity = this.f96b;
        switch (i3) {
            case 0:
                GoogleLoginActivity.m((GoogleLoginActivity) baseActivity);
                return false;
            case 1:
                Uri url = webResourceRequest != null ? webResourceRequest.getUrl() : null;
                if (url == null) {
                    return false;
                }
                OniBrowserActivity oniBrowserActivity = (OniBrowserActivity) baseActivity;
                int i4 = OniBrowserActivity.H;
                String scheme = url.getScheme();
                if (scheme == null || scheme.equals("http") || scheme.equals("https")) {
                    return false;
                }
                url.toString();
                boolean z4 = scheme.equals("fbconnect") || new Regex("fb\\d+").c(scheme);
                try {
                    if (scheme.equals("intent") && oniBrowserActivity.A != null) {
                        String string = url.toString();
                        kotlin.jvm.internal.d.e(string, "toString(...)");
                        String str = oniBrowserActivity.A;
                        if (str != null) {
                            Intent uri = Intent.parseUri(string, 1);
                            uri.setComponent(null);
                            uri.setSelector(null);
                            uri.setPackage(str);
                            BlackBoxCore.getBActivityManager().startActivity(uri, oniBrowserActivity.B);
                            uri.getAction();
                            Objects.toString(uri.getData());
                        }
                    } else if (!z4 || oniBrowserActivity.A == null) {
                        Intent intent = new Intent("android.intent.action.VIEW", url);
                        String str2 = oniBrowserActivity.A;
                        if (str2 != null) {
                            intent.setPackage(str2);
                        }
                        intent.addFlags(268435456);
                        BlackBoxCore.get().startActivity(intent, oniBrowserActivity.B);
                    } else {
                        File file = new File(BEnvironment.getDataFilesDir(oniBrowserActivity.A, oniBrowserActivity.B), "__oni");
                        file.mkdirs();
                        File file2 = new File(file, "fb_redirect.tmp");
                        String string2 = url.toString();
                        kotlin.jvm.internal.d.e(string2, "toString(...)");
                        h3.h.o0(file2, string2, kotlin.text.a.f2863a);
                        file2.renameTo(new File(file, "fb_redirect"));
                    }
                } catch (Throwable th) {
                    th.toString();
                }
                WebView webView2 = oniBrowserActivity.f4286y;
                if (webView2 != null) {
                    webView2.postDelayed(new m(oniBrowserActivity, 1), 800L);
                    return true;
                }
                kotlin.jvm.internal.d.k("webView");
                throw null;
            default:
                return super.shouldOverrideUrlLoading(webView, webResourceRequest);
        }
    }

    private final void a(WebView webView, String str, Bitmap bitmap) {
    }

    private final void b(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
    }

    private final void c(WebView webView, WebResourceRequest webResourceRequest, WebResourceResponse webResourceResponse) {
    }
}
