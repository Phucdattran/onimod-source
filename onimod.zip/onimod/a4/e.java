package a4;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.fragment.app.w;
import com.mod.menu.ModConfig;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.collections.EmptyList;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public final class e extends w {
    public s2.j V;
    public final Handler W = new Handler(Looper.getMainLooper());
    public List X = EmptyList.f2819a;
    public boolean Y = true;
    public String Z = "one";

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public String f79a0 = "month";

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public top.niunaijun.blackboxa.util.g f80b0;

    public static String P(double d4, String str) {
        String strK0 = String.format(Locale.US, "%.2f", Arrays.copyOf(new Object[]{Double.valueOf(d4)}, 1));
        if (kotlin.text.l.R(strK0, ".00", false)) {
            int length = strK0.length() - 3;
            strK0 = kotlin.text.e.k0(length >= 0 ? length : 0, strK0);
        }
        if (str.equalsIgnoreCase("USD")) {
            return "$".concat(strK0);
        }
        return strK0 + " " + str;
    }

    public final void O() {
        s2.j jVar = this.V;
        kotlin.jvm.internal.d.c(jVar);
        T((LinearLayout) jVar.f3884d);
        new Thread(new b(0, this)).start();
    }

    public final void Q(TextView textView, boolean z4, boolean z5) {
        int i3;
        if (z4) {
            i3 = z5 ? R.drawable.bg_seg_left_on : R.drawable.bg_seg_right_on;
        } else {
            i3 = 0;
        }
        textView.setBackgroundResource(i3);
        textView.setTextColor(c0.g.b(J(), z4 ? R.color.oni_on_primary : R.color.oni_text_secondary));
    }

    /* JADX WARN: Code duplicated, block: B:62:0x01dd  */
    public final void R() {
        String str;
        top.niunaijun.blackboxa.util.g gVar;
        Object next;
        String strN;
        String strH;
        int iRound;
        s2.j jVar = this.V;
        kotlin.jvm.internal.d.c(jVar);
        Q((TextView) jVar.f3891l, kotlin.jvm.internal.d.a(this.Z, "one"), true);
        s2.j jVar2 = this.V;
        kotlin.jvm.internal.d.c(jVar2);
        boolean z4 = false;
        Q((TextView) jVar2.f3888i, kotlin.jvm.internal.d.a(this.Z, "all"), false);
        s2.j jVar3 = this.V;
        kotlin.jvm.internal.d.c(jVar3);
        Q((TextView) jVar3.f3890k, kotlin.jvm.internal.d.a(this.f79a0, "month"), true);
        s2.j jVar4 = this.V;
        kotlin.jvm.internal.d.c(jVar4);
        Q((TextView) jVar4.f3889j, kotlin.jvm.internal.d.a(this.f79a0, "life"), false);
        List list = this.X;
        ArrayList arrayList = new ArrayList();
        for (Object obj : list) {
            top.niunaijun.blackboxa.util.g gVar2 = (top.niunaijun.blackboxa.util.g) obj;
            if (gVar2.f.equals(this.Z) && gVar2.f4116g.equals(this.f79a0) && gVar2.f4120k.length() > 0) {
                arrayList.add(obj);
            }
        }
        List listX = kotlin.collections.j.X(arrayList, new a0.j(1));
        S(this.Y ? listX.isEmpty() ? m(R.string.buy_kofi_none) : null : m(R.string.buy_closed));
        s2.j jVar5 = this.V;
        kotlin.jvm.internal.d.c(jVar5);
        ((LinearLayout) jVar5.f).removeAllViews();
        if (listX != null && listX.isEmpty()) {
            this.f80b0 = (top.niunaijun.blackboxa.util.g) kotlin.collections.j.U(listX);
            break;
        }
        Iterator it = listX.iterator();
        do {
            if (!it.hasNext()) {
                this.f80b0 = (top.niunaijun.blackboxa.util.g) kotlin.collections.j.U(listX);
                break;
            } else {
                str = ((top.niunaijun.blackboxa.util.g) it.next()).f4111a;
                gVar = this.f80b0;
            }
        } while (!str.equals(gVar != null ? gVar.f4111a : null));
        Iterator it2 = listX.iterator();
        do {
            if (!it2.hasNext()) {
                next = null;
                break;
            }
            next = it2.next();
        } while (((top.niunaijun.blackboxa.util.g) next).f4115e != 1);
        top.niunaijun.blackboxa.util.g gVar3 = (top.niunaijun.blackboxa.util.g) next;
        if (gVar3 == null) {
            gVar3 = (top.niunaijun.blackboxa.util.g) kotlin.collections.j.U(listX);
        }
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(J());
        Context contextJ = J();
        int i3 = (int) (8 * l().getDisplayMetrics().density);
        Iterator it3 = listX.iterator();
        int i4 = 0;
        while (true) {
            boolean zHasNext = it3.hasNext();
            strN = ModConfig.PREFIX;
            if (!zHasNext) {
                break;
            }
            int i5 = i4 + 1;
            top.niunaijun.blackboxa.util.g gVar4 = (top.niunaijun.blackboxa.util.g) it3.next();
            s2.j jVar6 = this.V;
            kotlin.jvm.internal.d.c(jVar6);
            View viewInflate = layoutInflaterFrom.inflate(R.layout.item_pack, (LinearLayout) jVar6.f, z4);
            String str2 = gVar4.f4111a;
            double d4 = gVar4.f4113c;
            int i6 = gVar4.f4115e;
            top.niunaijun.blackboxa.util.g gVar5 = this.f80b0;
            boolean zEquals = str2.equals(gVar5 != null ? gVar5.f4111a : null);
            TextView textView = (TextView) viewInflate.findViewById(R.id.packQty);
            Iterator it4 = it3;
            TextView textView2 = (TextView) viewInflate.findViewById(R.id.packPrice);
            LayoutInflater layoutInflater = layoutInflaterFrom;
            TextView textView3 = (TextView) viewInflate.findViewById(R.id.packSave);
            textView.setText(i6 > 1 ? n(new Object[]{Integer.valueOf(i6)}, R.string.buy_key_n) : m(R.string.buy_key_one));
            textView2.setText(P(d4, gVar4.f4114d));
            if (i6 <= 1 || gVar3 == null) {
                iRound = 0;
            } else {
                double d5 = gVar3.f4113c;
                if (d5 > 0.0d) {
                    iRound = (int) Math.round(((double) 100) * (((double) 1) - (d4 / (((double) i6) * d5))));
                } else {
                    iRound = 0;
                }
            }
            textView3.setVisibility(iRound > 0 ? 0 : 4);
            if (iRound > 0) {
                strN = n(new Object[]{Integer.valueOf(iRound)}, R.string.buy_save);
            }
            textView3.setText(strN);
            viewInflate.setBackgroundResource(zEquals ? R.drawable.bg_btn_login : R.drawable.bg_btn_ghost);
            int i7 = R.color.oni_on_primary;
            int iB = c0.g.b(contextJ, zEquals ? R.color.oni_on_primary : R.color.oni_text_primary);
            textView.setTextColor(iB);
            textView2.setTextColor(iB);
            if (!zEquals) {
                i7 = R.color.oni_success;
            }
            textView3.setTextColor(c0.g.b(contextJ, i7));
            ViewGroup.LayoutParams layoutParams = viewInflate.getLayoutParams();
            kotlin.jvm.internal.d.d(layoutParams, "null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
            ((LinearLayout.LayoutParams) layoutParams).setMarginStart(i4 == 0 ? 0 : i3);
            viewInflate.setOnClickListener(new c(this, 0, gVar4));
            s2.j jVar7 = this.V;
            kotlin.jvm.internal.d.c(jVar7);
            ((LinearLayout) jVar7.f).addView(viewInflate);
            i4 = i5;
            it3 = it4;
            layoutInflaterFrom = layoutInflater;
            i3 = i3;
            z4 = false;
        }
        s2.j jVar8 = this.V;
        kotlin.jvm.internal.d.c(jVar8);
        TextView textView4 = (TextView) jVar8.f3883c;
        String strM = m(R.string.buy_continue);
        top.niunaijun.blackboxa.util.g gVar6 = this.f80b0;
        if (gVar6 != null && (strH = g0.e.h("  ·  ", P(gVar6.f4113c, gVar6.f4114d))) != null) {
            strN = strH;
        }
        textView4.setText(strM + strN);
    }

    public final void S(String str) {
        s2.j jVar = this.V;
        kotlin.jvm.internal.d.c(jVar);
        ((TextView) jVar.f3885e).setVisibility(str == null ? 8 : 0);
        s2.j jVar2 = this.V;
        kotlin.jvm.internal.d.c(jVar2);
        TextView textView = (TextView) jVar2.f3885e;
        if (str == null) {
            str = ModConfig.PREFIX;
        }
        textView.setText(str);
    }

    public final void T(View view) {
        s2.j jVar = this.V;
        kotlin.jvm.internal.d.c(jVar);
        ScrollView scrollView = (ScrollView) jVar.f3886g;
        s2.j jVar2 = this.V;
        kotlin.jvm.internal.d.c(jVar2);
        LinearLayout linearLayout = (LinearLayout) jVar2.f3884d;
        s2.j jVar3 = this.V;
        kotlin.jvm.internal.d.c(jVar3);
        ViewGroup[] viewGroupArr = {scrollView, linearLayout, (LinearLayout) jVar3.f3882b};
        for (int i3 = 0; i3 < 3; i3++) {
            ViewGroup viewGroup = viewGroupArr[i3];
            viewGroup.setVisibility(viewGroup == view ? 0 : 8);
        }
    }

    @Override // androidx.fragment.app.w
    public final View x(LayoutInflater inflater, ViewGroup viewGroup) {
        kotlin.jvm.internal.d.f(inflater, "inflater");
        View viewInflate = inflater.inflate(R.layout.fragment_account, viewGroup, false);
        int i3 = R.id.buyError;
        LinearLayout linearLayout = (LinearLayout) i1.m.p(viewInflate, R.id.buyError);
        if (linearLayout != null) {
            i3 = R.id.buyGo;
            TextView textView = (TextView) i1.m.p(viewInflate, R.id.buyGo);
            if (textView != null) {
                i3 = R.id.buyLoading;
                LinearLayout linearLayout2 = (LinearLayout) i1.m.p(viewInflate, R.id.buyLoading);
                if (linearLayout2 != null) {
                    i3 = R.id.buyMsg;
                    TextView textView2 = (TextView) i1.m.p(viewInflate, R.id.buyMsg);
                    if (textView2 != null) {
                        i3 = R.id.buyPacks;
                        LinearLayout linearLayout3 = (LinearLayout) i1.m.p(viewInflate, R.id.buyPacks);
                        if (linearLayout3 != null) {
                            i3 = R.id.buyPick;
                            ScrollView scrollView = (ScrollView) i1.m.p(viewInflate, R.id.buyPick);
                            if (scrollView != null) {
                                i3 = R.id.buyRetry;
                                TextView textView3 = (TextView) i1.m.p(viewInflate, R.id.buyRetry);
                                if (textView3 != null) {
                                    i3 = R.id.buyTitle;
                                    TextView textView4 = (TextView) i1.m.p(viewInflate, R.id.buyTitle);
                                    if (textView4 != null) {
                                        i3 = R.id.segAll;
                                        TextView textView5 = (TextView) i1.m.p(viewInflate, R.id.segAll);
                                        if (textView5 != null) {
                                            i3 = R.id.segLife;
                                            TextView textView6 = (TextView) i1.m.p(viewInflate, R.id.segLife);
                                            if (textView6 != null) {
                                                i3 = R.id.segMonth;
                                                TextView textView7 = (TextView) i1.m.p(viewInflate, R.id.segMonth);
                                                if (textView7 != null) {
                                                    i3 = R.id.segOne;
                                                    TextView textView8 = (TextView) i1.m.p(viewInflate, R.id.segOne);
                                                    if (textView8 != null) {
                                                        s2.j jVar = new s2.j();
                                                        jVar.f3881a = (FrameLayout) viewInflate;
                                                        jVar.f3882b = linearLayout;
                                                        jVar.f3883c = textView;
                                                        jVar.f3884d = linearLayout2;
                                                        jVar.f3885e = textView2;
                                                        jVar.f = linearLayout3;
                                                        jVar.f3886g = scrollView;
                                                        jVar.f3887h = textView3;
                                                        jVar.f3888i = textView5;
                                                        jVar.f3889j = textView6;
                                                        jVar.f3890k = textView7;
                                                        jVar.f3891l = textView8;
                                                        this.V = jVar;
                                                        textView4.setTypeface(f0.m.b(J(), R.font.chakra_petch_bold));
                                                        s2.j jVar2 = this.V;
                                                        kotlin.jvm.internal.d.c(jVar2);
                                                        final int i4 = 0;
                                                        ((TextView) jVar2.f3891l).setOnClickListener(new View.OnClickListener(this) { // from class: a4.a

                                                            /* JADX INFO: renamed from: b, reason: collision with root package name */
                                                            public final /* synthetic */ e f70b;

                                                            {
                                                                this.f70b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                switch (i4) {
                                                                    case 0:
                                                                        e this$0 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$0, "this$0");
                                                                        this$0.Z = "one";
                                                                        this$0.R();
                                                                        break;
                                                                    case 1:
                                                                        e this$1 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$1, "this$0");
                                                                        this$1.Z = "all";
                                                                        this$1.R();
                                                                        break;
                                                                    case 2:
                                                                        e this$2 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$2, "this$0");
                                                                        this$2.f79a0 = "month";
                                                                        this$2.R();
                                                                        break;
                                                                    case 3:
                                                                        e this$3 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$3, "this$0");
                                                                        this$3.f79a0 = "life";
                                                                        this$3.R();
                                                                        break;
                                                                    case 4:
                                                                        e this$4 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$4, "this$0");
                                                                        this$4.O();
                                                                        break;
                                                                    default:
                                                                        e this$5 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$5, "this$0");
                                                                        top.niunaijun.blackboxa.util.g gVar = this$5.f80b0;
                                                                        if (gVar != null) {
                                                                            String str = gVar.f4120k;
                                                                            if (str.length() == 0) {
                                                                                this$5.S(this$5.m(R.string.buy_kofi_none));
                                                                            } else {
                                                                                try {
                                                                                    this$5.N(new Intent("android.intent.action.VIEW", Uri.parse("https://ko-fi.com/s/".concat(str))));
                                                                                } catch (Exception e4) {
                                                                                    e4.getMessage();
                                                                                }
                                                                            }
                                                                            break;
                                                                        }
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        s2.j jVar3 = this.V;
                                                        kotlin.jvm.internal.d.c(jVar3);
                                                        final int i5 = 1;
                                                        ((TextView) jVar3.f3888i).setOnClickListener(new View.OnClickListener(this) { // from class: a4.a

                                                            /* JADX INFO: renamed from: b, reason: collision with root package name */
                                                            public final /* synthetic */ e f70b;

                                                            {
                                                                this.f70b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                switch (i5) {
                                                                    case 0:
                                                                        e this$0 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$0, "this$0");
                                                                        this$0.Z = "one";
                                                                        this$0.R();
                                                                        break;
                                                                    case 1:
                                                                        e this$1 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$1, "this$0");
                                                                        this$1.Z = "all";
                                                                        this$1.R();
                                                                        break;
                                                                    case 2:
                                                                        e this$2 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$2, "this$0");
                                                                        this$2.f79a0 = "month";
                                                                        this$2.R();
                                                                        break;
                                                                    case 3:
                                                                        e this$3 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$3, "this$0");
                                                                        this$3.f79a0 = "life";
                                                                        this$3.R();
                                                                        break;
                                                                    case 4:
                                                                        e this$4 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$4, "this$0");
                                                                        this$4.O();
                                                                        break;
                                                                    default:
                                                                        e this$5 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$5, "this$0");
                                                                        top.niunaijun.blackboxa.util.g gVar = this$5.f80b0;
                                                                        if (gVar != null) {
                                                                            String str = gVar.f4120k;
                                                                            if (str.length() == 0) {
                                                                                this$5.S(this$5.m(R.string.buy_kofi_none));
                                                                            } else {
                                                                                try {
                                                                                    this$5.N(new Intent("android.intent.action.VIEW", Uri.parse("https://ko-fi.com/s/".concat(str))));
                                                                                } catch (Exception e4) {
                                                                                    e4.getMessage();
                                                                                }
                                                                            }
                                                                            break;
                                                                        }
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        s2.j jVar4 = this.V;
                                                        kotlin.jvm.internal.d.c(jVar4);
                                                        final int i6 = 2;
                                                        ((TextView) jVar4.f3890k).setOnClickListener(new View.OnClickListener(this) { // from class: a4.a

                                                            /* JADX INFO: renamed from: b, reason: collision with root package name */
                                                            public final /* synthetic */ e f70b;

                                                            {
                                                                this.f70b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                switch (i6) {
                                                                    case 0:
                                                                        e this$0 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$0, "this$0");
                                                                        this$0.Z = "one";
                                                                        this$0.R();
                                                                        break;
                                                                    case 1:
                                                                        e this$1 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$1, "this$0");
                                                                        this$1.Z = "all";
                                                                        this$1.R();
                                                                        break;
                                                                    case 2:
                                                                        e this$2 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$2, "this$0");
                                                                        this$2.f79a0 = "month";
                                                                        this$2.R();
                                                                        break;
                                                                    case 3:
                                                                        e this$3 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$3, "this$0");
                                                                        this$3.f79a0 = "life";
                                                                        this$3.R();
                                                                        break;
                                                                    case 4:
                                                                        e this$4 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$4, "this$0");
                                                                        this$4.O();
                                                                        break;
                                                                    default:
                                                                        e this$5 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$5, "this$0");
                                                                        top.niunaijun.blackboxa.util.g gVar = this$5.f80b0;
                                                                        if (gVar != null) {
                                                                            String str = gVar.f4120k;
                                                                            if (str.length() == 0) {
                                                                                this$5.S(this$5.m(R.string.buy_kofi_none));
                                                                            } else {
                                                                                try {
                                                                                    this$5.N(new Intent("android.intent.action.VIEW", Uri.parse("https://ko-fi.com/s/".concat(str))));
                                                                                } catch (Exception e4) {
                                                                                    e4.getMessage();
                                                                                }
                                                                            }
                                                                            break;
                                                                        }
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        s2.j jVar5 = this.V;
                                                        kotlin.jvm.internal.d.c(jVar5);
                                                        final int i7 = 3;
                                                        ((TextView) jVar5.f3889j).setOnClickListener(new View.OnClickListener(this) { // from class: a4.a

                                                            /* JADX INFO: renamed from: b, reason: collision with root package name */
                                                            public final /* synthetic */ e f70b;

                                                            {
                                                                this.f70b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                switch (i7) {
                                                                    case 0:
                                                                        e this$0 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$0, "this$0");
                                                                        this$0.Z = "one";
                                                                        this$0.R();
                                                                        break;
                                                                    case 1:
                                                                        e this$1 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$1, "this$0");
                                                                        this$1.Z = "all";
                                                                        this$1.R();
                                                                        break;
                                                                    case 2:
                                                                        e this$2 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$2, "this$0");
                                                                        this$2.f79a0 = "month";
                                                                        this$2.R();
                                                                        break;
                                                                    case 3:
                                                                        e this$3 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$3, "this$0");
                                                                        this$3.f79a0 = "life";
                                                                        this$3.R();
                                                                        break;
                                                                    case 4:
                                                                        e this$4 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$4, "this$0");
                                                                        this$4.O();
                                                                        break;
                                                                    default:
                                                                        e this$5 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$5, "this$0");
                                                                        top.niunaijun.blackboxa.util.g gVar = this$5.f80b0;
                                                                        if (gVar != null) {
                                                                            String str = gVar.f4120k;
                                                                            if (str.length() == 0) {
                                                                                this$5.S(this$5.m(R.string.buy_kofi_none));
                                                                            } else {
                                                                                try {
                                                                                    this$5.N(new Intent("android.intent.action.VIEW", Uri.parse("https://ko-fi.com/s/".concat(str))));
                                                                                } catch (Exception e4) {
                                                                                    e4.getMessage();
                                                                                }
                                                                            }
                                                                            break;
                                                                        }
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        s2.j jVar6 = this.V;
                                                        kotlin.jvm.internal.d.c(jVar6);
                                                        final int i8 = 4;
                                                        ((TextView) jVar6.f3887h).setOnClickListener(new View.OnClickListener(this) { // from class: a4.a

                                                            /* JADX INFO: renamed from: b, reason: collision with root package name */
                                                            public final /* synthetic */ e f70b;

                                                            {
                                                                this.f70b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                switch (i8) {
                                                                    case 0:
                                                                        e this$0 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$0, "this$0");
                                                                        this$0.Z = "one";
                                                                        this$0.R();
                                                                        break;
                                                                    case 1:
                                                                        e this$1 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$1, "this$0");
                                                                        this$1.Z = "all";
                                                                        this$1.R();
                                                                        break;
                                                                    case 2:
                                                                        e this$2 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$2, "this$0");
                                                                        this$2.f79a0 = "month";
                                                                        this$2.R();
                                                                        break;
                                                                    case 3:
                                                                        e this$3 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$3, "this$0");
                                                                        this$3.f79a0 = "life";
                                                                        this$3.R();
                                                                        break;
                                                                    case 4:
                                                                        e this$4 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$4, "this$0");
                                                                        this$4.O();
                                                                        break;
                                                                    default:
                                                                        e this$5 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$5, "this$0");
                                                                        top.niunaijun.blackboxa.util.g gVar = this$5.f80b0;
                                                                        if (gVar != null) {
                                                                            String str = gVar.f4120k;
                                                                            if (str.length() == 0) {
                                                                                this$5.S(this$5.m(R.string.buy_kofi_none));
                                                                            } else {
                                                                                try {
                                                                                    this$5.N(new Intent("android.intent.action.VIEW", Uri.parse("https://ko-fi.com/s/".concat(str))));
                                                                                } catch (Exception e4) {
                                                                                    e4.getMessage();
                                                                                }
                                                                            }
                                                                            break;
                                                                        }
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        s2.j jVar7 = this.V;
                                                        kotlin.jvm.internal.d.c(jVar7);
                                                        final int i9 = 5;
                                                        ((TextView) jVar7.f3883c).setOnClickListener(new View.OnClickListener(this) { // from class: a4.a

                                                            /* JADX INFO: renamed from: b, reason: collision with root package name */
                                                            public final /* synthetic */ e f70b;

                                                            {
                                                                this.f70b = this;
                                                            }

                                                            @Override // android.view.View.OnClickListener
                                                            public final void onClick(View view) {
                                                                switch (i9) {
                                                                    case 0:
                                                                        e this$0 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$0, "this$0");
                                                                        this$0.Z = "one";
                                                                        this$0.R();
                                                                        break;
                                                                    case 1:
                                                                        e this$1 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$1, "this$0");
                                                                        this$1.Z = "all";
                                                                        this$1.R();
                                                                        break;
                                                                    case 2:
                                                                        e this$2 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$2, "this$0");
                                                                        this$2.f79a0 = "month";
                                                                        this$2.R();
                                                                        break;
                                                                    case 3:
                                                                        e this$3 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$3, "this$0");
                                                                        this$3.f79a0 = "life";
                                                                        this$3.R();
                                                                        break;
                                                                    case 4:
                                                                        e this$4 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$4, "this$0");
                                                                        this$4.O();
                                                                        break;
                                                                    default:
                                                                        e this$5 = this.f70b;
                                                                        kotlin.jvm.internal.d.f(this$5, "this$0");
                                                                        top.niunaijun.blackboxa.util.g gVar = this$5.f80b0;
                                                                        if (gVar != null) {
                                                                            String str = gVar.f4120k;
                                                                            if (str.length() == 0) {
                                                                                this$5.S(this$5.m(R.string.buy_kofi_none));
                                                                            } else {
                                                                                try {
                                                                                    this$5.N(new Intent("android.intent.action.VIEW", Uri.parse("https://ko-fi.com/s/".concat(str))));
                                                                                } catch (Exception e4) {
                                                                                    e4.getMessage();
                                                                                }
                                                                            }
                                                                            break;
                                                                        }
                                                                        break;
                                                                }
                                                            }
                                                        });
                                                        O();
                                                        s2.j jVar8 = this.V;
                                                        kotlin.jvm.internal.d.c(jVar8);
                                                        FrameLayout frameLayout = (FrameLayout) jVar8.f3881a;
                                                        kotlin.jvm.internal.d.e(frameLayout, "getRoot(...)");
                                                        return frameLayout;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i3)));
    }

    @Override // androidx.fragment.app.w
    public final void y() {
        this.C = true;
        this.V = null;
    }
}
