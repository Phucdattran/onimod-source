package a4;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.system.Os;
import android.system.OsConstants;
import android.widget.Toast;
import androidx.emoji2.text.v;
import androidx.emoji2.text.w;
import androidx.fragment.app.z;
import com.mod.menu.ModConfig;
import com.mod.menu.UnityApplier;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import org.json.JSONObject;
import top.niunaijun.blackbox.R;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.core.system.JarConfig;
import top.niunaijun.blackbox.entity.location.BCell;
import top.niunaijun.blackboxa.view.apps.AppsFragment;
import top.niunaijun.blackboxa.view.login.GoogleLoginActivity;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class g implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f83a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f84b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f85c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f86d;

    public /* synthetic */ g(int i3, Object obj, Object obj2, Object obj3) {
        this.f83a = i3;
        this.f84b = obj;
        this.f85c = obj2;
        this.f86d = obj3;
    }

    /* JADX WARN: Code duplicated, block: B:38:0x0128  */
    /* JADX WARN: Type inference failed for: r7v0, types: [a4.h] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 6 */
    @Override // java.lang.Runnable
    public final void run() {
        SharedPreferences sharedPreferences;
        String string;
        Iterator it;
        top.niunaijun.blackboxa.util.i iVar;
        long jSysconf;
        boolean z4;
        Throwable th;
        String strC;
        String str;
        String absolutePath;
        z zVarG;
        top.niunaijun.blackboxa.util.i iVar2 = null;
        switch (this.f83a) {
            case 0:
                final GoogleLoginActivity googleLoginActivity = (GoogleLoginActivity) this.f84b;
                String str2 = (String) this.f85c;
                String str3 = (String) this.f86d;
                int i3 = GoogleLoginActivity.D;
                try {
                    a2.g gVar = new a2.g(googleLoginActivity);
                    e.g gVar2 = (e.g) gVar.f44b;
                    gVar2.f1705d = str2;
                    gVar2.f = str3;
                    gVar2.f1712l = false;
                    String string2 = googleLoginActivity.getString(R.string.close);
                    ?? r7 = new DialogInterface.OnClickListener() { // from class: a4.h
                        @Override // android.content.DialogInterface.OnClickListener
                        public final void onClick(DialogInterface dialogInterface, int i4) {
                            int i5 = GoogleLoginActivity.D;
                            GoogleLoginActivity this$0 = googleLoginActivity;
                            kotlin.jvm.internal.d.f(this$0, "this$0");
                            this$0.finish();
                        }
                    };
                    gVar2.f1707g = string2;
                    gVar2.f1708h = r7;
                    String string3 = googleLoginActivity.getString(R.string.copy_error);
                    i iVar3 = new i(googleLoginActivity, str2, str3, 0);
                    gVar2.f1710j = string3;
                    gVar2.f1711k = iVar3;
                    gVar.b().show();
                    return;
                } catch (Throwable unused) {
                    Toast.makeText(googleLoginActivity, str2 + ": " + str3, 1).show();
                    googleLoginActivity.finish();
                    return;
                }
            case 1:
                a0.b bVar = (a0.b) this.f84b;
                a3.a aVar = (a3.a) this.f85c;
                ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) this.f86d;
                try {
                    w wVarR = a3.a.r((Context) bVar.f3b);
                    if (wVarR == null) {
                        throw new RuntimeException("EmojiCompat font provider not available on this device.");
                    }
                    v vVar = (v) ((androidx.emoji2.text.l) wVarR.f533b);
                    synchronized (vVar.f568d) {
                        vVar.f = threadPoolExecutor;
                        break;
                    }
                    ((androidx.emoji2.text.l) wVarR.f533b).c(new androidx.emoji2.text.n(aVar, threadPoolExecutor));
                    return;
                } catch (Throwable th2) {
                    aVar.T(th2);
                    threadPoolExecutor.shutdown();
                    return;
                }
            case 2:
                UnityApplier.lambda$startOverlayWatch$0((List) this.f84b, (Context) this.f85c, (File) this.f86d);
                return;
            case 3:
                ((BActivityThread) this.f84b).lambda$handleNewIntent$2((Intent) this.f85c, (IBinder) this.f86d);
                return;
            case 4:
                String str4 = "oni_beacon";
                Context context = (Context) this.f84b;
                top.niunaijun.blackboxa.view.base.c cVar = (top.niunaijun.blackboxa.view.base.c) this.f85c;
                AppsFragment appsFragment = (AppsFragment) this.f86d;
                String str5 = "VM-";
                String str6 = "at";
                String str7 = "pkg";
                kotlin.jvm.internal.d.c(context);
                String str8 = ModConfig.PREFIX;
                if (Build.VERSION.SDK_INT >= 30 && (string = (sharedPreferences = context.getSharedPreferences("oni_diag", 0)).getString("pkg", null)) != null) {
                    long j4 = sharedPreferences.getLong("at", 0L);
                    if (j4 != 0 && System.currentTimeMillis() - j4 <= 60000) {
                        Object systemService = context.getSystemService("activity");
                        kotlin.jvm.internal.d.d(systemService, "null cannot be cast to non-null type android.app.ActivityManager");
                        try {
                            List historicalProcessExitReasons = ((ActivityManager) systemService).getHistoricalProcessExitReasons(context.getPackageName(), 0, 40);
                            kotlin.jvm.internal.d.c(historicalProcessExitReasons);
                            Iterator it2 = historicalProcessExitReasons.iterator();
                            iVar2 = null;
                            while (true) {
                                if (it2.hasNext()) {
                                    ApplicationExitInfo applicationExitInfoC = p0.d.c(it2.next());
                                    str4 = str4;
                                    if (applicationExitInfoC.getTimestamp() >= j4 - ((long) 3000)) {
                                        switch (applicationExitInfoC.getReason()) {
                                            case 2:
                                            case 3:
                                            case 4:
                                            case 5:
                                            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                                            case 9:
                                            case 12:
                                            case 13:
                                            case 14:
                                                String processName = applicationExitInfoC.getProcessName();
                                                if (processName == null) {
                                                    processName = str8;
                                                }
                                                boolean z5 = processName.equals(context.getPackageName()) || kotlin.text.l.R(processName, ":black", false);
                                                String strC2 = g0.e.c(z5 ? str5 : str8, top.niunaijun.blackboxa.util.b.L(applicationExitInfoC.getReason()));
                                                it = it2;
                                                int status = applicationExitInfoC.getStatus();
                                                iVar = iVar2;
                                                StringBuilder sb = new StringBuilder("=== ONIMOD DIAG ===\ngame    : ");
                                                sb.append(string);
                                                sb.append("\nproc    : ");
                                                sb.append(applicationExitInfoC.getProcessName());
                                                sb.append("\nreason  : ");
                                                sb.append(top.niunaijun.blackboxa.util.b.L(applicationExitInfoC.getReason()));
                                                sb.append(" (");
                                                sb.append(applicationExitInfoC.getReason());
                                                sb.append(")\nsignal  : ");
                                                sb.append(applicationExitInfoC.getStatus());
                                                sb.append("\ndesc    : ");
                                                String description = applicationExitInfoC.getDescription();
                                                if (description == null) {
                                                    description = str8;
                                                }
                                                sb.append(description);
                                                sb.append("\npageSize: ");
                                                try {
                                                    jSysconf = Os.sysconf(OsConstants._SC_PAGESIZE);
                                                } catch (Throwable unused2) {
                                                    jSysconf = -1;
                                                }
                                                sb.append(jSysconf);
                                                sb.append("\ndevice  : ");
                                                sb.append(Build.MANUFACTURER);
                                                sb.append(' ');
                                                sb.append(Build.MODEL);
                                                sb.append("  A");
                                                sb.append(Build.VERSION.RELEASE);
                                                sb.append(" sdk");
                                                sb.append(Build.VERSION.SDK_INT);
                                                sb.append(' ');
                                                String[] SUPPORTED_ABIS = Build.SUPPORTED_ABIS;
                                                kotlin.jvm.internal.d.e(SUPPORTED_ABIS, "SUPPORTED_ABIS");
                                                sb.append(SUPPORTED_ABIS.length == 0 ? null : SUPPORTED_ABIS[0]);
                                                sb.append("\ntime    : ");
                                                sb.append(applicationExitInfoC.getTimestamp());
                                                sb.append('\n');
                                                try {
                                                    InputStream traceInputStream = applicationExitInfoC.getTraceInputStream();
                                                    if (traceInputStream != null) {
                                                        z4 = z5;
                                                        try {
                                                            str8 = str8;
                                                            try {
                                                                int iOptInt = top.niunaijun.blackboxa.util.b.q(context).optInt("diag_trace_max", 8000);
                                                                try {
                                                                    str5 = str5;
                                                                    try {
                                                                        boolean zOptBoolean = top.niunaijun.blackboxa.util.b.q(context).optBoolean("diag_trace_raw", false);
                                                                        try {
                                                                            sb.append("--- trace (rút gọn) ---\n");
                                                                            try {
                                                                                str6 = str6;
                                                                                try {
                                                                                    int iOptInt2 = top.niunaijun.blackboxa.util.b.q(context).optInt("diag_trace_bytes", 524288);
                                                                                    try {
                                                                                        byte[] bArrCopyOf = new byte[iOptInt2];
                                                                                        int i4 = 0;
                                                                                        while (true) {
                                                                                            if (i4 < iOptInt2) {
                                                                                                str7 = str7;
                                                                                                try {
                                                                                                    int i5 = traceInputStream.read(bArrCopyOf, i4, iOptInt2 - i4);
                                                                                                    if (i5 > 0) {
                                                                                                        i4 += i5;
                                                                                                        str7 = str7;
                                                                                                    }
                                                                                                } catch (Throwable th3) {
                                                                                                    th = th3;
                                                                                                    th = th;
                                                                                                    try {
                                                                                                        throw th;
                                                                                                    } catch (Throwable th4) {
                                                                                                        a3.a.j(traceInputStream, th);
                                                                                                        throw th4;
                                                                                                    }
                                                                                                }
                                                                                            } else {
                                                                                                str7 = str7;
                                                                                            }
                                                                                        }
                                                                                        if (i4 != iOptInt2) {
                                                                                            bArrCopyOf = Arrays.copyOf(bArrCopyOf, i4);
                                                                                            kotlin.jvm.internal.d.e(bArrCopyOf, "copyOf(...)");
                                                                                        }
                                                                                        sb.append(top.niunaijun.blackboxa.util.b.K(bArrCopyOf, iOptInt, zOptBoolean));
                                                                                        sb.append('\n');
                                                                                        try {
                                                                                            traceInputStream.close();
                                                                                        } catch (Throwable unused3) {
                                                                                        }
                                                                                    } catch (Throwable th5) {
                                                                                        th = th5;
                                                                                        str7 = str7;
                                                                                        th = th;
                                                                                        throw th;
                                                                                    }
                                                                                } catch (Throwable th6) {
                                                                                    th = th6;
                                                                                }
                                                                            } catch (Throwable th7) {
                                                                                th = th7;
                                                                                str6 = str6;
                                                                            }
                                                                        } catch (Throwable th8) {
                                                                            th = th8;
                                                                            str6 = str6;
                                                                            str7 = str7;
                                                                            th = th;
                                                                            throw th;
                                                                        }
                                                                    } catch (Throwable th9) {
                                                                        th = th9;
                                                                    }
                                                                } catch (Throwable th10) {
                                                                    th = th10;
                                                                    str5 = str5;
                                                                }
                                                            } catch (Throwable th11) {
                                                                th = th11;
                                                                str5 = str5;
                                                                str6 = str6;
                                                                str7 = str7;
                                                                th = th;
                                                                throw th;
                                                            }
                                                        } catch (Throwable th12) {
                                                            th = th12;
                                                            str8 = str8;
                                                        }
                                                    } else {
                                                        z4 = z5;
                                                        str5 = str5;
                                                        str6 = str6;
                                                        str7 = str7;
                                                        str8 = str8;
                                                    }
                                                } catch (Throwable unused4) {
                                                    z4 = z5;
                                                    str5 = str5;
                                                    str6 = str6;
                                                    str7 = str7;
                                                    str8 = str8;
                                                }
                                                String string4 = sb.toString();
                                                kotlin.jvm.internal.d.e(string4, "toString(...)");
                                                top.niunaijun.blackboxa.util.i iVar4 = new top.niunaijun.blackboxa.util.i(string, strC2, status, string4);
                                                if (!z4) {
                                                    iVar2 = iVar4;
                                                } else if (iVar != null) {
                                                    it2 = it;
                                                    iVar2 = iVar;
                                                } else {
                                                    iVar2 = iVar4;
                                                    it2 = it;
                                                }
                                                break;
                                            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                                            case 8:
                                            case JarConfig.MAX_CACHE_SIZE /* 10 */:
                                            case 11:
                                            default:
                                                it = it2;
                                                iVar = iVar2;
                                                str5 = str5;
                                                str6 = str6;
                                                str7 = str7;
                                                str8 = str8;
                                                it2 = it;
                                                iVar2 = iVar;
                                                break;
                                        }
                                    } else {
                                        it = it2;
                                        iVar = iVar2;
                                        str5 = str5;
                                        str6 = str6;
                                        str7 = str7;
                                        str8 = str8;
                                        it2 = it;
                                        iVar2 = iVar;
                                    }
                                    str8 = str8;
                                    str5 = str5;
                                    str6 = str6;
                                    str7 = str7;
                                } else {
                                    str4 = str4;
                                    str5 = str5;
                                    str6 = str6;
                                    str7 = str7;
                                    str8 = str8;
                                }
                            }
                        } catch (Throwable unused5) {
                            iVar2 = null;
                        }
                    }
                    iVar2 = null;
                } else {
                    str4 = str4;
                    str5 = str5;
                    str6 = str6;
                    str7 = str7;
                    str8 = str8;
                }
                if (iVar2 != null) {
                    String str9 = iVar2.f4122b;
                    int i6 = iVar2.f4123c;
                    strC = g0.e.c(str9, i6 != 0 ? g0.e.b(i6, "·") : str8);
                } else {
                    strC = null;
                }
                String str10 = iVar2 != null ? iVar2.f4124d : null;
                String str11 = str4;
                try {
                    SharedPreferences sharedPreferences2 = context.getSharedPreferences(str11, 0);
                    str = null;
                    try {
                        String string5 = sharedPreferences2.getString("pending", null);
                        if (string5 != null) {
                            sharedPreferences2.edit().remove("pending").apply();
                            top.niunaijun.blackboxa.util.b.h(context, new JSONObject(string5), strC, str10);
                        }
                        if (context.getSharedPreferences(str11, 0).getBoolean("enabled", false)) {
                            new Thread(new c1.h(context.getApplicationContext(), 3)).start();
                            break;
                        }
                    } catch (Throwable unused6) {
                    }
                } catch (Throwable unused7) {
                    str = null;
                }
                if (iVar2 == null) {
                    return;
                }
                if (cVar != null && (zVarG = appsFragment.g()) != null) {
                    zVarG.runOnUiThread(new d(appsFragment, 12, cVar));
                }
                context.getSharedPreferences("oni_diag", 0).edit().remove(str7).remove(str6).apply();
                String reason = iVar2.f4122b;
                int i7 = iVar2.f4123c;
                kotlin.jvm.internal.d.f(reason, "reason");
                String strF0 = kotlin.text.e.f0(reason, str5);
                if (kotlin.text.l.V(strF0, "CRASH-") || strF0.equals("ANR") || (strF0.equals("Signal") && i7 != 9)) {
                    String str12 = iVar2.f4124d;
                    try {
                        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "onimod_diag");
                        if (!file.exists()) {
                            file.mkdirs();
                        }
                        File file2 = new File(file, "crash_" + System.currentTimeMillis() + ".txt");
                        h3.h.o0(file2, str12, kotlin.text.a.f2863a);
                        top.niunaijun.blackboxa.util.b.J();
                        absolutePath = file2.getAbsolutePath();
                        break;
                    } catch (Throwable unused8) {
                        absolutePath = str;
                    }
                    z zVarG2 = appsFragment.g();
                    if (zVarG2 != null) {
                        zVarG2.runOnUiThread(new g(appsFragment, iVar2, absolutePath));
                        return;
                    }
                    return;
                }
                return;
            case 5:
                AppsFragment appsFragment2 = (AppsFragment) this.f84b;
                top.niunaijun.blackboxa.util.i iVar5 = (top.niunaijun.blackboxa.util.i) this.f86d;
                String strM = (String) this.f85c;
                if (appsFragment2.r()) {
                    com.afollestad.materialdialogs.a aVar2 = new com.afollestad.materialdialogs.a(appsFragment2.J());
                    com.afollestad.materialdialogs.a.e(aVar2, Integer.valueOf(R.string.crash_title), null, 2);
                    String str13 = iVar5.f4122b;
                    Integer numValueOf = Integer.valueOf(iVar5.f4123c);
                    if (strM == null) {
                        strM = appsFragment2.m(R.string.crash_no_file);
                        kotlin.jvm.internal.d.e(strM, "getString(...)");
                    }
                    com.afollestad.materialdialogs.a.b(aVar2, null, appsFragment2.n(new Object[]{str13, numValueOf, strM}, R.string.crash_msg), 5);
                    com.afollestad.materialdialogs.a.d(aVar2, Integer.valueOf(R.string.ok), null, null, 6);
                    aVar2.show();
                    return;
                }
                return;
            default:
                androidx.lifecycle.w appsLiveData = (androidx.lifecycle.w) this.f84b;
                ArrayList arrayList = (ArrayList) this.f85c;
                top.niunaijun.blackboxa.data.a this$0 = (top.niunaijun.blackboxa.data.a) this.f86d;
                kotlin.jvm.internal.d.f(appsLiveData, "$appsLiveData");
                kotlin.jvm.internal.d.f(this$0, "this$0");
                try {
                    appsLiveData.f(arrayList);
                    return;
                } catch (Exception e4) {
                    e4.getMessage();
                    return;
                }
        }
    }

    public /* synthetic */ g(AppsFragment appsFragment, top.niunaijun.blackboxa.util.i iVar, String str) {
        this.f83a = 5;
        this.f84b = appsFragment;
        this.f86d = iVar;
        this.f85c = str;
    }
}
