package a3;

import a0.k;
import android.R;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.os.StrictMode;
import android.os.Trace;
import android.text.TextUtils;
import android.util.LongSparseArray;
import android.util.TypedValue;
import android.view.View;
import androidx.activity.u;
import androidx.emoji2.text.v;
import androidx.emoji2.text.w;
import androidx.fragment.app.z;
import b3.b;
import b3.e;
import c0.g;
import c0.h;
import com.afollestad.materialdialogs.internal.button.DialogActionButtonLayout;
import g0.f;
import i1.m;
import j3.p;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.internal.d;
import l.o2;
import l0.j;
import t1.c;
import top.niunaijun.blackbox.core.system.JarConfig;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static Field f56a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static boolean f57b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Class f58c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static boolean f59d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Field f60e;
    public static boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static Field f61g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static boolean f62h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static Method f63i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static boolean f64j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static Method f65k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static boolean f66l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static long f67m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static Method f68n;

    public a() {
        new ConcurrentHashMap();
    }

    public static f[] A(f[] fVarArr) {
        f[] fVarArr2 = new f[fVarArr.length];
        for (int i3 = 0; i3 < fVarArr.length; i3++) {
            fVarArr2[i3] = new f(fVarArr[i3]);
        }
        return fVarArr2;
    }

    public static void C(Object obj) {
        LongSparseArray longSparseArray;
        if (!f59d) {
            try {
                f58c = Class.forName("android.content.res.ThemedResourceCache");
            } catch (ClassNotFoundException unused) {
            }
            f59d = true;
        }
        Class cls = f58c;
        if (cls == null) {
            return;
        }
        if (!f) {
            try {
                Field declaredField = cls.getDeclaredField("mUnthemedEntries");
                f60e = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException unused2) {
            }
            f = true;
        }
        Field field = f60e;
        if (field == null) {
            return;
        }
        try {
            longSparseArray = (LongSparseArray) field.get(obj);
        } catch (IllegalAccessException unused3) {
            longSparseArray = null;
        }
        if (longSparseArray != null) {
            longSparseArray.clear();
        }
    }

    public static Object D(e eVar, Object obj, p operation) {
        d.f(operation, "operation");
        return operation.j(obj, eVar);
    }

    public static int E(Context context, int i3, int i4) {
        Integer numValueOf;
        TypedValue typedValueH = m.H(context, i3);
        if (typedValueH != null) {
            int i5 = typedValueH.resourceId;
            numValueOf = Integer.valueOf(i5 != 0 ? g.b(context, i5) : typedValueH.data);
        } else {
            numValueOf = null;
        }
        return numValueOf != null ? numValueOf.intValue() : i4;
    }

    public static int F(View view, int i3) {
        Context context = view.getContext();
        TypedValue typedValueL = m.L(view.getContext(), view.getClass().getCanonicalName(), i3);
        int i4 = typedValueL.resourceId;
        return i4 != 0 ? g.b(context, i4) : typedValueL.data;
    }

    public static Drawable G(Context context, int i3) {
        return o2.d().f(context, i3);
    }

    public static Set H() {
        try {
            Object objInvoke = Class.forName("android.text.EmojiConsistency").getMethod("getEmojiConsistencySet", null).invoke(null, null);
            if (objInvoke == null) {
                return Collections.EMPTY_SET;
            }
            Set set = (Set) objInvoke;
            Iterator it = set.iterator();
            while (it.hasNext()) {
                if (!(it.next() instanceof int[])) {
                    return Collections.EMPTY_SET;
                }
            }
            return set;
        } catch (Throwable unused) {
            return Collections.EMPTY_SET;
        }
    }

    public static int I(Drawable drawable) {
        if (Build.VERSION.SDK_INT >= 23) {
            return d0.a.e(drawable);
        }
        if (!f66l) {
            try {
                Method declaredMethod = Drawable.class.getDeclaredMethod("getLayoutDirection", null);
                f65k = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            f66l = true;
        }
        Method method = f65k;
        if (method == null) {
            return 0;
        }
        try {
            return ((Integer) method.invoke(drawable, null)).intValue();
        } catch (Exception unused2) {
            f65k = null;
            return 0;
        }
    }

    public static File K(Context context) {
        File cacheDir = context.getCacheDir();
        if (cacheDir == null) {
            return null;
        }
        String str = ".font" + Process.myPid() + "-" + Process.myTid() + "-";
        for (int i3 = 0; i3 < 100; i3++) {
            File file = new File(cacheDir, str + i3);
            try {
                if (file.createNewFile()) {
                    return file;
                }
            } catch (IOException unused) {
            }
        }
        return null;
    }

    public static final boolean L(Context context) {
        d.g(context, "context");
        int iC = c.c(context, null, Integer.valueOf(R.attr.textColorPrimary), null, 10);
        if (iC == 0) {
            return false;
        }
        return ((double) 1) - (((((double) Color.blue(iC)) * 0.114d) + ((((double) Color.green(iC)) * 0.587d) + (((double) Color.red(iC)) * 0.299d))) / ((double) 255)) >= 0.5d;
    }

    public static b M(b bVar) {
        d.f(bVar, "<this>");
        ContinuationImpl continuationImpl = bVar instanceof ContinuationImpl ? (ContinuationImpl) bVar : null;
        return continuationImpl != null ? continuationImpl.n() : bVar;
    }

    public static boolean N(int i3) {
        if (i3 == 0) {
            return false;
        }
        ThreadLocal threadLocal = g0.a.f2318a;
        double[] dArr = (double[]) threadLocal.get();
        if (dArr == null) {
            dArr = new double[3];
            threadLocal.set(dArr);
        }
        int iRed = Color.red(i3);
        int iGreen = Color.green(i3);
        int iBlue = Color.blue(i3);
        if (dArr.length != 3) {
            throw new IllegalArgumentException("outXyz must have a length of 3.");
        }
        double d4 = ((double) iRed) / 255.0d;
        double dPow = d4 < 0.04045d ? d4 / 12.92d : Math.pow((d4 + 0.055d) / 1.055d, 2.4d);
        double d5 = ((double) iGreen) / 255.0d;
        double dPow2 = d5 < 0.04045d ? d5 / 12.92d : Math.pow((d5 + 0.055d) / 1.055d, 2.4d);
        double d6 = ((double) iBlue) / 255.0d;
        double dPow3 = d6 < 0.04045d ? d6 / 12.92d : Math.pow((d6 + 0.055d) / 1.055d, 2.4d);
        dArr[0] = ((0.1805d * dPow3) + (0.3576d * dPow2) + (0.4124d * dPow)) * 100.0d;
        double d7 = ((0.0722d * dPow3) + (0.7152d * dPow2) + (0.2126d * dPow)) * 100.0d;
        dArr[1] = d7;
        dArr[2] = ((dPow3 * 0.9505d) + (dPow2 * 0.1192d) + (dPow * 0.0193d)) * 100.0d;
        return d7 / 100.0d > 0.5d;
    }

    public static boolean O() {
        if (Build.VERSION.SDK_INT >= 29) {
            return h1.a.a();
        }
        try {
            if (f68n == null) {
                f67m = Trace.class.getField("TRACE_TAG_APP").getLong(null);
                f68n = Trace.class.getMethod("isTagEnabled", Long.TYPE);
            }
            return ((Boolean) f68n.invoke(null, Long.valueOf(f67m))).booleanValue();
        } catch (Exception e4) {
            if (!(e4 instanceof InvocationTargetException)) {
                return false;
            }
            Throwable cause = e4.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            throw new RuntimeException(cause);
        }
    }

    public static boolean P(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            return e0.a.e(context.getSystemService(e0.a.f())).isRequestPinShortcutSupported();
        }
        if (g.a(context, "com.android.launcher.permission.INSTALL_SHORTCUT") == 0) {
            Iterator<ResolveInfo> it = context.getPackageManager().queryBroadcastReceivers(new Intent("com.android.launcher.action.INSTALL_SHORTCUT"), 0).iterator();
            while (it.hasNext()) {
                String str = it.next().activityInfo.permission;
                if (TextUtils.isEmpty(str) || "com.android.launcher.permission.INSTALL_SHORTCUT".equals(str)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static int Q(int i3, float f4, int i4) {
        return g0.a.b(g0.a.d(i4, Math.round(Color.alpha(i4) * f4)), i3);
    }

    public static b3.g R(e eVar, b3.f key) {
        d.f(key, "key");
        return d.a(eVar.getKey(), key) ? EmptyCoroutineContext.f2845a : eVar;
    }

    public static MappedByteBuffer S(Context context, Uri uri) {
        try {
            ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(uri, "r", null);
            if (parcelFileDescriptorOpenFileDescriptor == null) {
                if (parcelFileDescriptorOpenFileDescriptor != null) {
                    parcelFileDescriptorOpenFileDescriptor.close();
                    return null;
                }
                return null;
            }
            try {
                FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor());
                try {
                    FileChannel channel = fileInputStream.getChannel();
                    MappedByteBuffer map = channel.map(FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                    fileInputStream.close();
                    parcelFileDescriptorOpenFileDescriptor.close();
                    return map;
                } catch (Throwable th) {
                    try {
                        fileInputStream.close();
                        throw th;
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                        throw th;
                    }
                }
            } catch (Throwable th3) {
                try {
                    parcelFileDescriptorOpenFileDescriptor.close();
                    throw th3;
                } catch (Throwable th4) {
                    th3.addSuppressed(th4);
                    throw th3;
                }
            }
        } catch (IOException unused) {
        }
    }

    public static b3.g Y(e eVar, b3.g context) {
        d.f(context, "context");
        return kotlin.coroutines.a.a(eVar, context);
    }

    public static v0.b Z(MappedByteBuffer mappedByteBuffer) throws IOException {
        long j4;
        ByteBuffer byteBufferDuplicate = mappedByteBuffer.duplicate();
        byteBufferDuplicate.order(ByteOrder.BIG_ENDIAN);
        byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
        int i3 = byteBufferDuplicate.getShort() & 65535;
        if (i3 > 100) {
            throw new IOException("Cannot read metadata.");
        }
        byteBufferDuplicate.position(byteBufferDuplicate.position() + 6);
        int i4 = 0;
        while (true) {
            if (i4 >= i3) {
                j4 = -1;
                break;
            }
            int i5 = byteBufferDuplicate.getInt();
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
            j4 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
            if (1835365473 == i5) {
                break;
            }
            i4++;
        }
        if (j4 != -1) {
            byteBufferDuplicate.position(byteBufferDuplicate.position() + ((int) (j4 - ((long) byteBufferDuplicate.position()))));
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 12);
            long j5 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
            for (int i6 = 0; i6 < j5; i6++) {
                int i7 = byteBufferDuplicate.getInt();
                long j6 = ((long) byteBufferDuplicate.getInt()) & 4294967295L;
                byteBufferDuplicate.getInt();
                if (1164798569 == i7 || 1701669481 == i7) {
                    byteBufferDuplicate.position((int) (j6 + j4));
                    v0.b bVar = new v0.b();
                    byteBufferDuplicate.order(ByteOrder.LITTLE_ENDIAN);
                    int iPosition = byteBufferDuplicate.position() + byteBufferDuplicate.getInt(byteBufferDuplicate.position());
                    bVar.f3615d = byteBufferDuplicate;
                    bVar.f3612a = iPosition;
                    int i8 = iPosition - byteBufferDuplicate.getInt(iPosition);
                    bVar.f3613b = i8;
                    bVar.f3614c = ((ByteBuffer) bVar.f3615d).getShort(i8);
                    return bVar;
                }
            }
        }
        throw new IOException("Cannot read metadata.");
    }

    public static final String a0(Reader reader) throws IOException {
        StringWriter stringWriter = new StringWriter();
        char[] cArr = new char[JarConfig.DEFAULT_BUFFER_SIZE];
        int i3 = reader.read(cArr);
        while (i3 >= 0) {
            stringWriter.write(cArr, 0, i3);
            i3 = reader.read(cArr);
        }
        String string = stringWriter.toString();
        d.e(string, "toString(...)");
        return string;
    }

    public static final void c0(View view, u uVar) {
        d.f(view, "<this>");
        view.setTag(top.niunaijun.blackbox.R.id.view_tree_on_back_pressed_dispatcher_owner, uVar);
    }

    public static void d(String str) {
        if (str.length() > 127) {
            str = str.substring(0, 127);
        }
        Trace.beginSection(str);
    }

    public static final void d0(View view, f1.e eVar) {
        d.f(view, "<this>");
        view.setTag(top.niunaijun.blackbox.R.id.view_tree_saved_state_registry_owner, eVar);
    }

    public static boolean e0(Drawable drawable, int i3) {
        if (Build.VERSION.SDK_INT >= 23) {
            return d0.a.m(drawable, i3);
        }
        if (!f64j) {
            try {
                Method declaredMethod = Drawable.class.getDeclaredMethod("setLayoutDirection", Integer.TYPE);
                f63i = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            f64j = true;
        }
        Method method = f63i;
        if (method != null) {
            try {
                method.invoke(drawable, Integer.valueOf(i3));
                return true;
            } catch (Exception unused2) {
                f63i = null;
            }
        }
        return false;
    }

    public static boolean f(f[] fVarArr, f[] fVarArr2) {
        if (fVarArr == null || fVarArr2 == null || fVarArr.length != fVarArr2.length) {
            return false;
        }
        for (int i3 = 0; i3 < fVarArr.length; i3++) {
            f fVar = fVarArr[i3];
            char c3 = fVar.f2325a;
            f fVar2 = fVarArr2[i3];
            if (c3 != fVar2.f2325a || fVar.f2326b.length != fVar2.f2326b.length) {
                return false;
            }
        }
        return true;
    }

    public static void f0(Drawable drawable, int i3) {
        drawable.setTint(i3);
    }

    public static final boolean g0(DialogActionButtonLayout dialogActionButtonLayout) {
        if (dialogActionButtonLayout == null) {
            return false;
        }
        return !(dialogActionButtonLayout.getVisibleButtons().length == 0) || q1.b.L(dialogActionButtonLayout.getCheckBoxPrompt());
    }

    /* JADX WARN: Code duplicated, block: B:43:0x008a A[RETURN] */
    public static int h(Context context, String str) {
        int iCheckOpNoThrow;
        int iMyPid = Process.myPid();
        int iMyUid = Process.myUid();
        String packageName = context.getPackageName();
        if (context.checkPermission(str, iMyPid, iMyUid) != -1) {
            int i3 = Build.VERSION.SDK_INT;
            String strC = i3 >= 23 ? c0.a.c(str) : null;
            if (strC != null) {
                if (packageName == null) {
                    String[] packagesForUid = context.getPackageManager().getPackagesForUid(iMyUid);
                    if (packagesForUid != null && packagesForUid.length > 0) {
                        packageName = packagesForUid[0];
                    }
                }
                int iMyUid2 = Process.myUid();
                String packageName2 = context.getPackageName();
                int iB = 1;
                if (iMyUid2 == iMyUid && Objects.equals(packageName2, packageName)) {
                    if (i3 >= 29) {
                        AppOpsManager appOpsManagerB = h.b(context);
                        iCheckOpNoThrow = appOpsManagerB == null ? 1 : appOpsManagerB.checkOpNoThrow(strC, Binder.getCallingUid(), packageName);
                        if (iCheckOpNoThrow == 0) {
                            String strA = h.a(context);
                            if (appOpsManagerB != null) {
                                iB = appOpsManagerB.checkOpNoThrow(strC, iMyUid, strA);
                            }
                        }
                        if (iCheckOpNoThrow == 0) {
                            return -2;
                        }
                    } else if (i3 >= 23) {
                        iB = c0.a.b((AppOpsManager) c0.a.a(context), strC, packageName);
                    }
                } else if (i3 >= 23) {
                    iB = c0.a.b((AppOpsManager) c0.a.a(context), strC, packageName);
                }
                iCheckOpNoThrow = iB;
                if (iCheckOpNoThrow == 0) {
                    return -2;
                }
            }
            return 0;
        }
        return -1;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void i(Drawable drawable) {
        DrawableContainer.DrawableContainerState drawableContainerState;
        if (Build.VERSION.SDK_INT >= 23) {
            drawable.clearColorFilter();
            return;
        }
        drawable.clearColorFilter();
        if (drawable instanceof InsetDrawable) {
            i(((InsetDrawable) drawable).getDrawable());
            return;
        }
        if (drawable instanceof h0.e) {
            i(((h0.f) ((h0.e) drawable)).f);
            return;
        }
        if (!(drawable instanceof DrawableContainer) || (drawableContainerState = (DrawableContainer.DrawableContainerState) ((DrawableContainer) drawable).getConstantState()) == null) {
            return;
        }
        int childCount = drawableContainerState.getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            Drawable child = drawableContainerState.getChild(i3);
            if (child != null) {
                i(child);
            }
        }
    }

    public static final void j(Closeable closeable, Throwable th) throws IOException {
        if (closeable != null) {
            if (th == null) {
                closeable.close();
                return;
            }
            try {
                closeable.close();
            } catch (Throwable th2) {
                q1.b.b(th, th2);
            }
        }
    }

    public static int j0(Context context, int i3) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(R.style.Animation.Activity, new int[]{i3});
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, -1);
        typedArrayObtainStyledAttributes.recycle();
        return resourceId;
    }

    public static void k(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException unused) {
            }
        }
    }

    public static Drawable k0(Drawable drawable) {
        if (Build.VERSION.SDK_INT >= 23 || (drawable instanceof h0.d)) {
            return drawable;
        }
        h0.f fVar = new h0.f();
        fVar.f2359d = fVar.b();
        fVar.g(drawable);
        if (h0.f.f2355h == null) {
            try {
                h0.f.f2355h = Drawable.class.getDeclaredMethod("isProjected", null);
            } catch (Exception unused) {
            }
        }
        return fVar;
    }

    public static int l(Comparable comparable, Comparable comparable2) {
        if (comparable == comparable2) {
            return 0;
        }
        return comparable.compareTo(comparable2);
    }

    public static int m(int i3, int i4) {
        return g0.a.d(i3, (Color.alpha(i3) * i4) / 255);
    }

    public static float[] n(float[] fArr, int i3) {
        if (i3 < 0) {
            throw new IllegalArgumentException();
        }
        int length = fArr.length;
        if (length < 0) {
            throw new ArrayIndexOutOfBoundsException();
        }
        int iMin = Math.min(i3, length);
        float[] fArr2 = new float[i3];
        System.arraycopy(fArr, 0, fArr2, 0, iMin);
        return fArr2;
    }

    public static void o(InputStream inputStream, OutputStream outputStream) throws IOException {
        byte[] bArr = new byte[JarConfig.DEFAULT_BUFFER_SIZE];
        int i3 = inputStream.read(bArr);
        while (i3 >= 0) {
            outputStream.write(bArr, 0, i3);
            i3 = inputStream.read(bArr);
        }
    }

    public static boolean p(File file, Resources resources, int i3) throws Throwable {
        InputStream inputStreamOpenRawResource;
        try {
            inputStreamOpenRawResource = resources.openRawResource(i3);
            try {
                boolean zQ = q(inputStreamOpenRawResource, file);
                k(inputStreamOpenRawResource);
                return zQ;
            } catch (Throwable th) {
                th = th;
                k(inputStreamOpenRawResource);
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            inputStreamOpenRawResource = null;
        }
    }

    public static boolean q(InputStream inputStream, File file) throws Throwable {
        StrictMode.ThreadPolicy threadPolicyAllowThreadDiskWrites = StrictMode.allowThreadDiskWrites();
        FileOutputStream fileOutputStream = null;
        try {
            try {
                FileOutputStream fileOutputStream2 = new FileOutputStream(file, false);
                try {
                    byte[] bArr = new byte[1024];
                    while (true) {
                        int i3 = inputStream.read(bArr);
                        if (i3 == -1) {
                            k(fileOutputStream2);
                            StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                            return true;
                        }
                        fileOutputStream2.write(bArr, 0, i3);
                    }
                } catch (IOException e4) {
                    e = e4;
                    fileOutputStream = fileOutputStream2;
                    e.getMessage();
                    k(fileOutputStream);
                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                    return false;
                } catch (Throwable th) {
                    th = th;
                    fileOutputStream = fileOutputStream2;
                    k(fileOutputStream);
                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (IOException e5) {
            e = e5;
        }
    }

    public static w r(Context context) {
        ProviderInfo providerInfo;
        l0.e eVar;
        ApplicationInfo applicationInfo;
        s2.e dVar = Build.VERSION.SDK_INT >= 28 ? new androidx.emoji2.text.d(1) : new s2.e(1);
        PackageManager packageManager = context.getPackageManager();
        m.h(packageManager, "Package manager required to locate emoji font provider");
        Iterator<ResolveInfo> it = packageManager.queryIntentContentProviders(new Intent("androidx.content.action.LOAD_EMOJI_FONT"), 0).iterator();
        while (true) {
            if (!it.hasNext()) {
                providerInfo = null;
                break;
            }
            providerInfo = it.next().providerInfo;
            if (providerInfo != null && (applicationInfo = providerInfo.applicationInfo) != null && (applicationInfo.flags & 1) == 1) {
                break;
            }
        }
        if (providerInfo == null) {
            eVar = null;
        } else {
            try {
                String str = providerInfo.authority;
                String str2 = providerInfo.packageName;
                Signature[] signatureArrH = dVar.h(packageManager, str2);
                ArrayList arrayList = new ArrayList();
                for (Signature signature : signatureArrH) {
                    arrayList.add(signature.toByteArray());
                }
                eVar = new l0.e(str, str2, "emojicompat-emoji-font", Collections.singletonList(arrayList));
            } catch (PackageManager.NameNotFoundException unused) {
                eVar = null;
            }
        }
        if (eVar == null) {
            return null;
        }
        return new w(new v(context, eVar));
    }

    /* JADX WARN: Code duplicated, block: B:11:0x002e  */
    /* JADX WARN: Code duplicated, block: B:17:0x0044  */
    /* JADX WARN: Code duplicated, block: B:41:0x0093  */
    /* JADX WARN: Code duplicated, block: B:46:0x009e A[Catch: NumberFormatException -> 0x00ac, TryCatch #0 {NumberFormatException -> 0x00ac, blocks: (B:22:0x0056, B:25:0x006a, B:27:0x0070, B:31:0x007c, B:44:0x0098, B:46:0x009e, B:52:0x00b3, B:53:0x00b6), top: B:68:0x0056 }] */
    /* JADX WARN: Code duplicated, block: B:50:0x00b0  */
    /* JADX WARN: Code duplicated, block: B:52:0x00b3 A[Catch: NumberFormatException -> 0x00ac, TryCatch #0 {NumberFormatException -> 0x00ac, blocks: (B:22:0x0056, B:25:0x006a, B:27:0x0070, B:31:0x007c, B:44:0x0098, B:46:0x009e, B:52:0x00b3, B:53:0x00b6), top: B:68:0x0056 }] */
    /* JADX WARN: Code duplicated, block: B:57:0x00cb  */
    /* JADX WARN: Code duplicated, block: B:72:0x00d9 A[SYNTHETIC] */
    public static f[] y(String str) {
        int i3;
        String strTrim;
        float[] fArrN;
        ArrayList arrayList = new ArrayList();
        int i4 = 0;
        int i5 = 1;
        int i6 = 0;
        while (i5 < str.length()) {
            while (i5 < str.length()) {
                char cCharAt = str.charAt(i5);
                if ((cCharAt - 'Z') * (cCharAt - 'A') > 0) {
                    if ((cCharAt - 'z') * (cCharAt - 'a') > 0) {
                        continue;
                    } else if (cCharAt != 'e' && cCharAt != 'E') {
                        strTrim = str.substring(i6, i5).trim();
                        if (strTrim.isEmpty()) {
                            if (strTrim.charAt(i4) != 'z' || strTrim.charAt(i4) == 'Z') {
                                fArrN = new float[i4];
                            } else {
                                try {
                                    float[] fArr = new float[strTrim.length()];
                                    int length = strTrim.length();
                                    int i7 = 1;
                                    int i8 = 0;
                                    while (i7 < length) {
                                        boolean z4 = false;
                                        boolean z5 = false;
                                        boolean z6 = false;
                                        boolean z7 = false;
                                        for (int i9 = i7; i9 < strTrim.length(); i9++) {
                                            char cCharAt2 = strTrim.charAt(i9);
                                            if (cCharAt2 == ' ') {
                                                z4 = false;
                                                z6 = true;
                                            } else if (cCharAt2 != 'E' && cCharAt2 != 'e') {
                                                switch (cCharAt2) {
                                                    case ',':
                                                        z4 = false;
                                                        z6 = true;
                                                        break;
                                                    case '-':
                                                        if (i9 == i7 || z4) {
                                                            z4 = false;
                                                        } else {
                                                            z4 = false;
                                                            z6 = true;
                                                            z7 = true;
                                                        }
                                                        break;
                                                    case '.':
                                                        if (z5) {
                                                            z4 = false;
                                                            z6 = true;
                                                            z7 = true;
                                                        } else {
                                                            z4 = false;
                                                            z5 = true;
                                                        }
                                                        break;
                                                    default:
                                                        z4 = false;
                                                        break;
                                                }
                                            } else {
                                                z4 = true;
                                            }
                                            if (z6) {
                                                if (i7 < i9) {
                                                    fArr[i8] = Float.parseFloat(strTrim.substring(i7, i9));
                                                    i8++;
                                                }
                                                if (z7) {
                                                    i7 = i9;
                                                } else {
                                                    i7 = i9 + 1;
                                                }
                                            }
                                        }
                                        if (i7 < i9) {
                                            fArr[i8] = Float.parseFloat(strTrim.substring(i7, i9));
                                            i8++;
                                        }
                                        if (z7) {
                                            i7 = i9;
                                        } else {
                                            i7 = i9 + 1;
                                        }
                                    }
                                    fArrN = n(fArr, i8);
                                    i4 = 0;
                                } catch (NumberFormatException e4) {
                                    throw new RuntimeException(g0.e.d("error in parsing \"", strTrim, "\""), e4);
                                }
                            }
                            arrayList.add(new f(strTrim.charAt(i4), fArrN));
                        }
                        i6 = i5;
                        i5++;
                        i4 = 0;
                    }
                } else if (cCharAt != 'e') {
                    continue;
                }
                i5++;
            }
            strTrim = str.substring(i6, i5).trim();
            if (strTrim.isEmpty()) {
                if (strTrim.charAt(i4) != 'z') {
                    fArrN = new float[i4];
                } else {
                    fArrN = new float[i4];
                }
                arrayList.add(new f(strTrim.charAt(i4), fArrN));
            }
            i6 = i5;
            i5++;
            i4 = 0;
        }
        if (i5 - i6 != 1 || i6 >= str.length()) {
            i3 = 0;
        } else {
            i3 = 0;
            arrayList.add(new f(str.charAt(i6), new float[0]));
        }
        return (f[]) arrayList.toArray(new f[i3]);
    }

    public static Path z(String str) {
        Path path = new Path();
        try {
            f.b(y(str), path);
            return path;
        } catch (RuntimeException e4) {
            throw new RuntimeException("Error in parsing ".concat(str), e4);
        }
    }

    public j B(j[] jVarArr, int i3) {
        new s2.e(13);
        int i4 = (i3 & 1) == 0 ? 400 : 700;
        boolean z4 = (i3 & 2) != 0;
        j jVar = null;
        int i5 = Integer.MAX_VALUE;
        for (j jVar2 : jVarArr) {
            int iAbs = (Math.abs(jVar2.f3348c - i4) * 2) + (jVar2.f3349d == z4 ? 0 : 1);
            if (jVar == null || i5 > iAbs) {
                jVar = jVar2;
                i5 = iAbs;
            }
        }
        return jVar;
    }

    public b.a J(z zVar, Cloneable cloneable) {
        return null;
    }

    public abstract void T(Throwable th);

    public abstract View U(int i3);

    public abstract boolean V();

    public abstract void W(k kVar);

    public abstract Object X(int i3, Intent intent);

    public boolean g() {
        return false;
    }

    public abstract void h0();

    public abstract void i0();

    public abstract Typeface s(Context context, f0.f fVar, Resources resources, int i3);

    public abstract Typeface t(Context context, j[] jVarArr, int i3);

    public Typeface u(Context context, List list, int i3) {
        throw new IllegalStateException("createFromFontInfoWithFallback must only be called on API 29+");
    }

    public Typeface v(Context context, InputStream inputStream) {
        File fileK = K(context);
        if (fileK == null) {
            return null;
        }
        try {
            if (q(inputStream, fileK)) {
                return Typeface.createFromFile(fileK.getPath());
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            fileK.delete();
        }
    }

    public Typeface w(Context context, Resources resources, int i3, String str, int i4) {
        File fileK = K(context);
        if (fileK == null) {
            return null;
        }
        try {
            if (p(fileK, resources, i3)) {
                return Typeface.createFromFile(fileK.getPath());
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            fileK.delete();
        }
    }

    public abstract Intent x(z zVar, Cloneable cloneable);

    public void b0() {
    }
}
