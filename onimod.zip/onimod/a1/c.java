package a1;

/* JADX INFO: loaded from: classes.dex */
public final class c extends b {
    public c() {
        this(a.f29b);
    }

    public c(b initialExtras) {
        kotlin.jvm.internal.d.f(initialExtras, "initialExtras");
        this.f30a.putAll(initialExtras.f30a);
    }
}
