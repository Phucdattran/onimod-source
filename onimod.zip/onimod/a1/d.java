package a1;

import j3.l;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Class f31a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l f32b;

    public d(Class cls, l initializer) {
        kotlin.jvm.internal.d.f(initializer, "initializer");
        this.f31a = cls;
        this.f32b = initializer;
    }
}
