package a2;

import android.animation.ValueAnimator;
import android.graphics.Rect;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.SearchView$SearchAutoComplete;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.o;
import androidx.fragment.app.o0;
import androidx.lifecycle.w;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.internal.CheckableImageButton;
import com.google.android.material.textfield.TextInputLayout;
import e1.d0;
import e1.o1;
import e1.t;
import e1.y0;
import java.util.WeakHashMap;
import l.k;
import l.s1;
import n2.u;
import o0.h0;
import top.niunaijun.blackbox.core.system.JarConfig;
import top.niunaijun.blackbox.entity.location.BCell;
import top.niunaijun.blackboxa.view.apps.n;
import top.niunaijun.blackboxa.view.login.OniBrowserActivity;

/* JADX INFO: loaded from: classes.dex */
public final class i implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f49a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f50b;

    public /* synthetic */ i(int i3, Object obj) {
        this.f49a = i3;
        this.f50b = obj;
    }

    /* JADX WARN: Code duplicated, block: B:88:0x01ee  */
    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        int iC;
        int height;
        k kVar;
        int iC2 = 0;
        switch (this.f49a) {
            case 0:
                j jVar = (j) this.f50b;
                jVar.f53c = false;
                BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) jVar.f55e;
                t0.d dVar = bottomSheetBehavior.M;
                if (dVar != null && dVar.f()) {
                    jVar.a(jVar.f52b);
                    return;
                } else {
                    if (bottomSheetBehavior.L == 2) {
                        bottomSheetBehavior.C(jVar.f52b);
                        return;
                    }
                    return;
                }
            case 1:
                final OniBrowserActivity oniBrowserActivity = (OniBrowserActivity) this.f50b;
                if (oniBrowserActivity.F) {
                    return;
                }
                if (OniBrowserActivity.n(oniBrowserActivity)) {
                    OniBrowserActivity.m(oniBrowserActivity);
                    return;
                }
                WebView webView = oniBrowserActivity.f4286y;
                if (webView == null) {
                    kotlin.jvm.internal.d.k("webView");
                    throw null;
                }
                webView.evaluateJavascript("(function(){try{var b=document.body;if(!b)return 'blank';var n=b.querySelectorAll('input,button,a[href],[role=\"button\"],[type=\"submit\"]').length;return (n===0&&(b.innerText||'').trim().length<5)?'blank':'ok';}catch(e){return 'ok';}})()", new ValueCallback() { // from class: a4.n
                    @Override // android.webkit.ValueCallback
                    public final void onReceiveValue(Object obj2) {
                        String string;
                        String str = (String) obj2;
                        if (str != null) {
                            char[] cArr = {'\"'};
                            int length = str.length() - 1;
                            int i3 = 0;
                            boolean z4 = false;
                            while (i3 <= length) {
                                char cCharAt = str.charAt(!z4 ? i3 : length);
                                int i4 = 0;
                                while (true) {
                                    if (i4 >= 1) {
                                        i4 = -1;
                                        break;
                                    } else if (cCharAt == cArr[i4]) {
                                        break;
                                    } else {
                                        i4++;
                                    }
                                }
                                boolean z5 = i4 >= 0;
                                if (z4) {
                                    if (!z5) {
                                        break;
                                    } else {
                                        length--;
                                    }
                                } else if (z5) {
                                    i3++;
                                } else {
                                    z4 = true;
                                }
                            }
                            string = str.subSequence(i3, length + 1).toString();
                        } else {
                            string = null;
                        }
                        OniBrowserActivity oniBrowserActivity2 = oniBrowserActivity;
                        if (oniBrowserActivity2.F) {
                            return;
                        }
                        if (!kotlin.jvm.internal.d.a(string, "blank")) {
                            if (kotlin.jvm.internal.d.a(string, "ok")) {
                                oniBrowserActivity2.p();
                                return;
                            }
                            return;
                        }
                        oniBrowserActivity2.E = false;
                        View view = oniBrowserActivity2.f4287z;
                        if (view == null) {
                            kotlin.jvm.internal.d.k("loading");
                            throw null;
                        }
                        view.setVisibility(0);
                        WebView webView2 = oniBrowserActivity2.f4286y;
                        if (webView2 != null) {
                            webView2.setVisibility(4);
                        } else {
                            kotlin.jvm.internal.d.k("webView");
                            throw null;
                        }
                    }
                });
                WebView webView2 = oniBrowserActivity.f4286y;
                if (webView2 != null) {
                    webView2.postDelayed(this, 400L);
                    return;
                } else {
                    kotlin.jvm.internal.d.k("webView");
                    throw null;
                }
            case 2:
                try {
                    super/*android.app.Activity*/.onBackPressed();
                    return;
                } catch (IllegalStateException e4) {
                    if (!TextUtils.equals(e4.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                        throw e4;
                    }
                    return;
                } catch (NullPointerException e5) {
                    if (!TextUtils.equals(e5.getMessage(), "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference")) {
                        throw e5;
                    }
                    return;
                }
            case 3:
                androidx.fragment.app.f fVar = (androidx.fragment.app.f) this.f50b;
                fVar.f644b.endViewTransition(fVar.f645c);
                fVar.f646d.e();
                return;
            case 4:
                o oVar = (o) this.f50b;
                oVar.W.onDismiss(oVar.f681e0);
                return;
            case 5:
                ((o0) this.f50b).x(true);
                return;
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                synchronized (((w) this.f50b).f891a) {
                    obj = ((w) this.f50b).f;
                    ((w) this.f50b).f = w.f890k;
                    break;
                }
                ((w) this.f50b).g(obj);
                return;
            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                androidx.viewpager2.adapter.e eVar = (androidx.viewpager2.adapter.e) this.f50b;
                eVar.f1007j = false;
                eVar.o();
                return;
            case 8:
                t tVar = (t) this.f50b;
                ValueAnimator valueAnimator = tVar.f2067z;
                int i3 = tVar.A;
                if (i3 == 1) {
                    valueAnimator.cancel();
                } else if (i3 != 2) {
                    return;
                }
                tVar.A = 3;
                valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 0.0f);
                valueAnimator.setDuration(500);
                valueAnimator.start();
                return;
            case 9:
                d0 d0Var = (d0) this.f50b;
                if (d0Var.f1829c != null) {
                    long jCurrentTimeMillis = System.currentTimeMillis();
                    long j4 = d0Var.B;
                    long j5 = j4 != Long.MIN_VALUE ? jCurrentTimeMillis - j4 : 0L;
                    y0 layoutManager = d0Var.f1843r.getLayoutManager();
                    if (d0Var.A == null) {
                        d0Var.A = new Rect();
                    }
                    View view = d0Var.f1829c.f2003a;
                    Rect rect = d0Var.A;
                    RecyclerView recyclerView = layoutManager.f2123b;
                    if (recyclerView == null) {
                        rect.set(0, 0, 0, 0);
                    } else {
                        rect.set(recyclerView.K(view));
                    }
                    if (layoutManager.d()) {
                        int i4 = (int) (d0Var.f1835j + d0Var.f1833h);
                        int paddingLeft = (i4 - d0Var.A.left) - d0Var.f1843r.getPaddingLeft();
                        float f = d0Var.f1833h;
                        if ((f >= 0.0f || paddingLeft >= 0) && (f <= 0.0f || (paddingLeft = ((d0Var.f1829c.f2003a.getWidth() + i4) + d0Var.A.right) - (d0Var.f1843r.getWidth() - d0Var.f1843r.getPaddingRight())) <= 0)) {
                            iC = 0;
                        } else {
                            iC = paddingLeft;
                        }
                    } else {
                        iC = 0;
                    }
                    if (layoutManager.e()) {
                        int i5 = (int) (d0Var.f1836k + d0Var.f1834i);
                        int paddingTop = (i5 - d0Var.A.top) - d0Var.f1843r.getPaddingTop();
                        float f4 = d0Var.f1834i;
                        if (f4 < 0.0f && paddingTop < 0) {
                            iC2 = paddingTop;
                        } else if (f4 > 0.0f && (height = ((d0Var.f1829c.f2003a.getHeight() + i5) + d0Var.A.bottom) - (d0Var.f1843r.getHeight() - d0Var.f1843r.getPaddingBottom())) > 0) {
                            iC2 = height;
                        }
                    }
                    if (iC != 0) {
                        n nVar = d0Var.f1838m;
                        RecyclerView recyclerView2 = d0Var.f1843r;
                        int width = d0Var.f1829c.f2003a.getWidth();
                        d0Var.f1843r.getWidth();
                        iC = nVar.c(recyclerView2, width, iC, j5);
                    }
                    int i6 = iC;
                    if (iC2 != 0) {
                        n nVar2 = d0Var.f1838m;
                        RecyclerView recyclerView3 = d0Var.f1843r;
                        int height2 = d0Var.f1829c.f2003a.getHeight();
                        d0Var.f1843r.getHeight();
                        iC2 = nVar2.c(recyclerView3, height2, iC2, j5);
                    }
                    if (i6 == 0 && iC2 == 0) {
                        d0Var.B = Long.MIN_VALUE;
                        return;
                    }
                    if (d0Var.B == Long.MIN_VALUE) {
                        d0Var.B = jCurrentTimeMillis;
                    }
                    d0Var.f1843r.scrollBy(i6, iC2);
                    o1 o1Var = d0Var.f1829c;
                    if (o1Var != null) {
                        d0Var.q(o1Var);
                    }
                    d0Var.f1843r.removeCallbacks(d0Var.f1844s);
                    RecyclerView recyclerView4 = d0Var.f1843r;
                    WeakHashMap weakHashMap = h0.f3558a;
                    recyclerView4.postOnAnimation(this);
                    return;
                }
                return;
            case JarConfig.MAX_CACHE_SIZE /* 10 */:
                ((StaggeredGridLayoutManager) this.f50b).H0();
                return;
            case 11:
                g.e eVar2 = (g.e) this.f50b;
                eVar2.a(true);
                eVar2.invalidateSelf();
                return;
            case 12:
                s1 s1Var = (s1) this.f50b;
                s1Var.f3243l = null;
                s1Var.drawableStateChanged();
                return;
            case 13:
                SearchView$SearchAutoComplete searchView$SearchAutoComplete = (SearchView$SearchAutoComplete) this.f50b;
                if (searchView$SearchAutoComplete.f) {
                    ((InputMethodManager) searchView$SearchAutoComplete.getContext().getSystemService("input_method")).showSoftInput(searchView$SearchAutoComplete, 0);
                    searchView$SearchAutoComplete.f = false;
                    return;
                }
                return;
            case 14:
                ActionMenuView actionMenuView = ((Toolbar) this.f50b).f339a;
                if (actionMenuView == null || (kVar = actionMenuView.f286t) == null) {
                    return;
                }
                kVar.l();
                return;
            case 15:
                r0.d dVar2 = (r0.d) this.f50b;
                s1 s1Var2 = dVar2.f3774c;
                r0.a aVar = dVar2.f3772a;
                if (dVar2.f3785o) {
                    if (dVar2.f3783m) {
                        dVar2.f3783m = false;
                        long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
                        aVar.f3767e = jCurrentAnimationTimeMillis;
                        aVar.f3768g = -1L;
                        aVar.f = jCurrentAnimationTimeMillis;
                        aVar.f3769h = 0.5f;
                    }
                    if ((aVar.f3768g > 0 && AnimationUtils.currentAnimationTimeMillis() > aVar.f3768g + ((long) aVar.f3770i)) || !dVar2.e()) {
                        dVar2.f3785o = false;
                        return;
                    }
                    if (dVar2.f3784n) {
                        dVar2.f3784n = false;
                        long jUptimeMillis = SystemClock.uptimeMillis();
                        MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                        s1Var2.onTouchEvent(motionEventObtain);
                        motionEventObtain.recycle();
                    }
                    if (aVar.f == 0) {
                        throw new RuntimeException("Cannot compute scroll delta before calling start()");
                    }
                    long jCurrentAnimationTimeMillis2 = AnimationUtils.currentAnimationTimeMillis();
                    float fA = aVar.a(jCurrentAnimationTimeMillis2);
                    long j6 = jCurrentAnimationTimeMillis2 - aVar.f;
                    aVar.f = jCurrentAnimationTimeMillis2;
                    dVar2.f3787q.scrollListBy((int) (j6 * ((fA * 4.0f) + ((-4.0f) * fA * fA)) * aVar.f3766d));
                    WeakHashMap weakHashMap2 = h0.f3558a;
                    s1Var2.postOnAnimation(this);
                    return;
                }
                return;
            case 16:
                ((t0.d) this.f50b).m(0);
                return;
            case 17:
                top.niunaijun.blackboxa.view.base.c cVar = (top.niunaijun.blackboxa.view.base.c) this.f50b;
                Float f5 = cVar.f4228k;
                if (f5 == null) {
                    float f6 = cVar.f4226i;
                    cVar.f4226i = ((cVar.f4227j - f6) * 0.025f) + f6;
                } else if (cVar.f4226i < f5.floatValue()) {
                    cVar.f4226i = Math.min(f5.floatValue(), Math.max(2.0f, (f5.floatValue() - cVar.f4226i) * 0.18f) + cVar.f4226i);
                }
                u uVar = cVar.f;
                if (uVar == null) {
                    kotlin.jvm.internal.d.k("bar");
                    throw null;
                }
                uVar.b((int) cVar.f4226i);
                if (cVar.f4228k == null || cVar.f4226i < 1000.0f) {
                    cVar.f4222d.postDelayed(this, 40L);
                    return;
                }
                return;
            default:
                CheckableImageButton checkableImageButton = ((TextInputLayout) this.f50b).f1496c.f4586g;
                checkableImageButton.performClick();
                checkableImageButton.jumpDrawablesToCurrentState();
                return;
        }
    }
}
