package a2;

import android.animation.ValueAnimator;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.textfield.TextInputLayout;
import e1.t;
import e1.z;

/* JADX INFO: loaded from: classes.dex */
public final class d implements ValueAnimator.AnimatorUpdateListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f37a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f38b;

    public /* synthetic */ d(int i3, Object obj) {
        this.f37a = i3;
        this.f38b = obj;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        switch (this.f37a) {
            case 0:
                float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                s2.g gVar = ((BottomSheetBehavior) this.f38b).f1261i;
                if (gVar != null) {
                    gVar.l(fFloatValue);
                }
                break;
            case 1:
                int iFloatValue = (int) (((Float) valueAnimator.getAnimatedValue()).floatValue() * 255.0f);
                t tVar = (t) this.f38b;
                tVar.f2045c.setAlpha(iFloatValue);
                tVar.f2046d.setAlpha(iFloatValue);
                tVar.f2060s.invalidate();
                break;
            case 2:
                ((z) this.f38b).f2151m = valueAnimator.getAnimatedFraction();
                break;
            default:
                ((TextInputLayout) this.f38b).f1533v0.k(((Float) valueAnimator.getAnimatedValue()).floatValue());
                break;
        }
    }
}
