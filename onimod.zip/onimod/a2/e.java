package a2;

import com.google.android.material.bottomsheet.BottomSheetBehavior;

/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f39a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f40b;

    public e(m0.e eVar, boolean z4) {
        this.f40b = eVar;
        this.f39a = z4;
    }

    public boolean a() {
        return this.f39a;
    }

    /* JADX WARN: Code duplicated, block: B:20:0x0037  */
    /* JADX WARN: Code duplicated, block: B:21:0x0039  */
    public boolean b(CharSequence charSequence, int i3) {
        if (charSequence == null || i3 < 0 || charSequence.length() - i3 < 0) {
            throw new IllegalArgumentException();
        }
        m0.e eVar = (m0.e) this.f40b;
        if (eVar == null) {
            return a();
        }
        eVar.getClass();
        char c3 = 2;
        for (int i4 = 0; i4 < i3 && c3 == 2; i4++) {
            byte directionality = Character.getDirectionality(charSequence.charAt(i4));
            e eVar2 = m0.f.f3375a;
            if (directionality == 0) {
                c3 = 1;
            } else if (directionality != 1 && directionality != 2) {
                switch (directionality) {
                    case 14:
                    case 15:
                        c3 = 1;
                        break;
                    case 16:
                    case 17:
                        c3 = 0;
                        break;
                    default:
                        c3 = 2;
                        break;
                }
            } else {
                c3 = 0;
            }
        }
        if (c3 == 0) {
            return true;
        }
        if (c3 != 1) {
            return a();
        }
        return false;
    }

    public e(BottomSheetBehavior bottomSheetBehavior, boolean z4) {
        this.f40b = bottomSheetBehavior;
        this.f39a = z4;
    }
}
