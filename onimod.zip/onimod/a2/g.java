package a2;

import android.R;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AlertController$RecycleListView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import e.k;
import java.util.ArrayList;
import java.util.Collections;
import k.n;
import p0.p;

/* JADX INFO: loaded from: classes.dex */
public final class g implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f43a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f44b;

    public g(Context context) {
        int iH = k.h(context, 0);
        this.f44b = new e.g(new ContextThemeWrapper(context, k.h(context, iH)));
        this.f43a = iH;
    }

    @Override // p0.p
    public boolean a(View view) {
        ((BottomSheetBehavior) this.f44b).B(this.f43a);
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v13 */
    /* JADX WARN: Type inference failed for: r2v14 */
    /* JADX WARN: Type inference failed for: r2v15 */
    /* JADX WARN: Type inference failed for: r2v7, types: [android.widget.ListAdapter] */
    public k b() {
        ?? iVar;
        e.g gVar = (e.g) this.f44b;
        ContextThemeWrapper contextThemeWrapper = gVar.f1702a;
        ContextThemeWrapper contextThemeWrapper2 = gVar.f1702a;
        k kVar = new k(contextThemeWrapper, this.f43a);
        View view = gVar.f1706e;
        e.j jVar = kVar.f;
        if (view != null) {
            jVar.f1754u = view;
        } else {
            CharSequence charSequence = gVar.f1705d;
            if (charSequence != null) {
                jVar.f1738d = charSequence;
                TextView textView = jVar.f1752s;
                if (textView != null) {
                    textView.setText(charSequence);
                }
            }
            Drawable drawable = gVar.f1704c;
            if (drawable != null) {
                jVar.f1750q = drawable;
                ImageView imageView = jVar.f1751r;
                if (imageView != null) {
                    imageView.setVisibility(0);
                    jVar.f1751r.setImageDrawable(drawable);
                }
            }
        }
        CharSequence charSequence2 = gVar.f;
        if (charSequence2 != null) {
            jVar.f1739e = charSequence2;
            TextView textView2 = jVar.f1753t;
            if (textView2 != null) {
                textView2.setText(charSequence2);
            }
        }
        CharSequence charSequence3 = gVar.f1707g;
        if (charSequence3 != null) {
            jVar.c(-1, charSequence3, gVar.f1708h);
        }
        CharSequence charSequence4 = gVar.f1709i;
        if (charSequence4 != null) {
            jVar.c(-2, charSequence4, null);
        }
        CharSequence charSequence5 = gVar.f1710j;
        if (charSequence5 != null) {
            jVar.c(-3, charSequence5, gVar.f1711k);
        }
        if (gVar.f1714n != null || gVar.f1715o != null) {
            AlertController$RecycleListView alertController$RecycleListView = (AlertController$RecycleListView) gVar.f1703b.inflate(jVar.f1758y, (ViewGroup) null);
            if (gVar.f1718r) {
                iVar = new e.d(gVar, contextThemeWrapper2, jVar.f1759z, gVar.f1714n, alertController$RecycleListView);
            } else {
                int i3 = gVar.f1719s ? jVar.A : jVar.B;
                Object obj = gVar.f1715o;
                iVar = obj;
                if (obj == null) {
                    iVar = new e.i(contextThemeWrapper2, i3, R.id.text1, gVar.f1714n);
                }
            }
            jVar.f1755v = iVar;
            jVar.f1756w = gVar.f1720t;
            if (gVar.f1716p != null) {
                alertController$RecycleListView.setOnItemClickListener(new e.e(gVar, jVar));
            } else if (gVar.f1721u != null) {
                alertController$RecycleListView.setOnItemClickListener(new e.f(gVar, alertController$RecycleListView, jVar));
            }
            if (gVar.f1719s) {
                alertController$RecycleListView.setChoiceMode(1);
            } else if (gVar.f1718r) {
                alertController$RecycleListView.setChoiceMode(2);
            }
            jVar.f = alertController$RecycleListView;
        }
        kVar.setCancelable(gVar.f1712l);
        if (gVar.f1712l) {
            kVar.setCanceledOnTouchOutside(true);
        }
        kVar.setOnCancelListener(null);
        kVar.setOnDismissListener(null);
        n nVar = gVar.f1713m;
        if (nVar != null) {
            kVar.setOnKeyListener(nVar);
        }
        return kVar;
    }

    public g() {
        this.f43a = 1;
        this.f44b = Collections.singletonList(null);
    }

    public g(ArrayList arrayList) {
        this.f43a = 0;
        this.f44b = arrayList;
    }

    public g(BottomSheetBehavior bottomSheetBehavior, int i3) {
        this.f44b = bottomSheetBehavior;
        this.f43a = i3;
    }
}
