package a2;

import android.view.View;
import android.view.ViewGroup;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.sidesheet.SideSheetBehavior;
import i1.m;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedHashSet;

/* JADX INFO: loaded from: classes.dex */
public final class f extends q1.b {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ int f41g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ a0.c f42h;

    public /* synthetic */ f(a0.c cVar, int i3) {
        this.f41g = i3;
        this.f42h = cVar;
    }

    @Override // q1.b
    public int C(View view) {
        switch (this.f41g) {
            case 1:
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) this.f42h;
                return sideSheetBehavior.f1474l + sideSheetBehavior.f1477o;
            default:
                return super.C(view);
        }
    }

    @Override // q1.b
    public int D() {
        switch (this.f41g) {
            case 0:
                BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) this.f42h;
                return bottomSheetBehavior.I ? bottomSheetBehavior.T : bottomSheetBehavior.G;
            default:
                return super.D();
        }
    }

    @Override // q1.b
    public final void Q(int i3) {
        switch (this.f41g) {
            case 0:
                if (i3 == 1) {
                    BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) this.f42h;
                    if (bottomSheetBehavior.K) {
                        bottomSheetBehavior.C(1);
                    }
                }
                break;
            default:
                if (i3 == 1) {
                    SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) this.f42h;
                    if (sideSheetBehavior.f1469g) {
                        sideSheetBehavior.r(1);
                    }
                }
                break;
        }
    }

    @Override // q1.b
    public final void R(View view, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams;
        switch (this.f41g) {
            case 0:
                ((BottomSheetBehavior) this.f42h).u(i4);
                return;
            default:
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) this.f42h;
                WeakReference weakReference = sideSheetBehavior.f1479q;
                View view2 = weakReference != null ? (View) weakReference.get() : null;
                if (view2 != null && (marginLayoutParams = (ViewGroup.MarginLayoutParams) view2.getLayoutParams()) != null) {
                    sideSheetBehavior.f1464a.o0(marginLayoutParams, view.getLeft(), view.getRight());
                    view2.setLayoutParams(marginLayoutParams);
                }
                LinkedHashSet linkedHashSet = sideSheetBehavior.f1483u;
                if (linkedHashSet.isEmpty()) {
                    return;
                }
                sideSheetBehavior.f1464a.g(i3);
                Iterator it = linkedHashSet.iterator();
                if (it.hasNext()) {
                    it.next().getClass();
                    throw new ClassCastException();
                }
                return;
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x005a  */
    /* JADX WARN: Code duplicated, block: B:29:0x0071  */
    /* JADX WARN: Code duplicated, block: B:43:0x00b0  */
    /* JADX WARN: Code duplicated, block: B:57:0x00e9  */
    @Override // q1.b
    public final void S(View view, float f, float f4) {
        int i3;
        switch (this.f41g) {
            case 0:
                BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) this.f42h;
                int i4 = 6;
                if (f4 < 0.0f) {
                    if (bottomSheetBehavior.f1252b) {
                        i4 = 3;
                    } else {
                        int top2 = view.getTop();
                        System.currentTimeMillis();
                        bottomSheetBehavior.getClass();
                        if (top2 <= bottomSheetBehavior.E) {
                            i4 = 3;
                        }
                    }
                } else if (bottomSheetBehavior.I && bottomSheetBehavior.D(view, f4)) {
                    if (Math.abs(f) >= Math.abs(f4) || f4 <= bottomSheetBehavior.f1256d) {
                        if (view.getTop() > (bottomSheetBehavior.x() + bottomSheetBehavior.T) / 2) {
                            i4 = 5;
                        } else if (bottomSheetBehavior.f1252b || Math.abs(view.getTop() - bottomSheetBehavior.x()) < Math.abs(view.getTop() - bottomSheetBehavior.E)) {
                            i4 = 3;
                        }
                    } else {
                        i4 = 5;
                    }
                } else if (f4 == 0.0f || Math.abs(f) > Math.abs(f4)) {
                    int top3 = view.getTop();
                    if (!bottomSheetBehavior.f1252b) {
                        int i5 = bottomSheetBehavior.E;
                        if (top3 < i5) {
                            if (top3 < Math.abs(top3 - bottomSheetBehavior.G)) {
                                i4 = 3;
                            } else {
                                bottomSheetBehavior.getClass();
                            }
                        } else if (Math.abs(top3 - i5) < Math.abs(top3 - bottomSheetBehavior.G)) {
                            bottomSheetBehavior.getClass();
                        } else {
                            i4 = 4;
                        }
                    } else if (Math.abs(top3 - bottomSheetBehavior.D) < Math.abs(top3 - bottomSheetBehavior.G)) {
                        i4 = 3;
                    } else {
                        i4 = 4;
                    }
                } else if (bottomSheetBehavior.f1252b) {
                    i4 = 4;
                } else {
                    int top4 = view.getTop();
                    if (Math.abs(top4 - bottomSheetBehavior.E) < Math.abs(top4 - bottomSheetBehavior.G)) {
                        bottomSheetBehavior.getClass();
                    } else {
                        i4 = 4;
                    }
                }
                bottomSheetBehavior.getClass();
                bottomSheetBehavior.E(view, i4, true);
                break;
            default:
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) this.f42h;
                if (!sideSheetBehavior.f1464a.H(f)) {
                    if (!sideSheetBehavior.f1464a.i0(view, f)) {
                        if (f == 0.0f || Math.abs(f) <= Math.abs(f4)) {
                            int left = view.getLeft();
                            i3 = Math.abs(left - sideSheetBehavior.f1464a.t()) < Math.abs(left - sideSheetBehavior.f1464a.v()) ? 3 : 5;
                        }
                    } else if (sideSheetBehavior.f1464a.K(f, f4) || sideSheetBehavior.f1464a.I(view)) {
                    }
                }
                sideSheetBehavior.t(view, i3, true);
                break;
        }
    }

    @Override // q1.b
    public final int k(View view, int i3) {
        switch (this.f41g) {
            case 0:
                return view.getLeft();
            default:
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) this.f42h;
                return m.k(i3, sideSheetBehavior.f1464a.x(), sideSheetBehavior.f1464a.w());
        }
    }

    @Override // q1.b
    public final int l(View view, int i3) {
        switch (this.f41g) {
            case 0:
                return m.k(i3, ((BottomSheetBehavior) this.f42h).x(), D());
            default:
                return view.getTop();
        }
    }

    /* JADX WARN: Code duplicated, block: B:31:0x0048  */
    @Override // q1.b
    public final boolean m0(View view, int i3) {
        WeakReference weakReference;
        WeakReference weakReference2;
        switch (this.f41g) {
            case 0:
                BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) this.f42h;
                int i4 = bottomSheetBehavior.L;
                if (i4 != 1 && !bottomSheetBehavior.f1251a0) {
                    if (i4 == 3 && bottomSheetBehavior.Y == i3) {
                        WeakReference weakReference3 = bottomSheetBehavior.V;
                        View view2 = weakReference3 != null ? (View) weakReference3.get() : null;
                        if (view2 == null || !view2.canScrollVertically(-1)) {
                            System.currentTimeMillis();
                            weakReference = bottomSheetBehavior.U;
                            if (weakReference == null) {
                            }
                        }
                    } else {
                        System.currentTimeMillis();
                        weakReference = bottomSheetBehavior.U;
                        if (weakReference == null && weakReference.get() == view) {
                            return true;
                        }
                    }
                }
                return false;
            default:
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) this.f42h;
                return (sideSheetBehavior.f1470h == 1 || (weakReference2 = sideSheetBehavior.f1478p) == null || weakReference2.get() != view) ? false : true;
        }
    }
}
