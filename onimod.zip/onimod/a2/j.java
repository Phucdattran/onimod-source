package a2;

import android.view.View;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.sidesheet.SideSheetBehavior;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import o0.h0;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f51a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f52b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f53c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Runnable f54d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ a0.c f55e;

    public j(SideSheetBehavior sideSheetBehavior) {
        this.f51a = 1;
        this.f55e = sideSheetBehavior;
        this.f54d = new a4.b(12, this);
    }

    public final void a(int i3) {
        int i4 = this.f51a;
        Runnable runnable = this.f54d;
        a0.c cVar = this.f55e;
        switch (i4) {
            case 0:
                BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) cVar;
                WeakReference weakReference = bottomSheetBehavior.U;
                if (weakReference != null && weakReference.get() != null) {
                    this.f52b = i3;
                    if (!this.f53c) {
                        WeakHashMap weakHashMap = h0.f3558a;
                        ((View) bottomSheetBehavior.U.get()).postOnAnimation((i) runnable);
                        this.f53c = true;
                    }
                    break;
                }
                break;
            default:
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) cVar;
                WeakReference weakReference2 = sideSheetBehavior.f1478p;
                if (weakReference2 != null && weakReference2.get() != null) {
                    this.f52b = i3;
                    if (!this.f53c) {
                        WeakHashMap weakHashMap2 = h0.f3558a;
                        ((View) sideSheetBehavior.f1478p.get()).postOnAnimation((a4.b) runnable);
                        this.f53c = true;
                    }
                    break;
                }
                break;
        }
    }

    public j(BottomSheetBehavior bottomSheetBehavior) {
        this.f51a = 0;
        this.f55e = bottomSheetBehavior;
        this.f54d = new i(0, this);
    }
}
