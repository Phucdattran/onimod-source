package a2;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.view.View;
import android.widget.TextView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

/* JADX INFO: loaded from: classes.dex */
public final class c implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f33a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f34b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f35c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f36d;

    public /* synthetic */ c(androidx.activity.g gVar, int i3, Object obj, int i4) {
        this.f33a = i4;
        this.f36d = gVar;
        this.f34b = i3;
        this.f35c = obj;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f33a) {
            case 0:
                ((BottomSheetBehavior) this.f36d).E((View) this.f35c, this.f34b, false);
                break;
            case 1:
                androidx.activity.g gVar = (androidx.activity.g) this.f36d;
                Object obj = ((b.a) this.f35c).f1030a;
                String str = (String) gVar.f181a.get(Integer.valueOf(this.f34b));
                if (str != null) {
                    androidx.activity.result.f fVar = (androidx.activity.result.f) gVar.f185e.get(str);
                    if (fVar != null) {
                        androidx.activity.result.c cVar = fVar.f177a;
                        if (gVar.f184d.remove(str)) {
                            cVar.a(obj);
                        }
                    } else {
                        gVar.f186g.remove(str);
                        gVar.f.put(str, obj);
                    }
                    break;
                }
                break;
            case 2:
                ((androidx.activity.g) this.f36d).a(this.f34b, 0, new Intent().setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (IntentSender.SendIntentException) this.f35c));
                break;
            case 3:
                String[] strArr = (String[]) this.f35c;
                int[] iArr = new int[strArr.length];
                Activity activity = (Activity) this.f36d;
                PackageManager packageManager = activity.getPackageManager();
                String packageName = activity.getPackageName();
                int length = strArr.length;
                for (int i3 = 0; i3 < length; i3++) {
                    iArr[i3] = packageManager.checkPermission(strArr[i3], packageName);
                }
                ((c0.b) activity).onRequestPermissionsResult(this.f34b, strArr, iArr);
                break;
            default:
                ((TextView) this.f35c).setTypeface((Typeface) this.f36d, this.f34b);
                break;
        }
    }

    public /* synthetic */ c(Object obj, Object obj2, int i3, int i4) {
        this.f33a = i4;
        this.f35c = obj;
        this.f36d = obj2;
        this.f34b = i3;
    }

    public c(BottomSheetBehavior bottomSheetBehavior, View view, int i3) {
        this.f33a = 0;
        this.f36d = bottomSheetBehavior;
        this.f35c = view;
        this.f34b = i3;
    }
}
