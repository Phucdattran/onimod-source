package a2;

import android.content.ClipData;
import android.view.ContentInfo;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class b {
    public static /* synthetic */ ContentInfo.Builder e(ClipData clipData, int i3) {
        return new ContentInfo.Builder(clipData, i3);
    }

    public static /* bridge */ /* synthetic */ ContentInfo g(Object obj) {
        return (ContentInfo) obj;
    }
}
