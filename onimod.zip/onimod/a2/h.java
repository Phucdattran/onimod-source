package a2;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.AbsSavedState;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

/* JADX INFO: loaded from: classes.dex */
public final class h extends s0.b {
    public static final Parcelable.Creator<h> CREATOR = new a0.h(1);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f45c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f46d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f47e;
    public final boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f48g;

    public h(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.f45c = parcel.readInt();
        this.f46d = parcel.readInt();
        this.f47e = parcel.readInt() == 1;
        this.f = parcel.readInt() == 1;
        this.f48g = parcel.readInt() == 1;
    }

    @Override // s0.b, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i3) {
        super.writeToParcel(parcel, i3);
        parcel.writeInt(this.f45c);
        parcel.writeInt(this.f46d);
        parcel.writeInt(this.f47e ? 1 : 0);
        parcel.writeInt(this.f ? 1 : 0);
        parcel.writeInt(this.f48g ? 1 : 0);
    }

    public h(BottomSheetBehavior bottomSheetBehavior) {
        super(AbsSavedState.EMPTY_STATE);
        this.f45c = bottomSheetBehavior.L;
        this.f46d = bottomSheetBehavior.f1258e;
        this.f47e = bottomSheetBehavior.f1252b;
        this.f = bottomSheetBehavior.I;
        this.f48g = bottomSheetBehavior.J;
    }
}
