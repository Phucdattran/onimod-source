package b;

import android.os.Handler;
import android.os.Looper;
import u2.e;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static a f1029b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f1030a;

    public a() {
        this.f1030a = new Object();
        new Handler(Looper.getMainLooper(), new e(this));
    }

    public void a() {
        synchronized (this.f1030a) {
        }
    }

    public a(Object obj) {
        this.f1030a = obj;
    }
}
