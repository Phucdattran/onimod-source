package androidx.constraintlayout.core.widgets.analyzer;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
final class DependencyNode$Type {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final DependencyNode$Type f386a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final DependencyNode$Type f387b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final DependencyNode$Type f388c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final DependencyNode$Type f389d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final DependencyNode$Type f390e;
    public static final DependencyNode$Type f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final DependencyNode$Type f391g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final DependencyNode$Type f392h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final /* synthetic */ DependencyNode$Type[] f393i;

    static {
        DependencyNode$Type dependencyNode$Type = new DependencyNode$Type("UNKNOWN", 0);
        f386a = dependencyNode$Type;
        DependencyNode$Type dependencyNode$Type2 = new DependencyNode$Type("HORIZONTAL_DIMENSION", 1);
        f387b = dependencyNode$Type2;
        DependencyNode$Type dependencyNode$Type3 = new DependencyNode$Type("VERTICAL_DIMENSION", 2);
        f388c = dependencyNode$Type3;
        DependencyNode$Type dependencyNode$Type4 = new DependencyNode$Type("LEFT", 3);
        f389d = dependencyNode$Type4;
        DependencyNode$Type dependencyNode$Type5 = new DependencyNode$Type("RIGHT", 4);
        f390e = dependencyNode$Type5;
        DependencyNode$Type dependencyNode$Type6 = new DependencyNode$Type("TOP", 5);
        f = dependencyNode$Type6;
        DependencyNode$Type dependencyNode$Type7 = new DependencyNode$Type("BOTTOM", 6);
        f391g = dependencyNode$Type7;
        DependencyNode$Type dependencyNode$Type8 = new DependencyNode$Type("BASELINE", 7);
        f392h = dependencyNode$Type8;
        f393i = new DependencyNode$Type[]{dependencyNode$Type, dependencyNode$Type2, dependencyNode$Type3, dependencyNode$Type4, dependencyNode$Type5, dependencyNode$Type6, dependencyNode$Type7, dependencyNode$Type8};
    }

    public static DependencyNode$Type valueOf(String str) {
        return (DependencyNode$Type) Enum.valueOf(DependencyNode$Type.class, str);
    }

    public static DependencyNode$Type[] values() {
        return (DependencyNode$Type[]) f393i.clone();
    }
}
