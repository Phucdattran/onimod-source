package androidx.constraintlayout.core.widgets.analyzer;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class a implements w.d {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final f f400d;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f402g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public f f397a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f398b = false;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f399c = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public DependencyNode$Type f401e = DependencyNode$Type.f386a;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f403h = 1;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public b f404i = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f405j = false;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final ArrayList f406k = new ArrayList();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final ArrayList f407l = new ArrayList();

    public a(f fVar) {
        this.f400d = fVar;
    }

    @Override // w.d
    public final void a(w.d dVar) {
        ArrayList arrayList = this.f407l;
        int size = arrayList.size();
        int i3 = 0;
        int i4 = 0;
        while (i4 < size) {
            Object obj = arrayList.get(i4);
            i4++;
            if (!((a) obj).f405j) {
                return;
            }
        }
        this.f399c = true;
        f fVar = this.f397a;
        if (fVar != null) {
            fVar.a(this);
        }
        if (this.f398b) {
            this.f400d.a(this);
            return;
        }
        int size2 = arrayList.size();
        a aVar = null;
        int i5 = 0;
        while (i5 < size2) {
            Object obj2 = arrayList.get(i5);
            i5++;
            a aVar2 = (a) obj2;
            if (!(aVar2 instanceof b)) {
                i3++;
                aVar = aVar2;
            }
        }
        if (aVar != null && i3 == 1 && aVar.f405j) {
            b bVar = this.f404i;
            if (bVar != null) {
                if (!bVar.f405j) {
                    return;
                } else {
                    this.f = this.f403h * bVar.f402g;
                }
            }
            d(aVar.f402g + this.f);
        }
        f fVar2 = this.f397a;
        if (fVar2 != null) {
            fVar2.a(this);
        }
    }

    public final void b(f fVar) {
        this.f406k.add(fVar);
        if (this.f405j) {
            fVar.a(fVar);
        }
    }

    public final void c() {
        this.f407l.clear();
        this.f406k.clear();
        this.f405j = false;
        this.f402g = 0;
        this.f399c = false;
        this.f398b = false;
    }

    public void d(int i3) {
        if (this.f405j) {
            return;
        }
        this.f405j = true;
        this.f402g = i3;
        ArrayList arrayList = this.f406k;
        int size = arrayList.size();
        int i4 = 0;
        while (i4 < size) {
            Object obj = arrayList.get(i4);
            i4++;
            w.d dVar = (w.d) obj;
            dVar.a(dVar);
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f400d.f413b.f4447i0);
        sb.append(":");
        sb.append(this.f401e);
        sb.append("(");
        sb.append(this.f405j ? Integer.valueOf(this.f402g) : "unresolved");
        sb.append(") <t=");
        sb.append(this.f407l.size());
        sb.append(":d=");
        sb.append(this.f406k.size());
        sb.append(">");
        return sb.toString();
    }
}
