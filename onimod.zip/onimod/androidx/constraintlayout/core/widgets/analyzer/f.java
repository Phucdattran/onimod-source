package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour;
import w.h;

/* JADX INFO: loaded from: classes.dex */
public abstract class f implements w.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f412a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public v.d f413b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public h f414c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ConstraintWidget$DimensionBehaviour f415d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final b f416e = new b(this);
    public int f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f417g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final a f418h = new a(this);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final a f419i = new a(this);

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public WidgetRun$RunType f420j = WidgetRun$RunType.f394a;

    public f(v.d dVar) {
        this.f413b = dVar;
    }

    public static void b(a aVar, a aVar2, int i3) {
        aVar.f407l.add(aVar2);
        aVar.f = i3;
        aVar2.f406k.add(aVar);
    }

    public static a h(v.c cVar) {
        v.c cVar2 = cVar.f;
        if (cVar2 == null) {
            return null;
        }
        v.d dVar = cVar2.f4426d;
        int iOrdinal = cVar2.f4427e.ordinal();
        if (iOrdinal == 1) {
            return dVar.f4437d.f418h;
        }
        if (iOrdinal == 2) {
            return dVar.f4439e.f418h;
        }
        if (iOrdinal == 3) {
            return dVar.f4437d.f419i;
        }
        if (iOrdinal == 4) {
            return dVar.f4439e.f419i;
        }
        if (iOrdinal != 5) {
            return null;
        }
        return dVar.f4439e.f410k;
    }

    public static a i(v.c cVar, int i3) {
        v.c cVar2 = cVar.f;
        if (cVar2 == null) {
            return null;
        }
        v.d dVar = cVar2.f4426d;
        f fVar = i3 == 0 ? dVar.f4437d : dVar.f4439e;
        int iOrdinal = cVar2.f4427e.ordinal();
        if (iOrdinal == 1 || iOrdinal == 2) {
            return fVar.f418h;
        }
        if (iOrdinal == 3 || iOrdinal == 4) {
            return fVar.f419i;
        }
        return null;
    }

    public final void c(a aVar, a aVar2, int i3, b bVar) {
        aVar.f407l.add(aVar2);
        aVar.f407l.add(this.f416e);
        aVar.f403h = i3;
        aVar.f404i = bVar;
        aVar2.f406k.add(aVar);
        bVar.f406k.add(aVar);
    }

    public abstract void d();

    public abstract void e();

    public abstract void f();

    public final int g(int i3, int i4) {
        if (i4 == 0) {
            v.d dVar = this.f413b;
            int i5 = dVar.f4466v;
            int iMax = Math.max(dVar.f4465u, i3);
            if (i5 > 0) {
                iMax = Math.min(i5, i3);
            }
            if (iMax != i3) {
                return iMax;
            }
        } else {
            v.d dVar2 = this.f413b;
            int i6 = dVar2.f4469y;
            int iMax2 = Math.max(dVar2.f4468x, i3);
            if (i6 > 0) {
                iMax2 = Math.min(i6, i3);
            }
            if (iMax2 != i3) {
                return iMax2;
            }
        }
        return i3;
    }

    public long j() {
        b bVar = this.f416e;
        if (bVar.f405j) {
            return bVar.f402g;
        }
        return 0L;
    }

    public abstract boolean k();

    /* JADX WARN: Code duplicated, block: B:29:0x0056 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:30:0x0058  */
    /* JADX WARN: Code duplicated, block: B:33:0x0060  */
    /* JADX WARN: Code duplicated, block: B:35:0x0064  */
    /* JADX WARN: Code duplicated, block: B:36:0x006b  */
    public final void l(v.c cVar, v.c cVar2, int i3) {
        b bVar;
        float f;
        int i4;
        a aVarH = h(cVar);
        a aVarH2 = h(cVar2);
        if (aVarH.f405j && aVarH2.f405j) {
            int iE = cVar.e() + aVarH.f402g;
            int iE2 = aVarH2.f402g - cVar2.e();
            int i5 = iE2 - iE;
            b bVar2 = this.f416e;
            if (!bVar2.f405j) {
                ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour = this.f415d;
                ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour2 = ConstraintWidget$DimensionBehaviour.f383c;
                if (constraintWidget$DimensionBehaviour == constraintWidget$DimensionBehaviour2) {
                    int i6 = this.f412a;
                    if (i6 == 0) {
                        bVar2.d(g(i5, i3));
                    } else if (i6 == 1) {
                        bVar2.d(Math.min(g(bVar2.f408m, i3), i5));
                    } else if (i6 == 2) {
                        v.d dVar = this.f413b;
                        v.d dVar2 = dVar.U;
                        if (dVar2 != null) {
                            b bVar3 = (i3 == 0 ? dVar2.f4437d : dVar2.f4439e).f416e;
                            if (bVar3.f405j) {
                                bVar2.d(g((int) ((bVar3.f402g * (i3 == 0 ? dVar.f4467w : dVar.f4470z)) + 0.5f), i3));
                            }
                        }
                    } else if (i6 == 3) {
                        v.d dVar3 = this.f413b;
                        f fVar = dVar3.f4437d;
                        if (fVar.f415d == constraintWidget$DimensionBehaviour2 && fVar.f412a == 3) {
                            e eVar = dVar3.f4439e;
                            if (eVar.f415d != constraintWidget$DimensionBehaviour2 || eVar.f412a != 3) {
                                if (i3 == 0) {
                                    fVar = dVar3.f4439e;
                                }
                                bVar = fVar.f416e;
                                if (bVar.f405j) {
                                    f = dVar3.X;
                                    if (i3 == 1) {
                                        i4 = (int) ((bVar.f402g / f) + 0.5f);
                                    } else {
                                        i4 = (int) ((f * bVar.f402g) + 0.5f);
                                    }
                                    bVar2.d(i4);
                                }
                            }
                        } else {
                            if (i3 == 0) {
                                fVar = dVar3.f4439e;
                            }
                            bVar = fVar.f416e;
                            if (bVar.f405j) {
                                f = dVar3.X;
                                if (i3 == 1) {
                                    i4 = (int) ((bVar.f402g / f) + 0.5f);
                                } else {
                                    i4 = (int) ((f * bVar.f402g) + 0.5f);
                                }
                                bVar2.d(i4);
                            }
                        }
                    }
                }
            }
            if (bVar2.f405j) {
                int i7 = bVar2.f402g;
                a aVar = this.f419i;
                a aVar2 = this.f418h;
                if (i7 == i5) {
                    aVar2.d(iE);
                    aVar.d(iE2);
                    return;
                }
                float f4 = i3 == 0 ? this.f413b.f4440e0 : this.f413b.f4441f0;
                if (aVarH == aVarH2) {
                    iE = aVarH.f402g;
                    iE2 = aVarH2.f402g;
                    f4 = 0.5f;
                }
                aVar2.d((int) ((((iE2 - iE) - i7) * f4) + iE + 0.5f));
                aVar.d(aVar2.f402g + bVar2.f402g);
            }
        }
    }
}
