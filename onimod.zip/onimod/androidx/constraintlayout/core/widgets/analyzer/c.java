package androidx.constraintlayout.core.widgets.analyzer;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class c extends f {
    @Override // w.d
    public final void a(w.d dVar) {
        v.a aVar = (v.a) this.f413b;
        int i3 = aVar.f4403s0;
        a aVar2 = this.f418h;
        ArrayList arrayList = aVar2.f407l;
        int size = arrayList.size();
        int i4 = 0;
        int i5 = 0;
        int i6 = -1;
        while (i5 < size) {
            Object obj = arrayList.get(i5);
            i5++;
            int i7 = ((a) obj).f402g;
            if (i6 == -1 || i7 < i6) {
                i6 = i7;
            }
            if (i4 < i7) {
                i4 = i7;
            }
        }
        if (i3 == 0 || i3 == 2) {
            aVar2.d(i6 + aVar.f4405u0);
        } else {
            aVar2.d(i4 + aVar.f4405u0);
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final void d() {
        v.d dVar = this.f413b;
        if (dVar instanceof v.a) {
            a aVar = this.f418h;
            aVar.f398b = true;
            ArrayList arrayList = aVar.f407l;
            v.a aVar2 = (v.a) dVar;
            int i3 = aVar2.f4403s0;
            boolean z4 = aVar2.f4404t0;
            int i4 = 0;
            if (i3 == 0) {
                aVar.f401e = DependencyNode$Type.f389d;
                while (i4 < aVar2.f4515r0) {
                    v.d dVar2 = aVar2.f4514q0[i4];
                    if (z4 || dVar2.f4445h0 != 8) {
                        a aVar3 = dVar2.f4437d.f418h;
                        aVar3.f406k.add(aVar);
                        arrayList.add(aVar3);
                    }
                    i4++;
                }
                m(this.f413b.f4437d.f418h);
                m(this.f413b.f4437d.f419i);
                return;
            }
            if (i3 == 1) {
                aVar.f401e = DependencyNode$Type.f390e;
                while (i4 < aVar2.f4515r0) {
                    v.d dVar3 = aVar2.f4514q0[i4];
                    if (z4 || dVar3.f4445h0 != 8) {
                        a aVar4 = dVar3.f4437d.f419i;
                        aVar4.f406k.add(aVar);
                        arrayList.add(aVar4);
                    }
                    i4++;
                }
                m(this.f413b.f4437d.f418h);
                m(this.f413b.f4437d.f419i);
                return;
            }
            if (i3 == 2) {
                aVar.f401e = DependencyNode$Type.f;
                while (i4 < aVar2.f4515r0) {
                    v.d dVar4 = aVar2.f4514q0[i4];
                    if (z4 || dVar4.f4445h0 != 8) {
                        a aVar5 = dVar4.f4439e.f418h;
                        aVar5.f406k.add(aVar);
                        arrayList.add(aVar5);
                    }
                    i4++;
                }
                m(this.f413b.f4439e.f418h);
                m(this.f413b.f4439e.f419i);
                return;
            }
            if (i3 != 3) {
                return;
            }
            aVar.f401e = DependencyNode$Type.f391g;
            while (i4 < aVar2.f4515r0) {
                v.d dVar5 = aVar2.f4514q0[i4];
                if (z4 || dVar5.f4445h0 != 8) {
                    a aVar6 = dVar5.f4439e.f419i;
                    aVar6.f406k.add(aVar);
                    arrayList.add(aVar6);
                }
                i4++;
            }
            m(this.f413b.f4439e.f418h);
            m(this.f413b.f4439e.f419i);
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final void e() {
        v.d dVar = this.f413b;
        if (dVar instanceof v.a) {
            int i3 = ((v.a) dVar).f4403s0;
            a aVar = this.f418h;
            if (i3 == 0 || i3 == 1) {
                dVar.Z = aVar.f402g;
            } else {
                dVar.f4432a0 = aVar.f402g;
            }
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final void f() {
        this.f414c = null;
        this.f418h.c();
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final boolean k() {
        return false;
    }

    public final void m(a aVar) {
        a aVar2 = this.f418h;
        aVar2.f406k.add(aVar);
        aVar.f407l.add(aVar2);
    }
}
