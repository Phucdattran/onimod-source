package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor$Type;
import androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour;
import java.util.ArrayList;
import v.i;

/* JADX INFO: loaded from: classes.dex */
public final class d extends f {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final int[] f409k = new int[2];

    public d(v.d dVar) {
        super(dVar);
        this.f418h.f401e = DependencyNode$Type.f389d;
        this.f419i.f401e = DependencyNode$Type.f390e;
        this.f = 0;
    }

    public static void m(int[] iArr, int i3, int i4, int i5, int i6, float f, int i7) {
        int i8 = i4 - i3;
        int i9 = i6 - i5;
        if (i7 != -1) {
            if (i7 == 0) {
                iArr[0] = (int) ((i9 * f) + 0.5f);
                iArr[1] = i9;
                return;
            } else {
                if (i7 != 1) {
                    return;
                }
                iArr[0] = i8;
                iArr[1] = (int) ((i8 * f) + 0.5f);
                return;
            }
        }
        int i10 = (int) ((i9 * f) + 0.5f);
        int i11 = (int) ((i8 / f) + 0.5f);
        if (i10 <= i8) {
            iArr[0] = i10;
            iArr[1] = i9;
        } else if (i11 <= i9) {
            iArr[0] = i8;
            iArr[1] = i11;
        }
    }

    /* JADX WARN: Code duplicated, block: B:116:0x026e  */
    /* JADX WARN: Code duplicated, block: B:118:0x027e  */
    /* JADX WARN: Code duplicated, block: B:11:0x0028  */
    @Override // w.d
    public final void a(w.d dVar) {
        float f;
        int iG;
        int i3;
        int iG2;
        float f4;
        float f5;
        float f6;
        int i4;
        if (this.f420j.ordinal() == 3) {
            v.d dVar2 = this.f413b;
            l(dVar2.I, dVar2.K, 0);
            return;
        }
        b bVar = this.f416e;
        boolean z4 = bVar.f405j;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour = ConstraintWidget$DimensionBehaviour.f383c;
        a aVar = this.f418h;
        a aVar2 = this.f419i;
        if (z4 || this.f415d != constraintWidget$DimensionBehaviour) {
            f = 0.5f;
        } else {
            v.d dVar3 = this.f413b;
            int i5 = dVar3.f4462r;
            if (i5 == 2) {
                f = 0.5f;
                v.d dVar4 = dVar3.U;
                if (dVar4 != null) {
                    b bVar2 = dVar4.f4437d.f416e;
                    if (bVar2.f405j) {
                        bVar.d((int) ((bVar2.f402g * dVar3.f4467w) + 0.5f));
                    }
                }
            } else if (i5 == 3) {
                int i6 = dVar3.f4463s;
                if (i6 == 0 || i6 == 3) {
                    e eVar = dVar3.f4439e;
                    a aVar3 = eVar.f418h;
                    a aVar4 = eVar.f419i;
                    boolean z5 = dVar3.I.f != null;
                    boolean z6 = dVar3.J.f != null;
                    boolean z7 = dVar3.K.f != null;
                    boolean z8 = dVar3.L.f != null;
                    f = 0.5f;
                    int i7 = dVar3.Y;
                    if (z5 && z6 && z7 && z8) {
                        float f7 = dVar3.X;
                        boolean z9 = aVar3.f405j;
                        ArrayList arrayList = aVar3.f407l;
                        int[] iArr = f409k;
                        if (z9 && aVar4.f405j) {
                            if (aVar.f399c && aVar2.f399c) {
                                m(iArr, ((a) aVar.f407l.get(0)).f402g + aVar.f, ((a) aVar2.f407l.get(0)).f402g - aVar2.f, aVar3.f402g + aVar3.f, aVar4.f402g - aVar4.f, f7, i7);
                                bVar.d(iArr[0]);
                                this.f413b.f4439e.f416e.d(iArr[1]);
                                return;
                            }
                            return;
                        }
                        if (aVar.f405j && aVar2.f405j) {
                            if (!aVar3.f399c || !aVar4.f399c) {
                                return;
                            }
                            m(iArr, aVar.f402g + aVar.f, aVar2.f402g - aVar2.f, ((a) arrayList.get(0)).f402g + aVar3.f, ((a) aVar4.f407l.get(0)).f402g - aVar4.f, f7, i7);
                            bVar.d(iArr[0]);
                            this.f413b.f4439e.f416e.d(iArr[1]);
                        }
                        if (!aVar.f399c || !aVar2.f399c || !aVar3.f399c || !aVar4.f399c) {
                            return;
                        }
                        m(iArr, ((a) aVar.f407l.get(0)).f402g + aVar.f, ((a) aVar2.f407l.get(0)).f402g - aVar2.f, ((a) arrayList.get(0)).f402g + aVar3.f, ((a) aVar4.f407l.get(0)).f402g - aVar4.f, f7, i7);
                        bVar.d(iArr[0]);
                        this.f413b.f4439e.f416e.d(iArr[1]);
                    } else if (z5 && z7) {
                        if (!aVar.f399c || !aVar2.f399c) {
                            return;
                        }
                        float f8 = dVar3.X;
                        int i8 = ((a) aVar.f407l.get(0)).f402g + aVar.f;
                        int i9 = ((a) aVar2.f407l.get(0)).f402g - aVar2.f;
                        if (i7 == -1 || i7 == 0) {
                            int iG3 = g(i9 - i8, 0);
                            int i10 = (int) ((iG3 * f8) + 0.5f);
                            int iG4 = g(i10, 1);
                            if (i10 != iG4) {
                                iG3 = (int) ((iG4 / f8) + 0.5f);
                            }
                            bVar.d(iG3);
                            this.f413b.f4439e.f416e.d(iG4);
                        } else if (i7 == 1) {
                            int iG5 = g(i9 - i8, 0);
                            int i11 = (int) ((iG5 / f8) + 0.5f);
                            int iG6 = g(i11, 1);
                            if (i11 != iG6) {
                                iG5 = (int) ((iG6 * f8) + 0.5f);
                            }
                            bVar.d(iG5);
                            this.f413b.f4439e.f416e.d(iG6);
                        }
                    } else if (z6 && z8) {
                        if (!aVar3.f399c || !aVar4.f399c) {
                            return;
                        }
                        float f9 = dVar3.X;
                        int i12 = ((a) aVar3.f407l.get(0)).f402g + aVar3.f;
                        int i13 = ((a) aVar4.f407l.get(0)).f402g - aVar4.f;
                        if (i7 == -1) {
                            iG = g(i13 - i12, 1);
                            i3 = (int) ((iG / f9) + 0.5f);
                            iG2 = g(i3, 0);
                            if (i3 != iG2) {
                                iG = (int) ((iG2 * f9) + 0.5f);
                            }
                            bVar.d(iG2);
                            this.f413b.f4439e.f416e.d(iG);
                        } else if (i7 == 0) {
                            int iG7 = g(i13 - i12, 1);
                            int i14 = (int) ((iG7 * f9) + 0.5f);
                            int iG8 = g(i14, 0);
                            if (i14 != iG8) {
                                iG7 = (int) ((iG8 / f9) + 0.5f);
                            }
                            bVar.d(iG8);
                            this.f413b.f4439e.f416e.d(iG7);
                        } else if (i7 == 1) {
                            iG = g(i13 - i12, 1);
                            i3 = (int) ((iG / f9) + 0.5f);
                            iG2 = g(i3, 0);
                            if (i3 != iG2) {
                                iG = (int) ((iG2 * f9) + 0.5f);
                            }
                            bVar.d(iG2);
                            this.f413b.f4439e.f416e.d(iG);
                        }
                    }
                } else {
                    int i15 = dVar3.Y;
                    if (i15 != -1) {
                        if (i15 == 0) {
                            f6 = dVar3.f4439e.f416e.f402g / dVar3.X;
                            i4 = (int) (f6 + 0.5f);
                        } else if (i15 != 1) {
                            i4 = 0;
                        } else {
                            f4 = dVar3.f4439e.f416e.f402g;
                            f5 = dVar3.X;
                        }
                        bVar.d(i4);
                        f = 0.5f;
                    } else {
                        f4 = dVar3.f4439e.f416e.f402g;
                        f5 = dVar3.X;
                    }
                    f6 = f4 * f5;
                    i4 = (int) (f6 + 0.5f);
                    bVar.d(i4);
                    f = 0.5f;
                }
            } else {
                f = 0.5f;
            }
        }
        boolean z10 = aVar.f399c;
        ArrayList arrayList2 = aVar.f407l;
        if (z10) {
            boolean z11 = aVar2.f399c;
            ArrayList arrayList3 = aVar2.f407l;
            if (z11) {
                if (aVar.f405j && aVar2.f405j && bVar.f405j) {
                    return;
                }
                if (!bVar.f405j && this.f415d == constraintWidget$DimensionBehaviour) {
                    v.d dVar5 = this.f413b;
                    if (dVar5.f4462r == 0 && !dVar5.x()) {
                        a aVar5 = (a) arrayList2.get(0);
                        a aVar6 = (a) arrayList3.get(0);
                        int i16 = aVar5.f402g + aVar.f;
                        int i17 = aVar6.f402g + aVar2.f;
                        aVar.d(i16);
                        aVar2.d(i17);
                        bVar.d(i17 - i16);
                        return;
                    }
                }
                if (!bVar.f405j && this.f415d == constraintWidget$DimensionBehaviour && this.f412a == 1 && arrayList2.size() > 0 && arrayList3.size() > 0) {
                    int iMin = Math.min((((a) arrayList3.get(0)).f402g + aVar2.f) - (((a) arrayList2.get(0)).f402g + aVar.f), bVar.f408m);
                    v.d dVar6 = this.f413b;
                    int i18 = dVar6.f4466v;
                    int iMax = Math.max(dVar6.f4465u, iMin);
                    if (i18 > 0) {
                        iMax = Math.min(i18, iMax);
                    }
                    bVar.d(iMax);
                }
                if (bVar.f405j) {
                    a aVar7 = (a) arrayList2.get(0);
                    a aVar8 = (a) arrayList3.get(0);
                    int i19 = aVar7.f402g;
                    int i20 = aVar.f + i19;
                    int i21 = aVar8.f402g;
                    int i22 = aVar2.f + i21;
                    float f10 = this.f413b.f4440e0;
                    if (aVar7 == aVar8) {
                        f10 = 0.5f;
                    } else {
                        i19 = i20;
                        i21 = i22;
                    }
                    aVar.d((int) ((((i21 - i19) - bVar.f402g) * f10) + i19 + f));
                    aVar2.d(aVar.f402g + bVar.f402g);
                }
            }
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final void d() {
        v.d dVar;
        v.d dVar2;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour;
        v.d dVar3;
        v.d dVar4;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour2;
        v.d dVar5 = this.f413b;
        boolean z4 = dVar5.f4431a;
        b bVar = this.f416e;
        if (z4) {
            bVar.d(dVar5.q());
        }
        boolean z5 = bVar.f405j;
        ArrayList arrayList = bVar.f406k;
        ArrayList arrayList2 = bVar.f407l;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour3 = ConstraintWidget$DimensionBehaviour.f384d;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour4 = ConstraintWidget$DimensionBehaviour.f383c;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour5 = ConstraintWidget$DimensionBehaviour.f381a;
        a aVar = this.f419i;
        a aVar2 = this.f418h;
        if (!z5) {
            v.d dVar6 = this.f413b;
            ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour6 = dVar6.T[0];
            this.f415d = constraintWidget$DimensionBehaviour6;
            if (constraintWidget$DimensionBehaviour6 != constraintWidget$DimensionBehaviour4) {
                if (constraintWidget$DimensionBehaviour6 == constraintWidget$DimensionBehaviour3 && (dVar4 = dVar6.U) != null && ((constraintWidget$DimensionBehaviour2 = dVar4.T[0]) == constraintWidget$DimensionBehaviour5 || constraintWidget$DimensionBehaviour2 == constraintWidget$DimensionBehaviour3)) {
                    int iQ = (dVar4.q() - this.f413b.I.e()) - this.f413b.K.e();
                    f.b(aVar2, dVar4.f4437d.f418h, this.f413b.I.e());
                    f.b(aVar, dVar4.f4437d.f419i, -this.f413b.K.e());
                    bVar.d(iQ);
                    return;
                }
                if (constraintWidget$DimensionBehaviour6 == constraintWidget$DimensionBehaviour5) {
                    bVar.d(dVar6.q());
                }
            }
        } else if (this.f415d == constraintWidget$DimensionBehaviour3 && (dVar2 = (dVar = this.f413b).U) != null && ((constraintWidget$DimensionBehaviour = dVar2.T[0]) == constraintWidget$DimensionBehaviour5 || constraintWidget$DimensionBehaviour == constraintWidget$DimensionBehaviour3)) {
            f.b(aVar2, dVar2.f4437d.f418h, dVar.I.e());
            f.b(aVar, dVar2.f4437d.f419i, -this.f413b.K.e());
            return;
        }
        if (bVar.f405j) {
            v.d dVar7 = this.f413b;
            if (dVar7.f4431a) {
                v.c[] cVarArr = dVar7.Q;
                v.c cVar = cVarArr[0];
                v.c cVar2 = cVar.f;
                if (cVar2 != null && cVarArr[1].f != null) {
                    if (dVar7.x()) {
                        aVar2.f = this.f413b.Q[0].e();
                        aVar.f = -this.f413b.Q[1].e();
                        return;
                    }
                    a aVarH = f.h(this.f413b.Q[0]);
                    if (aVarH != null) {
                        f.b(aVar2, aVarH, this.f413b.Q[0].e());
                    }
                    a aVarH2 = f.h(this.f413b.Q[1]);
                    if (aVarH2 != null) {
                        f.b(aVar, aVarH2, -this.f413b.Q[1].e());
                    }
                    aVar2.f398b = true;
                    aVar.f398b = true;
                    return;
                }
                if (cVar2 != null) {
                    a aVarH3 = f.h(cVar);
                    if (aVarH3 != null) {
                        f.b(aVar2, aVarH3, this.f413b.Q[0].e());
                        f.b(aVar, aVar2, bVar.f402g);
                        return;
                    }
                    return;
                }
                v.c cVar3 = cVarArr[1];
                if (cVar3.f != null) {
                    a aVarH4 = f.h(cVar3);
                    if (aVarH4 != null) {
                        f.b(aVar, aVarH4, -this.f413b.Q[1].e());
                        f.b(aVar2, aVar, -bVar.f402g);
                        return;
                    }
                    return;
                }
                if ((dVar7 instanceof i) || dVar7.U == null || dVar7.i(ConstraintAnchor$Type.f).f != null) {
                    return;
                }
                v.d dVar8 = this.f413b;
                f.b(aVar2, dVar8.U.f4437d.f418h, dVar8.r());
                f.b(aVar, aVar2, bVar.f402g);
                return;
            }
        }
        if (this.f415d == constraintWidget$DimensionBehaviour4) {
            v.d dVar9 = this.f413b;
            int i3 = dVar9.f4462r;
            if (i3 == 2) {
                v.d dVar10 = dVar9.U;
                if (dVar10 != null) {
                    b bVar2 = dVar10.f4439e.f416e;
                    arrayList2.add(bVar2);
                    bVar2.f406k.add(bVar);
                    bVar.f398b = true;
                    arrayList.add(aVar2);
                    arrayList.add(aVar);
                }
            } else if (i3 == 3) {
                if (dVar9.f4463s == 3) {
                    aVar2.f397a = this;
                    aVar.f397a = this;
                    e eVar = dVar9.f4439e;
                    eVar.f418h.f397a = this;
                    eVar.f419i.f397a = this;
                    bVar.f397a = this;
                    if (dVar9.y()) {
                        arrayList2.add(this.f413b.f4439e.f416e);
                        this.f413b.f4439e.f416e.f406k.add(bVar);
                        e eVar2 = this.f413b.f4439e;
                        eVar2.f416e.f397a = this;
                        arrayList2.add(eVar2.f418h);
                        arrayList2.add(this.f413b.f4439e.f419i);
                        this.f413b.f4439e.f418h.f406k.add(bVar);
                        this.f413b.f4439e.f419i.f406k.add(bVar);
                    } else if (this.f413b.x()) {
                        this.f413b.f4439e.f416e.f407l.add(bVar);
                        arrayList.add(this.f413b.f4439e.f416e);
                    } else {
                        this.f413b.f4439e.f416e.f407l.add(bVar);
                    }
                } else {
                    b bVar3 = dVar9.f4439e.f416e;
                    arrayList2.add(bVar3);
                    bVar3.f406k.add(bVar);
                    this.f413b.f4439e.f418h.f406k.add(bVar);
                    this.f413b.f4439e.f419i.f406k.add(bVar);
                    bVar.f398b = true;
                    arrayList.add(aVar2);
                    arrayList.add(aVar);
                    aVar2.f407l.add(bVar);
                    aVar.f407l.add(bVar);
                }
            }
        }
        v.d dVar11 = this.f413b;
        v.c[] cVarArr2 = dVar11.Q;
        v.c cVar4 = cVarArr2[0];
        v.c cVar5 = cVar4.f;
        if (cVar5 != null && cVarArr2[1].f != null) {
            if (dVar11.x()) {
                aVar2.f = this.f413b.Q[0].e();
                aVar.f = -this.f413b.Q[1].e();
                return;
            }
            a aVarH5 = f.h(this.f413b.Q[0]);
            a aVarH6 = f.h(this.f413b.Q[1]);
            if (aVarH5 != null) {
                aVarH5.b(this);
            }
            if (aVarH6 != null) {
                aVarH6.b(this);
            }
            this.f420j = WidgetRun$RunType.f395b;
            return;
        }
        if (cVar5 != null) {
            a aVarH7 = f.h(cVar4);
            if (aVarH7 != null) {
                f.b(aVar2, aVarH7, this.f413b.Q[0].e());
                c(aVar, aVar2, 1, bVar);
                return;
            }
            return;
        }
        v.c cVar6 = cVarArr2[1];
        if (cVar6.f != null) {
            a aVarH8 = f.h(cVar6);
            if (aVarH8 != null) {
                f.b(aVar, aVarH8, -this.f413b.Q[1].e());
                c(aVar2, aVar, -1, bVar);
                return;
            }
            return;
        }
        if ((dVar11 instanceof i) || (dVar3 = dVar11.U) == null) {
            return;
        }
        f.b(aVar2, dVar3.f4437d.f418h, dVar11.r());
        c(aVar, aVar2, 1, bVar);
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final void e() {
        a aVar = this.f418h;
        if (aVar.f405j) {
            this.f413b.Z = aVar.f402g;
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final void f() {
        this.f414c = null;
        this.f418h.c();
        this.f419i.c();
        this.f416e.c();
        this.f417g = false;
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final boolean k() {
        return this.f415d != ConstraintWidget$DimensionBehaviour.f383c || this.f413b.f4462r == 0;
    }

    public final void n() {
        this.f417g = false;
        a aVar = this.f418h;
        aVar.c();
        aVar.f405j = false;
        a aVar2 = this.f419i;
        aVar2.c();
        aVar2.f405j = false;
        this.f416e.f405j = false;
    }

    public final String toString() {
        return "HorizontalRun " + this.f413b.f4447i0;
    }
}
