package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor$Type;
import androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour;
import java.util.ArrayList;
import v.i;

/* JADX INFO: loaded from: classes.dex */
public final class e extends f {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final a f410k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public w.a f411l;

    public e(v.d dVar) {
        super(dVar);
        a aVar = new a(this);
        this.f410k = aVar;
        this.f411l = null;
        this.f418h.f401e = DependencyNode$Type.f;
        this.f419i.f401e = DependencyNode$Type.f391g;
        aVar.f401e = DependencyNode$Type.f392h;
        this.f = 1;
    }

    @Override // w.d
    public final void a(w.d dVar) {
        float f;
        float f4;
        float f5;
        int i3;
        if (this.f420j.ordinal() == 3) {
            v.d dVar2 = this.f413b;
            l(dVar2.J, dVar2.L, 1);
            return;
        }
        b bVar = this.f416e;
        boolean z4 = bVar.f399c;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour = ConstraintWidget$DimensionBehaviour.f383c;
        if (z4 && !bVar.f405j && this.f415d == constraintWidget$DimensionBehaviour) {
            v.d dVar3 = this.f413b;
            int i4 = dVar3.f4463s;
            if (i4 == 2) {
                v.d dVar4 = dVar3.U;
                if (dVar4 != null) {
                    b bVar2 = dVar4.f4439e.f416e;
                    if (bVar2.f405j) {
                        bVar.d((int) ((bVar2.f402g * dVar3.f4470z) + 0.5f));
                    }
                }
            } else if (i4 == 3) {
                b bVar3 = dVar3.f4437d.f416e;
                if (bVar3.f405j) {
                    int i5 = dVar3.Y;
                    if (i5 != -1) {
                        if (i5 == 0) {
                            f5 = bVar3.f402g * dVar3.X;
                            i3 = (int) (f5 + 0.5f);
                        } else if (i5 != 1) {
                            i3 = 0;
                        } else {
                            f = bVar3.f402g;
                            f4 = dVar3.X;
                        }
                        bVar.d(i3);
                    } else {
                        f = bVar3.f402g;
                        f4 = dVar3.X;
                    }
                    f5 = f / f4;
                    i3 = (int) (f5 + 0.5f);
                    bVar.d(i3);
                }
            }
        }
        a aVar = this.f418h;
        boolean z5 = aVar.f399c;
        ArrayList arrayList = aVar.f407l;
        if (z5) {
            a aVar2 = this.f419i;
            boolean z6 = aVar2.f399c;
            ArrayList arrayList2 = aVar2.f407l;
            if (z6) {
                if (aVar.f405j && aVar2.f405j && bVar.f405j) {
                    return;
                }
                if (!bVar.f405j && this.f415d == constraintWidget$DimensionBehaviour) {
                    v.d dVar5 = this.f413b;
                    if (dVar5.f4462r == 0 && !dVar5.y()) {
                        a aVar3 = (a) arrayList.get(0);
                        a aVar4 = (a) arrayList2.get(0);
                        int i6 = aVar3.f402g + aVar.f;
                        int i7 = aVar4.f402g + aVar2.f;
                        aVar.d(i6);
                        aVar2.d(i7);
                        bVar.d(i7 - i6);
                        return;
                    }
                }
                if (!bVar.f405j && this.f415d == constraintWidget$DimensionBehaviour && this.f412a == 1 && arrayList.size() > 0 && arrayList2.size() > 0) {
                    a aVar5 = (a) arrayList.get(0);
                    int i8 = (((a) arrayList2.get(0)).f402g + aVar2.f) - (aVar5.f402g + aVar.f);
                    int i9 = bVar.f408m;
                    if (i8 < i9) {
                        bVar.d(i8);
                    } else {
                        bVar.d(i9);
                    }
                }
                if (bVar.f405j && arrayList.size() > 0 && arrayList2.size() > 0) {
                    a aVar6 = (a) arrayList.get(0);
                    a aVar7 = (a) arrayList2.get(0);
                    int i10 = aVar6.f402g;
                    int i11 = aVar.f + i10;
                    int i12 = aVar7.f402g;
                    int i13 = aVar2.f + i12;
                    float f6 = this.f413b.f4441f0;
                    if (aVar6 == aVar7) {
                        f6 = 0.5f;
                    } else {
                        i10 = i11;
                        i12 = i13;
                    }
                    aVar.d((int) ((((i12 - i10) - bVar.f402g) * f6) + i10 + 0.5f));
                    aVar2.d(aVar.f402g + bVar.f402g);
                }
            }
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final void d() {
        v.d dVar;
        v.d dVar2;
        v.d dVar3;
        v.d dVar4;
        v.d dVar5 = this.f413b;
        boolean z4 = dVar5.f4431a;
        b bVar = this.f416e;
        if (z4) {
            bVar.d(dVar5.k());
        }
        boolean z5 = bVar.f405j;
        ArrayList arrayList = bVar.f406k;
        ArrayList arrayList2 = bVar.f407l;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour = ConstraintWidget$DimensionBehaviour.f384d;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour2 = ConstraintWidget$DimensionBehaviour.f381a;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour3 = ConstraintWidget$DimensionBehaviour.f383c;
        a aVar = this.f419i;
        a aVar2 = this.f418h;
        if (!z5) {
            v.d dVar6 = this.f413b;
            this.f415d = dVar6.T[1];
            if (dVar6.E) {
                this.f411l = new w.a(this);
            }
            ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour4 = this.f415d;
            if (constraintWidget$DimensionBehaviour4 != constraintWidget$DimensionBehaviour3) {
                if (constraintWidget$DimensionBehaviour4 == constraintWidget$DimensionBehaviour && (dVar4 = this.f413b.U) != null && dVar4.T[1] == constraintWidget$DimensionBehaviour2) {
                    int iK = (dVar4.k() - this.f413b.J.e()) - this.f413b.L.e();
                    f.b(aVar2, dVar4.f4439e.f418h, this.f413b.J.e());
                    f.b(aVar, dVar4.f4439e.f419i, -this.f413b.L.e());
                    bVar.d(iK);
                    return;
                }
                if (constraintWidget$DimensionBehaviour4 == constraintWidget$DimensionBehaviour2) {
                    bVar.d(this.f413b.k());
                }
            }
        } else if (this.f415d == constraintWidget$DimensionBehaviour && (dVar2 = (dVar = this.f413b).U) != null && dVar2.T[1] == constraintWidget$DimensionBehaviour2) {
            f.b(aVar2, dVar2.f4439e.f418h, dVar.J.e());
            f.b(aVar, dVar2.f4439e.f419i, -this.f413b.L.e());
            return;
        }
        boolean z6 = bVar.f405j;
        a aVar3 = this.f410k;
        if (z6) {
            v.d dVar7 = this.f413b;
            if (dVar7.f4431a) {
                v.c[] cVarArr = dVar7.Q;
                v.c cVar = cVarArr[2];
                v.c cVar2 = cVar.f;
                if (cVar2 != null && cVarArr[3].f != null) {
                    if (dVar7.y()) {
                        aVar2.f = this.f413b.Q[2].e();
                        aVar.f = -this.f413b.Q[3].e();
                    } else {
                        a aVarH = f.h(this.f413b.Q[2]);
                        if (aVarH != null) {
                            f.b(aVar2, aVarH, this.f413b.Q[2].e());
                        }
                        a aVarH2 = f.h(this.f413b.Q[3]);
                        if (aVarH2 != null) {
                            f.b(aVar, aVarH2, -this.f413b.Q[3].e());
                        }
                        aVar2.f398b = true;
                        aVar.f398b = true;
                    }
                    v.d dVar8 = this.f413b;
                    if (dVar8.E) {
                        f.b(aVar3, aVar2, dVar8.f4434b0);
                        return;
                    }
                    return;
                }
                if (cVar2 != null) {
                    a aVarH3 = f.h(cVar);
                    if (aVarH3 != null) {
                        f.b(aVar2, aVarH3, this.f413b.Q[2].e());
                        f.b(aVar, aVar2, bVar.f402g);
                        v.d dVar9 = this.f413b;
                        if (dVar9.E) {
                            f.b(aVar3, aVar2, dVar9.f4434b0);
                            return;
                        }
                        return;
                    }
                    return;
                }
                v.c cVar3 = cVarArr[3];
                if (cVar3.f != null) {
                    a aVarH4 = f.h(cVar3);
                    if (aVarH4 != null) {
                        f.b(aVar, aVarH4, -this.f413b.Q[3].e());
                        f.b(aVar2, aVar, -bVar.f402g);
                    }
                    v.d dVar10 = this.f413b;
                    if (dVar10.E) {
                        f.b(aVar3, aVar2, dVar10.f4434b0);
                        return;
                    }
                    return;
                }
                v.c cVar4 = cVarArr[4];
                if (cVar4.f != null) {
                    a aVarH5 = f.h(cVar4);
                    if (aVarH5 != null) {
                        f.b(aVar3, aVarH5, 0);
                        f.b(aVar2, aVar3, -this.f413b.f4434b0);
                        f.b(aVar, aVar2, bVar.f402g);
                        return;
                    }
                    return;
                }
                if ((dVar7 instanceof i) || dVar7.U == null || dVar7.i(ConstraintAnchor$Type.f).f != null) {
                    return;
                }
                v.d dVar11 = this.f413b;
                f.b(aVar2, dVar11.U.f4439e.f418h, dVar11.s());
                f.b(aVar, aVar2, bVar.f402g);
                v.d dVar12 = this.f413b;
                if (dVar12.E) {
                    f.b(aVar3, aVar2, dVar12.f4434b0);
                    return;
                }
                return;
            }
        }
        if (z6 || this.f415d != constraintWidget$DimensionBehaviour3) {
            bVar.b(this);
        } else {
            v.d dVar13 = this.f413b;
            int i3 = dVar13.f4463s;
            if (i3 == 2) {
                v.d dVar14 = dVar13.U;
                if (dVar14 != null) {
                    b bVar2 = dVar14.f4439e.f416e;
                    arrayList2.add(bVar2);
                    bVar2.f406k.add(bVar);
                    bVar.f398b = true;
                    arrayList.add(aVar2);
                    arrayList.add(aVar);
                }
            } else if (i3 == 3 && !dVar13.y()) {
                v.d dVar15 = this.f413b;
                if (dVar15.f4462r != 3) {
                    b bVar3 = dVar15.f4437d.f416e;
                    arrayList2.add(bVar3);
                    bVar3.f406k.add(bVar);
                    bVar.f398b = true;
                    arrayList.add(aVar2);
                    arrayList.add(aVar);
                }
            }
        }
        v.d dVar16 = this.f413b;
        v.c[] cVarArr2 = dVar16.Q;
        v.c cVar5 = cVarArr2[2];
        v.c cVar6 = cVar5.f;
        if (cVar6 != null && cVarArr2[3].f != null) {
            if (dVar16.y()) {
                aVar2.f = this.f413b.Q[2].e();
                aVar.f = -this.f413b.Q[3].e();
            } else {
                a aVarH6 = f.h(this.f413b.Q[2]);
                a aVarH7 = f.h(this.f413b.Q[3]);
                if (aVarH6 != null) {
                    aVarH6.b(this);
                }
                if (aVarH7 != null) {
                    aVarH7.b(this);
                }
                this.f420j = WidgetRun$RunType.f395b;
            }
            if (this.f413b.E) {
                c(aVar3, aVar2, 1, this.f411l);
            }
        } else if (cVar6 != null) {
            a aVarH8 = f.h(cVar5);
            if (aVarH8 != null) {
                f.b(aVar2, aVarH8, this.f413b.Q[2].e());
                c(aVar, aVar2, 1, bVar);
                if (this.f413b.E) {
                    c(aVar3, aVar2, 1, this.f411l);
                }
                if (this.f415d == constraintWidget$DimensionBehaviour3) {
                    v.d dVar17 = this.f413b;
                    if (dVar17.X > 0.0f) {
                        d dVar18 = dVar17.f4437d;
                        if (dVar18.f415d == constraintWidget$DimensionBehaviour3) {
                            dVar18.f416e.f406k.add(bVar);
                            arrayList2.add(this.f413b.f4437d.f416e);
                            bVar.f397a = this;
                        }
                    }
                }
            }
        } else {
            v.c cVar7 = cVarArr2[3];
            if (cVar7.f != null) {
                a aVarH9 = f.h(cVar7);
                if (aVarH9 != null) {
                    f.b(aVar, aVarH9, -this.f413b.Q[3].e());
                    c(aVar2, aVar, -1, bVar);
                    if (this.f413b.E) {
                        c(aVar3, aVar2, 1, this.f411l);
                    }
                }
            } else {
                v.c cVar8 = cVarArr2[4];
                if (cVar8.f != null) {
                    a aVarH10 = f.h(cVar8);
                    if (aVarH10 != null) {
                        f.b(aVar3, aVarH10, 0);
                        c(aVar2, aVar3, -1, this.f411l);
                        c(aVar, aVar2, 1, bVar);
                    }
                } else if (!(dVar16 instanceof i) && (dVar3 = dVar16.U) != null) {
                    f.b(aVar2, dVar3.f4439e.f418h, dVar16.s());
                    c(aVar, aVar2, 1, bVar);
                    if (this.f413b.E) {
                        c(aVar3, aVar2, 1, this.f411l);
                    }
                    if (this.f415d == constraintWidget$DimensionBehaviour3) {
                        v.d dVar19 = this.f413b;
                        if (dVar19.X > 0.0f) {
                            d dVar20 = dVar19.f4437d;
                            if (dVar20.f415d == constraintWidget$DimensionBehaviour3) {
                                dVar20.f416e.f406k.add(bVar);
                                arrayList2.add(this.f413b.f4437d.f416e);
                                bVar.f397a = this;
                            }
                        }
                    }
                }
            }
        }
        if (arrayList2.size() == 0) {
            bVar.f399c = true;
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final void e() {
        a aVar = this.f418h;
        if (aVar.f405j) {
            this.f413b.f4432a0 = aVar.f402g;
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final void f() {
        this.f414c = null;
        this.f418h.c();
        this.f419i.c();
        this.f410k.c();
        this.f416e.c();
        this.f417g = false;
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.f
    public final boolean k() {
        return this.f415d != ConstraintWidget$DimensionBehaviour.f383c || this.f413b.f4463s == 0;
    }

    public final void m() {
        this.f417g = false;
        a aVar = this.f418h;
        aVar.c();
        aVar.f405j = false;
        a aVar2 = this.f419i;
        aVar2.c();
        aVar2.f405j = false;
        a aVar3 = this.f410k;
        aVar3.c();
        aVar3.f405j = false;
        this.f416e.f405j = false;
    }

    public final String toString() {
        return "VerticalRun " + this.f413b.f4447i0;
    }
}
