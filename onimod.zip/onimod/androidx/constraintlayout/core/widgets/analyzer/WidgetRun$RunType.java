package androidx.constraintlayout.core.widgets.analyzer;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
final class WidgetRun$RunType {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final WidgetRun$RunType f394a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final WidgetRun$RunType f395b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ WidgetRun$RunType[] f396c;

    static {
        WidgetRun$RunType widgetRun$RunType = new WidgetRun$RunType("NONE", 0);
        f394a = widgetRun$RunType;
        WidgetRun$RunType widgetRun$RunType2 = new WidgetRun$RunType("START", 1);
        WidgetRun$RunType widgetRun$RunType3 = new WidgetRun$RunType("END", 2);
        WidgetRun$RunType widgetRun$RunType4 = new WidgetRun$RunType("CENTER", 3);
        f395b = widgetRun$RunType4;
        f396c = new WidgetRun$RunType[]{widgetRun$RunType, widgetRun$RunType2, widgetRun$RunType3, widgetRun$RunType4};
    }

    public static WidgetRun$RunType valueOf(String str) {
        return (WidgetRun$RunType) Enum.valueOf(WidgetRun$RunType.class, str);
    }

    public static WidgetRun$RunType[] values() {
        return (WidgetRun$RunType[]) f396c.clone();
    }
}
