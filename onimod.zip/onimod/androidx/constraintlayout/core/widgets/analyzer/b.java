package androidx.constraintlayout.core.widgets.analyzer;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class b extends a {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f408m;

    public b(f fVar) {
        super(fVar);
        if (fVar instanceof d) {
            this.f401e = DependencyNode$Type.f387b;
        } else {
            this.f401e = DependencyNode$Type.f388c;
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.a
    public final void d(int i3) {
        if (this.f405j) {
            return;
        }
        this.f405j = true;
        this.f402g = i3;
        ArrayList arrayList = this.f406k;
        int size = arrayList.size();
        int i4 = 0;
        while (i4 < size) {
            Object obj = arrayList.get(i4);
            i4++;
            w.d dVar = (w.d) obj;
            dVar.a(dVar);
        }
    }
}
