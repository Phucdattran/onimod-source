package androidx.constraintlayout.core.widgets;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class ConstraintWidget$DimensionBehaviour {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final ConstraintWidget$DimensionBehaviour f381a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final ConstraintWidget$DimensionBehaviour f382b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final ConstraintWidget$DimensionBehaviour f383c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final ConstraintWidget$DimensionBehaviour f384d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final /* synthetic */ ConstraintWidget$DimensionBehaviour[] f385e;

    static {
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour = new ConstraintWidget$DimensionBehaviour("FIXED", 0);
        f381a = constraintWidget$DimensionBehaviour;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour2 = new ConstraintWidget$DimensionBehaviour("WRAP_CONTENT", 1);
        f382b = constraintWidget$DimensionBehaviour2;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour3 = new ConstraintWidget$DimensionBehaviour("MATCH_CONSTRAINT", 2);
        f383c = constraintWidget$DimensionBehaviour3;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour4 = new ConstraintWidget$DimensionBehaviour("MATCH_PARENT", 3);
        f384d = constraintWidget$DimensionBehaviour4;
        f385e = new ConstraintWidget$DimensionBehaviour[]{constraintWidget$DimensionBehaviour, constraintWidget$DimensionBehaviour2, constraintWidget$DimensionBehaviour3, constraintWidget$DimensionBehaviour4};
    }

    public static ConstraintWidget$DimensionBehaviour valueOf(String str) {
        return (ConstraintWidget$DimensionBehaviour) Enum.valueOf(ConstraintWidget$DimensionBehaviour.class, str);
    }

    public static ConstraintWidget$DimensionBehaviour[] values() {
        return (ConstraintWidget$DimensionBehaviour[]) f385e.clone();
    }
}
