package androidx.constraintlayout.core;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class SolverVariable$Type {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final SolverVariable$Type f368a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final SolverVariable$Type f369b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final SolverVariable$Type f370c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final SolverVariable$Type f371d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final /* synthetic */ SolverVariable$Type[] f372e;

    static {
        SolverVariable$Type solverVariable$Type = new SolverVariable$Type("UNRESTRICTED", 0);
        f368a = solverVariable$Type;
        SolverVariable$Type solverVariable$Type2 = new SolverVariable$Type("CONSTANT", 1);
        SolverVariable$Type solverVariable$Type3 = new SolverVariable$Type("SLACK", 2);
        f369b = solverVariable$Type3;
        SolverVariable$Type solverVariable$Type4 = new SolverVariable$Type("ERROR", 3);
        f370c = solverVariable$Type4;
        SolverVariable$Type solverVariable$Type5 = new SolverVariable$Type("UNKNOWN", 4);
        f371d = solverVariable$Type5;
        f372e = new SolverVariable$Type[]{solverVariable$Type, solverVariable$Type2, solverVariable$Type3, solverVariable$Type4, solverVariable$Type5};
    }

    public static SolverVariable$Type valueOf(String str) {
        return (SolverVariable$Type) Enum.valueOf(SolverVariable$Type.class, str);
    }

    public static SolverVariable$Type[] values() {
        return (SolverVariable$Type[]) f372e.clone();
    }
}
