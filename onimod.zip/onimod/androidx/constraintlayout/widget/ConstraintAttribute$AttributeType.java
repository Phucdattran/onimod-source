package androidx.constraintlayout.widget;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class ConstraintAttribute$AttributeType {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final ConstraintAttribute$AttributeType f422a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final ConstraintAttribute$AttributeType f423b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final ConstraintAttribute$AttributeType f424c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final ConstraintAttribute$AttributeType f425d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final ConstraintAttribute$AttributeType f426e;
    public static final ConstraintAttribute$AttributeType f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final ConstraintAttribute$AttributeType f427g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final ConstraintAttribute$AttributeType f428h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final /* synthetic */ ConstraintAttribute$AttributeType[] f429i;

    static {
        ConstraintAttribute$AttributeType constraintAttribute$AttributeType = new ConstraintAttribute$AttributeType("INT_TYPE", 0);
        f422a = constraintAttribute$AttributeType;
        ConstraintAttribute$AttributeType constraintAttribute$AttributeType2 = new ConstraintAttribute$AttributeType("FLOAT_TYPE", 1);
        f423b = constraintAttribute$AttributeType2;
        ConstraintAttribute$AttributeType constraintAttribute$AttributeType3 = new ConstraintAttribute$AttributeType("COLOR_TYPE", 2);
        f424c = constraintAttribute$AttributeType3;
        ConstraintAttribute$AttributeType constraintAttribute$AttributeType4 = new ConstraintAttribute$AttributeType("COLOR_DRAWABLE_TYPE", 3);
        f425d = constraintAttribute$AttributeType4;
        ConstraintAttribute$AttributeType constraintAttribute$AttributeType5 = new ConstraintAttribute$AttributeType("STRING_TYPE", 4);
        f426e = constraintAttribute$AttributeType5;
        ConstraintAttribute$AttributeType constraintAttribute$AttributeType6 = new ConstraintAttribute$AttributeType("BOOLEAN_TYPE", 5);
        f = constraintAttribute$AttributeType6;
        ConstraintAttribute$AttributeType constraintAttribute$AttributeType7 = new ConstraintAttribute$AttributeType("DIMENSION_TYPE", 6);
        f427g = constraintAttribute$AttributeType7;
        ConstraintAttribute$AttributeType constraintAttribute$AttributeType8 = new ConstraintAttribute$AttributeType("REFERENCE_TYPE", 7);
        f428h = constraintAttribute$AttributeType8;
        f429i = new ConstraintAttribute$AttributeType[]{constraintAttribute$AttributeType, constraintAttribute$AttributeType2, constraintAttribute$AttributeType3, constraintAttribute$AttributeType4, constraintAttribute$AttributeType5, constraintAttribute$AttributeType6, constraintAttribute$AttributeType7, constraintAttribute$AttributeType8};
    }

    public static ConstraintAttribute$AttributeType valueOf(String str) {
        return (ConstraintAttribute$AttributeType) Enum.valueOf(ConstraintAttribute$AttributeType.class, str);
    }

    public static ConstraintAttribute$AttributeType[] values() {
        return (ConstraintAttribute$AttributeType[]) f429i.clone();
    }
}
