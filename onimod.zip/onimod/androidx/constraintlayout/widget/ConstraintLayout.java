package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.core.widgets.ConstraintAnchor$Type;
import androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour;
import androidx.emoji2.text.q;
import androidx.emoji2.text.u;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import kotlinx.coroutines.internal.a;
import org.xmlpull.v1.XmlPullParserException;
import top.niunaijun.blackbox.core.system.JarConfig;
import top.niunaijun.blackbox.entity.location.BCell;
import top.niunaijun.blackbox.proxy.ProxyManifest;
import v.d;
import v.e;
import v.h;
import v.i;
import v.j;
import y.c;
import y.f;
import y.g;
import y.n;
import y.o;
import y.p;
import y.r;
import y.s;

/* JADX INFO: loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static s f430p;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final SparseArray f431a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f432b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final e f433c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f434d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f435e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f436g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f437h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f438i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public n f439j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public q f440k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f441l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public HashMap f442m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final SparseArray f443n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final f f444o;

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f431a = new SparseArray();
        this.f432b = new ArrayList(4);
        this.f433c = new e();
        this.f434d = 0;
        this.f435e = 0;
        this.f = Integer.MAX_VALUE;
        this.f436g = Integer.MAX_VALUE;
        this.f437h = true;
        this.f438i = 257;
        this.f439j = null;
        this.f440k = null;
        this.f441l = -1;
        this.f442m = new HashMap();
        this.f443n = new SparseArray();
        this.f444o = new f(this, this);
        i(attributeSet, 0);
    }

    public static y.e g() {
        y.e eVar = new y.e(-2, -2);
        eVar.f4753a = -1;
        eVar.f4755b = -1;
        eVar.f4757c = -1.0f;
        eVar.f4759d = true;
        eVar.f4761e = -1;
        eVar.f = -1;
        eVar.f4764g = -1;
        eVar.f4766h = -1;
        eVar.f4768i = -1;
        eVar.f4770j = -1;
        eVar.f4771k = -1;
        eVar.f4773l = -1;
        eVar.f4775m = -1;
        eVar.f4777n = -1;
        eVar.f4779o = -1;
        eVar.f4781p = -1;
        eVar.f4783q = 0;
        eVar.f4784r = 0.0f;
        eVar.f4785s = -1;
        eVar.f4786t = -1;
        eVar.f4787u = -1;
        eVar.f4788v = -1;
        eVar.f4789w = Integer.MIN_VALUE;
        eVar.f4790x = Integer.MIN_VALUE;
        eVar.f4791y = Integer.MIN_VALUE;
        eVar.f4792z = Integer.MIN_VALUE;
        eVar.A = Integer.MIN_VALUE;
        eVar.B = Integer.MIN_VALUE;
        eVar.C = Integer.MIN_VALUE;
        eVar.D = 0;
        eVar.E = 0.5f;
        eVar.F = 0.5f;
        eVar.G = null;
        eVar.H = -1.0f;
        eVar.I = -1.0f;
        eVar.J = 0;
        eVar.K = 0;
        eVar.L = 0;
        eVar.M = 0;
        eVar.N = 0;
        eVar.O = 0;
        eVar.P = 0;
        eVar.Q = 0;
        eVar.R = 1.0f;
        eVar.S = 1.0f;
        eVar.T = -1;
        eVar.U = -1;
        eVar.V = -1;
        eVar.W = false;
        eVar.X = false;
        eVar.Y = null;
        eVar.Z = 0;
        eVar.f4754a0 = true;
        eVar.f4756b0 = true;
        eVar.f4758c0 = false;
        eVar.f4760d0 = false;
        eVar.f4762e0 = false;
        eVar.f4763f0 = -1;
        eVar.f4765g0 = -1;
        eVar.f4767h0 = -1;
        eVar.f4769i0 = -1;
        eVar.j0 = Integer.MIN_VALUE;
        eVar.f4772k0 = Integer.MIN_VALUE;
        eVar.f4774l0 = 0.5f;
        eVar.f4782p0 = new d();
        return eVar;
    }

    private int getPaddingWidth() {
        int iMax = Math.max(0, getPaddingRight()) + Math.max(0, getPaddingLeft());
        int iMax2 = Math.max(0, getPaddingEnd()) + Math.max(0, getPaddingStart());
        return iMax2 > 0 ? iMax2 : iMax;
    }

    public static s getSharedValues() {
        if (f430p == null) {
            s sVar = new s();
            new SparseIntArray();
            new HashMap();
            f430p = sVar;
        }
        return f430p;
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof y.e;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList arrayList = this.f432b;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i3 = 0; i3 < size; i3++) {
                ((c) arrayList.get(i3)).getClass();
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt = getChildAt(i4);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] strArrSplit = ((String) tag).split(",");
                    if (strArrSplit.length == 4) {
                        int i5 = Integer.parseInt(strArrSplit[0]);
                        int i6 = Integer.parseInt(strArrSplit[1]);
                        int i7 = Integer.parseInt(strArrSplit[2]);
                        int i8 = (int) ((i5 / 1080.0f) * width);
                        int i9 = (int) ((i6 / 1920.0f) * height);
                        int i10 = (int) ((Integer.parseInt(strArrSplit[3]) / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f = i8;
                        float f4 = i9;
                        float f5 = i8 + ((int) ((i7 / 1080.0f) * width));
                        canvas.drawLine(f, f4, f5, f4, paint);
                        float f6 = i9 + i10;
                        canvas.drawLine(f5, f4, f5, f6, paint);
                        canvas.drawLine(f5, f6, f, f6, paint);
                        canvas.drawLine(f, f6, f, f4, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f, f4, f5, f6, paint);
                        canvas.drawLine(f, f6, f5, f4, paint);
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public final void forceLayout() {
        this.f437h = true;
        super.forceLayout();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return g();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        y.e eVar = new y.e(context, attributeSet);
        eVar.f4753a = -1;
        eVar.f4755b = -1;
        eVar.f4757c = -1.0f;
        eVar.f4759d = true;
        eVar.f4761e = -1;
        eVar.f = -1;
        eVar.f4764g = -1;
        eVar.f4766h = -1;
        eVar.f4768i = -1;
        eVar.f4770j = -1;
        eVar.f4771k = -1;
        eVar.f4773l = -1;
        eVar.f4775m = -1;
        eVar.f4777n = -1;
        eVar.f4779o = -1;
        eVar.f4781p = -1;
        eVar.f4783q = 0;
        eVar.f4784r = 0.0f;
        eVar.f4785s = -1;
        eVar.f4786t = -1;
        eVar.f4787u = -1;
        eVar.f4788v = -1;
        eVar.f4789w = Integer.MIN_VALUE;
        eVar.f4790x = Integer.MIN_VALUE;
        eVar.f4791y = Integer.MIN_VALUE;
        eVar.f4792z = Integer.MIN_VALUE;
        eVar.A = Integer.MIN_VALUE;
        eVar.B = Integer.MIN_VALUE;
        eVar.C = Integer.MIN_VALUE;
        eVar.D = 0;
        eVar.E = 0.5f;
        eVar.F = 0.5f;
        eVar.G = null;
        eVar.H = -1.0f;
        eVar.I = -1.0f;
        eVar.J = 0;
        eVar.K = 0;
        eVar.L = 0;
        eVar.M = 0;
        eVar.N = 0;
        eVar.O = 0;
        eVar.P = 0;
        eVar.Q = 0;
        eVar.R = 1.0f;
        eVar.S = 1.0f;
        eVar.T = -1;
        eVar.U = -1;
        eVar.V = -1;
        eVar.W = false;
        eVar.X = false;
        eVar.Y = null;
        eVar.Z = 0;
        eVar.f4754a0 = true;
        eVar.f4756b0 = true;
        eVar.f4758c0 = false;
        eVar.f4760d0 = false;
        eVar.f4762e0 = false;
        eVar.f4763f0 = -1;
        eVar.f4765g0 = -1;
        eVar.f4767h0 = -1;
        eVar.f4769i0 = -1;
        eVar.j0 = Integer.MIN_VALUE;
        eVar.f4772k0 = Integer.MIN_VALUE;
        eVar.f4774l0 = 0.5f;
        eVar.f4782p0 = new d();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, r.f4894b);
        int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
        for (int i3 = 0; i3 < indexCount; i3++) {
            int index = typedArrayObtainStyledAttributes.getIndex(i3);
            int i4 = y.d.f4752a.get(index);
            switch (i4) {
                case 1:
                    eVar.V = typedArrayObtainStyledAttributes.getInt(index, eVar.V);
                    break;
                case 2:
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4781p);
                    eVar.f4781p = resourceId;
                    if (resourceId == -1) {
                        eVar.f4781p = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 3:
                    eVar.f4783q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f4783q);
                    break;
                case 4:
                    float f = typedArrayObtainStyledAttributes.getFloat(index, eVar.f4784r) % 360.0f;
                    eVar.f4784r = f;
                    if (f < 0.0f) {
                        eVar.f4784r = (360.0f - f) % 360.0f;
                    }
                    break;
                case 5:
                    eVar.f4753a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.f4753a);
                    break;
                case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                    eVar.f4755b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.f4755b);
                    break;
                case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                    eVar.f4757c = typedArrayObtainStyledAttributes.getFloat(index, eVar.f4757c);
                    break;
                case 8:
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4761e);
                    eVar.f4761e = resourceId2;
                    if (resourceId2 == -1) {
                        eVar.f4761e = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 9:
                    int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f);
                    eVar.f = resourceId3;
                    if (resourceId3 == -1) {
                        eVar.f = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case JarConfig.MAX_CACHE_SIZE /* 10 */:
                    int resourceId4 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4764g);
                    eVar.f4764g = resourceId4;
                    if (resourceId4 == -1) {
                        eVar.f4764g = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 11:
                    int resourceId5 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4766h);
                    eVar.f4766h = resourceId5;
                    if (resourceId5 == -1) {
                        eVar.f4766h = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 12:
                    int resourceId6 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4768i);
                    eVar.f4768i = resourceId6;
                    if (resourceId6 == -1) {
                        eVar.f4768i = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 13:
                    int resourceId7 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4770j);
                    eVar.f4770j = resourceId7;
                    if (resourceId7 == -1) {
                        eVar.f4770j = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 14:
                    int resourceId8 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4771k);
                    eVar.f4771k = resourceId8;
                    if (resourceId8 == -1) {
                        eVar.f4771k = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 15:
                    int resourceId9 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4773l);
                    eVar.f4773l = resourceId9;
                    if (resourceId9 == -1) {
                        eVar.f4773l = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 16:
                    int resourceId10 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4775m);
                    eVar.f4775m = resourceId10;
                    if (resourceId10 == -1) {
                        eVar.f4775m = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 17:
                    int resourceId11 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4785s);
                    eVar.f4785s = resourceId11;
                    if (resourceId11 == -1) {
                        eVar.f4785s = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 18:
                    int resourceId12 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4786t);
                    eVar.f4786t = resourceId12;
                    if (resourceId12 == -1) {
                        eVar.f4786t = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 19:
                    int resourceId13 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4787u);
                    eVar.f4787u = resourceId13;
                    if (resourceId13 == -1) {
                        eVar.f4787u = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 20:
                    int resourceId14 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4788v);
                    eVar.f4788v = resourceId14;
                    if (resourceId14 == -1) {
                        eVar.f4788v = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    break;
                case 21:
                    eVar.f4789w = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f4789w);
                    break;
                case 22:
                    eVar.f4790x = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f4790x);
                    break;
                case 23:
                    eVar.f4791y = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f4791y);
                    break;
                case 24:
                    eVar.f4792z = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f4792z);
                    break;
                case 25:
                    eVar.A = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.A);
                    break;
                case 26:
                    eVar.B = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.B);
                    break;
                case 27:
                    eVar.W = typedArrayObtainStyledAttributes.getBoolean(index, eVar.W);
                    break;
                case 28:
                    eVar.X = typedArrayObtainStyledAttributes.getBoolean(index, eVar.X);
                    break;
                case 29:
                    eVar.E = typedArrayObtainStyledAttributes.getFloat(index, eVar.E);
                    break;
                case 30:
                    eVar.F = typedArrayObtainStyledAttributes.getFloat(index, eVar.F);
                    break;
                case 31:
                    eVar.L = typedArrayObtainStyledAttributes.getInt(index, 0);
                    break;
                case 32:
                    eVar.M = typedArrayObtainStyledAttributes.getInt(index, 0);
                    break;
                case 33:
                    try {
                        eVar.N = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.N);
                    } catch (Exception unused) {
                        if (typedArrayObtainStyledAttributes.getInt(index, eVar.N) == -2) {
                            eVar.N = -2;
                        }
                    }
                    break;
                case 34:
                    try {
                        eVar.P = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.P);
                    } catch (Exception unused2) {
                        if (typedArrayObtainStyledAttributes.getInt(index, eVar.P) == -2) {
                            eVar.P = -2;
                        }
                    }
                    break;
                case 35:
                    eVar.R = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, eVar.R));
                    eVar.L = 2;
                    break;
                case 36:
                    try {
                        eVar.O = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.O);
                    } catch (Exception unused3) {
                        if (typedArrayObtainStyledAttributes.getInt(index, eVar.O) == -2) {
                            eVar.O = -2;
                        }
                    }
                    break;
                case 37:
                    try {
                        eVar.Q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.Q);
                    } catch (Exception unused4) {
                        if (typedArrayObtainStyledAttributes.getInt(index, eVar.Q) == -2) {
                            eVar.Q = -2;
                        }
                    }
                    break;
                case 38:
                    eVar.S = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, eVar.S));
                    eVar.M = 2;
                    break;
                default:
                    switch (i4) {
                        case 44:
                            n.h(eVar, typedArrayObtainStyledAttributes.getString(index));
                            break;
                        case 45:
                            eVar.H = typedArrayObtainStyledAttributes.getFloat(index, eVar.H);
                            break;
                        case 46:
                            eVar.I = typedArrayObtainStyledAttributes.getFloat(index, eVar.I);
                            break;
                        case 47:
                            eVar.J = typedArrayObtainStyledAttributes.getInt(index, 0);
                            break;
                        case 48:
                            eVar.K = typedArrayObtainStyledAttributes.getInt(index, 0);
                            break;
                        case 49:
                            eVar.T = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.T);
                            break;
                        case ProxyManifest.FREE_COUNT /* 50 */:
                            eVar.U = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.U);
                            break;
                        case 51:
                            eVar.Y = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 52:
                            int resourceId15 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4777n);
                            eVar.f4777n = resourceId15;
                            if (resourceId15 == -1) {
                                eVar.f4777n = typedArrayObtainStyledAttributes.getInt(index, -1);
                            }
                            break;
                        case 53:
                            int resourceId16 = typedArrayObtainStyledAttributes.getResourceId(index, eVar.f4779o);
                            eVar.f4779o = resourceId16;
                            if (resourceId16 == -1) {
                                eVar.f4779o = typedArrayObtainStyledAttributes.getInt(index, -1);
                            }
                            break;
                        case 54:
                            eVar.D = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.D);
                            break;
                        case 55:
                            eVar.C = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.C);
                            break;
                        default:
                            switch (i4) {
                                case 64:
                                    n.g(eVar, typedArrayObtainStyledAttributes, index, 0);
                                    break;
                                case 65:
                                    n.g(eVar, typedArrayObtainStyledAttributes, index, 1);
                                    break;
                                case 66:
                                    eVar.Z = typedArrayObtainStyledAttributes.getInt(index, eVar.Z);
                                    break;
                                case 67:
                                    eVar.f4759d = typedArrayObtainStyledAttributes.getBoolean(index, eVar.f4759d);
                                    break;
                            }
                            break;
                    }
                    break;
            }
        }
        typedArrayObtainStyledAttributes.recycle();
        eVar.a();
        return eVar;
    }

    public int getMaxHeight() {
        return this.f436g;
    }

    public int getMaxWidth() {
        return this.f;
    }

    public int getMinHeight() {
        return this.f435e;
    }

    public int getMinWidth() {
        return this.f434d;
    }

    public int getOptimizationLevel() {
        return this.f433c.D0;
    }

    public String getSceneString() {
        int id;
        StringBuilder sb = new StringBuilder();
        e eVar = this.f433c;
        if (eVar.f4448j == null) {
            int id2 = getId();
            if (id2 != -1) {
                eVar.f4448j = getContext().getResources().getResourceEntryName(id2);
            } else {
                eVar.f4448j = "parent";
            }
        }
        if (eVar.f4447i0 == null) {
            eVar.f4447i0 = eVar.f4448j;
        }
        ArrayList arrayList = eVar.f4471q0;
        int size = arrayList.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayList.get(i3);
            i3++;
            d dVar = (d) obj;
            View view = dVar.f4443g0;
            if (view != null) {
                if (dVar.f4448j == null && (id = view.getId()) != -1) {
                    dVar.f4448j = getContext().getResources().getResourceEntryName(id);
                }
                if (dVar.f4447i0 == null) {
                    dVar.f4447i0 = dVar.f4448j;
                }
            }
        }
        eVar.n(sb);
        return sb.toString();
    }

    public final d h(View view) {
        if (view == this) {
            return this.f433c;
        }
        if (view == null) {
            return null;
        }
        if (view.getLayoutParams() instanceof y.e) {
            return ((y.e) view.getLayoutParams()).f4782p0;
        }
        view.setLayoutParams(new y.e(view.getLayoutParams()));
        if (view.getLayoutParams() instanceof y.e) {
            return ((y.e) view.getLayoutParams()).f4782p0;
        }
        return null;
    }

    public final void i(AttributeSet attributeSet, int i3) {
        e eVar = this.f433c;
        eVar.f4443g0 = this;
        f fVar = this.f444o;
        eVar.f4475u0 = fVar;
        eVar.f4473s0.f = fVar;
        this.f431a.put(getId(), this);
        this.f439j = null;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, r.f4894b, i3, 0);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i4 = 0; i4 < indexCount; i4++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i4);
                if (index == 16) {
                    this.f434d = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f434d);
                } else if (index == 17) {
                    this.f435e = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f435e);
                } else if (index == 14) {
                    this.f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f);
                } else if (index == 15) {
                    this.f436g = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f436g);
                } else if (index == 113) {
                    this.f438i = typedArrayObtainStyledAttributes.getInt(index, this.f438i);
                } else if (index == 56) {
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            j(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.f440k = null;
                        }
                    }
                } else if (index == 34) {
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    try {
                        n nVar = new n();
                        this.f439j = nVar;
                        nVar.e(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f439j = null;
                    }
                    this.f441l = resourceId2;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        eVar.D0 = this.f438i;
        t.c.f3952q = eVar.W(512);
    }

    public final void j(int i3) {
        String str;
        Context context = getContext();
        q qVar = new q(19, false);
        qVar.f551b = new SparseArray();
        qVar.f552c = new SparseArray();
        XmlResourceParser xml = context.getResources().getXml(i3);
        try {
            a aVar = null;
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 2) {
                    String name = xml.getName();
                    switch (name.hashCode()) {
                        case -1349929691:
                            if (name.equals("ConstraintSet")) {
                                qVar.u(context, xml);
                            }
                            break;
                        case 80204913:
                            if (name.equals("State")) {
                                a aVar2 = new a(context, xml);
                                ((SparseArray) qVar.f551b).put(aVar2.f2904a, aVar2);
                                aVar = aVar2;
                            }
                            break;
                        case 1382829617:
                            str = "StateSet";
                            name.equals(str);
                            break;
                        case 1657696882:
                            str = "layoutDescription";
                            name.equals(str);
                            break;
                        case 1901439077:
                            if (name.equals("Variant")) {
                                g gVar = new g(context, xml);
                                if (aVar != null) {
                                    ((ArrayList) aVar.f2906c).add(gVar);
                                }
                            }
                            break;
                    }
                }
            }
        } catch (IOException | XmlPullParserException unused) {
        }
        this.f440k = qVar;
    }

    /* JADX WARN: Code duplicated, block: B:102:0x01f1  */
    /* JADX WARN: Code duplicated, block: B:105:0x01f8 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:106:0x01fa A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:111:0x0202  */
    /* JADX WARN: Code duplicated, block: B:113:0x0216  */
    /* JADX WARN: Code duplicated, block: B:117:0x0225  */
    /* JADX WARN: Code duplicated, block: B:119:0x0229  */
    /* JADX WARN: Code duplicated, block: B:124:0x0238 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:201:0x03df  */
    /* JADX WARN: Code duplicated, block: B:203:0x03ef  */
    /* JADX WARN: Code duplicated, block: B:205:0x03f8 A[LOOP:11: B:204:0x03f6->B:205:0x03f8, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:207:0x0441  */
    /* JADX WARN: Code duplicated, block: B:210:0x045d  */
    /* JADX WARN: Code duplicated, block: B:211:0x0463  */
    /* JADX WARN: Code duplicated, block: B:213:0x0467  */
    /* JADX WARN: Code duplicated, block: B:214:0x0470  */
    /* JADX WARN: Code duplicated, block: B:216:0x0473 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:217:0x0475  */
    /* JADX WARN: Code duplicated, block: B:218:0x0477  */
    /* JADX WARN: Code duplicated, block: B:220:0x047a  */
    /* JADX WARN: Code duplicated, block: B:221:0x047c  */
    /* JADX WARN: Code duplicated, block: B:223:0x0481  */
    /* JADX WARN: Code duplicated, block: B:225:0x048f  */
    /* JADX WARN: Code duplicated, block: B:231:0x0498  */
    /* JADX WARN: Code duplicated, block: B:233:0x04a9  */
    /* JADX WARN: Code duplicated, block: B:236:0x04b7  */
    /* JADX WARN: Code duplicated, block: B:254:0x04e6  */
    /* JADX WARN: Code duplicated, block: B:260:0x04f2  */
    /* JADX WARN: Code duplicated, block: B:262:0x04f5  */
    /* JADX WARN: Code duplicated, block: B:267:0x0501  */
    /* JADX WARN: Code duplicated, block: B:274:0x0510  */
    /* JADX WARN: Code duplicated, block: B:281:0x051f A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:282:0x0521  */
    /* JADX WARN: Code duplicated, block: B:287:0x052b  */
    /* JADX WARN: Code duplicated, block: B:291:0x053e A[LOOP:4: B:290:0x053c->B:291:0x053e, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:294:0x054a  */
    /* JADX WARN: Code duplicated, block: B:296:0x054d A[LOOP:5: B:295:0x054b->B:296:0x054d, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:299:0x0563  */
    /* JADX WARN: Code duplicated, block: B:29:0x00c6 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:301:0x0568  */
    /* JADX WARN: Code duplicated, block: B:303:0x0570  */
    /* JADX WARN: Code duplicated, block: B:305:0x0573  */
    /* JADX WARN: Code duplicated, block: B:308:0x0579  */
    /* JADX WARN: Code duplicated, block: B:309:0x057b  */
    /* JADX WARN: Code duplicated, block: B:30:0x00c8  */
    /* JADX WARN: Code duplicated, block: B:313:0x059a  */
    /* JADX WARN: Code duplicated, block: B:315:0x05aa  */
    /* JADX WARN: Code duplicated, block: B:316:0x05b4  */
    /* JADX WARN: Code duplicated, block: B:318:0x05d9  */
    /* JADX WARN: Code duplicated, block: B:320:0x05de  */
    /* JADX WARN: Code duplicated, block: B:325:0x05ff  */
    /* JADX WARN: Code duplicated, block: B:327:0x0604  */
    /* JADX WARN: Code duplicated, block: B:32:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:336:0x0649  */
    /* JADX WARN: Code duplicated, block: B:338:0x064e  */
    /* JADX WARN: Code duplicated, block: B:33:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:340:0x0658  */
    /* JADX WARN: Code duplicated, block: B:344:0x0660  */
    /* JADX WARN: Code duplicated, block: B:34:0x00de A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:350:0x066e A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:358:0x0685 A[PHI: r16
  0x0685: PHI (r16v5 int) = (r16v3 int), (r16v3 int), (r16v3 int), (r16v6 int) binds: [B:348:0x066b, B:357:0x0683, B:354:0x067e, B:343:0x065d] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:35:0x00e0  */
    /* JADX WARN: Code duplicated, block: B:361:0x069e  */
    /* JADX WARN: Code duplicated, block: B:364:0x06b3  */
    /* JADX WARN: Code duplicated, block: B:366:0x06b8  */
    /* JADX WARN: Code duplicated, block: B:36:0x00ed  */
    /* JADX WARN: Code duplicated, block: B:371:0x06d8  */
    /* JADX WARN: Code duplicated, block: B:373:0x06dd  */
    /* JADX WARN: Code duplicated, block: B:379:0x06ff  */
    /* JADX WARN: Code duplicated, block: B:385:0x0719 A[LOOP:7: B:334:0x0646->B:385:0x0719, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:389:0x01f3 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:38:0x00f2  */
    /* JADX WARN: Code duplicated, block: B:40:0x00f5  */
    /* JADX WARN: Code duplicated, block: B:416:0x052f A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:41:0x00fc  */
    /* JADX WARN: Code duplicated, block: B:420:0x052f A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:423:0x0639 A[EDGE_INSN: B:423:0x0639->B:333:0x0639 BREAK  A[LOOP:6: B:311:0x0594->B:332:0x062a], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:426:0x0726 A[EDGE_INSN: B:426:0x0726->B:386:0x0726 BREAK  A[LOOP:7: B:334:0x0646->B:385:0x0719], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:431:0x0704 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:44:0x010c  */
    /* JADX WARN: Code duplicated, block: B:46:0x0112  */
    /* JADX WARN: Code duplicated, block: B:51:0x0144  */
    /* JADX WARN: Code duplicated, block: B:52:0x0147  */
    /* JADX WARN: Code duplicated, block: B:55:0x014f  */
    /* JADX WARN: Code duplicated, block: B:56:0x0152  */
    /* JADX WARN: Code duplicated, block: B:59:0x017e  */
    /* JADX WARN: Code duplicated, block: B:63:0x0187  */
    /* JADX WARN: Code duplicated, block: B:66:0x0190  */
    /* JADX WARN: Code duplicated, block: B:69:0x0195  */
    /* JADX WARN: Code duplicated, block: B:71:0x01a9  */
    /* JADX WARN: Code duplicated, block: B:73:0x01ae  */
    /* JADX WARN: Code duplicated, block: B:76:0x01b5  */
    /* JADX WARN: Code duplicated, block: B:77:0x01b7  */
    /* JADX WARN: Code duplicated, block: B:79:0x01ba A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:83:0x01c4  */
    /* JADX WARN: Code duplicated, block: B:86:0x01cb A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:89:0x01d1  */
    public final void k(e eVar, int i3, int i4, int i5) {
        int iMax;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour;
        int i6;
        int iMax2;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour2;
        int iQ;
        w.e eVar2;
        int[] iArr;
        int i7;
        int i8;
        u uVar;
        e eVar3;
        ArrayList arrayList;
        f fVar;
        int size;
        int iQ2;
        int iK;
        boolean zC;
        boolean z4;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour3;
        int i9;
        boolean z5;
        boolean z6;
        e eVar4;
        ArrayList arrayList2;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour4;
        boolean zT;
        int i10;
        int i11;
        int size2;
        ConstraintWidget$DimensionBehaviour[] constraintWidget$DimensionBehaviourArr;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour5;
        boolean z7;
        boolean z8;
        int iMax3;
        int iMax4;
        int i12;
        boolean z9;
        ConstraintAnchor$Type constraintAnchor$Type;
        ConstraintAnchor$Type constraintAnchor$Type2;
        boolean z10;
        boolean z11;
        boolean z12;
        f fVar2;
        ArrayList arrayList3;
        int i13;
        boolean zW;
        int i14;
        int i15;
        int i16;
        f fVar3;
        d dVar;
        int i17;
        int iQ3;
        int iK2;
        int i18;
        int i19;
        int iQ4;
        f fVar4;
        int iK3;
        d dVar2;
        boolean z13;
        int iQ5;
        int iK4;
        boolean z14;
        f fVar5;
        boolean zW2;
        int iQ6;
        int iK5;
        int size3;
        f fVar6;
        int i20;
        ConstraintLayout constraintLayout;
        int childCount;
        ArrayList arrayList4;
        int i21;
        int size4;
        int i22;
        d dVar3;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviourJ;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviourJ2;
        boolean z15;
        androidx.constraintlayout.core.widgets.analyzer.d dVar4;
        androidx.constraintlayout.core.widgets.analyzer.e eVar5;
        int iMin;
        boolean z16;
        e eVar6;
        int i23;
        int i24;
        boolean zT2;
        ArrayList arrayList5;
        int size5;
        int i25;
        boolean z17;
        boolean z18;
        int i26;
        int i27;
        int i28;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour6;
        boolean z19;
        int i29;
        d dVar5;
        int i30;
        ConstraintWidget$DimensionBehaviour[] constraintWidget$DimensionBehaviourArr2;
        boolean z20;
        boolean z21;
        boolean z22;
        int mode = View.MeasureSpec.getMode(i4);
        int size6 = View.MeasureSpec.getSize(i4);
        int mode2 = View.MeasureSpec.getMode(i5);
        int size7 = View.MeasureSpec.getSize(i5);
        int iMax5 = Math.max(0, getPaddingTop());
        int iMax6 = Math.max(0, getPaddingBottom());
        int i31 = iMax5 + iMax6;
        int paddingWidth = getPaddingWidth();
        f fVar7 = this.f444o;
        fVar7.f4794b = iMax5;
        fVar7.f4795c = iMax6;
        fVar7.f4796d = paddingWidth;
        fVar7.f4797e = i31;
        fVar7.f = i4;
        fVar7.f4798g = i5;
        int iMax7 = Math.max(0, getPaddingStart());
        int iMax8 = Math.max(0, getPaddingEnd());
        if (iMax7 <= 0 && iMax8 <= 0) {
            iMax7 = Math.max(0, getPaddingLeft());
        } else if ((getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection()) {
            iMax7 = iMax8;
        }
        int i32 = size6 - paddingWidth;
        int i33 = size7 - i31;
        int i34 = fVar7.f4797e;
        int i35 = fVar7.f4796d;
        int childCount2 = getChildCount();
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour7 = ConstraintWidget$DimensionBehaviour.f381a;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour8 = ConstraintWidget$DimensionBehaviour.f382b;
        if (mode != Integer.MIN_VALUE) {
            if (mode != 0) {
                if (mode != 1073741824) {
                    constraintWidget$DimensionBehaviour = constraintWidget$DimensionBehaviour7;
                    i6 = Integer.MIN_VALUE;
                    iMax = 0;
                } else {
                    iMax = Math.min(this.f - i35, i32);
                    constraintWidget$DimensionBehaviour = constraintWidget$DimensionBehaviour7;
                }
            } else if (childCount2 == 0) {
                constraintWidget$DimensionBehaviour = constraintWidget$DimensionBehaviour8;
                iMax = Math.max(0, this.f434d);
            } else {
                constraintWidget$DimensionBehaviour = constraintWidget$DimensionBehaviour8;
                i6 = Integer.MIN_VALUE;
                iMax = 0;
            }
            if (mode2 != i6) {
                if (mode2 != 0) {
                    if (mode2 != 1073741824) {
                        constraintWidget$DimensionBehaviour2 = constraintWidget$DimensionBehaviour7;
                        iMax2 = 0;
                    } else {
                        iMax2 = Math.min(this.f436g - i34, i33);
                        constraintWidget$DimensionBehaviour2 = constraintWidget$DimensionBehaviour7;
                    }
                } else if (childCount2 == 0) {
                    constraintWidget$DimensionBehaviour2 = constraintWidget$DimensionBehaviour8;
                    iMax2 = Math.max(0, this.f435e);
                } else {
                    iMax2 = 0;
                }
                iQ = eVar.q();
                eVar2 = eVar.f4473s0;
                iArr = eVar.C;
                if (iMax == iQ || iMax2 != eVar.k()) {
                    eVar2.f4677c = true;
                }
                eVar.Z = 0;
                eVar.f4432a0 = 0;
                iArr[0] = this.f - i35;
                iArr[1] = this.f436g - i34;
                eVar.f4436c0 = 0;
                eVar.f4438d0 = 0;
                eVar.M(constraintWidget$DimensionBehaviour);
                eVar.O(iMax);
                eVar.N(constraintWidget$DimensionBehaviour2);
                eVar.L(iMax2);
                i7 = this.f434d - i35;
                if (i7 < 0) {
                    eVar.f4436c0 = 0;
                } else {
                    eVar.f4436c0 = i7;
                }
                i8 = this.f435e - i34;
                if (i8 < 0) {
                    eVar.f4438d0 = 0;
                } else {
                    eVar.f4438d0 = i8;
                }
                eVar.f4478x0 = iMax7;
                eVar.f4479y0 = iMax5;
                uVar = eVar.f4472r0;
                eVar3 = (e) uVar.f564d;
                arrayList = (ArrayList) uVar.f562b;
                fVar = eVar.f4475u0;
                size = eVar.f4471q0.size();
                iQ2 = eVar.q();
                iK = eVar.k();
                zC = j.c(i3, 128);
                if (!zC || j.c(i3, 64)) {
                    z4 = true;
                } else {
                    z4 = false;
                }
                constraintWidget$DimensionBehaviour3 = ConstraintWidget$DimensionBehaviour.f383c;
                boolean z23 = z4;
                if (z4) {
                    i29 = 0;
                    while (true) {
                        i9 = size;
                        if (i29 < size) {
                            dVar5 = (d) eVar.f4471q0.get(i29);
                            i30 = i29;
                            constraintWidget$DimensionBehaviourArr2 = dVar5.T;
                            if (constraintWidget$DimensionBehaviourArr2[0] == constraintWidget$DimensionBehaviour3) {
                                z20 = true;
                            } else {
                                z20 = false;
                            }
                            if (constraintWidget$DimensionBehaviourArr2[1] == constraintWidget$DimensionBehaviour3) {
                                z21 = true;
                            } else {
                                z21 = false;
                            }
                            if (z20 || !z21 || dVar5.X <= 0.0f) {
                                z22 = false;
                            } else {
                                z22 = true;
                            }
                            if ((dVar5.x() || !z22) && !((dVar5.y() && z22) || (dVar5 instanceof v.g) || dVar5.x() || dVar5.y())) {
                                i29 = i30 + 1;
                                size = i9;
                            } else {
                                z5 = false;
                            }
                        }
                        z6 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
                        if (z6) {
                            int iMin2 = Math.min(iArr[0], i32);
                            iMin = Math.min(iArr[1], i33);
                            if (mode == 1073741824 || eVar.q() == iMin2) {
                                z16 = true;
                            } else {
                                eVar.O(iMin2);
                                z16 = true;
                                eVar2.f4676b = true;
                            }
                            if (mode2 == 1073741824 && eVar.k() != iMin) {
                                eVar.L(iMin);
                                eVar2.f4676b = z16;
                            }
                            if (mode == 1073741824 || mode2 != 1073741824) {
                                z6 = z6;
                                eVar4 = eVar3;
                                arrayList2 = arrayList;
                                fVar = fVar;
                                constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                                eVar6 = eVar2.f4675a;
                                if (eVar2.f4676b) {
                                    arrayList5 = eVar6.f4471q0;
                                    size5 = arrayList5.size();
                                    i25 = 0;
                                    while (i25 < size5) {
                                        Object obj = arrayList5.get(i25);
                                        i25++;
                                        d dVar6 = (d) obj;
                                        dVar6.h();
                                        dVar6.f4431a = false;
                                        androidx.constraintlayout.core.widgets.analyzer.d dVar7 = dVar6.f4437d;
                                        ArrayList arrayList6 = arrayList5;
                                        dVar7.f416e.f405j = false;
                                        dVar7.f417g = false;
                                        dVar7.n();
                                        androidx.constraintlayout.core.widgets.analyzer.e eVar7 = dVar6.f4439e;
                                        eVar7.f416e.f405j = false;
                                        eVar7.f417g = false;
                                        eVar7.m();
                                        arrayList5 = arrayList6;
                                    }
                                    i23 = 0;
                                    eVar6.h();
                                    eVar6.f4431a = false;
                                    androidx.constraintlayout.core.widgets.analyzer.d dVar8 = eVar6.f4437d;
                                    dVar8.f416e.f405j = false;
                                    dVar8.f417g = false;
                                    dVar8.n();
                                    androidx.constraintlayout.core.widgets.analyzer.e eVar8 = eVar6.f4439e;
                                    eVar8.f416e.f405j = false;
                                    eVar8.f417g = false;
                                    eVar8.m();
                                    eVar2.c();
                                } else {
                                    i23 = 0;
                                }
                                eVar2.b(eVar2.f4678d);
                                eVar6.Z = i23;
                                eVar6.f4432a0 = i23;
                                eVar6.f4437d.f418h.d(i23);
                                eVar6.f4439e.f418h.d(i23);
                                i24 = 1073741824;
                                if (mode == 1073741824) {
                                    zT2 = eVar.T(i23, zC);
                                    i10 = 1;
                                } else {
                                    zT2 = true;
                                    i10 = 0;
                                }
                                if (mode2 == 1073741824) {
                                    zT = eVar.T(1, zC) & zT2;
                                    i10++;
                                } else {
                                    zT = zT2;
                                }
                            } else {
                                ArrayList arrayList7 = eVar2.f4679e;
                                e eVar9 = eVar2.f4675a;
                                if (eVar2.f4676b || eVar2.f4677c) {
                                    ArrayList arrayList8 = eVar9.f4471q0;
                                    int size8 = arrayList8.size();
                                    int i36 = 0;
                                    while (i36 < size8) {
                                        int i37 = size8;
                                        d dVar9 = (d) arrayList8.get(i36);
                                        dVar9.h();
                                        dVar9.f4431a = false;
                                        dVar9.f4437d.n();
                                        dVar9.f4439e.m();
                                        i36++;
                                        size8 = i37;
                                    }
                                    eVar9.h();
                                    i26 = 0;
                                    eVar9.f4431a = false;
                                    eVar9.f4437d.n();
                                    eVar9.f4439e.m();
                                    eVar2.f4677c = false;
                                } else {
                                    i26 = 0;
                                }
                                eVar2.b(eVar2.f4678d);
                                eVar9.Z = i26;
                                ConstraintWidget$DimensionBehaviour[] constraintWidget$DimensionBehaviourArr3 = eVar9.T;
                                eVar9.f4432a0 = i26;
                                ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviourJ3 = eVar9.j(i26);
                                ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviourJ4 = eVar9.j(1);
                                if (eVar2.f4676b) {
                                    eVar2.c();
                                }
                                int iR = eVar9.r();
                                arrayList2 = arrayList;
                                int iS = eVar9.s();
                                eVar4 = eVar3;
                                eVar9.f4437d.f418h.d(iR);
                                eVar9.f4439e.f418h.d(iS);
                                eVar2.g();
                                constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                                if (constraintWidget$DimensionBehaviourJ3 == constraintWidget$DimensionBehaviour4 || constraintWidget$DimensionBehaviourJ4 == constraintWidget$DimensionBehaviour4) {
                                    i27 = iS;
                                    if (zC) {
                                        int size9 = arrayList7.size();
                                        i28 = iR;
                                        int i38 = 0;
                                        while (i38 < size9) {
                                            Object obj2 = arrayList7.get(i38);
                                            i38++;
                                            if (!((androidx.constraintlayout.core.widgets.analyzer.f) obj2).k()) {
                                                zC = false;
                                                break;
                                            }
                                        }
                                    } else {
                                        i28 = iR;
                                    }
                                    if (zC && constraintWidget$DimensionBehaviourJ3 == constraintWidget$DimensionBehaviour4) {
                                        constraintWidget$DimensionBehaviour6 = constraintWidget$DimensionBehaviour7;
                                        eVar9.M(constraintWidget$DimensionBehaviour6);
                                        eVar9.O(eVar2.d(eVar9, 0));
                                        eVar9.f4437d.f416e.d(eVar9.q());
                                    } else {
                                        constraintWidget$DimensionBehaviour6 = constraintWidget$DimensionBehaviour7;
                                    }
                                    if (zC && constraintWidget$DimensionBehaviourJ4 == constraintWidget$DimensionBehaviour4) {
                                        eVar9.N(constraintWidget$DimensionBehaviour6);
                                        eVar9.L(eVar2.d(eVar9, 1));
                                        eVar9.f4439e.f416e.d(eVar9.k());
                                    }
                                } else {
                                    i27 = iS;
                                    i28 = iR;
                                    constraintWidget$DimensionBehaviour6 = constraintWidget$DimensionBehaviour7;
                                }
                                ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour9 = constraintWidget$DimensionBehaviourArr3[0];
                                ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour10 = ConstraintWidget$DimensionBehaviour.f384d;
                                if (constraintWidget$DimensionBehaviour9 == constraintWidget$DimensionBehaviour6 || constraintWidget$DimensionBehaviour9 == constraintWidget$DimensionBehaviour10) {
                                    int iQ7 = eVar9.q() + i28;
                                    eVar9.f4437d.f419i.d(iQ7);
                                    eVar9.f4437d.f416e.d(iQ7 - i28);
                                    eVar2.g();
                                    ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour11 = constraintWidget$DimensionBehaviourArr3[1];
                                    if (constraintWidget$DimensionBehaviour11 == constraintWidget$DimensionBehaviour6 || constraintWidget$DimensionBehaviour11 == constraintWidget$DimensionBehaviour10) {
                                        int iK6 = eVar9.k() + i27;
                                        eVar9.f4439e.f419i.d(iK6);
                                        eVar9.f4439e.f416e.d(iK6 - i27);
                                    }
                                    eVar2.g();
                                    z19 = true;
                                } else {
                                    z19 = false;
                                }
                                int size10 = arrayList7.size();
                                int i39 = 0;
                                while (i39 < size10) {
                                    Object obj3 = arrayList7.get(i39);
                                    i39++;
                                    androidx.constraintlayout.core.widgets.analyzer.f fVar8 = (androidx.constraintlayout.core.widgets.analyzer.f) obj3;
                                    if (fVar8.f413b != eVar9 || fVar8.f417g) {
                                        fVar8.e();
                                    }
                                }
                                int size11 = arrayList7.size();
                                int i40 = 0;
                                while (true) {
                                    if (i40 >= size11) {
                                        zT = true;
                                        break;
                                    }
                                    Object obj4 = arrayList7.get(i40);
                                    i40++;
                                    androidx.constraintlayout.core.widgets.analyzer.f fVar9 = (androidx.constraintlayout.core.widgets.analyzer.f) obj4;
                                    if (z19 || fVar9.f413b != eVar9) {
                                        if (!fVar9.f418h.f405j || ((!fVar9.f419i.f405j && !(fVar9 instanceof w.g)) || (!fVar9.f416e.f405j && !(fVar9 instanceof w.c) && !(fVar9 instanceof w.g)))) {
                                            zT = false;
                                            break;
                                        }
                                    }
                                }
                                eVar9.M(constraintWidget$DimensionBehaviourJ3);
                                eVar9.N(constraintWidget$DimensionBehaviourJ4);
                                i24 = 1073741824;
                                i10 = 2;
                            }
                            if (zT) {
                                if (mode == i24) {
                                    z17 = true;
                                } else {
                                    z17 = false;
                                }
                                if (mode2 == i24) {
                                    z18 = true;
                                } else {
                                    z18 = false;
                                }
                                eVar.P(z17, z18);
                            }
                        } else {
                            z6 = z6;
                            eVar4 = eVar3;
                            arrayList2 = arrayList;
                            fVar = fVar;
                            constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                            zT = false;
                            i10 = 0;
                        }
                        if (zT || i10 != 2) {
                            i11 = eVar.D0;
                            if (i9 > 0) {
                                size3 = eVar.f4471q0.size();
                                boolean zW3 = eVar.W(64);
                                fVar6 = eVar.f4475u0;
                                for (i20 = 0; i20 < size3; i20++) {
                                    dVar3 = (d) eVar.f4471q0.get(i20);
                                    if (!(dVar3 instanceof h) && !(dVar3 instanceof v.a) && !dVar3.F && (!zW3 || (dVar4 = dVar3.f4437d) == null || (eVar5 = dVar3.f4439e) == null || !dVar4.f416e.f405j || !eVar5.f416e.f405j)) {
                                        constraintWidget$DimensionBehaviourJ = dVar3.j(0);
                                        constraintWidget$DimensionBehaviourJ2 = dVar3.j(1);
                                        if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3 || dVar3.f4462r == 1 || constraintWidget$DimensionBehaviourJ2 != constraintWidget$DimensionBehaviour3 || dVar3.f4463s == 1) {
                                            z15 = false;
                                        } else {
                                            z15 = true;
                                        }
                                        if (!z15 && eVar.W(1) && !(dVar3 instanceof v.g)) {
                                            if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3 && dVar3.f4462r == 0 && constraintWidget$DimensionBehaviourJ2 != constraintWidget$DimensionBehaviour3 && !dVar3.x()) {
                                                z15 = true;
                                            }
                                            if (constraintWidget$DimensionBehaviourJ2 == constraintWidget$DimensionBehaviour3 && dVar3.f4463s == 0 && constraintWidget$DimensionBehaviourJ != constraintWidget$DimensionBehaviour3 && !dVar3.x()) {
                                                z15 = true;
                                            }
                                            if ((constraintWidget$DimensionBehaviourJ != constraintWidget$DimensionBehaviour3 || constraintWidget$DimensionBehaviourJ2 == constraintWidget$DimensionBehaviour3) && dVar3.X > 0.0f) {
                                            }
                                        }
                                        if (z15) {
                                            uVar.w(0, dVar3, fVar6);
                                        }
                                    }
                                }
                                constraintLayout = fVar6.f4793a;
                                childCount = constraintLayout.getChildCount();
                                arrayList4 = constraintLayout.f432b;
                                for (i21 = 0; i21 < childCount; i21++) {
                                    constraintLayout.getChildAt(i21);
                                }
                                size4 = arrayList4.size();
                                if (size4 > 0) {
                                    for (i22 = 0; i22 < size4; i22++) {
                                        ((c) arrayList4.get(i22)).getClass();
                                    }
                                }
                            }
                            uVar.D(eVar);
                            size2 = arrayList2.size();
                            if (i9 > 0) {
                                uVar.A(eVar, 0, iQ2, iK);
                            }
                            if (size2 > 0) {
                                constraintWidget$DimensionBehaviourArr = eVar.T;
                                constraintWidget$DimensionBehaviour5 = constraintWidget$DimensionBehaviour4;
                                if (constraintWidget$DimensionBehaviourArr[0] == constraintWidget$DimensionBehaviour5) {
                                    z7 = true;
                                } else {
                                    z7 = false;
                                }
                                if (constraintWidget$DimensionBehaviourArr[1] == constraintWidget$DimensionBehaviour5) {
                                    z8 = true;
                                } else {
                                    z8 = false;
                                }
                                e eVar10 = eVar4;
                                iMax3 = Math.max(eVar.q(), eVar10.f4436c0);
                                iMax4 = Math.max(eVar.k(), eVar10.f4438d0);
                                i12 = 0;
                                z9 = false;
                                while (true) {
                                    constraintAnchor$Type = ConstraintAnchor$Type.f376d;
                                    constraintAnchor$Type2 = ConstraintAnchor$Type.f375c;
                                    if (i12 < size2) {
                                        break;
                                    }
                                    ArrayList arrayList9 = arrayList2;
                                    dVar2 = (d) arrayList9.get(i12);
                                    z13 = z7;
                                    if (dVar2 instanceof v.g) {
                                        iQ5 = dVar2.q();
                                        iK4 = dVar2.k();
                                        z14 = z8;
                                        fVar5 = fVar;
                                        zW2 = z9 | uVar.w(1, dVar2, fVar5);
                                        iQ6 = dVar2.q();
                                        iK5 = dVar2.k();
                                        if (iQ6 != iQ5) {
                                            dVar2.O(iQ6);
                                            if (z13 && dVar2.r() + dVar2.V > iMax3) {
                                                iMax3 = Math.max(iMax3, dVar2.i(constraintAnchor$Type2).e() + dVar2.r() + dVar2.V);
                                            }
                                            zW2 = true;
                                        }
                                        if (iK5 != iK4) {
                                            dVar2.L(iK5);
                                            if (z14 && dVar2.s() + dVar2.W > iMax4) {
                                                iMax4 = Math.max(iMax4, dVar2.i(constraintAnchor$Type).e() + dVar2.s() + dVar2.W);
                                            }
                                            zW2 = true;
                                        }
                                        z9 = zW2 | ((v.g) dVar2).f4506y0;
                                    } else {
                                        z14 = z8;
                                        fVar5 = fVar;
                                    }
                                    i12++;
                                    z7 = z13;
                                    fVar = fVar5;
                                    arrayList2 = arrayList9;
                                    z8 = z14;
                                    i11 = i11;
                                }
                                int i41 = i11;
                                z10 = z7;
                                z11 = z8;
                                z12 = z9;
                                fVar2 = fVar;
                                arrayList3 = arrayList2;
                                i13 = 0;
                                while (i13 < 2) {
                                    zW = z12;
                                    i14 = 0;
                                    while (i14 < size2) {
                                        dVar = (d) arrayList3.get(i14);
                                        if (((dVar instanceof i) || (dVar instanceof v.g)) && !(dVar instanceof h)) {
                                            i17 = size2;
                                            if (dVar.f4445h0 == 8 && ((!z6 || !dVar.f4437d.f416e.f405j || !dVar.f4439e.f416e.f405j) && !(dVar instanceof v.g))) {
                                                iQ3 = dVar.q();
                                                iK2 = dVar.k();
                                                i18 = i14;
                                                int i42 = dVar.f4434b0;
                                                zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                                i19 = i13;
                                                iQ4 = dVar.q();
                                                fVar4 = fVar2;
                                                iK3 = dVar.k();
                                                if (iQ4 != iQ3) {
                                                    dVar.O(iQ4);
                                                    if (z10 && dVar.r() + dVar.V > iMax3) {
                                                        iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                                    }
                                                    zW = true;
                                                }
                                                if (iK3 != iK2) {
                                                    dVar.L(iK3);
                                                    if (z11 && dVar.s() + dVar.W > iMax4) {
                                                        iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                                    }
                                                    zW = true;
                                                }
                                                if (!dVar.E && i42 != dVar.f4434b0) {
                                                    zW = true;
                                                }
                                            }
                                            i14 = i18 + 1;
                                            size2 = i17;
                                            i13 = i19;
                                            fVar2 = fVar4;
                                        } else {
                                            i17 = size2;
                                        }
                                        i19 = i13;
                                        i18 = i14;
                                        fVar4 = fVar2;
                                        i14 = i18 + 1;
                                        size2 = i17;
                                        i13 = i19;
                                        fVar2 = fVar4;
                                    }
                                    i15 = i13;
                                    i16 = size2;
                                    fVar3 = fVar2;
                                    if (zW) {
                                        break;
                                    }
                                    i13 = i15 + 1;
                                    uVar.A(eVar, i13, iQ2, iK);
                                    size2 = i16;
                                    fVar2 = fVar3;
                                    z12 = false;
                                }
                                i11 = i41;
                            }
                            eVar.D0 = i11;
                            t.c.f3952q = eVar.W(512);
                        }
                        return;
                    }
                }
                i9 = size;
                z5 = z23;
                z6 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
                if (z6) {
                    int iMin3 = Math.min(iArr[0], i32);
                    iMin = Math.min(iArr[1], i33);
                    if (mode == 1073741824) {
                        z16 = true;
                    } else {
                        z16 = true;
                    }
                    if (mode2 == 1073741824) {
                        eVar.L(iMin);
                        eVar2.f4676b = z16;
                    }
                    if (mode == 1073741824) {
                        z6 = z6;
                        eVar4 = eVar3;
                        arrayList2 = arrayList;
                        fVar = fVar;
                        constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                        eVar6 = eVar2.f4675a;
                        if (eVar2.f4676b) {
                            arrayList5 = eVar6.f4471q0;
                            size5 = arrayList5.size();
                            i25 = 0;
                            while (i25 < size5) {
                                Object obj5 = arrayList5.get(i25);
                                i25++;
                                d dVar10 = (d) obj5;
                                dVar10.h();
                                dVar10.f4431a = false;
                                androidx.constraintlayout.core.widgets.analyzer.d dVar11 = dVar10.f4437d;
                                ArrayList arrayList10 = arrayList5;
                                dVar11.f416e.f405j = false;
                                dVar11.f417g = false;
                                dVar11.n();
                                androidx.constraintlayout.core.widgets.analyzer.e eVar11 = dVar10.f4439e;
                                eVar11.f416e.f405j = false;
                                eVar11.f417g = false;
                                eVar11.m();
                                arrayList5 = arrayList10;
                            }
                            i23 = 0;
                            eVar6.h();
                            eVar6.f4431a = false;
                            androidx.constraintlayout.core.widgets.analyzer.d dVar12 = eVar6.f4437d;
                            dVar12.f416e.f405j = false;
                            dVar12.f417g = false;
                            dVar12.n();
                            androidx.constraintlayout.core.widgets.analyzer.e eVar12 = eVar6.f4439e;
                            eVar12.f416e.f405j = false;
                            eVar12.f417g = false;
                            eVar12.m();
                            eVar2.c();
                        } else {
                            i23 = 0;
                        }
                        eVar2.b(eVar2.f4678d);
                        eVar6.Z = i23;
                        eVar6.f4432a0 = i23;
                        eVar6.f4437d.f418h.d(i23);
                        eVar6.f4439e.f418h.d(i23);
                        i24 = 1073741824;
                        if (mode == 1073741824) {
                            zT2 = eVar.T(i23, zC);
                            i10 = 1;
                        } else {
                            zT2 = true;
                            i10 = 0;
                        }
                        if (mode2 == 1073741824) {
                            zT = eVar.T(1, zC) & zT2;
                            i10++;
                        } else {
                            zT = zT2;
                        }
                    } else {
                        z6 = z6;
                        eVar4 = eVar3;
                        arrayList2 = arrayList;
                        fVar = fVar;
                        constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                        eVar6 = eVar2.f4675a;
                        if (eVar2.f4676b) {
                            arrayList5 = eVar6.f4471q0;
                            size5 = arrayList5.size();
                            i25 = 0;
                            while (i25 < size5) {
                                Object obj6 = arrayList5.get(i25);
                                i25++;
                                d dVar13 = (d) obj6;
                                dVar13.h();
                                dVar13.f4431a = false;
                                androidx.constraintlayout.core.widgets.analyzer.d dVar14 = dVar13.f4437d;
                                ArrayList arrayList11 = arrayList5;
                                dVar14.f416e.f405j = false;
                                dVar14.f417g = false;
                                dVar14.n();
                                androidx.constraintlayout.core.widgets.analyzer.e eVar13 = dVar13.f4439e;
                                eVar13.f416e.f405j = false;
                                eVar13.f417g = false;
                                eVar13.m();
                                arrayList5 = arrayList11;
                            }
                            i23 = 0;
                            eVar6.h();
                            eVar6.f4431a = false;
                            androidx.constraintlayout.core.widgets.analyzer.d dVar15 = eVar6.f4437d;
                            dVar15.f416e.f405j = false;
                            dVar15.f417g = false;
                            dVar15.n();
                            androidx.constraintlayout.core.widgets.analyzer.e eVar14 = eVar6.f4439e;
                            eVar14.f416e.f405j = false;
                            eVar14.f417g = false;
                            eVar14.m();
                            eVar2.c();
                        } else {
                            i23 = 0;
                        }
                        eVar2.b(eVar2.f4678d);
                        eVar6.Z = i23;
                        eVar6.f4432a0 = i23;
                        eVar6.f4437d.f418h.d(i23);
                        eVar6.f4439e.f418h.d(i23);
                        i24 = 1073741824;
                        if (mode == 1073741824) {
                            zT2 = eVar.T(i23, zC);
                            i10 = 1;
                        } else {
                            zT2 = true;
                            i10 = 0;
                        }
                        if (mode2 == 1073741824) {
                            zT = eVar.T(1, zC) & zT2;
                            i10++;
                        } else {
                            zT = zT2;
                        }
                    }
                    if (zT) {
                        if (mode == i24) {
                            z17 = true;
                        } else {
                            z17 = false;
                        }
                        if (mode2 == i24) {
                            z18 = true;
                        } else {
                            z18 = false;
                        }
                        eVar.P(z17, z18);
                    }
                } else {
                    z6 = z6;
                    eVar4 = eVar3;
                    arrayList2 = arrayList;
                    fVar = fVar;
                    constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                    zT = false;
                    i10 = 0;
                }
                if (zT) {
                }
                i11 = eVar.D0;
                if (i9 > 0) {
                    size3 = eVar.f4471q0.size();
                    boolean zW4 = eVar.W(64);
                    fVar6 = eVar.f4475u0;
                    while (i20 < size3) {
                        dVar3 = (d) eVar.f4471q0.get(i20);
                        if (!(dVar3 instanceof h)) {
                            constraintWidget$DimensionBehaviourJ = dVar3.j(0);
                            constraintWidget$DimensionBehaviourJ2 = dVar3.j(1);
                            if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                                z15 = false;
                            } else {
                                z15 = false;
                            }
                            if (!z15) {
                                if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                                    z15 = true;
                                }
                                if (constraintWidget$DimensionBehaviourJ2 == constraintWidget$DimensionBehaviour3) {
                                    z15 = true;
                                }
                                z15 = constraintWidget$DimensionBehaviourJ != constraintWidget$DimensionBehaviour3 ? true : true;
                            }
                            if (z15) {
                                uVar.w(0, dVar3, fVar6);
                            }
                        }
                    }
                    constraintLayout = fVar6.f4793a;
                    childCount = constraintLayout.getChildCount();
                    arrayList4 = constraintLayout.f432b;
                    while (i21 < childCount) {
                        constraintLayout.getChildAt(i21);
                    }
                    size4 = arrayList4.size();
                    if (size4 > 0) {
                        while (i22 < size4) {
                            ((c) arrayList4.get(i22)).getClass();
                        }
                    }
                }
                uVar.D(eVar);
                size2 = arrayList2.size();
                if (i9 > 0) {
                    uVar.A(eVar, 0, iQ2, iK);
                }
                if (size2 > 0) {
                    constraintWidget$DimensionBehaviourArr = eVar.T;
                    constraintWidget$DimensionBehaviour5 = constraintWidget$DimensionBehaviour4;
                    if (constraintWidget$DimensionBehaviourArr[0] == constraintWidget$DimensionBehaviour5) {
                        z7 = true;
                    } else {
                        z7 = false;
                    }
                    if (constraintWidget$DimensionBehaviourArr[1] == constraintWidget$DimensionBehaviour5) {
                        z8 = true;
                    } else {
                        z8 = false;
                    }
                    e eVar15 = eVar4;
                    iMax3 = Math.max(eVar.q(), eVar15.f4436c0);
                    iMax4 = Math.max(eVar.k(), eVar15.f4438d0);
                    i12 = 0;
                    z9 = false;
                    while (true) {
                        constraintAnchor$Type = ConstraintAnchor$Type.f376d;
                        constraintAnchor$Type2 = ConstraintAnchor$Type.f375c;
                        if (i12 < size2) {
                            break;
                            break;
                        }
                        ArrayList arrayList12 = arrayList2;
                        dVar2 = (d) arrayList12.get(i12);
                        z13 = z7;
                        if (dVar2 instanceof v.g) {
                            z14 = z8;
                            fVar5 = fVar;
                        } else {
                            iQ5 = dVar2.q();
                            iK4 = dVar2.k();
                            z14 = z8;
                            fVar5 = fVar;
                            zW2 = z9 | uVar.w(1, dVar2, fVar5);
                            iQ6 = dVar2.q();
                            iK5 = dVar2.k();
                            if (iQ6 != iQ5) {
                                dVar2.O(iQ6);
                                if (z13) {
                                    iMax3 = Math.max(iMax3, dVar2.i(constraintAnchor$Type2).e() + dVar2.r() + dVar2.V);
                                }
                                zW2 = true;
                            }
                            if (iK5 != iK4) {
                                dVar2.L(iK5);
                                if (z14) {
                                    iMax4 = Math.max(iMax4, dVar2.i(constraintAnchor$Type).e() + dVar2.s() + dVar2.W);
                                }
                                zW2 = true;
                            }
                            z9 = zW2 | ((v.g) dVar2).f4506y0;
                        }
                        i12++;
                        z7 = z13;
                        fVar = fVar5;
                        arrayList2 = arrayList12;
                        z8 = z14;
                        i11 = i11;
                    }
                    int i43 = i11;
                    z10 = z7;
                    z11 = z8;
                    z12 = z9;
                    fVar2 = fVar;
                    arrayList3 = arrayList2;
                    i13 = 0;
                    while (i13 < 2) {
                        zW = z12;
                        i14 = 0;
                        while (i14 < size2) {
                            dVar = (d) arrayList3.get(i14);
                            if (dVar instanceof i) {
                                i17 = size2;
                                if (dVar.f4445h0 == 8) {
                                    i19 = i13;
                                    i18 = i14;
                                    fVar4 = fVar2;
                                } else {
                                    iQ3 = dVar.q();
                                    iK2 = dVar.k();
                                    i18 = i14;
                                    int i44 = dVar.f4434b0;
                                    zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                    i19 = i13;
                                    iQ4 = dVar.q();
                                    fVar4 = fVar2;
                                    iK3 = dVar.k();
                                    if (iQ4 != iQ3) {
                                        dVar.O(iQ4);
                                        if (z10) {
                                            iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                        }
                                        zW = true;
                                    }
                                    if (iK3 != iK2) {
                                        dVar.L(iK3);
                                        if (z11) {
                                            iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                        }
                                        zW = true;
                                    }
                                    if (!dVar.E) {
                                    }
                                }
                            } else {
                                i17 = size2;
                                if (dVar.f4445h0 == 8) {
                                    i19 = i13;
                                    i18 = i14;
                                    fVar4 = fVar2;
                                } else {
                                    iQ3 = dVar.q();
                                    iK2 = dVar.k();
                                    i18 = i14;
                                    int i45 = dVar.f4434b0;
                                    zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                    i19 = i13;
                                    iQ4 = dVar.q();
                                    fVar4 = fVar2;
                                    iK3 = dVar.k();
                                    if (iQ4 != iQ3) {
                                        dVar.O(iQ4);
                                        if (z10) {
                                            iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                        }
                                        zW = true;
                                    }
                                    if (iK3 != iK2) {
                                        dVar.L(iK3);
                                        if (z11) {
                                            iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                        }
                                        zW = true;
                                    }
                                    if (!dVar.E) {
                                    }
                                }
                            }
                            i14 = i18 + 1;
                            size2 = i17;
                            i13 = i19;
                            fVar2 = fVar4;
                        }
                        i15 = i13;
                        i16 = size2;
                        fVar3 = fVar2;
                        if (zW) {
                            break;
                            break;
                        }
                        i13 = i15 + 1;
                        uVar.A(eVar, i13, iQ2, iK);
                        size2 = i16;
                        fVar2 = fVar3;
                        z12 = false;
                    }
                    i11 = i43;
                }
                eVar.D0 = i11;
                t.c.f3952q = eVar.W(512);
            }
            if (childCount2 == 0) {
                iMax2 = Math.max(0, this.f435e);
            } else {
                iMax2 = i33;
            }
            constraintWidget$DimensionBehaviour2 = constraintWidget$DimensionBehaviour8;
            iQ = eVar.q();
            eVar2 = eVar.f4473s0;
            iArr = eVar.C;
            if (iMax == iQ) {
                eVar2.f4677c = true;
            } else {
                eVar2.f4677c = true;
            }
            eVar.Z = 0;
            eVar.f4432a0 = 0;
            iArr[0] = this.f - i35;
            iArr[1] = this.f436g - i34;
            eVar.f4436c0 = 0;
            eVar.f4438d0 = 0;
            eVar.M(constraintWidget$DimensionBehaviour);
            eVar.O(iMax);
            eVar.N(constraintWidget$DimensionBehaviour2);
            eVar.L(iMax2);
            i7 = this.f434d - i35;
            if (i7 < 0) {
                eVar.f4436c0 = 0;
            } else {
                eVar.f4436c0 = i7;
            }
            i8 = this.f435e - i34;
            if (i8 < 0) {
                eVar.f4438d0 = 0;
            } else {
                eVar.f4438d0 = i8;
            }
            eVar.f4478x0 = iMax7;
            eVar.f4479y0 = iMax5;
            uVar = eVar.f4472r0;
            eVar3 = (e) uVar.f564d;
            arrayList = (ArrayList) uVar.f562b;
            fVar = eVar.f4475u0;
            size = eVar.f4471q0.size();
            iQ2 = eVar.q();
            iK = eVar.k();
            zC = j.c(i3, 128);
            if (zC) {
                z4 = true;
            } else {
                z4 = true;
            }
            constraintWidget$DimensionBehaviour3 = ConstraintWidget$DimensionBehaviour.f383c;
            boolean z24 = z4;
            if (z4) {
                i29 = 0;
                while (true) {
                    i9 = size;
                    if (i29 < size) {
                        dVar5 = (d) eVar.f4471q0.get(i29);
                        i30 = i29;
                        constraintWidget$DimensionBehaviourArr2 = dVar5.T;
                        if (constraintWidget$DimensionBehaviourArr2[0] == constraintWidget$DimensionBehaviour3) {
                            z20 = true;
                        } else {
                            z20 = false;
                        }
                        if (constraintWidget$DimensionBehaviourArr2[1] == constraintWidget$DimensionBehaviour3) {
                            z21 = true;
                        } else {
                            z21 = false;
                        }
                        if (z20) {
                            z22 = false;
                        } else {
                            z22 = false;
                        }
                        if (dVar5.x()) {
                            i29 = i30 + 1;
                            size = i9;
                        } else {
                            i29 = i30 + 1;
                            size = i9;
                        }
                        z5 = false;
                    }
                    z6 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
                    if (z6) {
                        int iMin4 = Math.min(iArr[0], i32);
                        iMin = Math.min(iArr[1], i33);
                        if (mode == 1073741824) {
                            z16 = true;
                        } else {
                            z16 = true;
                        }
                        if (mode2 == 1073741824) {
                            eVar.L(iMin);
                            eVar2.f4676b = z16;
                        }
                        if (mode == 1073741824) {
                            z6 = z6;
                            eVar4 = eVar3;
                            arrayList2 = arrayList;
                            fVar = fVar;
                            constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                            eVar6 = eVar2.f4675a;
                            if (eVar2.f4676b) {
                                arrayList5 = eVar6.f4471q0;
                                size5 = arrayList5.size();
                                i25 = 0;
                                while (i25 < size5) {
                                    Object obj7 = arrayList5.get(i25);
                                    i25++;
                                    d dVar16 = (d) obj7;
                                    dVar16.h();
                                    dVar16.f4431a = false;
                                    androidx.constraintlayout.core.widgets.analyzer.d dVar17 = dVar16.f4437d;
                                    ArrayList arrayList13 = arrayList5;
                                    dVar17.f416e.f405j = false;
                                    dVar17.f417g = false;
                                    dVar17.n();
                                    androidx.constraintlayout.core.widgets.analyzer.e eVar16 = dVar16.f4439e;
                                    eVar16.f416e.f405j = false;
                                    eVar16.f417g = false;
                                    eVar16.m();
                                    arrayList5 = arrayList13;
                                }
                                i23 = 0;
                                eVar6.h();
                                eVar6.f4431a = false;
                                androidx.constraintlayout.core.widgets.analyzer.d dVar18 = eVar6.f4437d;
                                dVar18.f416e.f405j = false;
                                dVar18.f417g = false;
                                dVar18.n();
                                androidx.constraintlayout.core.widgets.analyzer.e eVar17 = eVar6.f4439e;
                                eVar17.f416e.f405j = false;
                                eVar17.f417g = false;
                                eVar17.m();
                                eVar2.c();
                            } else {
                                i23 = 0;
                            }
                            eVar2.b(eVar2.f4678d);
                            eVar6.Z = i23;
                            eVar6.f4432a0 = i23;
                            eVar6.f4437d.f418h.d(i23);
                            eVar6.f4439e.f418h.d(i23);
                            i24 = 1073741824;
                            if (mode == 1073741824) {
                                zT2 = eVar.T(i23, zC);
                                i10 = 1;
                            } else {
                                zT2 = true;
                                i10 = 0;
                            }
                            if (mode2 == 1073741824) {
                                zT = eVar.T(1, zC) & zT2;
                                i10++;
                            } else {
                                zT = zT2;
                            }
                        } else {
                            z6 = z6;
                            eVar4 = eVar3;
                            arrayList2 = arrayList;
                            fVar = fVar;
                            constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                            eVar6 = eVar2.f4675a;
                            if (eVar2.f4676b) {
                                arrayList5 = eVar6.f4471q0;
                                size5 = arrayList5.size();
                                i25 = 0;
                                while (i25 < size5) {
                                    Object obj8 = arrayList5.get(i25);
                                    i25++;
                                    d dVar19 = (d) obj8;
                                    dVar19.h();
                                    dVar19.f4431a = false;
                                    androidx.constraintlayout.core.widgets.analyzer.d dVar110 = dVar19.f4437d;
                                    ArrayList arrayList14 = arrayList5;
                                    dVar110.f416e.f405j = false;
                                    dVar110.f417g = false;
                                    dVar110.n();
                                    androidx.constraintlayout.core.widgets.analyzer.e eVar18 = dVar19.f4439e;
                                    eVar18.f416e.f405j = false;
                                    eVar18.f417g = false;
                                    eVar18.m();
                                    arrayList5 = arrayList14;
                                }
                                i23 = 0;
                                eVar6.h();
                                eVar6.f4431a = false;
                                androidx.constraintlayout.core.widgets.analyzer.d dVar111 = eVar6.f4437d;
                                dVar111.f416e.f405j = false;
                                dVar111.f417g = false;
                                dVar111.n();
                                androidx.constraintlayout.core.widgets.analyzer.e eVar19 = eVar6.f4439e;
                                eVar19.f416e.f405j = false;
                                eVar19.f417g = false;
                                eVar19.m();
                                eVar2.c();
                            } else {
                                i23 = 0;
                            }
                            eVar2.b(eVar2.f4678d);
                            eVar6.Z = i23;
                            eVar6.f4432a0 = i23;
                            eVar6.f4437d.f418h.d(i23);
                            eVar6.f4439e.f418h.d(i23);
                            i24 = 1073741824;
                            if (mode == 1073741824) {
                                zT2 = eVar.T(i23, zC);
                                i10 = 1;
                            } else {
                                zT2 = true;
                                i10 = 0;
                            }
                            if (mode2 == 1073741824) {
                                zT = eVar.T(1, zC) & zT2;
                                i10++;
                            } else {
                                zT = zT2;
                            }
                        }
                        if (zT) {
                            if (mode == i24) {
                                z17 = true;
                            } else {
                                z17 = false;
                            }
                            if (mode2 == i24) {
                                z18 = true;
                            } else {
                                z18 = false;
                            }
                            eVar.P(z17, z18);
                        }
                    } else {
                        z6 = z6;
                        eVar4 = eVar3;
                        arrayList2 = arrayList;
                        fVar = fVar;
                        constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                        zT = false;
                        i10 = 0;
                    }
                    if (zT) {
                    }
                    i11 = eVar.D0;
                    if (i9 > 0) {
                        size3 = eVar.f4471q0.size();
                        boolean zW5 = eVar.W(64);
                        fVar6 = eVar.f4475u0;
                        while (i20 < size3) {
                            dVar3 = (d) eVar.f4471q0.get(i20);
                            if (!(dVar3 instanceof h)) {
                                constraintWidget$DimensionBehaviourJ = dVar3.j(0);
                                constraintWidget$DimensionBehaviourJ2 = dVar3.j(1);
                                if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                                    z15 = false;
                                } else {
                                    z15 = false;
                                }
                                if (!z15) {
                                    if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                                        z15 = true;
                                    }
                                    if (constraintWidget$DimensionBehaviourJ2 == constraintWidget$DimensionBehaviour3) {
                                        z15 = true;
                                    }
                                    if (constraintWidget$DimensionBehaviourJ != constraintWidget$DimensionBehaviour3) {
                                    }
                                }
                                if (z15) {
                                    uVar.w(0, dVar3, fVar6);
                                }
                            }
                        }
                        constraintLayout = fVar6.f4793a;
                        childCount = constraintLayout.getChildCount();
                        arrayList4 = constraintLayout.f432b;
                        while (i21 < childCount) {
                            constraintLayout.getChildAt(i21);
                        }
                        size4 = arrayList4.size();
                        if (size4 > 0) {
                            while (i22 < size4) {
                                ((c) arrayList4.get(i22)).getClass();
                            }
                        }
                    }
                    uVar.D(eVar);
                    size2 = arrayList2.size();
                    if (i9 > 0) {
                        uVar.A(eVar, 0, iQ2, iK);
                    }
                    if (size2 > 0) {
                        constraintWidget$DimensionBehaviourArr = eVar.T;
                        constraintWidget$DimensionBehaviour5 = constraintWidget$DimensionBehaviour4;
                        if (constraintWidget$DimensionBehaviourArr[0] == constraintWidget$DimensionBehaviour5) {
                            z7 = true;
                        } else {
                            z7 = false;
                        }
                        if (constraintWidget$DimensionBehaviourArr[1] == constraintWidget$DimensionBehaviour5) {
                            z8 = true;
                        } else {
                            z8 = false;
                        }
                        e eVar110 = eVar4;
                        iMax3 = Math.max(eVar.q(), eVar110.f4436c0);
                        iMax4 = Math.max(eVar.k(), eVar110.f4438d0);
                        i12 = 0;
                        z9 = false;
                        while (true) {
                            constraintAnchor$Type = ConstraintAnchor$Type.f376d;
                            constraintAnchor$Type2 = ConstraintAnchor$Type.f375c;
                            if (i12 < size2) {
                                break;
                                break;
                            }
                            ArrayList arrayList15 = arrayList2;
                            dVar2 = (d) arrayList15.get(i12);
                            z13 = z7;
                            if (dVar2 instanceof v.g) {
                                z14 = z8;
                                fVar5 = fVar;
                            } else {
                                iQ5 = dVar2.q();
                                iK4 = dVar2.k();
                                z14 = z8;
                                fVar5 = fVar;
                                zW2 = z9 | uVar.w(1, dVar2, fVar5);
                                iQ6 = dVar2.q();
                                iK5 = dVar2.k();
                                if (iQ6 != iQ5) {
                                    dVar2.O(iQ6);
                                    if (z13) {
                                        iMax3 = Math.max(iMax3, dVar2.i(constraintAnchor$Type2).e() + dVar2.r() + dVar2.V);
                                    }
                                    zW2 = true;
                                }
                                if (iK5 != iK4) {
                                    dVar2.L(iK5);
                                    if (z14) {
                                        iMax4 = Math.max(iMax4, dVar2.i(constraintAnchor$Type).e() + dVar2.s() + dVar2.W);
                                    }
                                    zW2 = true;
                                }
                                z9 = zW2 | ((v.g) dVar2).f4506y0;
                            }
                            i12++;
                            z7 = z13;
                            fVar = fVar5;
                            arrayList2 = arrayList15;
                            z8 = z14;
                            i11 = i11;
                        }
                        int i46 = i11;
                        z10 = z7;
                        z11 = z8;
                        z12 = z9;
                        fVar2 = fVar;
                        arrayList3 = arrayList2;
                        i13 = 0;
                        while (i13 < 2) {
                            zW = z12;
                            i14 = 0;
                            while (i14 < size2) {
                                dVar = (d) arrayList3.get(i14);
                                if (dVar instanceof i) {
                                    i17 = size2;
                                    if (dVar.f4445h0 == 8) {
                                        i19 = i13;
                                        i18 = i14;
                                        fVar4 = fVar2;
                                    } else {
                                        iQ3 = dVar.q();
                                        iK2 = dVar.k();
                                        i18 = i14;
                                        int i47 = dVar.f4434b0;
                                        zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                        i19 = i13;
                                        iQ4 = dVar.q();
                                        fVar4 = fVar2;
                                        iK3 = dVar.k();
                                        if (iQ4 != iQ3) {
                                            dVar.O(iQ4);
                                            if (z10) {
                                                iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                            }
                                            zW = true;
                                        }
                                        if (iK3 != iK2) {
                                            dVar.L(iK3);
                                            if (z11) {
                                                iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                            }
                                            zW = true;
                                        }
                                        if (!dVar.E) {
                                        }
                                    }
                                } else {
                                    i17 = size2;
                                    if (dVar.f4445h0 == 8) {
                                        i19 = i13;
                                        i18 = i14;
                                        fVar4 = fVar2;
                                    } else {
                                        iQ3 = dVar.q();
                                        iK2 = dVar.k();
                                        i18 = i14;
                                        int i48 = dVar.f4434b0;
                                        zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                        i19 = i13;
                                        iQ4 = dVar.q();
                                        fVar4 = fVar2;
                                        iK3 = dVar.k();
                                        if (iQ4 != iQ3) {
                                            dVar.O(iQ4);
                                            if (z10) {
                                                iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                            }
                                            zW = true;
                                        }
                                        if (iK3 != iK2) {
                                            dVar.L(iK3);
                                            if (z11) {
                                                iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                            }
                                            zW = true;
                                        }
                                        if (!dVar.E) {
                                        }
                                    }
                                }
                                i14 = i18 + 1;
                                size2 = i17;
                                i13 = i19;
                                fVar2 = fVar4;
                            }
                            i15 = i13;
                            i16 = size2;
                            fVar3 = fVar2;
                            if (zW) {
                                break;
                                break;
                            }
                            i13 = i15 + 1;
                            uVar.A(eVar, i13, iQ2, iK);
                            size2 = i16;
                            fVar2 = fVar3;
                            z12 = false;
                        }
                        i11 = i46;
                    }
                    eVar.D0 = i11;
                    t.c.f3952q = eVar.W(512);
                }
            }
            i9 = size;
            z5 = z24;
            z6 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
            if (z6) {
                int iMin5 = Math.min(iArr[0], i32);
                iMin = Math.min(iArr[1], i33);
                if (mode == 1073741824) {
                    z16 = true;
                } else {
                    z16 = true;
                }
                if (mode2 == 1073741824) {
                    eVar.L(iMin);
                    eVar2.f4676b = z16;
                }
                if (mode == 1073741824) {
                    z6 = z6;
                    eVar4 = eVar3;
                    arrayList2 = arrayList;
                    fVar = fVar;
                    constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                    eVar6 = eVar2.f4675a;
                    if (eVar2.f4676b) {
                        arrayList5 = eVar6.f4471q0;
                        size5 = arrayList5.size();
                        i25 = 0;
                        while (i25 < size5) {
                            Object obj9 = arrayList5.get(i25);
                            i25++;
                            d dVar112 = (d) obj9;
                            dVar112.h();
                            dVar112.f4431a = false;
                            androidx.constraintlayout.core.widgets.analyzer.d dVar113 = dVar112.f4437d;
                            ArrayList arrayList16 = arrayList5;
                            dVar113.f416e.f405j = false;
                            dVar113.f417g = false;
                            dVar113.n();
                            androidx.constraintlayout.core.widgets.analyzer.e eVar111 = dVar112.f4439e;
                            eVar111.f416e.f405j = false;
                            eVar111.f417g = false;
                            eVar111.m();
                            arrayList5 = arrayList16;
                        }
                        i23 = 0;
                        eVar6.h();
                        eVar6.f4431a = false;
                        androidx.constraintlayout.core.widgets.analyzer.d dVar114 = eVar6.f4437d;
                        dVar114.f416e.f405j = false;
                        dVar114.f417g = false;
                        dVar114.n();
                        androidx.constraintlayout.core.widgets.analyzer.e eVar112 = eVar6.f4439e;
                        eVar112.f416e.f405j = false;
                        eVar112.f417g = false;
                        eVar112.m();
                        eVar2.c();
                    } else {
                        i23 = 0;
                    }
                    eVar2.b(eVar2.f4678d);
                    eVar6.Z = i23;
                    eVar6.f4432a0 = i23;
                    eVar6.f4437d.f418h.d(i23);
                    eVar6.f4439e.f418h.d(i23);
                    i24 = 1073741824;
                    if (mode == 1073741824) {
                        zT2 = eVar.T(i23, zC);
                        i10 = 1;
                    } else {
                        zT2 = true;
                        i10 = 0;
                    }
                    if (mode2 == 1073741824) {
                        zT = eVar.T(1, zC) & zT2;
                        i10++;
                    } else {
                        zT = zT2;
                    }
                } else {
                    z6 = z6;
                    eVar4 = eVar3;
                    arrayList2 = arrayList;
                    fVar = fVar;
                    constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                    eVar6 = eVar2.f4675a;
                    if (eVar2.f4676b) {
                        arrayList5 = eVar6.f4471q0;
                        size5 = arrayList5.size();
                        i25 = 0;
                        while (i25 < size5) {
                            Object obj10 = arrayList5.get(i25);
                            i25++;
                            d dVar115 = (d) obj10;
                            dVar115.h();
                            dVar115.f4431a = false;
                            androidx.constraintlayout.core.widgets.analyzer.d dVar116 = dVar115.f4437d;
                            ArrayList arrayList17 = arrayList5;
                            dVar116.f416e.f405j = false;
                            dVar116.f417g = false;
                            dVar116.n();
                            androidx.constraintlayout.core.widgets.analyzer.e eVar113 = dVar115.f4439e;
                            eVar113.f416e.f405j = false;
                            eVar113.f417g = false;
                            eVar113.m();
                            arrayList5 = arrayList17;
                        }
                        i23 = 0;
                        eVar6.h();
                        eVar6.f4431a = false;
                        androidx.constraintlayout.core.widgets.analyzer.d dVar117 = eVar6.f4437d;
                        dVar117.f416e.f405j = false;
                        dVar117.f417g = false;
                        dVar117.n();
                        androidx.constraintlayout.core.widgets.analyzer.e eVar114 = eVar6.f4439e;
                        eVar114.f416e.f405j = false;
                        eVar114.f417g = false;
                        eVar114.m();
                        eVar2.c();
                    } else {
                        i23 = 0;
                    }
                    eVar2.b(eVar2.f4678d);
                    eVar6.Z = i23;
                    eVar6.f4432a0 = i23;
                    eVar6.f4437d.f418h.d(i23);
                    eVar6.f4439e.f418h.d(i23);
                    i24 = 1073741824;
                    if (mode == 1073741824) {
                        zT2 = eVar.T(i23, zC);
                        i10 = 1;
                    } else {
                        zT2 = true;
                        i10 = 0;
                    }
                    if (mode2 == 1073741824) {
                        zT = eVar.T(1, zC) & zT2;
                        i10++;
                    } else {
                        zT = zT2;
                    }
                }
                if (zT) {
                    if (mode == i24) {
                        z17 = true;
                    } else {
                        z17 = false;
                    }
                    if (mode2 == i24) {
                        z18 = true;
                    } else {
                        z18 = false;
                    }
                    eVar.P(z17, z18);
                }
            } else {
                z6 = z6;
                eVar4 = eVar3;
                arrayList2 = arrayList;
                fVar = fVar;
                constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                zT = false;
                i10 = 0;
            }
            if (zT) {
            }
            i11 = eVar.D0;
            if (i9 > 0) {
                size3 = eVar.f4471q0.size();
                boolean zW6 = eVar.W(64);
                fVar6 = eVar.f4475u0;
                while (i20 < size3) {
                    dVar3 = (d) eVar.f4471q0.get(i20);
                    if (!(dVar3 instanceof h)) {
                        constraintWidget$DimensionBehaviourJ = dVar3.j(0);
                        constraintWidget$DimensionBehaviourJ2 = dVar3.j(1);
                        if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                            z15 = false;
                        } else {
                            z15 = false;
                        }
                        if (!z15) {
                            if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                                z15 = true;
                            }
                            if (constraintWidget$DimensionBehaviourJ2 == constraintWidget$DimensionBehaviour3) {
                                z15 = true;
                            }
                            if (constraintWidget$DimensionBehaviourJ != constraintWidget$DimensionBehaviour3) {
                            }
                        }
                        if (z15) {
                            uVar.w(0, dVar3, fVar6);
                        }
                    }
                }
                constraintLayout = fVar6.f4793a;
                childCount = constraintLayout.getChildCount();
                arrayList4 = constraintLayout.f432b;
                while (i21 < childCount) {
                    constraintLayout.getChildAt(i21);
                }
                size4 = arrayList4.size();
                if (size4 > 0) {
                    while (i22 < size4) {
                        ((c) arrayList4.get(i22)).getClass();
                    }
                }
            }
            uVar.D(eVar);
            size2 = arrayList2.size();
            if (i9 > 0) {
                uVar.A(eVar, 0, iQ2, iK);
            }
            if (size2 > 0) {
                constraintWidget$DimensionBehaviourArr = eVar.T;
                constraintWidget$DimensionBehaviour5 = constraintWidget$DimensionBehaviour4;
                if (constraintWidget$DimensionBehaviourArr[0] == constraintWidget$DimensionBehaviour5) {
                    z7 = true;
                } else {
                    z7 = false;
                }
                if (constraintWidget$DimensionBehaviourArr[1] == constraintWidget$DimensionBehaviour5) {
                    z8 = true;
                } else {
                    z8 = false;
                }
                e eVar115 = eVar4;
                iMax3 = Math.max(eVar.q(), eVar115.f4436c0);
                iMax4 = Math.max(eVar.k(), eVar115.f4438d0);
                i12 = 0;
                z9 = false;
                while (true) {
                    constraintAnchor$Type = ConstraintAnchor$Type.f376d;
                    constraintAnchor$Type2 = ConstraintAnchor$Type.f375c;
                    if (i12 < size2) {
                        break;
                        break;
                    }
                    ArrayList arrayList18 = arrayList2;
                    dVar2 = (d) arrayList18.get(i12);
                    z13 = z7;
                    if (dVar2 instanceof v.g) {
                        z14 = z8;
                        fVar5 = fVar;
                    } else {
                        iQ5 = dVar2.q();
                        iK4 = dVar2.k();
                        z14 = z8;
                        fVar5 = fVar;
                        zW2 = z9 | uVar.w(1, dVar2, fVar5);
                        iQ6 = dVar2.q();
                        iK5 = dVar2.k();
                        if (iQ6 != iQ5) {
                            dVar2.O(iQ6);
                            if (z13) {
                                iMax3 = Math.max(iMax3, dVar2.i(constraintAnchor$Type2).e() + dVar2.r() + dVar2.V);
                            }
                            zW2 = true;
                        }
                        if (iK5 != iK4) {
                            dVar2.L(iK5);
                            if (z14) {
                                iMax4 = Math.max(iMax4, dVar2.i(constraintAnchor$Type).e() + dVar2.s() + dVar2.W);
                            }
                            zW2 = true;
                        }
                        z9 = zW2 | ((v.g) dVar2).f4506y0;
                    }
                    i12++;
                    z7 = z13;
                    fVar = fVar5;
                    arrayList2 = arrayList18;
                    z8 = z14;
                    i11 = i11;
                }
                int i49 = i11;
                z10 = z7;
                z11 = z8;
                z12 = z9;
                fVar2 = fVar;
                arrayList3 = arrayList2;
                i13 = 0;
                while (i13 < 2) {
                    zW = z12;
                    i14 = 0;
                    while (i14 < size2) {
                        dVar = (d) arrayList3.get(i14);
                        if (dVar instanceof i) {
                            i17 = size2;
                            if (dVar.f4445h0 == 8) {
                                i19 = i13;
                                i18 = i14;
                                fVar4 = fVar2;
                            } else {
                                iQ3 = dVar.q();
                                iK2 = dVar.k();
                                i18 = i14;
                                int i410 = dVar.f4434b0;
                                zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                i19 = i13;
                                iQ4 = dVar.q();
                                fVar4 = fVar2;
                                iK3 = dVar.k();
                                if (iQ4 != iQ3) {
                                    dVar.O(iQ4);
                                    if (z10) {
                                        iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                    }
                                    zW = true;
                                }
                                if (iK3 != iK2) {
                                    dVar.L(iK3);
                                    if (z11) {
                                        iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                    }
                                    zW = true;
                                }
                                if (!dVar.E) {
                                }
                            }
                        } else {
                            i17 = size2;
                            if (dVar.f4445h0 == 8) {
                                i19 = i13;
                                i18 = i14;
                                fVar4 = fVar2;
                            } else {
                                iQ3 = dVar.q();
                                iK2 = dVar.k();
                                i18 = i14;
                                int i411 = dVar.f4434b0;
                                zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                i19 = i13;
                                iQ4 = dVar.q();
                                fVar4 = fVar2;
                                iK3 = dVar.k();
                                if (iQ4 != iQ3) {
                                    dVar.O(iQ4);
                                    if (z10) {
                                        iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                    }
                                    zW = true;
                                }
                                if (iK3 != iK2) {
                                    dVar.L(iK3);
                                    if (z11) {
                                        iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                    }
                                    zW = true;
                                }
                                if (!dVar.E) {
                                }
                            }
                        }
                        i14 = i18 + 1;
                        size2 = i17;
                        i13 = i19;
                        fVar2 = fVar4;
                    }
                    i15 = i13;
                    i16 = size2;
                    fVar3 = fVar2;
                    if (zW) {
                        break;
                        break;
                    }
                    i13 = i15 + 1;
                    uVar.A(eVar, i13, iQ2, iK);
                    size2 = i16;
                    fVar2 = fVar3;
                    z12 = false;
                }
                i11 = i49;
            }
            eVar.D0 = i11;
            t.c.f3952q = eVar.W(512);
        }
        iMax = childCount2 == 0 ? Math.max(0, this.f434d) : i32;
        constraintWidget$DimensionBehaviour = constraintWidget$DimensionBehaviour8;
        i6 = Integer.MIN_VALUE;
        if (mode2 != i6) {
            if (mode2 != 0) {
                if (mode2 != 1073741824) {
                    constraintWidget$DimensionBehaviour2 = constraintWidget$DimensionBehaviour7;
                    iMax2 = 0;
                } else {
                    iMax2 = Math.min(this.f436g - i34, i33);
                    constraintWidget$DimensionBehaviour2 = constraintWidget$DimensionBehaviour7;
                }
            } else if (childCount2 == 0) {
                constraintWidget$DimensionBehaviour2 = constraintWidget$DimensionBehaviour8;
                iMax2 = Math.max(0, this.f435e);
            } else {
                iMax2 = 0;
            }
            iQ = eVar.q();
            eVar2 = eVar.f4473s0;
            iArr = eVar.C;
            if (iMax == iQ) {
                eVar2.f4677c = true;
            } else {
                eVar2.f4677c = true;
            }
            eVar.Z = 0;
            eVar.f4432a0 = 0;
            iArr[0] = this.f - i35;
            iArr[1] = this.f436g - i34;
            eVar.f4436c0 = 0;
            eVar.f4438d0 = 0;
            eVar.M(constraintWidget$DimensionBehaviour);
            eVar.O(iMax);
            eVar.N(constraintWidget$DimensionBehaviour2);
            eVar.L(iMax2);
            i7 = this.f434d - i35;
            if (i7 < 0) {
                eVar.f4436c0 = 0;
            } else {
                eVar.f4436c0 = i7;
            }
            i8 = this.f435e - i34;
            if (i8 < 0) {
                eVar.f4438d0 = 0;
            } else {
                eVar.f4438d0 = i8;
            }
            eVar.f4478x0 = iMax7;
            eVar.f4479y0 = iMax5;
            uVar = eVar.f4472r0;
            eVar3 = (e) uVar.f564d;
            arrayList = (ArrayList) uVar.f562b;
            fVar = eVar.f4475u0;
            size = eVar.f4471q0.size();
            iQ2 = eVar.q();
            iK = eVar.k();
            zC = j.c(i3, 128);
            if (zC) {
                z4 = true;
            } else {
                z4 = true;
            }
            constraintWidget$DimensionBehaviour3 = ConstraintWidget$DimensionBehaviour.f383c;
            boolean z25 = z4;
            if (z4) {
                i29 = 0;
                while (true) {
                    i9 = size;
                    if (i29 < size) {
                        dVar5 = (d) eVar.f4471q0.get(i29);
                        i30 = i29;
                        constraintWidget$DimensionBehaviourArr2 = dVar5.T;
                        if (constraintWidget$DimensionBehaviourArr2[0] == constraintWidget$DimensionBehaviour3) {
                            z20 = true;
                        } else {
                            z20 = false;
                        }
                        if (constraintWidget$DimensionBehaviourArr2[1] == constraintWidget$DimensionBehaviour3) {
                            z21 = true;
                        } else {
                            z21 = false;
                        }
                        if (z20) {
                            z22 = false;
                        } else {
                            z22 = false;
                        }
                        if (dVar5.x()) {
                            i29 = i30 + 1;
                            size = i9;
                        } else {
                            i29 = i30 + 1;
                            size = i9;
                        }
                        z5 = false;
                    }
                    z6 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
                    if (z6) {
                        int iMin6 = Math.min(iArr[0], i32);
                        iMin = Math.min(iArr[1], i33);
                        if (mode == 1073741824) {
                            z16 = true;
                        } else {
                            z16 = true;
                        }
                        if (mode2 == 1073741824) {
                            eVar.L(iMin);
                            eVar2.f4676b = z16;
                        }
                        if (mode == 1073741824) {
                            z6 = z6;
                            eVar4 = eVar3;
                            arrayList2 = arrayList;
                            fVar = fVar;
                            constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                            eVar6 = eVar2.f4675a;
                            if (eVar2.f4676b) {
                                arrayList5 = eVar6.f4471q0;
                                size5 = arrayList5.size();
                                i25 = 0;
                                while (i25 < size5) {
                                    Object obj11 = arrayList5.get(i25);
                                    i25++;
                                    d dVar118 = (d) obj11;
                                    dVar118.h();
                                    dVar118.f4431a = false;
                                    androidx.constraintlayout.core.widgets.analyzer.d dVar119 = dVar118.f4437d;
                                    ArrayList arrayList19 = arrayList5;
                                    dVar119.f416e.f405j = false;
                                    dVar119.f417g = false;
                                    dVar119.n();
                                    androidx.constraintlayout.core.widgets.analyzer.e eVar116 = dVar118.f4439e;
                                    eVar116.f416e.f405j = false;
                                    eVar116.f417g = false;
                                    eVar116.m();
                                    arrayList5 = arrayList19;
                                }
                                i23 = 0;
                                eVar6.h();
                                eVar6.f4431a = false;
                                androidx.constraintlayout.core.widgets.analyzer.d dVar1110 = eVar6.f4437d;
                                dVar1110.f416e.f405j = false;
                                dVar1110.f417g = false;
                                dVar1110.n();
                                androidx.constraintlayout.core.widgets.analyzer.e eVar117 = eVar6.f4439e;
                                eVar117.f416e.f405j = false;
                                eVar117.f417g = false;
                                eVar117.m();
                                eVar2.c();
                            } else {
                                i23 = 0;
                            }
                            eVar2.b(eVar2.f4678d);
                            eVar6.Z = i23;
                            eVar6.f4432a0 = i23;
                            eVar6.f4437d.f418h.d(i23);
                            eVar6.f4439e.f418h.d(i23);
                            i24 = 1073741824;
                            if (mode == 1073741824) {
                                zT2 = eVar.T(i23, zC);
                                i10 = 1;
                            } else {
                                zT2 = true;
                                i10 = 0;
                            }
                            if (mode2 == 1073741824) {
                                zT = eVar.T(1, zC) & zT2;
                                i10++;
                            } else {
                                zT = zT2;
                            }
                        } else {
                            z6 = z6;
                            eVar4 = eVar3;
                            arrayList2 = arrayList;
                            fVar = fVar;
                            constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                            eVar6 = eVar2.f4675a;
                            if (eVar2.f4676b) {
                                arrayList5 = eVar6.f4471q0;
                                size5 = arrayList5.size();
                                i25 = 0;
                                while (i25 < size5) {
                                    Object obj12 = arrayList5.get(i25);
                                    i25++;
                                    d dVar1111 = (d) obj12;
                                    dVar1111.h();
                                    dVar1111.f4431a = false;
                                    androidx.constraintlayout.core.widgets.analyzer.d dVar1112 = dVar1111.f4437d;
                                    ArrayList arrayList110 = arrayList5;
                                    dVar1112.f416e.f405j = false;
                                    dVar1112.f417g = false;
                                    dVar1112.n();
                                    androidx.constraintlayout.core.widgets.analyzer.e eVar118 = dVar1111.f4439e;
                                    eVar118.f416e.f405j = false;
                                    eVar118.f417g = false;
                                    eVar118.m();
                                    arrayList5 = arrayList110;
                                }
                                i23 = 0;
                                eVar6.h();
                                eVar6.f4431a = false;
                                androidx.constraintlayout.core.widgets.analyzer.d dVar1113 = eVar6.f4437d;
                                dVar1113.f416e.f405j = false;
                                dVar1113.f417g = false;
                                dVar1113.n();
                                androidx.constraintlayout.core.widgets.analyzer.e eVar119 = eVar6.f4439e;
                                eVar119.f416e.f405j = false;
                                eVar119.f417g = false;
                                eVar119.m();
                                eVar2.c();
                            } else {
                                i23 = 0;
                            }
                            eVar2.b(eVar2.f4678d);
                            eVar6.Z = i23;
                            eVar6.f4432a0 = i23;
                            eVar6.f4437d.f418h.d(i23);
                            eVar6.f4439e.f418h.d(i23);
                            i24 = 1073741824;
                            if (mode == 1073741824) {
                                zT2 = eVar.T(i23, zC);
                                i10 = 1;
                            } else {
                                zT2 = true;
                                i10 = 0;
                            }
                            if (mode2 == 1073741824) {
                                zT = eVar.T(1, zC) & zT2;
                                i10++;
                            } else {
                                zT = zT2;
                            }
                        }
                        if (zT) {
                            if (mode == i24) {
                                z17 = true;
                            } else {
                                z17 = false;
                            }
                            if (mode2 == i24) {
                                z18 = true;
                            } else {
                                z18 = false;
                            }
                            eVar.P(z17, z18);
                        }
                    } else {
                        z6 = z6;
                        eVar4 = eVar3;
                        arrayList2 = arrayList;
                        fVar = fVar;
                        constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                        zT = false;
                        i10 = 0;
                    }
                    if (zT) {
                    }
                    i11 = eVar.D0;
                    if (i9 > 0) {
                        size3 = eVar.f4471q0.size();
                        boolean zW7 = eVar.W(64);
                        fVar6 = eVar.f4475u0;
                        while (i20 < size3) {
                            dVar3 = (d) eVar.f4471q0.get(i20);
                            if (!(dVar3 instanceof h)) {
                                constraintWidget$DimensionBehaviourJ = dVar3.j(0);
                                constraintWidget$DimensionBehaviourJ2 = dVar3.j(1);
                                if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                                    z15 = false;
                                } else {
                                    z15 = false;
                                }
                                if (!z15) {
                                    if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                                        z15 = true;
                                    }
                                    if (constraintWidget$DimensionBehaviourJ2 == constraintWidget$DimensionBehaviour3) {
                                        z15 = true;
                                    }
                                    if (constraintWidget$DimensionBehaviourJ != constraintWidget$DimensionBehaviour3) {
                                    }
                                }
                                if (z15) {
                                    uVar.w(0, dVar3, fVar6);
                                }
                            }
                        }
                        constraintLayout = fVar6.f4793a;
                        childCount = constraintLayout.getChildCount();
                        arrayList4 = constraintLayout.f432b;
                        while (i21 < childCount) {
                            constraintLayout.getChildAt(i21);
                        }
                        size4 = arrayList4.size();
                        if (size4 > 0) {
                            while (i22 < size4) {
                                ((c) arrayList4.get(i22)).getClass();
                            }
                        }
                    }
                    uVar.D(eVar);
                    size2 = arrayList2.size();
                    if (i9 > 0) {
                        uVar.A(eVar, 0, iQ2, iK);
                    }
                    if (size2 > 0) {
                        constraintWidget$DimensionBehaviourArr = eVar.T;
                        constraintWidget$DimensionBehaviour5 = constraintWidget$DimensionBehaviour4;
                        if (constraintWidget$DimensionBehaviourArr[0] == constraintWidget$DimensionBehaviour5) {
                            z7 = true;
                        } else {
                            z7 = false;
                        }
                        if (constraintWidget$DimensionBehaviourArr[1] == constraintWidget$DimensionBehaviour5) {
                            z8 = true;
                        } else {
                            z8 = false;
                        }
                        e eVar1110 = eVar4;
                        iMax3 = Math.max(eVar.q(), eVar1110.f4436c0);
                        iMax4 = Math.max(eVar.k(), eVar1110.f4438d0);
                        i12 = 0;
                        z9 = false;
                        while (true) {
                            constraintAnchor$Type = ConstraintAnchor$Type.f376d;
                            constraintAnchor$Type2 = ConstraintAnchor$Type.f375c;
                            if (i12 < size2) {
                                break;
                                break;
                            }
                            ArrayList arrayList111 = arrayList2;
                            dVar2 = (d) arrayList111.get(i12);
                            z13 = z7;
                            if (dVar2 instanceof v.g) {
                                z14 = z8;
                                fVar5 = fVar;
                            } else {
                                iQ5 = dVar2.q();
                                iK4 = dVar2.k();
                                z14 = z8;
                                fVar5 = fVar;
                                zW2 = z9 | uVar.w(1, dVar2, fVar5);
                                iQ6 = dVar2.q();
                                iK5 = dVar2.k();
                                if (iQ6 != iQ5) {
                                    dVar2.O(iQ6);
                                    if (z13) {
                                        iMax3 = Math.max(iMax3, dVar2.i(constraintAnchor$Type2).e() + dVar2.r() + dVar2.V);
                                    }
                                    zW2 = true;
                                }
                                if (iK5 != iK4) {
                                    dVar2.L(iK5);
                                    if (z14) {
                                        iMax4 = Math.max(iMax4, dVar2.i(constraintAnchor$Type).e() + dVar2.s() + dVar2.W);
                                    }
                                    zW2 = true;
                                }
                                z9 = zW2 | ((v.g) dVar2).f4506y0;
                            }
                            i12++;
                            z7 = z13;
                            fVar = fVar5;
                            arrayList2 = arrayList111;
                            z8 = z14;
                            i11 = i11;
                        }
                        int i412 = i11;
                        z10 = z7;
                        z11 = z8;
                        z12 = z9;
                        fVar2 = fVar;
                        arrayList3 = arrayList2;
                        i13 = 0;
                        while (i13 < 2) {
                            zW = z12;
                            i14 = 0;
                            while (i14 < size2) {
                                dVar = (d) arrayList3.get(i14);
                                if (dVar instanceof i) {
                                    i17 = size2;
                                    if (dVar.f4445h0 == 8) {
                                        i19 = i13;
                                        i18 = i14;
                                        fVar4 = fVar2;
                                    } else {
                                        iQ3 = dVar.q();
                                        iK2 = dVar.k();
                                        i18 = i14;
                                        int i413 = dVar.f4434b0;
                                        zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                        i19 = i13;
                                        iQ4 = dVar.q();
                                        fVar4 = fVar2;
                                        iK3 = dVar.k();
                                        if (iQ4 != iQ3) {
                                            dVar.O(iQ4);
                                            if (z10) {
                                                iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                            }
                                            zW = true;
                                        }
                                        if (iK3 != iK2) {
                                            dVar.L(iK3);
                                            if (z11) {
                                                iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                            }
                                            zW = true;
                                        }
                                        if (!dVar.E) {
                                        }
                                    }
                                } else {
                                    i17 = size2;
                                    if (dVar.f4445h0 == 8) {
                                        i19 = i13;
                                        i18 = i14;
                                        fVar4 = fVar2;
                                    } else {
                                        iQ3 = dVar.q();
                                        iK2 = dVar.k();
                                        i18 = i14;
                                        int i414 = dVar.f4434b0;
                                        zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                        i19 = i13;
                                        iQ4 = dVar.q();
                                        fVar4 = fVar2;
                                        iK3 = dVar.k();
                                        if (iQ4 != iQ3) {
                                            dVar.O(iQ4);
                                            if (z10) {
                                                iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                            }
                                            zW = true;
                                        }
                                        if (iK3 != iK2) {
                                            dVar.L(iK3);
                                            if (z11) {
                                                iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                            }
                                            zW = true;
                                        }
                                        if (!dVar.E) {
                                        }
                                    }
                                }
                                i14 = i18 + 1;
                                size2 = i17;
                                i13 = i19;
                                fVar2 = fVar4;
                            }
                            i15 = i13;
                            i16 = size2;
                            fVar3 = fVar2;
                            if (zW) {
                                break;
                                break;
                            }
                            i13 = i15 + 1;
                            uVar.A(eVar, i13, iQ2, iK);
                            size2 = i16;
                            fVar2 = fVar3;
                            z12 = false;
                        }
                        i11 = i412;
                    }
                    eVar.D0 = i11;
                    t.c.f3952q = eVar.W(512);
                }
            }
            i9 = size;
            z5 = z25;
            z6 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
            if (z6) {
                int iMin7 = Math.min(iArr[0], i32);
                iMin = Math.min(iArr[1], i33);
                if (mode == 1073741824) {
                    z16 = true;
                } else {
                    z16 = true;
                }
                if (mode2 == 1073741824) {
                    eVar.L(iMin);
                    eVar2.f4676b = z16;
                }
                if (mode == 1073741824) {
                    z6 = z6;
                    eVar4 = eVar3;
                    arrayList2 = arrayList;
                    fVar = fVar;
                    constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                    eVar6 = eVar2.f4675a;
                    if (eVar2.f4676b) {
                        arrayList5 = eVar6.f4471q0;
                        size5 = arrayList5.size();
                        i25 = 0;
                        while (i25 < size5) {
                            Object obj13 = arrayList5.get(i25);
                            i25++;
                            d dVar1114 = (d) obj13;
                            dVar1114.h();
                            dVar1114.f4431a = false;
                            androidx.constraintlayout.core.widgets.analyzer.d dVar1115 = dVar1114.f4437d;
                            ArrayList arrayList112 = arrayList5;
                            dVar1115.f416e.f405j = false;
                            dVar1115.f417g = false;
                            dVar1115.n();
                            androidx.constraintlayout.core.widgets.analyzer.e eVar1111 = dVar1114.f4439e;
                            eVar1111.f416e.f405j = false;
                            eVar1111.f417g = false;
                            eVar1111.m();
                            arrayList5 = arrayList112;
                        }
                        i23 = 0;
                        eVar6.h();
                        eVar6.f4431a = false;
                        androidx.constraintlayout.core.widgets.analyzer.d dVar1116 = eVar6.f4437d;
                        dVar1116.f416e.f405j = false;
                        dVar1116.f417g = false;
                        dVar1116.n();
                        androidx.constraintlayout.core.widgets.analyzer.e eVar1112 = eVar6.f4439e;
                        eVar1112.f416e.f405j = false;
                        eVar1112.f417g = false;
                        eVar1112.m();
                        eVar2.c();
                    } else {
                        i23 = 0;
                    }
                    eVar2.b(eVar2.f4678d);
                    eVar6.Z = i23;
                    eVar6.f4432a0 = i23;
                    eVar6.f4437d.f418h.d(i23);
                    eVar6.f4439e.f418h.d(i23);
                    i24 = 1073741824;
                    if (mode == 1073741824) {
                        zT2 = eVar.T(i23, zC);
                        i10 = 1;
                    } else {
                        zT2 = true;
                        i10 = 0;
                    }
                    if (mode2 == 1073741824) {
                        zT = eVar.T(1, zC) & zT2;
                        i10++;
                    } else {
                        zT = zT2;
                    }
                } else {
                    z6 = z6;
                    eVar4 = eVar3;
                    arrayList2 = arrayList;
                    fVar = fVar;
                    constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                    eVar6 = eVar2.f4675a;
                    if (eVar2.f4676b) {
                        arrayList5 = eVar6.f4471q0;
                        size5 = arrayList5.size();
                        i25 = 0;
                        while (i25 < size5) {
                            Object obj14 = arrayList5.get(i25);
                            i25++;
                            d dVar1117 = (d) obj14;
                            dVar1117.h();
                            dVar1117.f4431a = false;
                            androidx.constraintlayout.core.widgets.analyzer.d dVar1118 = dVar1117.f4437d;
                            ArrayList arrayList113 = arrayList5;
                            dVar1118.f416e.f405j = false;
                            dVar1118.f417g = false;
                            dVar1118.n();
                            androidx.constraintlayout.core.widgets.analyzer.e eVar1113 = dVar1117.f4439e;
                            eVar1113.f416e.f405j = false;
                            eVar1113.f417g = false;
                            eVar1113.m();
                            arrayList5 = arrayList113;
                        }
                        i23 = 0;
                        eVar6.h();
                        eVar6.f4431a = false;
                        androidx.constraintlayout.core.widgets.analyzer.d dVar1119 = eVar6.f4437d;
                        dVar1119.f416e.f405j = false;
                        dVar1119.f417g = false;
                        dVar1119.n();
                        androidx.constraintlayout.core.widgets.analyzer.e eVar1114 = eVar6.f4439e;
                        eVar1114.f416e.f405j = false;
                        eVar1114.f417g = false;
                        eVar1114.m();
                        eVar2.c();
                    } else {
                        i23 = 0;
                    }
                    eVar2.b(eVar2.f4678d);
                    eVar6.Z = i23;
                    eVar6.f4432a0 = i23;
                    eVar6.f4437d.f418h.d(i23);
                    eVar6.f4439e.f418h.d(i23);
                    i24 = 1073741824;
                    if (mode == 1073741824) {
                        zT2 = eVar.T(i23, zC);
                        i10 = 1;
                    } else {
                        zT2 = true;
                        i10 = 0;
                    }
                    if (mode2 == 1073741824) {
                        zT = eVar.T(1, zC) & zT2;
                        i10++;
                    } else {
                        zT = zT2;
                    }
                }
                if (zT) {
                    if (mode == i24) {
                        z17 = true;
                    } else {
                        z17 = false;
                    }
                    if (mode2 == i24) {
                        z18 = true;
                    } else {
                        z18 = false;
                    }
                    eVar.P(z17, z18);
                }
            } else {
                z6 = z6;
                eVar4 = eVar3;
                arrayList2 = arrayList;
                fVar = fVar;
                constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                zT = false;
                i10 = 0;
            }
            if (zT) {
            }
            i11 = eVar.D0;
            if (i9 > 0) {
                size3 = eVar.f4471q0.size();
                boolean zW8 = eVar.W(64);
                fVar6 = eVar.f4475u0;
                while (i20 < size3) {
                    dVar3 = (d) eVar.f4471q0.get(i20);
                    if (!(dVar3 instanceof h)) {
                        constraintWidget$DimensionBehaviourJ = dVar3.j(0);
                        constraintWidget$DimensionBehaviourJ2 = dVar3.j(1);
                        if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                            z15 = false;
                        } else {
                            z15 = false;
                        }
                        if (!z15) {
                            if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                                z15 = true;
                            }
                            if (constraintWidget$DimensionBehaviourJ2 == constraintWidget$DimensionBehaviour3) {
                                z15 = true;
                            }
                            if (constraintWidget$DimensionBehaviourJ != constraintWidget$DimensionBehaviour3) {
                            }
                        }
                        if (z15) {
                            uVar.w(0, dVar3, fVar6);
                        }
                    }
                }
                constraintLayout = fVar6.f4793a;
                childCount = constraintLayout.getChildCount();
                arrayList4 = constraintLayout.f432b;
                while (i21 < childCount) {
                    constraintLayout.getChildAt(i21);
                }
                size4 = arrayList4.size();
                if (size4 > 0) {
                    while (i22 < size4) {
                        ((c) arrayList4.get(i22)).getClass();
                    }
                }
            }
            uVar.D(eVar);
            size2 = arrayList2.size();
            if (i9 > 0) {
                uVar.A(eVar, 0, iQ2, iK);
            }
            if (size2 > 0) {
                constraintWidget$DimensionBehaviourArr = eVar.T;
                constraintWidget$DimensionBehaviour5 = constraintWidget$DimensionBehaviour4;
                if (constraintWidget$DimensionBehaviourArr[0] == constraintWidget$DimensionBehaviour5) {
                    z7 = true;
                } else {
                    z7 = false;
                }
                if (constraintWidget$DimensionBehaviourArr[1] == constraintWidget$DimensionBehaviour5) {
                    z8 = true;
                } else {
                    z8 = false;
                }
                e eVar1115 = eVar4;
                iMax3 = Math.max(eVar.q(), eVar1115.f4436c0);
                iMax4 = Math.max(eVar.k(), eVar1115.f4438d0);
                i12 = 0;
                z9 = false;
                while (true) {
                    constraintAnchor$Type = ConstraintAnchor$Type.f376d;
                    constraintAnchor$Type2 = ConstraintAnchor$Type.f375c;
                    if (i12 < size2) {
                        break;
                        break;
                    }
                    ArrayList arrayList114 = arrayList2;
                    dVar2 = (d) arrayList114.get(i12);
                    z13 = z7;
                    if (dVar2 instanceof v.g) {
                        z14 = z8;
                        fVar5 = fVar;
                    } else {
                        iQ5 = dVar2.q();
                        iK4 = dVar2.k();
                        z14 = z8;
                        fVar5 = fVar;
                        zW2 = z9 | uVar.w(1, dVar2, fVar5);
                        iQ6 = dVar2.q();
                        iK5 = dVar2.k();
                        if (iQ6 != iQ5) {
                            dVar2.O(iQ6);
                            if (z13) {
                                iMax3 = Math.max(iMax3, dVar2.i(constraintAnchor$Type2).e() + dVar2.r() + dVar2.V);
                            }
                            zW2 = true;
                        }
                        if (iK5 != iK4) {
                            dVar2.L(iK5);
                            if (z14) {
                                iMax4 = Math.max(iMax4, dVar2.i(constraintAnchor$Type).e() + dVar2.s() + dVar2.W);
                            }
                            zW2 = true;
                        }
                        z9 = zW2 | ((v.g) dVar2).f4506y0;
                    }
                    i12++;
                    z7 = z13;
                    fVar = fVar5;
                    arrayList2 = arrayList114;
                    z8 = z14;
                    i11 = i11;
                }
                int i415 = i11;
                z10 = z7;
                z11 = z8;
                z12 = z9;
                fVar2 = fVar;
                arrayList3 = arrayList2;
                i13 = 0;
                while (i13 < 2) {
                    zW = z12;
                    i14 = 0;
                    while (i14 < size2) {
                        dVar = (d) arrayList3.get(i14);
                        if (dVar instanceof i) {
                            i17 = size2;
                            if (dVar.f4445h0 == 8) {
                                i19 = i13;
                                i18 = i14;
                                fVar4 = fVar2;
                            } else {
                                iQ3 = dVar.q();
                                iK2 = dVar.k();
                                i18 = i14;
                                int i416 = dVar.f4434b0;
                                zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                i19 = i13;
                                iQ4 = dVar.q();
                                fVar4 = fVar2;
                                iK3 = dVar.k();
                                if (iQ4 != iQ3) {
                                    dVar.O(iQ4);
                                    if (z10) {
                                        iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                    }
                                    zW = true;
                                }
                                if (iK3 != iK2) {
                                    dVar.L(iK3);
                                    if (z11) {
                                        iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                    }
                                    zW = true;
                                }
                                if (!dVar.E) {
                                }
                            }
                        } else {
                            i17 = size2;
                            if (dVar.f4445h0 == 8) {
                                i19 = i13;
                                i18 = i14;
                                fVar4 = fVar2;
                            } else {
                                iQ3 = dVar.q();
                                iK2 = dVar.k();
                                i18 = i14;
                                int i417 = dVar.f4434b0;
                                zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                i19 = i13;
                                iQ4 = dVar.q();
                                fVar4 = fVar2;
                                iK3 = dVar.k();
                                if (iQ4 != iQ3) {
                                    dVar.O(iQ4);
                                    if (z10) {
                                        iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                    }
                                    zW = true;
                                }
                                if (iK3 != iK2) {
                                    dVar.L(iK3);
                                    if (z11) {
                                        iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                    }
                                    zW = true;
                                }
                                if (!dVar.E) {
                                }
                            }
                        }
                        i14 = i18 + 1;
                        size2 = i17;
                        i13 = i19;
                        fVar2 = fVar4;
                    }
                    i15 = i13;
                    i16 = size2;
                    fVar3 = fVar2;
                    if (zW) {
                        break;
                        break;
                    }
                    i13 = i15 + 1;
                    uVar.A(eVar, i13, iQ2, iK);
                    size2 = i16;
                    fVar2 = fVar3;
                    z12 = false;
                }
                i11 = i415;
            }
            eVar.D0 = i11;
            t.c.f3952q = eVar.W(512);
        }
        if (childCount2 == 0) {
            iMax2 = Math.max(0, this.f435e);
        } else {
            iMax2 = i33;
        }
        constraintWidget$DimensionBehaviour2 = constraintWidget$DimensionBehaviour8;
        iQ = eVar.q();
        eVar2 = eVar.f4473s0;
        iArr = eVar.C;
        if (iMax == iQ) {
            eVar2.f4677c = true;
        } else {
            eVar2.f4677c = true;
        }
        eVar.Z = 0;
        eVar.f4432a0 = 0;
        iArr[0] = this.f - i35;
        iArr[1] = this.f436g - i34;
        eVar.f4436c0 = 0;
        eVar.f4438d0 = 0;
        eVar.M(constraintWidget$DimensionBehaviour);
        eVar.O(iMax);
        eVar.N(constraintWidget$DimensionBehaviour2);
        eVar.L(iMax2);
        i7 = this.f434d - i35;
        if (i7 < 0) {
            eVar.f4436c0 = 0;
        } else {
            eVar.f4436c0 = i7;
        }
        i8 = this.f435e - i34;
        if (i8 < 0) {
            eVar.f4438d0 = 0;
        } else {
            eVar.f4438d0 = i8;
        }
        eVar.f4478x0 = iMax7;
        eVar.f4479y0 = iMax5;
        uVar = eVar.f4472r0;
        eVar3 = (e) uVar.f564d;
        arrayList = (ArrayList) uVar.f562b;
        fVar = eVar.f4475u0;
        size = eVar.f4471q0.size();
        iQ2 = eVar.q();
        iK = eVar.k();
        zC = j.c(i3, 128);
        if (zC) {
            z4 = true;
        } else {
            z4 = true;
        }
        constraintWidget$DimensionBehaviour3 = ConstraintWidget$DimensionBehaviour.f383c;
        boolean z26 = z4;
        if (z4) {
            i29 = 0;
            while (true) {
                i9 = size;
                if (i29 < size) {
                    dVar5 = (d) eVar.f4471q0.get(i29);
                    i30 = i29;
                    constraintWidget$DimensionBehaviourArr2 = dVar5.T;
                    if (constraintWidget$DimensionBehaviourArr2[0] == constraintWidget$DimensionBehaviour3) {
                        z20 = true;
                    } else {
                        z20 = false;
                    }
                    if (constraintWidget$DimensionBehaviourArr2[1] == constraintWidget$DimensionBehaviour3) {
                        z21 = true;
                    } else {
                        z21 = false;
                    }
                    if (z20) {
                        z22 = false;
                    } else {
                        z22 = false;
                    }
                    if (dVar5.x()) {
                        i29 = i30 + 1;
                        size = i9;
                    } else {
                        i29 = i30 + 1;
                        size = i9;
                    }
                    z5 = false;
                }
                z6 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
                if (z6) {
                    int iMin8 = Math.min(iArr[0], i32);
                    iMin = Math.min(iArr[1], i33);
                    if (mode == 1073741824) {
                        z16 = true;
                    } else {
                        z16 = true;
                    }
                    if (mode2 == 1073741824) {
                        eVar.L(iMin);
                        eVar2.f4676b = z16;
                    }
                    if (mode == 1073741824) {
                        z6 = z6;
                        eVar4 = eVar3;
                        arrayList2 = arrayList;
                        fVar = fVar;
                        constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                        eVar6 = eVar2.f4675a;
                        if (eVar2.f4676b) {
                            arrayList5 = eVar6.f4471q0;
                            size5 = arrayList5.size();
                            i25 = 0;
                            while (i25 < size5) {
                                Object obj15 = arrayList5.get(i25);
                                i25++;
                                d dVar11110 = (d) obj15;
                                dVar11110.h();
                                dVar11110.f4431a = false;
                                androidx.constraintlayout.core.widgets.analyzer.d dVar11111 = dVar11110.f4437d;
                                ArrayList arrayList115 = arrayList5;
                                dVar11111.f416e.f405j = false;
                                dVar11111.f417g = false;
                                dVar11111.n();
                                androidx.constraintlayout.core.widgets.analyzer.e eVar1116 = dVar11110.f4439e;
                                eVar1116.f416e.f405j = false;
                                eVar1116.f417g = false;
                                eVar1116.m();
                                arrayList5 = arrayList115;
                            }
                            i23 = 0;
                            eVar6.h();
                            eVar6.f4431a = false;
                            androidx.constraintlayout.core.widgets.analyzer.d dVar11112 = eVar6.f4437d;
                            dVar11112.f416e.f405j = false;
                            dVar11112.f417g = false;
                            dVar11112.n();
                            androidx.constraintlayout.core.widgets.analyzer.e eVar1117 = eVar6.f4439e;
                            eVar1117.f416e.f405j = false;
                            eVar1117.f417g = false;
                            eVar1117.m();
                            eVar2.c();
                        } else {
                            i23 = 0;
                        }
                        eVar2.b(eVar2.f4678d);
                        eVar6.Z = i23;
                        eVar6.f4432a0 = i23;
                        eVar6.f4437d.f418h.d(i23);
                        eVar6.f4439e.f418h.d(i23);
                        i24 = 1073741824;
                        if (mode == 1073741824) {
                            zT2 = eVar.T(i23, zC);
                            i10 = 1;
                        } else {
                            zT2 = true;
                            i10 = 0;
                        }
                        if (mode2 == 1073741824) {
                            zT = eVar.T(1, zC) & zT2;
                            i10++;
                        } else {
                            zT = zT2;
                        }
                    } else {
                        z6 = z6;
                        eVar4 = eVar3;
                        arrayList2 = arrayList;
                        fVar = fVar;
                        constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                        eVar6 = eVar2.f4675a;
                        if (eVar2.f4676b) {
                            arrayList5 = eVar6.f4471q0;
                            size5 = arrayList5.size();
                            i25 = 0;
                            while (i25 < size5) {
                                Object obj16 = arrayList5.get(i25);
                                i25++;
                                d dVar11113 = (d) obj16;
                                dVar11113.h();
                                dVar11113.f4431a = false;
                                androidx.constraintlayout.core.widgets.analyzer.d dVar11114 = dVar11113.f4437d;
                                ArrayList arrayList116 = arrayList5;
                                dVar11114.f416e.f405j = false;
                                dVar11114.f417g = false;
                                dVar11114.n();
                                androidx.constraintlayout.core.widgets.analyzer.e eVar1118 = dVar11113.f4439e;
                                eVar1118.f416e.f405j = false;
                                eVar1118.f417g = false;
                                eVar1118.m();
                                arrayList5 = arrayList116;
                            }
                            i23 = 0;
                            eVar6.h();
                            eVar6.f4431a = false;
                            androidx.constraintlayout.core.widgets.analyzer.d dVar11115 = eVar6.f4437d;
                            dVar11115.f416e.f405j = false;
                            dVar11115.f417g = false;
                            dVar11115.n();
                            androidx.constraintlayout.core.widgets.analyzer.e eVar1119 = eVar6.f4439e;
                            eVar1119.f416e.f405j = false;
                            eVar1119.f417g = false;
                            eVar1119.m();
                            eVar2.c();
                        } else {
                            i23 = 0;
                        }
                        eVar2.b(eVar2.f4678d);
                        eVar6.Z = i23;
                        eVar6.f4432a0 = i23;
                        eVar6.f4437d.f418h.d(i23);
                        eVar6.f4439e.f418h.d(i23);
                        i24 = 1073741824;
                        if (mode == 1073741824) {
                            zT2 = eVar.T(i23, zC);
                            i10 = 1;
                        } else {
                            zT2 = true;
                            i10 = 0;
                        }
                        if (mode2 == 1073741824) {
                            zT = eVar.T(1, zC) & zT2;
                            i10++;
                        } else {
                            zT = zT2;
                        }
                    }
                    if (zT) {
                        if (mode == i24) {
                            z17 = true;
                        } else {
                            z17 = false;
                        }
                        if (mode2 == i24) {
                            z18 = true;
                        } else {
                            z18 = false;
                        }
                        eVar.P(z17, z18);
                    }
                } else {
                    z6 = z6;
                    eVar4 = eVar3;
                    arrayList2 = arrayList;
                    fVar = fVar;
                    constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                    zT = false;
                    i10 = 0;
                }
                if (zT) {
                }
                i11 = eVar.D0;
                if (i9 > 0) {
                    size3 = eVar.f4471q0.size();
                    boolean zW9 = eVar.W(64);
                    fVar6 = eVar.f4475u0;
                    while (i20 < size3) {
                        dVar3 = (d) eVar.f4471q0.get(i20);
                        if (!(dVar3 instanceof h)) {
                            constraintWidget$DimensionBehaviourJ = dVar3.j(0);
                            constraintWidget$DimensionBehaviourJ2 = dVar3.j(1);
                            if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                                z15 = false;
                            } else {
                                z15 = false;
                            }
                            if (!z15) {
                                if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                                    z15 = true;
                                }
                                if (constraintWidget$DimensionBehaviourJ2 == constraintWidget$DimensionBehaviour3) {
                                    z15 = true;
                                }
                                if (constraintWidget$DimensionBehaviourJ != constraintWidget$DimensionBehaviour3) {
                                }
                            }
                            if (z15) {
                                uVar.w(0, dVar3, fVar6);
                            }
                        }
                    }
                    constraintLayout = fVar6.f4793a;
                    childCount = constraintLayout.getChildCount();
                    arrayList4 = constraintLayout.f432b;
                    while (i21 < childCount) {
                        constraintLayout.getChildAt(i21);
                    }
                    size4 = arrayList4.size();
                    if (size4 > 0) {
                        while (i22 < size4) {
                            ((c) arrayList4.get(i22)).getClass();
                        }
                    }
                }
                uVar.D(eVar);
                size2 = arrayList2.size();
                if (i9 > 0) {
                    uVar.A(eVar, 0, iQ2, iK);
                }
                if (size2 > 0) {
                    constraintWidget$DimensionBehaviourArr = eVar.T;
                    constraintWidget$DimensionBehaviour5 = constraintWidget$DimensionBehaviour4;
                    if (constraintWidget$DimensionBehaviourArr[0] == constraintWidget$DimensionBehaviour5) {
                        z7 = true;
                    } else {
                        z7 = false;
                    }
                    if (constraintWidget$DimensionBehaviourArr[1] == constraintWidget$DimensionBehaviour5) {
                        z8 = true;
                    } else {
                        z8 = false;
                    }
                    e eVar11110 = eVar4;
                    iMax3 = Math.max(eVar.q(), eVar11110.f4436c0);
                    iMax4 = Math.max(eVar.k(), eVar11110.f4438d0);
                    i12 = 0;
                    z9 = false;
                    while (true) {
                        constraintAnchor$Type = ConstraintAnchor$Type.f376d;
                        constraintAnchor$Type2 = ConstraintAnchor$Type.f375c;
                        if (i12 < size2) {
                            break;
                            break;
                        }
                        ArrayList arrayList117 = arrayList2;
                        dVar2 = (d) arrayList117.get(i12);
                        z13 = z7;
                        if (dVar2 instanceof v.g) {
                            z14 = z8;
                            fVar5 = fVar;
                        } else {
                            iQ5 = dVar2.q();
                            iK4 = dVar2.k();
                            z14 = z8;
                            fVar5 = fVar;
                            zW2 = z9 | uVar.w(1, dVar2, fVar5);
                            iQ6 = dVar2.q();
                            iK5 = dVar2.k();
                            if (iQ6 != iQ5) {
                                dVar2.O(iQ6);
                                if (z13) {
                                    iMax3 = Math.max(iMax3, dVar2.i(constraintAnchor$Type2).e() + dVar2.r() + dVar2.V);
                                }
                                zW2 = true;
                            }
                            if (iK5 != iK4) {
                                dVar2.L(iK5);
                                if (z14) {
                                    iMax4 = Math.max(iMax4, dVar2.i(constraintAnchor$Type).e() + dVar2.s() + dVar2.W);
                                }
                                zW2 = true;
                            }
                            z9 = zW2 | ((v.g) dVar2).f4506y0;
                        }
                        i12++;
                        z7 = z13;
                        fVar = fVar5;
                        arrayList2 = arrayList117;
                        z8 = z14;
                        i11 = i11;
                    }
                    int i418 = i11;
                    z10 = z7;
                    z11 = z8;
                    z12 = z9;
                    fVar2 = fVar;
                    arrayList3 = arrayList2;
                    i13 = 0;
                    while (i13 < 2) {
                        zW = z12;
                        i14 = 0;
                        while (i14 < size2) {
                            dVar = (d) arrayList3.get(i14);
                            if (dVar instanceof i) {
                                i17 = size2;
                                if (dVar.f4445h0 == 8) {
                                    i19 = i13;
                                    i18 = i14;
                                    fVar4 = fVar2;
                                } else {
                                    iQ3 = dVar.q();
                                    iK2 = dVar.k();
                                    i18 = i14;
                                    int i419 = dVar.f4434b0;
                                    zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                    i19 = i13;
                                    iQ4 = dVar.q();
                                    fVar4 = fVar2;
                                    iK3 = dVar.k();
                                    if (iQ4 != iQ3) {
                                        dVar.O(iQ4);
                                        if (z10) {
                                            iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                        }
                                        zW = true;
                                    }
                                    if (iK3 != iK2) {
                                        dVar.L(iK3);
                                        if (z11) {
                                            iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                        }
                                        zW = true;
                                    }
                                    if (!dVar.E) {
                                    }
                                }
                            } else {
                                i17 = size2;
                                if (dVar.f4445h0 == 8) {
                                    i19 = i13;
                                    i18 = i14;
                                    fVar4 = fVar2;
                                } else {
                                    iQ3 = dVar.q();
                                    iK2 = dVar.k();
                                    i18 = i14;
                                    int i4110 = dVar.f4434b0;
                                    zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                                    i19 = i13;
                                    iQ4 = dVar.q();
                                    fVar4 = fVar2;
                                    iK3 = dVar.k();
                                    if (iQ4 != iQ3) {
                                        dVar.O(iQ4);
                                        if (z10) {
                                            iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                        }
                                        zW = true;
                                    }
                                    if (iK3 != iK2) {
                                        dVar.L(iK3);
                                        if (z11) {
                                            iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                        }
                                        zW = true;
                                    }
                                    if (!dVar.E) {
                                    }
                                }
                            }
                            i14 = i18 + 1;
                            size2 = i17;
                            i13 = i19;
                            fVar2 = fVar4;
                        }
                        i15 = i13;
                        i16 = size2;
                        fVar3 = fVar2;
                        if (zW) {
                            break;
                            break;
                        }
                        i13 = i15 + 1;
                        uVar.A(eVar, i13, iQ2, iK);
                        size2 = i16;
                        fVar2 = fVar3;
                        z12 = false;
                    }
                    i11 = i418;
                }
                eVar.D0 = i11;
                t.c.f3952q = eVar.W(512);
            }
        }
        i9 = size;
        z5 = z26;
        z6 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
        if (z6) {
            int iMin9 = Math.min(iArr[0], i32);
            iMin = Math.min(iArr[1], i33);
            if (mode == 1073741824) {
                z16 = true;
            } else {
                z16 = true;
            }
            if (mode2 == 1073741824) {
                eVar.L(iMin);
                eVar2.f4676b = z16;
            }
            if (mode == 1073741824) {
                z6 = z6;
                eVar4 = eVar3;
                arrayList2 = arrayList;
                fVar = fVar;
                constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                eVar6 = eVar2.f4675a;
                if (eVar2.f4676b) {
                    arrayList5 = eVar6.f4471q0;
                    size5 = arrayList5.size();
                    i25 = 0;
                    while (i25 < size5) {
                        Object obj17 = arrayList5.get(i25);
                        i25++;
                        d dVar11116 = (d) obj17;
                        dVar11116.h();
                        dVar11116.f4431a = false;
                        androidx.constraintlayout.core.widgets.analyzer.d dVar11117 = dVar11116.f4437d;
                        ArrayList arrayList118 = arrayList5;
                        dVar11117.f416e.f405j = false;
                        dVar11117.f417g = false;
                        dVar11117.n();
                        androidx.constraintlayout.core.widgets.analyzer.e eVar11111 = dVar11116.f4439e;
                        eVar11111.f416e.f405j = false;
                        eVar11111.f417g = false;
                        eVar11111.m();
                        arrayList5 = arrayList118;
                    }
                    i23 = 0;
                    eVar6.h();
                    eVar6.f4431a = false;
                    androidx.constraintlayout.core.widgets.analyzer.d dVar11118 = eVar6.f4437d;
                    dVar11118.f416e.f405j = false;
                    dVar11118.f417g = false;
                    dVar11118.n();
                    androidx.constraintlayout.core.widgets.analyzer.e eVar11112 = eVar6.f4439e;
                    eVar11112.f416e.f405j = false;
                    eVar11112.f417g = false;
                    eVar11112.m();
                    eVar2.c();
                } else {
                    i23 = 0;
                }
                eVar2.b(eVar2.f4678d);
                eVar6.Z = i23;
                eVar6.f4432a0 = i23;
                eVar6.f4437d.f418h.d(i23);
                eVar6.f4439e.f418h.d(i23);
                i24 = 1073741824;
                if (mode == 1073741824) {
                    zT2 = eVar.T(i23, zC);
                    i10 = 1;
                } else {
                    zT2 = true;
                    i10 = 0;
                }
                if (mode2 == 1073741824) {
                    zT = eVar.T(1, zC) & zT2;
                    i10++;
                } else {
                    zT = zT2;
                }
            } else {
                z6 = z6;
                eVar4 = eVar3;
                arrayList2 = arrayList;
                fVar = fVar;
                constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
                eVar6 = eVar2.f4675a;
                if (eVar2.f4676b) {
                    arrayList5 = eVar6.f4471q0;
                    size5 = arrayList5.size();
                    i25 = 0;
                    while (i25 < size5) {
                        Object obj18 = arrayList5.get(i25);
                        i25++;
                        d dVar11119 = (d) obj18;
                        dVar11119.h();
                        dVar11119.f4431a = false;
                        androidx.constraintlayout.core.widgets.analyzer.d dVar111110 = dVar11119.f4437d;
                        ArrayList arrayList119 = arrayList5;
                        dVar111110.f416e.f405j = false;
                        dVar111110.f417g = false;
                        dVar111110.n();
                        androidx.constraintlayout.core.widgets.analyzer.e eVar11113 = dVar11119.f4439e;
                        eVar11113.f416e.f405j = false;
                        eVar11113.f417g = false;
                        eVar11113.m();
                        arrayList5 = arrayList119;
                    }
                    i23 = 0;
                    eVar6.h();
                    eVar6.f4431a = false;
                    androidx.constraintlayout.core.widgets.analyzer.d dVar111111 = eVar6.f4437d;
                    dVar111111.f416e.f405j = false;
                    dVar111111.f417g = false;
                    dVar111111.n();
                    androidx.constraintlayout.core.widgets.analyzer.e eVar11114 = eVar6.f4439e;
                    eVar11114.f416e.f405j = false;
                    eVar11114.f417g = false;
                    eVar11114.m();
                    eVar2.c();
                } else {
                    i23 = 0;
                }
                eVar2.b(eVar2.f4678d);
                eVar6.Z = i23;
                eVar6.f4432a0 = i23;
                eVar6.f4437d.f418h.d(i23);
                eVar6.f4439e.f418h.d(i23);
                i24 = 1073741824;
                if (mode == 1073741824) {
                    zT2 = eVar.T(i23, zC);
                    i10 = 1;
                } else {
                    zT2 = true;
                    i10 = 0;
                }
                if (mode2 == 1073741824) {
                    zT = eVar.T(1, zC) & zT2;
                    i10++;
                } else {
                    zT = zT2;
                }
            }
            if (zT) {
                if (mode == i24) {
                    z17 = true;
                } else {
                    z17 = false;
                }
                if (mode2 == i24) {
                    z18 = true;
                } else {
                    z18 = false;
                }
                eVar.P(z17, z18);
            }
        } else {
            z6 = z6;
            eVar4 = eVar3;
            arrayList2 = arrayList;
            fVar = fVar;
            constraintWidget$DimensionBehaviour4 = constraintWidget$DimensionBehaviour8;
            zT = false;
            i10 = 0;
        }
        if (zT) {
        }
        i11 = eVar.D0;
        if (i9 > 0) {
            size3 = eVar.f4471q0.size();
            boolean zW10 = eVar.W(64);
            fVar6 = eVar.f4475u0;
            while (i20 < size3) {
                dVar3 = (d) eVar.f4471q0.get(i20);
                if (!(dVar3 instanceof h)) {
                    constraintWidget$DimensionBehaviourJ = dVar3.j(0);
                    constraintWidget$DimensionBehaviourJ2 = dVar3.j(1);
                    if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                        z15 = false;
                    } else {
                        z15 = false;
                    }
                    if (!z15) {
                        if (constraintWidget$DimensionBehaviourJ == constraintWidget$DimensionBehaviour3) {
                            z15 = true;
                        }
                        if (constraintWidget$DimensionBehaviourJ2 == constraintWidget$DimensionBehaviour3) {
                            z15 = true;
                        }
                        if (constraintWidget$DimensionBehaviourJ != constraintWidget$DimensionBehaviour3) {
                        }
                    }
                    if (z15) {
                        uVar.w(0, dVar3, fVar6);
                    }
                }
            }
            constraintLayout = fVar6.f4793a;
            childCount = constraintLayout.getChildCount();
            arrayList4 = constraintLayout.f432b;
            while (i21 < childCount) {
                constraintLayout.getChildAt(i21);
            }
            size4 = arrayList4.size();
            if (size4 > 0) {
                while (i22 < size4) {
                    ((c) arrayList4.get(i22)).getClass();
                }
            }
        }
        uVar.D(eVar);
        size2 = arrayList2.size();
        if (i9 > 0) {
            uVar.A(eVar, 0, iQ2, iK);
        }
        if (size2 > 0) {
            constraintWidget$DimensionBehaviourArr = eVar.T;
            constraintWidget$DimensionBehaviour5 = constraintWidget$DimensionBehaviour4;
            if (constraintWidget$DimensionBehaviourArr[0] == constraintWidget$DimensionBehaviour5) {
                z7 = true;
            } else {
                z7 = false;
            }
            if (constraintWidget$DimensionBehaviourArr[1] == constraintWidget$DimensionBehaviour5) {
                z8 = true;
            } else {
                z8 = false;
            }
            e eVar11115 = eVar4;
            iMax3 = Math.max(eVar.q(), eVar11115.f4436c0);
            iMax4 = Math.max(eVar.k(), eVar11115.f4438d0);
            i12 = 0;
            z9 = false;
            while (true) {
                constraintAnchor$Type = ConstraintAnchor$Type.f376d;
                constraintAnchor$Type2 = ConstraintAnchor$Type.f375c;
                if (i12 < size2) {
                    break;
                    break;
                }
                ArrayList arrayList1110 = arrayList2;
                dVar2 = (d) arrayList1110.get(i12);
                z13 = z7;
                if (dVar2 instanceof v.g) {
                    z14 = z8;
                    fVar5 = fVar;
                } else {
                    iQ5 = dVar2.q();
                    iK4 = dVar2.k();
                    z14 = z8;
                    fVar5 = fVar;
                    zW2 = z9 | uVar.w(1, dVar2, fVar5);
                    iQ6 = dVar2.q();
                    iK5 = dVar2.k();
                    if (iQ6 != iQ5) {
                        dVar2.O(iQ6);
                        if (z13) {
                            iMax3 = Math.max(iMax3, dVar2.i(constraintAnchor$Type2).e() + dVar2.r() + dVar2.V);
                        }
                        zW2 = true;
                    }
                    if (iK5 != iK4) {
                        dVar2.L(iK5);
                        if (z14) {
                            iMax4 = Math.max(iMax4, dVar2.i(constraintAnchor$Type).e() + dVar2.s() + dVar2.W);
                        }
                        zW2 = true;
                    }
                    z9 = zW2 | ((v.g) dVar2).f4506y0;
                }
                i12++;
                z7 = z13;
                fVar = fVar5;
                arrayList2 = arrayList1110;
                z8 = z14;
                i11 = i11;
            }
            int i4111 = i11;
            z10 = z7;
            z11 = z8;
            z12 = z9;
            fVar2 = fVar;
            arrayList3 = arrayList2;
            i13 = 0;
            while (i13 < 2) {
                zW = z12;
                i14 = 0;
                while (i14 < size2) {
                    dVar = (d) arrayList3.get(i14);
                    if (dVar instanceof i) {
                        i17 = size2;
                        if (dVar.f4445h0 == 8) {
                            i19 = i13;
                            i18 = i14;
                            fVar4 = fVar2;
                        } else {
                            iQ3 = dVar.q();
                            iK2 = dVar.k();
                            i18 = i14;
                            int i4112 = dVar.f4434b0;
                            zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                            i19 = i13;
                            iQ4 = dVar.q();
                            fVar4 = fVar2;
                            iK3 = dVar.k();
                            if (iQ4 != iQ3) {
                                dVar.O(iQ4);
                                if (z10) {
                                    iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                }
                                zW = true;
                            }
                            if (iK3 != iK2) {
                                dVar.L(iK3);
                                if (z11) {
                                    iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                }
                                zW = true;
                            }
                            if (!dVar.E) {
                            }
                        }
                    } else {
                        i17 = size2;
                        if (dVar.f4445h0 == 8) {
                            i19 = i13;
                            i18 = i14;
                            fVar4 = fVar2;
                        } else {
                            iQ3 = dVar.q();
                            iK2 = dVar.k();
                            i18 = i14;
                            int i4113 = dVar.f4434b0;
                            zW |= uVar.w(i13 == 1 ? 2 : 1, dVar, fVar2);
                            i19 = i13;
                            iQ4 = dVar.q();
                            fVar4 = fVar2;
                            iK3 = dVar.k();
                            if (iQ4 != iQ3) {
                                dVar.O(iQ4);
                                if (z10) {
                                    iMax3 = Math.max(iMax3, dVar.i(constraintAnchor$Type2).e() + dVar.r() + dVar.V);
                                }
                                zW = true;
                            }
                            if (iK3 != iK2) {
                                dVar.L(iK3);
                                if (z11) {
                                    iMax4 = Math.max(iMax4, dVar.i(constraintAnchor$Type).e() + dVar.s() + dVar.W);
                                }
                                zW = true;
                            }
                            if (!dVar.E) {
                            }
                        }
                    }
                    i14 = i18 + 1;
                    size2 = i17;
                    i13 = i19;
                    fVar2 = fVar4;
                }
                i15 = i13;
                i16 = size2;
                fVar3 = fVar2;
                if (zW) {
                    break;
                    break;
                }
                i13 = i15 + 1;
                uVar.A(eVar, i13, iQ2, iK);
                size2 = i16;
                fVar2 = fVar3;
                z12 = false;
            }
            i11 = i4111;
        }
        eVar.D0 = i11;
        t.c.f3952q = eVar.W(512);
    }

    public final void l(d dVar, y.e eVar, SparseArray sparseArray, int i3, ConstraintAnchor$Type constraintAnchor$Type) {
        View view = (View) this.f431a.get(i3);
        d dVar2 = (d) sparseArray.get(i3);
        if (dVar2 == null || view == null || !(view.getLayoutParams() instanceof y.e)) {
            return;
        }
        eVar.f4758c0 = true;
        ConstraintAnchor$Type constraintAnchor$Type2 = ConstraintAnchor$Type.f377e;
        if (constraintAnchor$Type == constraintAnchor$Type2) {
            y.e eVar2 = (y.e) view.getLayoutParams();
            eVar2.f4758c0 = true;
            eVar2.f4782p0.E = true;
        }
        dVar.i(constraintAnchor$Type2).b(dVar2.i(constraintAnchor$Type), eVar.D, eVar.C, true);
        dVar.E = true;
        dVar.i(ConstraintAnchor$Type.f374b).j();
        dVar.i(ConstraintAnchor$Type.f376d).j();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        int childCount = getChildCount();
        boolean zIsInEditMode = isInEditMode();
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            y.e eVar = (y.e) childAt.getLayoutParams();
            d dVar = eVar.f4782p0;
            if (childAt.getVisibility() != 8 || eVar.f4760d0 || eVar.f4762e0 || zIsInEditMode) {
                int iR = dVar.r();
                int iS = dVar.s();
                childAt.layout(iR, iS, dVar.q() + iR, dVar.k() + iS);
            }
        }
        ArrayList arrayList = this.f432b;
        int size = arrayList.size();
        if (size > 0) {
            for (int i8 = 0; i8 < size; i8++) {
                ((c) arrayList.get(i8)).getClass();
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:114:0x01d5  */
    /* JADX WARN: Code duplicated, block: B:166:0x0337  */
    /* JADX WARN: Code duplicated, block: B:168:0x0341  */
    /* JADX WARN: Code duplicated, block: B:171:0x034f  */
    /* JADX WARN: Code duplicated, block: B:178:0x036d  */
    /* JADX WARN: Code duplicated, block: B:180:0x0377  */
    /* JADX WARN: Code duplicated, block: B:181:0x0387  */
    /* JADX WARN: Code duplicated, block: B:183:0x038f  */
    /* JADX WARN: Code duplicated, block: B:188:0x03b2  */
    /* JADX WARN: Code duplicated, block: B:191:0x03ba  */
    /* JADX WARN: Code duplicated, block: B:193:0x03c4  */
    /* JADX WARN: Code duplicated, block: B:194:0x03d4  */
    /* JADX WARN: Code duplicated, block: B:196:0x03d7  */
    /* JADX WARN: Code duplicated, block: B:203:0x03f9  */
    /* JADX WARN: Code duplicated, block: B:205:0x0405  */
    /* JADX WARN: Code duplicated, block: B:207:0x0409  */
    /* JADX WARN: Code duplicated, block: B:208:0x0412  */
    /* JADX WARN: Code duplicated, block: B:210:0x041c  */
    /* JADX WARN: Code duplicated, block: B:213:0x0423  */
    /* JADX WARN: Code duplicated, block: B:216:0x042b  */
    /* JADX WARN: Code duplicated, block: B:289:0x055a  */
    @Override // android.view.View
    public void onMeasure(int i3, int i4) {
        boolean z4;
        int i5;
        boolean z5;
        d dVar;
        ConstraintAnchor$Type constraintAnchor$Type;
        d dVar2;
        ConstraintAnchor$Type constraintAnchor$Type2;
        ConstraintAnchor$Type constraintAnchor$Type3;
        ConstraintAnchor$Type constraintAnchor$Type4;
        d dVar3;
        ConstraintAnchor$Type constraintAnchor$Type5;
        int i6;
        int i7;
        int i8;
        ConstraintAnchor$Type constraintAnchor$Type6;
        ConstraintAnchor$Type constraintAnchor$Type7;
        d dVar4;
        int i9;
        ConstraintAnchor$Type constraintAnchor$Type8;
        int i10;
        d dVar5;
        y.e eVar;
        int i11;
        int i12;
        int i13;
        d dVar6;
        ConstraintAnchor$Type constraintAnchor$Type9;
        float f;
        d dVar7;
        d dVar8;
        ConstraintAnchor$Type constraintAnchor$Type10;
        d dVar9;
        SparseArray sparseArray;
        boolean z6;
        int i14;
        int i15;
        int i16;
        float fAbs;
        int i17;
        SparseArray sparseArray2;
        ArrayList arrayList;
        String str;
        int iF;
        d dVar10;
        ConstraintLayout constraintLayout = this;
        boolean z7 = constraintLayout.f437h;
        constraintLayout.f437h = z7;
        int i18 = 0;
        if (!z7) {
            int childCount = constraintLayout.getChildCount();
            for (int i19 = 0; i19 < childCount; i19++) {
                if (constraintLayout.getChildAt(i19).isLayoutRequested()) {
                    constraintLayout.f437h = true;
                    break;
                }
            }
        }
        boolean z8 = (constraintLayout.getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == constraintLayout.getLayoutDirection();
        e eVar2 = constraintLayout.f433c;
        eVar2.f4476v0 = z8;
        if (constraintLayout.f437h) {
            constraintLayout.f437h = false;
            int childCount2 = constraintLayout.getChildCount();
            int i20 = 0;
            while (true) {
                if (i20 >= childCount2) {
                    z4 = false;
                    break;
                } else {
                    if (constraintLayout.getChildAt(i20).isLayoutRequested()) {
                        z4 = true;
                        break;
                    }
                    i20++;
                }
            }
            if (z4) {
                boolean zIsInEditMode = constraintLayout.isInEditMode();
                int childCount3 = constraintLayout.getChildCount();
                for (int i21 = 0; i21 < childCount3; i21++) {
                    d dVarH = constraintLayout.h(constraintLayout.getChildAt(i21));
                    if (dVarH != null) {
                        dVarH.C();
                    }
                }
                SparseArray sparseArray3 = constraintLayout.f431a;
                if (zIsInEditMode) {
                    for (int i22 = 0; i22 < childCount3; i22++) {
                        View childAt = constraintLayout.getChildAt(i22);
                        try {
                            String resourceName = constraintLayout.getResources().getResourceName(childAt.getId());
                            Integer numValueOf = Integer.valueOf(childAt.getId());
                            if (resourceName != null) {
                                try {
                                    if (constraintLayout.f442m == null) {
                                        constraintLayout.f442m = new HashMap();
                                    }
                                    int iIndexOf = resourceName.indexOf("/");
                                    constraintLayout.f442m.put(iIndexOf != -1 ? resourceName.substring(iIndexOf + 1) : resourceName, numValueOf);
                                } catch (Resources.NotFoundException unused) {
                                }
                            }
                            int iIndexOf2 = resourceName.indexOf(47);
                            if (iIndexOf2 != -1) {
                                resourceName = resourceName.substring(iIndexOf2 + 1);
                            }
                            int id = childAt.getId();
                            if (id != 0) {
                                View viewFindViewById = (View) sparseArray3.get(id);
                                if (viewFindViewById == null && (viewFindViewById = constraintLayout.findViewById(id)) != null && viewFindViewById != constraintLayout && viewFindViewById.getParent() == constraintLayout) {
                                    constraintLayout.onViewAdded(viewFindViewById);
                                }
                                dVar10 = viewFindViewById == constraintLayout ? eVar2 : viewFindViewById == null ? null : ((y.e) viewFindViewById.getLayoutParams()).f4782p0;
                            }
                            dVar10.f4447i0 = resourceName;
                        } catch (Resources.NotFoundException unused2) {
                        }
                    }
                }
                if (constraintLayout.f441l != -1) {
                    for (int i23 = 0; i23 < childCount3; i23++) {
                        constraintLayout.getChildAt(i23).getId();
                    }
                }
                n nVar = constraintLayout.f439j;
                if (nVar != null) {
                    nVar.a(constraintLayout);
                }
                eVar2.f4471q0.clear();
                ArrayList arrayList2 = constraintLayout.f432b;
                int size = arrayList2.size();
                if (size > 0) {
                    int i24 = 0;
                    while (i24 < size) {
                        c cVar = (c) arrayList2.get(i24);
                        HashMap map = cVar.f4751g;
                        if (cVar.isInEditMode()) {
                            cVar.setIds(cVar.f4750e);
                        }
                        i iVar = cVar.f4749d;
                        if (iVar == null) {
                            sparseArray2 = sparseArray3;
                            arrayList = arrayList2;
                        } else {
                            iVar.f4515r0 = i18;
                            Arrays.fill(iVar.f4514q0, (Object) null);
                            int i25 = 0;
                            while (i25 < cVar.f4747b) {
                                int i26 = cVar.f4746a[i25];
                                View view = (View) sparseArray3.get(i26);
                                if (view == null && (iF = cVar.f(constraintLayout, (str = (String) map.get(Integer.valueOf(i26))))) != 0) {
                                    cVar.f4746a[i25] = iF;
                                    map.put(Integer.valueOf(iF), str);
                                    view = (View) sparseArray3.get(iF);
                                }
                                View view2 = view;
                                if (view2 != null) {
                                    i iVar2 = cVar.f4749d;
                                    d dVarH2 = constraintLayout.h(view2);
                                    iVar2.getClass();
                                    if (dVarH2 != iVar2 && dVarH2 != null) {
                                        int i27 = iVar2.f4515r0 + 1;
                                        d[] dVarArr = iVar2.f4514q0;
                                        if (i27 > dVarArr.length) {
                                            iVar2.f4514q0 = (d[]) Arrays.copyOf(dVarArr, dVarArr.length * 2);
                                        }
                                        d[] dVarArr2 = iVar2.f4514q0;
                                        int i28 = iVar2.f4515r0;
                                        dVarArr2[i28] = dVarH2;
                                        iVar2.f4515r0 = i28 + 1;
                                    }
                                }
                                i25++;
                                sparseArray3 = sparseArray3;
                                arrayList2 = arrayList2;
                            }
                            sparseArray2 = sparseArray3;
                            arrayList = arrayList2;
                            cVar.f4749d.S();
                        }
                        i24++;
                        sparseArray3 = sparseArray2;
                        arrayList2 = arrayList;
                        i18 = 0;
                    }
                }
                for (int i29 = 0; i29 < childCount3; i29++) {
                    constraintLayout.getChildAt(i29);
                }
                SparseArray sparseArray4 = constraintLayout.f443n;
                sparseArray4.clear();
                sparseArray4.put(0, eVar2);
                sparseArray4.put(constraintLayout.getId(), eVar2);
                for (int i30 = 0; i30 < childCount3; i30++) {
                    View childAt2 = constraintLayout.getChildAt(i30);
                    sparseArray4.put(childAt2.getId(), constraintLayout.h(childAt2));
                }
                int i31 = 0;
                while (i31 < childCount3) {
                    View childAt3 = constraintLayout.getChildAt(i31);
                    d dVarH3 = constraintLayout.h(childAt3);
                    if (dVarH3 == null) {
                        sparseArray = sparseArray4;
                        i5 = i31;
                        z5 = z4;
                        z6 = zIsInEditMode;
                        i14 = childCount3;
                    } else {
                        y.e eVar3 = (y.e) childAt3.getLayoutParams();
                        eVar2.f4471q0.add(dVarH3);
                        d dVar11 = dVarH3.U;
                        if (dVar11 != null) {
                            ((e) dVar11).f4471q0.remove(dVarH3);
                            dVarH3.C();
                        }
                        dVarH3.U = eVar2;
                        eVar3.a();
                        dVarH3.f4445h0 = childAt3.getVisibility();
                        dVarH3.f4443g0 = childAt3;
                        if (childAt3 instanceof c) {
                            ((c) childAt3).h(dVarH3, eVar2.f4476v0);
                        }
                        if (eVar3.f4760d0) {
                            h hVar = (h) dVarH3;
                            int i32 = eVar3.f4776m0;
                            int i33 = eVar3.f4778n0;
                            float f4 = eVar3.f4780o0;
                            if (f4 != -1.0f) {
                                if (f4 > -1.0f) {
                                    hVar.f4508q0 = f4;
                                    hVar.f4509r0 = -1;
                                    hVar.f4510s0 = -1;
                                }
                            } else if (i32 != -1) {
                                if (i32 > -1) {
                                    hVar.f4508q0 = -1.0f;
                                    hVar.f4509r0 = i32;
                                    hVar.f4510s0 = -1;
                                }
                            } else if (i33 != -1 && i33 > -1) {
                                hVar.f4508q0 = -1.0f;
                                hVar.f4509r0 = -1;
                                hVar.f4510s0 = i33;
                            }
                            sparseArray = sparseArray4;
                            i5 = i31;
                            z5 = z4;
                            z6 = zIsInEditMode;
                            i14 = childCount3;
                        } else {
                            int i34 = eVar3.f4763f0;
                            int i35 = eVar3.f4765g0;
                            int i36 = eVar3.f4767h0;
                            int i37 = eVar3.f4769i0;
                            int i38 = eVar3.j0;
                            int i39 = eVar3.f4772k0;
                            i5 = i31;
                            float f5 = eVar3.f4774l0;
                            int i40 = eVar3.f4781p;
                            ConstraintAnchor$Type constraintAnchor$Type11 = ConstraintAnchor$Type.f375c;
                            ConstraintAnchor$Type constraintAnchor$Type12 = ConstraintAnchor$Type.f373a;
                            z5 = z4;
                            ConstraintAnchor$Type constraintAnchor$Type13 = ConstraintAnchor$Type.f376d;
                            ConstraintAnchor$Type constraintAnchor$Type14 = ConstraintAnchor$Type.f374b;
                            if (i40 != -1) {
                                d dVar12 = (d) sparseArray4.get(i40);
                                if (dVar12 != null) {
                                    float f6 = eVar3.f4784r;
                                    int i41 = eVar3.f4783q;
                                    ConstraintAnchor$Type constraintAnchor$Type15 = ConstraintAnchor$Type.f;
                                    dVarH3.v(constraintAnchor$Type15, dVar12, constraintAnchor$Type15, i41, 0);
                                    dVarH3.D = f6;
                                }
                                constraintLayout = this;
                                dVar6 = dVarH3;
                                eVar = eVar3;
                                constraintAnchor$Type5 = constraintAnchor$Type11;
                                constraintAnchor$Type4 = constraintAnchor$Type12;
                                constraintAnchor$Type9 = constraintAnchor$Type13;
                                constraintAnchor$Type8 = constraintAnchor$Type14;
                            } else {
                                if (i34 != -1) {
                                    d dVar13 = (d) sparseArray4.get(i34);
                                    if (dVar13 != null) {
                                        dVar = dVarH3;
                                        constraintAnchor$Type = constraintAnchor$Type12;
                                        dVar.v(constraintAnchor$Type, dVar13, constraintAnchor$Type12, ((ViewGroup.MarginLayoutParams) eVar3).leftMargin, i38);
                                    } else {
                                        dVar = dVarH3;
                                        constraintAnchor$Type = constraintAnchor$Type12;
                                    }
                                } else {
                                    dVar = dVarH3;
                                    constraintAnchor$Type = constraintAnchor$Type12;
                                    if (i35 != -1 && (dVar2 = (d) sparseArray4.get(i35)) != null) {
                                        dVar.v(constraintAnchor$Type, dVar2, constraintAnchor$Type11, ((ViewGroup.MarginLayoutParams) eVar3).leftMargin, i38);
                                        constraintAnchor$Type2 = constraintAnchor$Type;
                                        constraintAnchor$Type3 = constraintAnchor$Type11;
                                    }
                                    if (i36 != -1) {
                                        dVar9 = (d) sparseArray4.get(i36);
                                        if (dVar9 != null) {
                                            dVar.v(constraintAnchor$Type3, dVar9, constraintAnchor$Type2, ((ViewGroup.MarginLayoutParams) eVar3).rightMargin, i39);
                                        }
                                        constraintAnchor$Type4 = constraintAnchor$Type2;
                                    } else {
                                        constraintAnchor$Type4 = constraintAnchor$Type2;
                                        if (i37 != -1 && (dVar3 = (d) sparseArray4.get(i37)) != null) {
                                            dVar.v(constraintAnchor$Type3, dVar3, constraintAnchor$Type3, ((ViewGroup.MarginLayoutParams) eVar3).rightMargin, i39);
                                        }
                                    }
                                    constraintAnchor$Type5 = constraintAnchor$Type3;
                                    i6 = eVar3.f4768i;
                                    if (i6 != -1) {
                                        dVar8 = (d) sparseArray4.get(i6);
                                        if (dVar8 != null) {
                                            constraintAnchor$Type10 = constraintAnchor$Type14;
                                            dVar.v(constraintAnchor$Type10, dVar8, constraintAnchor$Type14, ((ViewGroup.MarginLayoutParams) eVar3).topMargin, eVar3.f4790x);
                                        } else {
                                            constraintAnchor$Type10 = constraintAnchor$Type14;
                                        }
                                        constraintAnchor$Type6 = constraintAnchor$Type10;
                                        constraintAnchor$Type7 = constraintAnchor$Type13;
                                        i8 = -1;
                                    } else {
                                        i7 = eVar3.f4770j;
                                        i8 = -1;
                                        if (i7 != -1 || (dVar4 = (d) sparseArray4.get(i7)) == null) {
                                            constraintAnchor$Type6 = constraintAnchor$Type14;
                                            constraintAnchor$Type7 = constraintAnchor$Type13;
                                        } else {
                                            dVar.v(constraintAnchor$Type14, dVar4, constraintAnchor$Type13, ((ViewGroup.MarginLayoutParams) eVar3).topMargin, eVar3.f4790x);
                                            constraintAnchor$Type6 = constraintAnchor$Type14;
                                            constraintAnchor$Type7 = constraintAnchor$Type13;
                                        }
                                    }
                                    i9 = eVar3.f4771k;
                                    if (i9 != i8) {
                                        dVar7 = (d) sparseArray4.get(i9);
                                        if (dVar7 != null) {
                                            ConstraintAnchor$Type constraintAnchor$Type16 = constraintAnchor$Type6;
                                            dVar.v(constraintAnchor$Type7, dVar7, constraintAnchor$Type16, ((ViewGroup.MarginLayoutParams) eVar3).bottomMargin, eVar3.f4792z);
                                            constraintAnchor$Type8 = constraintAnchor$Type16;
                                        } else {
                                            constraintAnchor$Type8 = constraintAnchor$Type6;
                                        }
                                    } else {
                                        constraintAnchor$Type8 = constraintAnchor$Type6;
                                        i10 = eVar3.f4773l;
                                        if (i10 != i8 && (dVar5 = (d) sparseArray4.get(i10)) != null) {
                                            dVar.v(constraintAnchor$Type7, dVar5, constraintAnchor$Type7, ((ViewGroup.MarginLayoutParams) eVar3).bottomMargin, eVar3.f4792z);
                                        }
                                    }
                                    eVar = eVar3;
                                    i11 = eVar.f4775m;
                                    if (i11 != -1) {
                                        constraintLayout = this;
                                        dVar6 = dVar;
                                        constraintLayout.l(dVar6, eVar, sparseArray4, i11, ConstraintAnchor$Type.f377e);
                                    } else {
                                        i12 = eVar.f4777n;
                                        if (i12 != -1) {
                                            constraintLayout = this;
                                            dVar6 = dVar;
                                            constraintLayout.l(dVar6, eVar, sparseArray4, i12, constraintAnchor$Type8);
                                        } else {
                                            i13 = eVar.f4779o;
                                            constraintLayout = this;
                                            dVar6 = dVar;
                                            constraintAnchor$Type9 = constraintAnchor$Type7;
                                            if (i13 != -1) {
                                                constraintLayout.l(dVar6, eVar, sparseArray4, i13, constraintAnchor$Type9);
                                            }
                                        }
                                        if (f5 >= 0.0f) {
                                            dVar6.f4440e0 = f5;
                                        }
                                        f = eVar.F;
                                        if (f >= 0.0f) {
                                            dVar6.f4441f0 = f;
                                        }
                                    }
                                    constraintAnchor$Type9 = constraintAnchor$Type7;
                                    if (f5 >= 0.0f) {
                                        dVar6.f4440e0 = f5;
                                    }
                                    f = eVar.F;
                                    if (f >= 0.0f) {
                                        dVar6.f4441f0 = f;
                                    }
                                }
                                constraintAnchor$Type2 = constraintAnchor$Type;
                                constraintAnchor$Type3 = constraintAnchor$Type11;
                                if (i36 != -1) {
                                    dVar9 = (d) sparseArray4.get(i36);
                                    if (dVar9 != null) {
                                        dVar.v(constraintAnchor$Type3, dVar9, constraintAnchor$Type2, ((ViewGroup.MarginLayoutParams) eVar3).rightMargin, i39);
                                    }
                                    constraintAnchor$Type4 = constraintAnchor$Type2;
                                } else {
                                    constraintAnchor$Type4 = constraintAnchor$Type2;
                                    if (i37 != -1) {
                                        dVar.v(constraintAnchor$Type3, dVar3, constraintAnchor$Type3, ((ViewGroup.MarginLayoutParams) eVar3).rightMargin, i39);
                                    }
                                }
                                constraintAnchor$Type5 = constraintAnchor$Type3;
                                i6 = eVar3.f4768i;
                                if (i6 != -1) {
                                    dVar8 = (d) sparseArray4.get(i6);
                                    if (dVar8 != null) {
                                        constraintAnchor$Type10 = constraintAnchor$Type14;
                                        dVar.v(constraintAnchor$Type10, dVar8, constraintAnchor$Type14, ((ViewGroup.MarginLayoutParams) eVar3).topMargin, eVar3.f4790x);
                                    } else {
                                        constraintAnchor$Type10 = constraintAnchor$Type14;
                                    }
                                    constraintAnchor$Type6 = constraintAnchor$Type10;
                                    constraintAnchor$Type7 = constraintAnchor$Type13;
                                    i8 = -1;
                                } else {
                                    i7 = eVar3.f4770j;
                                    i8 = -1;
                                    if (i7 != -1) {
                                        constraintAnchor$Type6 = constraintAnchor$Type14;
                                        constraintAnchor$Type7 = constraintAnchor$Type13;
                                    } else {
                                        constraintAnchor$Type6 = constraintAnchor$Type14;
                                        constraintAnchor$Type7 = constraintAnchor$Type13;
                                    }
                                }
                                i9 = eVar3.f4771k;
                                if (i9 != i8) {
                                    dVar7 = (d) sparseArray4.get(i9);
                                    if (dVar7 != null) {
                                        ConstraintAnchor$Type constraintAnchor$Type17 = constraintAnchor$Type6;
                                        dVar.v(constraintAnchor$Type7, dVar7, constraintAnchor$Type17, ((ViewGroup.MarginLayoutParams) eVar3).bottomMargin, eVar3.f4792z);
                                        constraintAnchor$Type8 = constraintAnchor$Type17;
                                    } else {
                                        constraintAnchor$Type8 = constraintAnchor$Type6;
                                    }
                                } else {
                                    constraintAnchor$Type8 = constraintAnchor$Type6;
                                    i10 = eVar3.f4773l;
                                    if (i10 != i8) {
                                        dVar.v(constraintAnchor$Type7, dVar5, constraintAnchor$Type7, ((ViewGroup.MarginLayoutParams) eVar3).bottomMargin, eVar3.f4792z);
                                    }
                                }
                                eVar = eVar3;
                                i11 = eVar.f4775m;
                                if (i11 != -1) {
                                    constraintLayout = this;
                                    dVar6 = dVar;
                                    constraintLayout.l(dVar6, eVar, sparseArray4, i11, ConstraintAnchor$Type.f377e);
                                } else {
                                    i12 = eVar.f4777n;
                                    if (i12 != -1) {
                                        constraintLayout = this;
                                        dVar6 = dVar;
                                        constraintLayout.l(dVar6, eVar, sparseArray4, i12, constraintAnchor$Type8);
                                    } else {
                                        i13 = eVar.f4779o;
                                        constraintLayout = this;
                                        dVar6 = dVar;
                                        constraintAnchor$Type9 = constraintAnchor$Type7;
                                        if (i13 != -1) {
                                            constraintLayout.l(dVar6, eVar, sparseArray4, i13, constraintAnchor$Type9);
                                        }
                                    }
                                    if (f5 >= 0.0f) {
                                        dVar6.f4440e0 = f5;
                                    }
                                    f = eVar.F;
                                    if (f >= 0.0f) {
                                        dVar6.f4441f0 = f;
                                    }
                                }
                                constraintAnchor$Type9 = constraintAnchor$Type7;
                                if (f5 >= 0.0f) {
                                    dVar6.f4440e0 = f5;
                                }
                                f = eVar.F;
                                if (f >= 0.0f) {
                                    dVar6.f4441f0 = f;
                                }
                            }
                            if (zIsInEditMode && ((i17 = eVar.T) != -1 || eVar.U != -1)) {
                                int i42 = eVar.U;
                                dVar6.Z = i17;
                                dVar6.f4432a0 = i42;
                            }
                            boolean z9 = eVar.f4754a0;
                            ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour = ConstraintWidget$DimensionBehaviour.f382b;
                            ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour2 = ConstraintWidget$DimensionBehaviour.f381a;
                            sparseArray = sparseArray4;
                            ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour3 = ConstraintWidget$DimensionBehaviour.f384d;
                            ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour4 = ConstraintWidget$DimensionBehaviour.f383c;
                            if (z9) {
                                z6 = zIsInEditMode;
                                i14 = childCount3;
                                dVar6.M(constraintWidget$DimensionBehaviour2);
                                dVar6.O(((ViewGroup.MarginLayoutParams) eVar).width);
                                if (((ViewGroup.MarginLayoutParams) eVar).width == -2) {
                                    dVar6.M(constraintWidget$DimensionBehaviour);
                                }
                            } else {
                                z6 = zIsInEditMode;
                                i14 = childCount3;
                                if (((ViewGroup.MarginLayoutParams) eVar).width == -1) {
                                    if (eVar.W) {
                                        dVar6.M(constraintWidget$DimensionBehaviour4);
                                    } else {
                                        dVar6.M(constraintWidget$DimensionBehaviour3);
                                    }
                                    dVar6.i(constraintAnchor$Type4).f4428g = ((ViewGroup.MarginLayoutParams) eVar).leftMargin;
                                    dVar6.i(constraintAnchor$Type5).f4428g = ((ViewGroup.MarginLayoutParams) eVar).rightMargin;
                                } else {
                                    dVar6.M(constraintWidget$DimensionBehaviour4);
                                    dVar6.O(0);
                                }
                            }
                            if (eVar.f4756b0) {
                                dVar6.N(constraintWidget$DimensionBehaviour2);
                                dVar6.L(((ViewGroup.MarginLayoutParams) eVar).height);
                                if (((ViewGroup.MarginLayoutParams) eVar).height == -2) {
                                    dVar6.N(constraintWidget$DimensionBehaviour);
                                }
                            } else if (((ViewGroup.MarginLayoutParams) eVar).height == -1) {
                                if (eVar.X) {
                                    dVar6.N(constraintWidget$DimensionBehaviour4);
                                } else {
                                    dVar6.N(constraintWidget$DimensionBehaviour3);
                                }
                                dVar6.i(constraintAnchor$Type8).f4428g = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
                                dVar6.i(constraintAnchor$Type9).f4428g = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
                            } else {
                                dVar6.N(constraintWidget$DimensionBehaviour4);
                                dVar6.L(0);
                            }
                            String str2 = eVar.G;
                            if (str2 == null || str2.length() == 0) {
                                dVar6.X = 0.0f;
                            } else {
                                int length = str2.length();
                                int iIndexOf3 = str2.indexOf(44);
                                if (iIndexOf3 <= 0 || iIndexOf3 >= length - 1) {
                                    i15 = 0;
                                    i16 = -1;
                                } else {
                                    String strSubstring = str2.substring(0, iIndexOf3);
                                    i16 = strSubstring.equalsIgnoreCase("W") ? 0 : strSubstring.equalsIgnoreCase("H") ? 1 : -1;
                                    i15 = iIndexOf3 + 1;
                                }
                                int iIndexOf4 = str2.indexOf(58);
                                if (iIndexOf4 < 0 || iIndexOf4 >= length - 1) {
                                    String strSubstring2 = str2.substring(i15);
                                    if (strSubstring2.length() > 0) {
                                        fAbs = Float.parseFloat(strSubstring2);
                                    } else {
                                        fAbs = 0.0f;
                                    }
                                } else {
                                    String strSubstring3 = str2.substring(i15, iIndexOf4);
                                    String strSubstring4 = str2.substring(iIndexOf4 + 1);
                                    if (strSubstring3.length() <= 0 || strSubstring4.length() <= 0) {
                                        fAbs = 0.0f;
                                    } else {
                                        try {
                                            float f7 = Float.parseFloat(strSubstring3);
                                            float f8 = Float.parseFloat(strSubstring4);
                                            if (f7 <= 0.0f || f8 <= 0.0f) {
                                                fAbs = 0.0f;
                                            } else {
                                                fAbs = i16 == 1 ? Math.abs(f8 / f7) : Math.abs(f7 / f8);
                                            }
                                        } catch (NumberFormatException unused3) {
                                        }
                                    }
                                }
                                if (fAbs > 0.0f) {
                                    dVar6.X = fAbs;
                                    dVar6.Y = i16;
                                }
                            }
                            float f9 = eVar.H;
                            float[] fArr = dVar6.f4452l0;
                            fArr[0] = f9;
                            fArr[1] = eVar.I;
                            dVar6.j0 = eVar.J;
                            dVar6.f4450k0 = eVar.K;
                            int i43 = eVar.Z;
                            if (i43 >= 0 && i43 <= 3) {
                                dVar6.f4461q = i43;
                            }
                            int i44 = eVar.L;
                            int i45 = eVar.N;
                            int i46 = eVar.P;
                            float f10 = eVar.R;
                            dVar6.f4462r = i44;
                            dVar6.f4465u = i45;
                            if (i46 == Integer.MAX_VALUE) {
                                i46 = 0;
                            }
                            dVar6.f4466v = i46;
                            dVar6.f4467w = f10;
                            if (f10 > 0.0f && f10 < 1.0f && i44 == 0) {
                                dVar6.f4462r = 2;
                            }
                            int i47 = eVar.M;
                            int i48 = eVar.O;
                            int i49 = eVar.Q;
                            float f11 = eVar.S;
                            dVar6.f4463s = i47;
                            dVar6.f4468x = i48;
                            if (i49 == Integer.MAX_VALUE) {
                                i49 = 0;
                            }
                            dVar6.f4469y = i49;
                            dVar6.f4470z = f11;
                            if (f11 > 0.0f && f11 < 1.0f && i47 == 0) {
                                dVar6.f4463s = 2;
                            }
                        }
                    }
                    i31 = i5 + 1;
                    sparseArray4 = sparseArray;
                    zIsInEditMode = z6;
                    childCount3 = i14;
                    z4 = z5;
                }
            }
            if (z4) {
                eVar2.f4472r0.D(eVar2);
            }
        }
        eVar2.f4477w0.getClass();
        constraintLayout.k(eVar2, constraintLayout.f438i, i3, i4);
        int iQ = eVar2.q();
        int iK = eVar2.k();
        boolean z10 = eVar2.E0;
        boolean z11 = eVar2.F0;
        f fVar = constraintLayout.f444o;
        int i50 = fVar.f4797e;
        int iResolveSizeAndState = View.resolveSizeAndState(iQ + fVar.f4796d, i3, 0);
        int iResolveSizeAndState2 = View.resolveSizeAndState(iK + i50, i4, 0) & 16777215;
        int iMin = Math.min(constraintLayout.f, iResolveSizeAndState & 16777215);
        int iMin2 = Math.min(constraintLayout.f436g, iResolveSizeAndState2);
        if (z10) {
            iMin |= 16777216;
        }
        if (z11) {
            iMin2 |= 16777216;
        }
        constraintLayout.setMeasuredDimension(iMin, iMin2);
    }

    @Override // android.view.ViewGroup
    public final void onViewAdded(View view) {
        super.onViewAdded(view);
        d dVarH = h(view);
        if ((view instanceof p) && !(dVarH instanceof h)) {
            y.e eVar = (y.e) view.getLayoutParams();
            h hVar = new h();
            eVar.f4782p0 = hVar;
            eVar.f4760d0 = true;
            hVar.S(eVar.V);
        }
        if (view instanceof c) {
            c cVar = (c) view;
            cVar.i();
            ((y.e) view.getLayoutParams()).f4762e0 = true;
            ArrayList arrayList = this.f432b;
            if (!arrayList.contains(cVar)) {
                arrayList.add(cVar);
            }
        }
        this.f431a.put(view.getId(), view);
        this.f437h = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f431a.remove(view.getId());
        d dVarH = h(view);
        this.f433c.f4471q0.remove(dVarH);
        dVarH.C();
        this.f432b.remove(view);
        this.f437h = true;
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.f437h = true;
        super.requestLayout();
    }

    public void setConstraintSet(n nVar) {
        this.f439j = nVar;
    }

    @Override // android.view.View
    public void setId(int i3) {
        int id = getId();
        SparseArray sparseArray = this.f431a;
        sparseArray.remove(id);
        super.setId(i3);
        sparseArray.put(getId(), this);
    }

    public void setMaxHeight(int i3) {
        if (i3 == this.f436g) {
            return;
        }
        this.f436g = i3;
        requestLayout();
    }

    public void setMaxWidth(int i3) {
        if (i3 == this.f) {
            return;
        }
        this.f = i3;
        requestLayout();
    }

    public void setMinHeight(int i3) {
        if (i3 == this.f435e) {
            return;
        }
        this.f435e = i3;
        requestLayout();
    }

    public void setMinWidth(int i3) {
        if (i3 == this.f434d) {
            return;
        }
        this.f434d = i3;
        requestLayout();
    }

    public void setOnConstraintsChanged(o oVar) {
        q qVar = this.f440k;
        if (qVar != null) {
            qVar.getClass();
        }
    }

    public void setOptimizationLevel(int i3) {
        this.f438i = i3;
        e eVar = this.f433c;
        eVar.D0 = i3;
        t.c.f3952q = eVar.W(512);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i3) {
        super(context, attributeSet, i3);
        this.f431a = new SparseArray();
        this.f432b = new ArrayList(4);
        this.f433c = new e();
        this.f434d = 0;
        this.f435e = 0;
        this.f = Integer.MAX_VALUE;
        this.f436g = Integer.MAX_VALUE;
        this.f437h = true;
        this.f438i = 257;
        this.f439j = null;
        this.f440k = null;
        this.f441l = -1;
        this.f442m = new HashMap();
        this.f443n = new SparseArray();
        this.f444o = new f(this, this);
        i(attributeSet, i3);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new y.e(layoutParams);
    }
}
