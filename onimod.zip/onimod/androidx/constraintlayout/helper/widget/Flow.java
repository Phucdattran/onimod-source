package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import java.util.ArrayList;
import java.util.HashMap;
import v.d;
import v.g;
import w.b;
import y.r;
import y.t;

/* JADX INFO: loaded from: classes.dex */
public class Flow extends t {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final g f421j;

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f4746a = new int[32];
        this.f4751g = new HashMap();
        this.f4748c = context;
        super.g(attributeSet);
        g gVar = new g();
        gVar.f4500s0 = 0;
        gVar.f4501t0 = 0;
        gVar.f4502u0 = 0;
        gVar.f4503v0 = 0;
        gVar.f4504w0 = 0;
        gVar.f4505x0 = 0;
        gVar.f4506y0 = false;
        gVar.f4507z0 = 0;
        gVar.A0 = 0;
        gVar.B0 = new b();
        gVar.C0 = null;
        gVar.D0 = -1;
        gVar.E0 = -1;
        gVar.F0 = -1;
        gVar.G0 = -1;
        gVar.H0 = -1;
        gVar.I0 = -1;
        gVar.J0 = 0.5f;
        gVar.K0 = 0.5f;
        gVar.L0 = 0.5f;
        gVar.M0 = 0.5f;
        gVar.N0 = 0.5f;
        gVar.O0 = 0.5f;
        gVar.P0 = 0;
        gVar.Q0 = 0;
        gVar.R0 = 2;
        gVar.S0 = 2;
        gVar.T0 = 0;
        gVar.U0 = -1;
        gVar.V0 = 0;
        gVar.W0 = new ArrayList();
        gVar.X0 = null;
        gVar.Y0 = null;
        gVar.Z0 = null;
        gVar.f4499b1 = 0;
        this.f421j = gVar;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, r.f4894b);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i3);
                if (index == 0) {
                    this.f421j.V0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 1) {
                    g gVar2 = this.f421j;
                    int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    gVar2.f4500s0 = dimensionPixelSize;
                    gVar2.f4501t0 = dimensionPixelSize;
                    gVar2.f4502u0 = dimensionPixelSize;
                    gVar2.f4503v0 = dimensionPixelSize;
                } else if (index == 18) {
                    g gVar3 = this.f421j;
                    int dimensionPixelSize2 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    gVar3.f4502u0 = dimensionPixelSize2;
                    gVar3.f4504w0 = dimensionPixelSize2;
                    gVar3.f4505x0 = dimensionPixelSize2;
                } else if (index == 19) {
                    this.f421j.f4503v0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 2) {
                    this.f421j.f4504w0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 3) {
                    this.f421j.f4500s0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 4) {
                    this.f421j.f4505x0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 5) {
                    this.f421j.f4501t0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 54) {
                    this.f421j.T0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 44) {
                    this.f421j.D0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 53) {
                    this.f421j.E0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 38) {
                    this.f421j.F0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 46) {
                    this.f421j.H0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 40) {
                    this.f421j.G0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 48) {
                    this.f421j.I0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 42) {
                    this.f421j.J0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 37) {
                    this.f421j.L0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 45) {
                    this.f421j.N0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 39) {
                    this.f421j.M0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 47) {
                    this.f421j.O0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 51) {
                    this.f421j.K0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 41) {
                    this.f421j.R0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == 50) {
                    this.f421j.S0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == 43) {
                    this.f421j.P0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 52) {
                    this.f421j.Q0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 49) {
                    this.f421j.U0 = typedArrayObtainStyledAttributes.getInt(index, -1);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.f4749d = this.f421j;
        i();
    }

    @Override // y.c
    public final void h(d dVar, boolean z4) {
        g gVar = this.f421j;
        int i3 = gVar.f4502u0;
        if (i3 > 0 || gVar.f4503v0 > 0) {
            if (z4) {
                gVar.f4504w0 = gVar.f4503v0;
                gVar.f4505x0 = i3;
            } else {
                gVar.f4504w0 = i3;
                gVar.f4505x0 = gVar.f4503v0;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:226:0x03da A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:227:0x03dc  */
    /* JADX WARN: Code duplicated, block: B:228:0x03e6  */
    /* JADX WARN: Code duplicated, block: B:231:0x03f3  */
    /* JADX WARN: Code duplicated, block: B:233:0x03f6  */
    /* JADX WARN: Code duplicated, block: B:238:0x0405  */
    /* JADX WARN: Code duplicated, block: B:242:0x040d  */
    /* JADX WARN: Code duplicated, block: B:245:0x0414  */
    /* JADX WARN: Code duplicated, block: B:247:0x0417  */
    /* JADX WARN: Code duplicated, block: B:249:0x041d  */
    /* JADX WARN: Code duplicated, block: B:253:0x0424  */
    /* JADX WARN: Code duplicated, block: B:258:0x0433  */
    /* JADX WARN: Code duplicated, block: B:260:0x0439  */
    /* JADX WARN: Code duplicated, block: B:263:0x0447  */
    /* JADX WARN: Code duplicated, block: B:265:0x044d  */
    /* JADX WARN: Code duplicated, block: B:270:0x045b  */
    /* JADX WARN: Code duplicated, block: B:272:0x0461 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:273:0x0463  */
    /* JADX WARN: Code duplicated, block: B:278:0x0473  */
    /* JADX WARN: Code duplicated, block: B:280:0x0479 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:281:0x047b  */
    /* JADX WARN: Code duplicated, block: B:290:0x049a A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:452:0x0498 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:455:0x04a0 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:457:0x03d4 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:467:0x0451 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:471:0x046c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:474:0x0484 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:82:0x014c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:286:0x0490 -> B:223:0x03d4). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:287:0x0492 -> B:223:0x03d4). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:289:0x0498 -> B:223:0x03d4). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:290:0x049a -> B:223:0x03d4). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // y.t
    public final void j(v.g r42, int r43, int r44) {
        /*
            Method dump skipped, instruction units count: 1900
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.helper.widget.Flow.j(v.g, int, int):void");
    }

    @Override // y.c, android.view.View
    public final void onMeasure(int i3, int i4) {
        j(this.f421j, i3, i4);
    }

    public void setFirstHorizontalBias(float f) {
        this.f421j.L0 = f;
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i3) {
        this.f421j.F0 = i3;
        requestLayout();
    }

    public void setFirstVerticalBias(float f) {
        this.f421j.M0 = f;
        requestLayout();
    }

    public void setFirstVerticalStyle(int i3) {
        this.f421j.G0 = i3;
        requestLayout();
    }

    public void setHorizontalAlign(int i3) {
        this.f421j.R0 = i3;
        requestLayout();
    }

    public void setHorizontalBias(float f) {
        this.f421j.J0 = f;
        requestLayout();
    }

    public void setHorizontalGap(int i3) {
        this.f421j.P0 = i3;
        requestLayout();
    }

    public void setHorizontalStyle(int i3) {
        this.f421j.D0 = i3;
        requestLayout();
    }

    public void setLastHorizontalBias(float f) {
        this.f421j.N0 = f;
        requestLayout();
    }

    public void setLastHorizontalStyle(int i3) {
        this.f421j.H0 = i3;
        requestLayout();
    }

    public void setLastVerticalBias(float f) {
        this.f421j.O0 = f;
        requestLayout();
    }

    public void setLastVerticalStyle(int i3) {
        this.f421j.I0 = i3;
        requestLayout();
    }

    public void setMaxElementsWrap(int i3) {
        this.f421j.U0 = i3;
        requestLayout();
    }

    public void setOrientation(int i3) {
        this.f421j.V0 = i3;
        requestLayout();
    }

    public void setPadding(int i3) {
        g gVar = this.f421j;
        gVar.f4500s0 = i3;
        gVar.f4501t0 = i3;
        gVar.f4502u0 = i3;
        gVar.f4503v0 = i3;
        requestLayout();
    }

    public void setPaddingBottom(int i3) {
        this.f421j.f4501t0 = i3;
        requestLayout();
    }

    public void setPaddingLeft(int i3) {
        this.f421j.f4504w0 = i3;
        requestLayout();
    }

    public void setPaddingRight(int i3) {
        this.f421j.f4505x0 = i3;
        requestLayout();
    }

    public void setPaddingTop(int i3) {
        this.f421j.f4500s0 = i3;
        requestLayout();
    }

    public void setVerticalAlign(int i3) {
        this.f421j.S0 = i3;
        requestLayout();
    }

    public void setVerticalBias(float f) {
        this.f421j.K0 = f;
        requestLayout();
    }

    public void setVerticalGap(int i3) {
        this.f421j.Q0 = i3;
        requestLayout();
    }

    public void setVerticalStyle(int i3) {
        this.f421j.E0 = i3;
        requestLayout();
    }

    public void setWrapMode(int i3) {
        this.f421j.T0 = i3;
        requestLayout();
    }
}
