package androidx.viewpager2.widget;

import a0.k;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.fragment.app.w;
import androidx.viewpager2.adapter.b;
import e1.o0;
import e1.u0;
import e1.y0;
import java.util.ArrayList;
import java.util.WeakHashMap;
import m1.a;
import n1.c;
import n1.d;
import n1.e;
import n1.f;
import n1.g;
import n1.h;
import n1.l;
import n1.m;
import n1.n;
import o0.h0;
import top.niunaijun.blackbox.core.system.JarConfig;

/* JADX INFO: loaded from: classes.dex */
public final class ViewPager2 extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Rect f1010a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Rect f1011b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final b f1012c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1013d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f1014e;
    public final e f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final h f1015g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f1016h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Parcelable f1017i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final m f1018j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final l f1019k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final d f1020l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final b f1021m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final a0.b f1022n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final n1.b f1023o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public u0 f1024p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f1025q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f1026r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1027s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final k f1028t;

    public ViewPager2(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1010a = new Rect();
        this.f1011b = new Rect();
        b bVar = new b();
        this.f1012c = bVar;
        int i3 = 0;
        this.f1014e = false;
        this.f = new e(i3, this);
        this.f1016h = -1;
        this.f1024p = null;
        this.f1025q = false;
        int i4 = 1;
        this.f1026r = true;
        this.f1027s = -1;
        this.f1028t = new k(this);
        m mVar = new m(this, context);
        this.f1018j = mVar;
        WeakHashMap weakHashMap = h0.f3558a;
        mVar.setId(View.generateViewId());
        this.f1018j.setDescendantFocusability(131072);
        h hVar = new h(this);
        this.f1015g = hVar;
        this.f1018j.setLayoutManager(hVar);
        this.f1018j.setScrollingTouchSlop(1);
        int[] iArr = a.f3379a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr);
        if (Build.VERSION.SDK_INT >= 29) {
            saveAttributeDataForStyleable(context, iArr, attributeSet, typedArrayObtainStyledAttributes, 0, 0);
        }
        try {
            setOrientation(typedArrayObtainStyledAttributes.getInt(0, 0));
            typedArrayObtainStyledAttributes.recycle();
            this.f1018j.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
            m mVar2 = this.f1018j;
            g gVar = new g();
            if (mVar2.B == null) {
                mVar2.B = new ArrayList();
            }
            mVar2.B.add(gVar);
            d dVar = new d(this);
            this.f1020l = dVar;
            this.f1022n = new a0.b(19, dVar);
            l lVar = new l(this);
            this.f1019k = lVar;
            lVar.a(this.f1018j);
            this.f1018j.h(this.f1020l);
            b bVar2 = new b();
            this.f1021m = bVar2;
            this.f1020l.f3412a = bVar2;
            f fVar = new f(this, i3);
            f fVar2 = new f(this, i4);
            ((ArrayList) bVar2.f994b).add(fVar);
            ((ArrayList) this.f1021m.f994b).add(fVar2);
            k kVar = this.f1028t;
            m mVar3 = this.f1018j;
            kVar.getClass();
            mVar3.setImportantForAccessibility(2);
            kVar.f25c = new e(i4, kVar);
            ViewPager2 viewPager2 = (ViewPager2) kVar.f26d;
            if (viewPager2.getImportantForAccessibility() == 0) {
                viewPager2.setImportantForAccessibility(1);
            }
            ((ArrayList) this.f1021m.f994b).add(bVar);
            n1.b bVar3 = new n1.b();
            this.f1023o = bVar3;
            ((ArrayList) this.f1021m.f994b).add(bVar3);
            m mVar4 = this.f1018j;
            attachViewToParent(mVar4, 0, mVar4.getLayoutParams());
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final void a() {
        o0 adapter;
        if (this.f1016h == -1 || (adapter = getAdapter()) == null) {
            return;
        }
        Parcelable parcelable = this.f1017i;
        if (parcelable != null) {
            if (adapter instanceof androidx.viewpager2.adapter.e) {
                ((androidx.viewpager2.adapter.e) adapter).s(parcelable);
            }
            this.f1017i = null;
        }
        int iMax = Math.max(0, Math.min(this.f1016h, adapter.a() - 1));
        this.f1013d = iMax;
        this.f1016h = -1;
        this.f1018j.c0(iMax);
        this.f1028t.m();
    }

    public final void b(int i3) {
        Object obj = this.f1022n.f3b;
        c(i3);
    }

    public final void c(int i3) {
        y0 y0Var;
        b bVar;
        o0 adapter = getAdapter();
        if (adapter == null) {
            if (this.f1016h != -1) {
                this.f1016h = Math.max(i3, 0);
                return;
            }
            return;
        }
        if (adapter.a() <= 0) {
            return;
        }
        int iMin = Math.min(Math.max(i3, 0), adapter.a() - 1);
        int i4 = this.f1013d;
        if ((iMin == i4 && this.f1020l.f == 0) || iMin == i4) {
            return;
        }
        double d4 = i4;
        this.f1013d = iMin;
        this.f1028t.m();
        d dVar = this.f1020l;
        if (dVar.f != 0) {
            dVar.e();
            c cVar = dVar.f3417g;
            d4 = ((double) cVar.f3409a) + ((double) cVar.f3410b);
        }
        d dVar2 = this.f1020l;
        dVar2.getClass();
        dVar2.f3416e = 2;
        boolean z4 = dVar2.f3419i != iMin;
        dVar2.f3419i = iMin;
        dVar2.c(2);
        if (z4 && (bVar = dVar2.f3412a) != null) {
            bVar.c(iMin);
        }
        double d5 = iMin;
        if (Math.abs(d5 - d4) > 3.0d) {
            this.f1018j.c0(d5 > d4 ? iMin - 3 : iMin + 3);
            m mVar = this.f1018j;
            mVar.post(new androidx.emoji2.text.k(iMin, mVar));
        } else {
            m mVar2 = this.f1018j;
            if (mVar2.f963w || (y0Var = mVar2.f943m) == null) {
                return;
            }
            y0Var.E0(mVar2, iMin);
        }
    }

    @Override // android.view.View
    public final boolean canScrollHorizontally(int i3) {
        return this.f1018j.canScrollHorizontally(i3);
    }

    @Override // android.view.View
    public final boolean canScrollVertically(int i3) {
        return this.f1018j.canScrollVertically(i3);
    }

    public final void d() {
        l lVar = this.f1019k;
        if (lVar == null) {
            throw new IllegalStateException("Design assumption violated.");
        }
        View viewE = lVar.e(this.f1015g);
        if (viewE == null) {
            return;
        }
        this.f1015g.getClass();
        int iL = y0.L(viewE);
        if (iL != this.f1013d && getScrollState() == 0) {
            this.f1021m.c(iL);
        }
        this.f1014e = false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        Parcelable parcelable = (Parcelable) sparseArray.get(getId());
        if (parcelable instanceof n) {
            int i3 = ((n) parcelable).f3430a;
            sparseArray.put(this.f1018j.getId(), sparseArray.get(i3));
            sparseArray.remove(i3);
        }
        super.dispatchRestoreInstanceState(sparseArray);
        a();
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        this.f1028t.getClass();
        this.f1028t.getClass();
        return "androidx.viewpager.widget.ViewPager";
    }

    public o0 getAdapter() {
        return this.f1018j.getAdapter();
    }

    public int getCurrentItem() {
        return this.f1013d;
    }

    public int getItemDecorationCount() {
        return this.f1018j.getItemDecorationCount();
    }

    public int getOffscreenPageLimit() {
        return this.f1027s;
    }

    public int getOrientation() {
        return this.f1015g.f909p;
    }

    public int getPageSize() {
        int height;
        int paddingBottom;
        int orientation = getOrientation();
        m mVar = this.f1018j;
        if (orientation == 0) {
            height = mVar.getWidth() - mVar.getPaddingLeft();
            paddingBottom = mVar.getPaddingRight();
        } else {
            height = mVar.getHeight() - mVar.getPaddingTop();
            paddingBottom = mVar.getPaddingBottom();
        }
        return height - paddingBottom;
    }

    public int getScrollState() {
        return this.f1020l.f;
    }

    /* JADX WARN: Code duplicated, block: B:20:0x004b  */
    /* JADX WARN: Code duplicated, block: B:23:0x0055  */
    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        int iA;
        int iA2;
        o0 adapter;
        int iA3;
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        ViewPager2 viewPager2 = (ViewPager2) this.f1028t.f26d;
        if (viewPager2.getAdapter() != null) {
            if (viewPager2.getOrientation() == 1) {
                iA = viewPager2.getAdapter().a();
            } else {
                iA2 = viewPager2.getAdapter().a();
                iA = 0;
            }
            accessibilityNodeInfo.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(iA, iA2, false, 0));
            adapter = viewPager2.getAdapter();
            if (adapter == null && (iA3 = adapter.a()) != 0 && viewPager2.f1026r) {
                if (viewPager2.f1013d > 0) {
                    accessibilityNodeInfo.addAction(JarConfig.DEFAULT_BUFFER_SIZE);
                }
                if (viewPager2.f1013d < iA3 - 1) {
                    accessibilityNodeInfo.addAction(4096);
                }
                accessibilityNodeInfo.setScrollable(true);
            }
            return;
        }
        iA = 0;
        iA2 = 0;
        accessibilityNodeInfo.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(iA, iA2, false, 0));
        adapter = viewPager2.getAdapter();
        if (adapter == null) {
            return;
        }
        if (viewPager2.f1013d > 0) {
            accessibilityNodeInfo.addAction(JarConfig.DEFAULT_BUFFER_SIZE);
        }
        if (viewPager2.f1013d < iA3 - 1) {
            accessibilityNodeInfo.addAction(4096);
        }
        accessibilityNodeInfo.setScrollable(true);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        int measuredWidth = this.f1018j.getMeasuredWidth();
        int measuredHeight = this.f1018j.getMeasuredHeight();
        int paddingLeft = getPaddingLeft();
        Rect rect = this.f1010a;
        rect.left = paddingLeft;
        rect.right = (i5 - i3) - getPaddingRight();
        rect.top = getPaddingTop();
        rect.bottom = (i6 - i4) - getPaddingBottom();
        Rect rect2 = this.f1011b;
        Gravity.apply(8388659, measuredWidth, measuredHeight, rect, rect2);
        this.f1018j.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
        if (this.f1014e) {
            d();
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i3, int i4) {
        measureChild(this.f1018j, i3, i4);
        int measuredWidth = this.f1018j.getMeasuredWidth();
        int measuredHeight = this.f1018j.getMeasuredHeight();
        int measuredState = this.f1018j.getMeasuredState();
        int paddingRight = getPaddingRight() + getPaddingLeft() + measuredWidth;
        int paddingBottom = getPaddingBottom() + getPaddingTop() + measuredHeight;
        setMeasuredDimension(View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i3, measuredState), View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i4, measuredState << 16));
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof n)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        n nVar = (n) parcelable;
        super.onRestoreInstanceState(nVar.getSuperState());
        this.f1016h = nVar.f3431b;
        this.f1017i = nVar.f3432c;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        n nVar = new n(super.onSaveInstanceState());
        nVar.f3430a = this.f1018j.getId();
        int i3 = this.f1016h;
        if (i3 == -1) {
            i3 = this.f1013d;
        }
        nVar.f3431b = i3;
        Parcelable parcelable = this.f1017i;
        if (parcelable != null) {
            nVar.f3432c = parcelable;
            return nVar;
        }
        o0 adapter = this.f1018j.getAdapter();
        if (adapter instanceof androidx.viewpager2.adapter.e) {
            androidx.viewpager2.adapter.e eVar = (androidx.viewpager2.adapter.e) adapter;
            eVar.getClass();
            q.g gVar = eVar.f;
            int iJ = gVar.j();
            q.g gVar2 = eVar.f1004g;
            Bundle bundle = new Bundle(gVar2.j() + iJ);
            for (int i4 = 0; i4 < gVar.j(); i4++) {
                long jG = gVar.g(i4);
                w wVar = (w) gVar.d(jG);
                if (wVar != null && wVar.r()) {
                    String str = "f#" + jG;
                    androidx.fragment.app.o0 o0Var = eVar.f1003e;
                    o0Var.getClass();
                    if (wVar.f790r != o0Var) {
                        o0Var.a0(new IllegalStateException("Fragment " + wVar + " is not currently in the FragmentManager"));
                        throw null;
                    }
                    bundle.putString(str, wVar.f778e);
                }
            }
            for (int i5 = 0; i5 < gVar2.j(); i5++) {
                long jG2 = gVar2.g(i5);
                if (androidx.viewpager2.adapter.e.n(jG2)) {
                    bundle.putParcelable("s#" + jG2, (Parcelable) gVar2.d(jG2));
                }
            }
            nVar.f3432c = bundle;
        }
        return nVar;
    }

    @Override // android.view.ViewGroup
    public final void onViewAdded(View view) {
        throw new IllegalStateException("ViewPager2 does not support direct child views");
    }

    @Override // android.view.View
    public final boolean performAccessibilityAction(int i3, Bundle bundle) {
        this.f1028t.getClass();
        if (i3 != 8192 && i3 != 4096) {
            return super.performAccessibilityAction(i3, bundle);
        }
        k kVar = this.f1028t;
        ViewPager2 viewPager2 = (ViewPager2) kVar.f26d;
        if (i3 != 8192 && i3 != 4096) {
            throw new IllegalStateException();
        }
        int currentItem = i3 == 8192 ? viewPager2.getCurrentItem() - 1 : viewPager2.getCurrentItem() + 1;
        ViewPager2 viewPager3 = (ViewPager2) kVar.f26d;
        if (viewPager3.f1026r) {
            viewPager3.c(currentItem);
        }
        return true;
    }

    public void setAdapter(o0 o0Var) {
        o0 adapter = this.f1018j.getAdapter();
        k kVar = this.f1028t;
        if (adapter != null) {
            adapter.f1999a.unregisterObserver((e) kVar.f25c);
        } else {
            kVar.getClass();
        }
        e eVar = this.f;
        if (adapter != null) {
            adapter.f1999a.unregisterObserver(eVar);
        }
        this.f1018j.setAdapter(o0Var);
        this.f1013d = 0;
        a();
        k kVar2 = this.f1028t;
        kVar2.m();
        if (o0Var != null) {
            o0Var.f1999a.registerObserver((e) kVar2.f25c);
        }
        if (o0Var != null) {
            o0Var.f1999a.registerObserver(eVar);
        }
    }

    public void setCurrentItem(int i3) {
        b(i3);
    }

    @Override // android.view.View
    public void setLayoutDirection(int i3) {
        super.setLayoutDirection(i3);
        this.f1028t.m();
    }

    public void setOffscreenPageLimit(int i3) {
        if (i3 < 1 && i3 != -1) {
            throw new IllegalArgumentException("Offscreen page limit must be OFFSCREEN_PAGE_LIMIT_DEFAULT or a number > 0");
        }
        this.f1027s = i3;
        this.f1018j.requestLayout();
    }

    public void setOrientation(int i3) {
        this.f1015g.i1(i3);
        this.f1028t.m();
    }

    public void setPageTransformer(n1.k kVar) {
        if (kVar != null) {
            if (!this.f1025q) {
                this.f1024p = this.f1018j.getItemAnimator();
                this.f1025q = true;
            }
            this.f1018j.setItemAnimator(null);
        } else if (this.f1025q) {
            this.f1018j.setItemAnimator(this.f1024p);
            this.f1024p = null;
            this.f1025q = false;
        }
        this.f1023o.getClass();
        if (kVar == null) {
            return;
        }
        this.f1023o.getClass();
        this.f1023o.getClass();
    }

    public void setUserInputEnabled(boolean z4) {
        this.f1026r = z4;
        this.f1028t.m();
    }
}
