package androidx.viewpager2.adapter;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import n1.i;
import top.niunaijun.blackboxa.view.main.OniNavBar;

/* JADX INFO: loaded from: classes.dex */
public final class b extends i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f993a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f994b;

    public /* synthetic */ b(int i3, Object obj) {
        this.f993a = i3;
        this.f994b = obj;
    }

    @Override // n1.i
    public void a(int i3) {
        switch (this.f993a) {
            case 0:
                ((d) this.f994b).b(false);
                return;
            case 1:
                try {
                    ArrayList arrayList = (ArrayList) this.f994b;
                    int size = arrayList.size();
                    int i4 = 0;
                    while (i4 < size) {
                        Object obj = arrayList.get(i4);
                        i4++;
                        ((i) obj).a(i3);
                    }
                    return;
                } catch (ConcurrentModificationException e4) {
                    throw new IllegalStateException("Adding and removing callbacks during dispatch to callbacks is not supported", e4);
                }
            default:
                return;
        }
    }

    @Override // n1.i
    public void b(int i3, float f, int i4) {
        switch (this.f993a) {
            case 1:
                try {
                    ArrayList arrayList = (ArrayList) this.f994b;
                    int size = arrayList.size();
                    int i5 = 0;
                    while (i5 < size) {
                        Object obj = arrayList.get(i5);
                        i5++;
                        ((i) obj).b(i3, f, i4);
                    }
                    return;
                } catch (ConcurrentModificationException e4) {
                    throw new IllegalStateException("Adding and removing callbacks during dispatch to callbacks is not supported", e4);
                }
            default:
                return;
        }
    }

    @Override // n1.i
    public final void c(int i3) {
        switch (this.f993a) {
            case 0:
                ((d) this.f994b).b(false);
                return;
            case 1:
                try {
                    ArrayList arrayList = (ArrayList) this.f994b;
                    int size = arrayList.size();
                    int i4 = 0;
                    while (i4 < size) {
                        Object obj = arrayList.get(i4);
                        i4++;
                        ((i) obj).c(i3);
                    }
                    return;
                } catch (ConcurrentModificationException e4) {
                    throw new IllegalStateException("Adding and removing callbacks during dispatch to callbacks is not supported", e4);
                }
            default:
                ((OniNavBar) this.f994b).c(i3);
                return;
        }
    }

    public b() {
        this.f993a = 1;
        this.f994b = new ArrayList(3);
    }
}
