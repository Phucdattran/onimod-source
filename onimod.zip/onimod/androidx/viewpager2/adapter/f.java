package androidx.viewpager2.adapter;

import e1.o1;

/* JADX INFO: loaded from: classes.dex */
public final class f extends o1 {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final /* synthetic */ int f1009u = 0;
}
