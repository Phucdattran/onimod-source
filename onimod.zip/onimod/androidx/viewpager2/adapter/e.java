package androidx.viewpager2.adapter;

import a2.i;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import androidx.fragment.app.d0;
import androidx.fragment.app.u0;
import androidx.fragment.app.v;
import androidx.fragment.app.w;
import androidx.fragment.app.y;
import androidx.lifecycle.Lifecycle$Event;
import androidx.lifecycle.Lifecycle$State;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import androidx.lifecycle.s;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import e1.o0;
import e1.o1;
import i1.m;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.Pair;
import o0.h0;
import q.g;
import top.niunaijun.blackboxa.view.apps.AppsFragment;
import top.niunaijun.blackboxa.view.main.MainActivity;

/* JADX INFO: loaded from: classes.dex */
public abstract class e extends o0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final s f1002d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final androidx.fragment.app.o0 f1003e;
    public final g f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final g f1004g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final g f1005h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public d f1006i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f1007j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f1008k;

    public e(MainActivity mainActivity) {
        androidx.fragment.app.o0 o0Var = ((y) mainActivity.f814s.f3b).f809r;
        s sVar = mainActivity.f138d;
        this.f = new g();
        this.f1004g = new g();
        this.f1005h = new g();
        this.f1007j = false;
        this.f1008k = false;
        this.f1003e = o0Var;
        this.f1002d = sVar;
        if (this.f1999a.a()) {
            throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
        }
        this.f2000b = true;
    }

    public static void m(View view, FrameLayout frameLayout) {
        if (frameLayout.getChildCount() > 1) {
            throw new IllegalStateException("Design assumption violated.");
        }
        if (view.getParent() == frameLayout) {
            return;
        }
        if (frameLayout.getChildCount() > 0) {
            frameLayout.removeAllViews();
        }
        if (view.getParent() != null) {
            ((ViewGroup) view.getParent()).removeView(view);
        }
        frameLayout.addView(view);
    }

    public static boolean n(long j4) {
        return j4 >= 0 && j4 < ((long) 4);
    }

    @Override // e1.o0
    public final long b(int i3) {
        return i3;
    }

    @Override // e1.o0
    public final void d(RecyclerView recyclerView) {
        if (this.f1006i != null) {
            throw new IllegalArgumentException();
        }
        final d dVar = new d(this);
        this.f1006i = dVar;
        ViewPager2 viewPager2A = d.a(recyclerView);
        dVar.f1000d = viewPager2A;
        b bVar = new b(0, dVar);
        dVar.f997a = bVar;
        ((ArrayList) viewPager2A.f1012c.f994b).add(bVar);
        c cVar = new c(0, dVar);
        dVar.f998b = cVar;
        this.f1999a.registerObserver(cVar);
        o oVar = new o() { // from class: androidx.viewpager2.adapter.FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3
            @Override // androidx.lifecycle.o
            public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
                dVar.b(false);
            }
        };
        dVar.f999c = oVar;
        this.f1002d.a(oVar);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // e1.o0
    public final void e(o1 o1Var, int i3) {
        w appsFragment;
        Bundle bundle;
        f fVar = (f) o1Var;
        long j4 = fVar.f2007e;
        FrameLayout frameLayout = (FrameLayout) fVar.f2003a;
        int id = frameLayout.getId();
        Long lP = p(id);
        g gVar = this.f1005h;
        if (lP != null && lP.longValue() != j4) {
            r(lP.longValue());
            gVar.i(lP.longValue());
        }
        gVar.h(j4, Integer.valueOf(id));
        long j5 = i3;
        g gVar2 = this.f;
        if (gVar2.f(j5) < 0) {
            if (i3 == 0) {
                appsFragment = new AppsFragment();
                appsFragment.M(m.e(new Pair("userID", 0)));
            } else if (i3 != 1) {
                appsFragment = i3 != 2 ? new top.niunaijun.blackboxa.view.setting.g() : new a4.e();
            } else {
                appsFragment = new top.niunaijun.blackboxa.view.list.m();
                appsFragment.M(m.e(new Pair("userID", 0)));
            }
            v vVar = (v) this.f1004g.d(j5);
            if (appsFragment.f790r != null) {
                throw new IllegalStateException("Fragment already added");
            }
            if (vVar == null || (bundle = vVar.f765a) == null) {
                bundle = null;
            }
            appsFragment.f775b = bundle;
            gVar2.h(j5, appsFragment);
        }
        WeakHashMap weakHashMap = h0.f3558a;
        if (frameLayout.isAttachedToWindow()) {
            if (frameLayout.getParent() != null) {
                throw new IllegalStateException("Design assumption violated.");
            }
            frameLayout.addOnLayoutChangeListener(new a(this, frameLayout, fVar));
        }
        o();
    }

    @Override // e1.o0
    public final o1 g(ViewGroup viewGroup, int i3) {
        int i4 = f.f1009u;
        FrameLayout frameLayout = new FrameLayout(viewGroup.getContext());
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        WeakHashMap weakHashMap = h0.f3558a;
        frameLayout.setId(View.generateViewId());
        frameLayout.setSaveEnabled(false);
        return new f(frameLayout);
    }

    @Override // e1.o0
    public final void h(RecyclerView recyclerView) {
        d dVar = this.f1006i;
        dVar.getClass();
        ViewPager2 viewPager2A = d.a(recyclerView);
        ((ArrayList) viewPager2A.f1012c.f994b).remove(dVar.f997a);
        e eVar = dVar.f;
        eVar.f1999a.unregisterObserver(dVar.f998b);
        eVar.f1002d.f(dVar.f999c);
        dVar.f1000d = null;
        this.f1006i = null;
    }

    @Override // e1.o0
    public final /* bridge */ /* synthetic */ boolean i(o1 o1Var) {
        return true;
    }

    @Override // e1.o0
    public final void j(o1 o1Var) {
        q((f) o1Var);
        o();
    }

    @Override // e1.o0
    public final void l(o1 o1Var) {
        Long lP = p(((FrameLayout) ((f) o1Var).f2003a).getId());
        if (lP != null) {
            r(lP.longValue());
            this.f1005h.i(lP.longValue());
        }
    }

    public final void o() {
        g gVar;
        g gVar2;
        w wVar;
        View view;
        if (!this.f1008k || this.f1003e.K()) {
            return;
        }
        q.f fVar = new q.f(0);
        int i3 = 0;
        while (true) {
            gVar = this.f;
            int iJ = gVar.j();
            gVar2 = this.f1005h;
            if (i3 >= iJ) {
                break;
            }
            long jG = gVar.g(i3);
            if (!n(jG)) {
                fVar.add(Long.valueOf(jG));
                gVar2.i(jG);
            }
            i3++;
        }
        if (!this.f1007j) {
            this.f1008k = false;
            for (int i4 = 0; i4 < gVar.j(); i4++) {
                long jG2 = gVar.g(i4);
                if (gVar2.f(jG2) < 0 && ((wVar = (w) gVar.d(jG2)) == null || (view = wVar.E) == null || view.getParent() == null)) {
                    fVar.add(Long.valueOf(jG2));
                }
            }
        }
        q.b bVar = new q.b(fVar);
        while (bVar.hasNext()) {
            r(((Long) bVar.next()).longValue());
        }
    }

    public final Long p(int i3) {
        Long lValueOf = null;
        int i4 = 0;
        while (true) {
            g gVar = this.f1005h;
            if (i4 >= gVar.j()) {
                return lValueOf;
            }
            if (((Integer) gVar.k(i4)).intValue() == i3) {
                if (lValueOf != null) {
                    throw new IllegalStateException("Design assumption violated: a ViewHolder can only be bound to one item at a time.");
                }
                lValueOf = Long.valueOf(gVar.g(i4));
            }
            i4++;
        }
    }

    public final void q(final f fVar) {
        w wVar = (w) this.f.d(fVar.f2007e);
        if (wVar == null) {
            throw new IllegalStateException("Design assumption violated.");
        }
        FrameLayout frameLayout = (FrameLayout) fVar.f2003a;
        View view = wVar.E;
        if (!wVar.r() && view != null) {
            throw new IllegalStateException("Design assumption violated.");
        }
        boolean zR = wVar.r();
        androidx.fragment.app.o0 o0Var = this.f1003e;
        if (zR && view == null) {
            ((CopyOnWriteArrayList) o0Var.f695l.f639a).add(new d0(new androidx.emoji2.text.q(this, wVar, frameLayout)));
            return;
        }
        if (wVar.r() && view.getParent() != null) {
            if (view.getParent() != frameLayout) {
                m(view, frameLayout);
                return;
            }
            return;
        }
        if (wVar.r()) {
            m(view, frameLayout);
            return;
        }
        if (o0Var.K()) {
            if (o0Var.G) {
                return;
            }
            this.f1002d.a(new o() { // from class: androidx.viewpager2.adapter.FragmentStateAdapter$2
                @Override // androidx.lifecycle.o
                public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
                    e eVar = this.f986b;
                    if (eVar.f1003e.K()) {
                        return;
                    }
                    qVar.e().f(this);
                    f fVar2 = fVar;
                    FrameLayout frameLayout2 = (FrameLayout) fVar2.f2003a;
                    WeakHashMap weakHashMap = h0.f3558a;
                    if (frameLayout2.isAttachedToWindow()) {
                        eVar.q(fVar2);
                    }
                }
            });
            return;
        }
        ((CopyOnWriteArrayList) o0Var.f695l.f639a).add(new d0(new androidx.emoji2.text.q(this, wVar, frameLayout)));
        androidx.fragment.app.a aVar = new androidx.fragment.app.a(o0Var);
        aVar.e(0, wVar, "f" + fVar.f2007e, 1);
        aVar.h(wVar, Lifecycle$State.f832d);
        aVar.d();
        this.f1006i.b(false);
    }

    public final void r(long j4) {
        Bundle bundleO;
        ViewParent parent;
        g gVar = this.f;
        w wVar = (w) gVar.d(j4);
        if (wVar == null) {
            return;
        }
        View view = wVar.E;
        if (view != null && (parent = view.getParent()) != null) {
            ((FrameLayout) parent).removeAllViews();
        }
        boolean zN = n(j4);
        g gVar2 = this.f1004g;
        if (!zN) {
            gVar2.i(j4);
        }
        if (!wVar.r()) {
            gVar.i(j4);
            return;
        }
        androidx.fragment.app.o0 o0Var = this.f1003e;
        if (o0Var.K()) {
            this.f1008k = true;
            return;
        }
        if (wVar.r() && n(j4)) {
            u0 u0Var = (u0) ((HashMap) o0Var.f687c.f23a).get(wVar.f778e);
            v vVar = null;
            if (u0Var != null) {
                w wVar2 = u0Var.f762c;
                if (wVar2.equals(wVar)) {
                    if (wVar2.f774a > -1 && (bundleO = u0Var.o()) != null) {
                        vVar = new v(bundleO);
                    }
                    gVar2.h(j4, vVar);
                }
            }
            o0Var.a0(new IllegalStateException("Fragment " + wVar + " is not currently in the FragmentManager"));
            throw null;
        }
        androidx.fragment.app.a aVar = new androidx.fragment.app.a(o0Var);
        aVar.g(wVar);
        aVar.d();
        gVar.i(j4);
    }

    public final void s(Parcelable parcelable) {
        g gVar = this.f1004g;
        if (gVar.j() == 0) {
            g gVar2 = this.f;
            if (gVar2.j() == 0) {
                Bundle bundle = (Bundle) parcelable;
                if (bundle.getClassLoader() == null) {
                    bundle.setClassLoader(getClass().getClassLoader());
                }
                for (String str : bundle.keySet()) {
                    if (str.startsWith("f#") && str.length() > 2) {
                        long j4 = Long.parseLong(str.substring(2));
                        androidx.fragment.app.o0 o0Var = this.f1003e;
                        o0Var.getClass();
                        String string = bundle.getString(str);
                        w wVar = null;
                        if (string != null) {
                            w wVarC = o0Var.f687c.c(string);
                            if (wVarC == null) {
                                o0Var.a0(new IllegalStateException("Fragment no longer exists for key " + str + ": unique id " + string));
                                throw null;
                            }
                            wVar = wVarC;
                        }
                        gVar2.h(j4, wVar);
                    } else {
                        if (!str.startsWith("s#") || str.length() <= 2) {
                            throw new IllegalArgumentException("Unexpected key in savedState: ".concat(str));
                        }
                        long j5 = Long.parseLong(str.substring(2));
                        v vVar = (v) bundle.getParcelable(str);
                        if (n(j5)) {
                            gVar.h(j5, vVar);
                        }
                    }
                }
                if (gVar2.j() == 0) {
                    return;
                }
                this.f1008k = true;
                this.f1007j = true;
                o();
                final Handler handler = new Handler(Looper.getMainLooper());
                final i iVar = new i(7, this);
                this.f1002d.a(new o() { // from class: androidx.viewpager2.adapter.FragmentStateAdapter$5
                    @Override // androidx.lifecycle.o
                    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
                        if (lifecycle$Event == Lifecycle$Event.ON_DESTROY) {
                            handler.removeCallbacks(iVar);
                            qVar.e().f(this);
                        }
                    }
                });
                handler.postDelayed(iVar, 10000L);
                return;
            }
        }
        throw new IllegalStateException("Expected the adapter to be 'fresh' while restoring state.");
    }
}
