package androidx.viewpager2.adapter;

import android.view.ViewParent;
import androidx.fragment.app.o0;
import androidx.fragment.app.w;
import androidx.lifecycle.Lifecycle$State;
import androidx.lifecycle.o;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import q.g;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public b f997a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public c f998b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public o f999c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ViewPager2 f1000d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f1001e = -1;
    public final /* synthetic */ e f;

    public d(e eVar) {
        this.f = eVar;
    }

    public static ViewPager2 a(RecyclerView recyclerView) {
        ViewParent parent = recyclerView.getParent();
        if (parent instanceof ViewPager2) {
            return (ViewPager2) parent;
        }
        throw new IllegalStateException("Expected ViewPager2 instance. Got: " + parent);
    }

    public final void b(boolean z4) {
        int currentItem;
        w wVar;
        e eVar = this.f;
        g gVar = eVar.f;
        o0 o0Var = eVar.f1003e;
        if (!o0Var.K() && this.f1000d.getScrollState() == 0 && gVar.j() != 0 && (currentItem = this.f1000d.getCurrentItem()) < 4) {
            long j4 = currentItem;
            if ((j4 != this.f1001e || z4) && (wVar = (w) gVar.d(j4)) != null && wVar.r()) {
                this.f1001e = j4;
                o0Var.getClass();
                androidx.fragment.app.a aVar = new androidx.fragment.app.a(o0Var);
                w wVar2 = null;
                for (int i3 = 0; i3 < gVar.j(); i3++) {
                    long jG = gVar.g(i3);
                    w wVar3 = (w) gVar.k(i3);
                    if (wVar3.r()) {
                        if (jG != this.f1001e) {
                            aVar.h(wVar3, Lifecycle$State.f832d);
                        } else {
                            wVar2 = wVar3;
                        }
                        boolean z5 = jG == this.f1001e;
                        if (wVar3.B != z5) {
                            wVar3.B = z5;
                        }
                    }
                }
                if (wVar2 != null) {
                    aVar.h(wVar2, Lifecycle$State.f833e);
                }
                if (aVar.f593a.isEmpty()) {
                    return;
                }
                aVar.d();
            }
        }
    }
}
