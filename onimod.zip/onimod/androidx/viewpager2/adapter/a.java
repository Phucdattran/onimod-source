package androidx.viewpager2.adapter;

import android.view.View;
import android.widget.FrameLayout;

/* JADX INFO: loaded from: classes.dex */
public final class a implements View.OnLayoutChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ FrameLayout f990a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ f f991b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ e f992c;

    public a(e eVar, FrameLayout frameLayout, f fVar) {
        this.f992c = eVar;
        this.f990a = frameLayout;
        this.f991b = fVar;
    }

    @Override // android.view.View.OnLayoutChangeListener
    public final void onLayoutChange(View view, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10) {
        FrameLayout frameLayout = this.f990a;
        if (frameLayout.getParent() != null) {
            frameLayout.removeOnLayoutChangeListener(this);
            this.f992c.q(this.f991b);
        }
    }
}
