package androidx.viewpager2.adapter;

import androidx.recyclerview.widget.RecyclerView;
import e1.m0;
import e1.q0;
import java.util.ArrayList;
import java.util.WeakHashMap;
import o0.h0;

/* JADX INFO: loaded from: classes.dex */
public final class c extends q0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f995a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f996b;

    public /* synthetic */ c(int i3, Object obj) {
        this.f995a = i3;
        this.f996b = obj;
    }

    @Override // e1.q0
    public final void a() {
        switch (this.f995a) {
            case 0:
                ((d) this.f996b).b(true);
                break;
            default:
                RecyclerView recyclerView = (RecyclerView) this.f996b;
                recyclerView.i(null);
                recyclerView.f933g0.f = true;
                recyclerView.V(true);
                if (!recyclerView.f927d.j()) {
                    recyclerView.requestLayout();
                }
                break;
        }
    }

    @Override // e1.q0
    public final void b(int i3, int i4) {
        switch (this.f995a) {
            case 0:
                a();
                break;
            default:
                RecyclerView recyclerView = (RecyclerView) this.f996b;
                recyclerView.i(null);
                e1.b bVar = recyclerView.f927d;
                ArrayList arrayList = (ArrayList) bVar.f1813c;
                if (i4 >= 1) {
                    arrayList.add(bVar.l(4, i3, i4));
                    bVar.f1811a |= 4;
                    if (arrayList.size() == 1) {
                        f();
                    }
                    break;
                }
                break;
        }
    }

    @Override // e1.q0
    public final void c(int i3, int i4) {
        switch (this.f995a) {
            case 0:
                a();
                break;
            default:
                RecyclerView recyclerView = (RecyclerView) this.f996b;
                recyclerView.i(null);
                e1.b bVar = recyclerView.f927d;
                ArrayList arrayList = (ArrayList) bVar.f1813c;
                if (i4 >= 1) {
                    arrayList.add(bVar.l(1, i3, i4));
                    bVar.f1811a |= 1;
                    if (arrayList.size() == 1) {
                        f();
                    }
                    break;
                }
                break;
        }
    }

    @Override // e1.q0
    public final void d(int i3, int i4) {
        switch (this.f995a) {
            case 0:
                a();
                break;
            default:
                RecyclerView recyclerView = (RecyclerView) this.f996b;
                recyclerView.i(null);
                e1.b bVar = recyclerView.f927d;
                ArrayList arrayList = (ArrayList) bVar.f1813c;
                if (i3 != i4) {
                    arrayList.add(bVar.l(8, i3, i4));
                    bVar.f1811a |= 8;
                    if (arrayList.size() == 1) {
                        f();
                    }
                    break;
                }
                break;
        }
    }

    @Override // e1.q0
    public final void e(int i3, int i4) {
        switch (this.f995a) {
            case 0:
                a();
                break;
            default:
                RecyclerView recyclerView = (RecyclerView) this.f996b;
                recyclerView.i(null);
                e1.b bVar = recyclerView.f927d;
                ArrayList arrayList = (ArrayList) bVar.f1813c;
                if (i4 >= 1) {
                    arrayList.add(bVar.l(2, i3, i4));
                    bVar.f1811a |= 2;
                    if (arrayList.size() == 1) {
                        f();
                    }
                    break;
                }
                break;
        }
    }

    public void f() {
        RecyclerView recyclerView = (RecyclerView) this.f996b;
        if (!RecyclerView.B0 || !recyclerView.f955s || !recyclerView.f953r) {
            recyclerView.f969z = true;
            recyclerView.requestLayout();
        } else {
            m0 m0Var = recyclerView.f934h;
            WeakHashMap weakHashMap = h0.f3558a;
            recyclerView.postOnAnimation(m0Var);
        }
    }
}
