package androidx.fragment.app;

import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: classes.dex */
public final class s extends u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ a0.b f726a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ AtomicReference f727b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ k0 f728c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ top.niunaijun.blackboxa.view.setting.d f729d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ top.niunaijun.blackboxa.view.setting.g f730e;

    public s(top.niunaijun.blackboxa.view.setting.g gVar, a0.b bVar, AtomicReference atomicReference, k0 k0Var, top.niunaijun.blackboxa.view.setting.d dVar) {
        this.f730e = gVar;
        this.f726a = bVar;
        this.f727b = atomicReference;
        this.f728c = k0Var;
        this.f729d = dVar;
    }

    @Override // androidx.fragment.app.u
    public final void a() {
        StringBuilder sb = new StringBuilder("fragment_");
        top.niunaijun.blackboxa.view.setting.g gVar = this.f730e;
        sb.append(gVar.f778e);
        sb.append("_rq#");
        sb.append(gVar.R.getAndIncrement());
        String string = sb.toString();
        top.niunaijun.blackboxa.view.setting.g gVar2 = (top.niunaijun.blackboxa.view.setting.g) this.f726a.f3b;
        y yVar = gVar2.f791s;
        this.f727b.set((yVar != null ? yVar.f810s.f144k : gVar2.I().f144k).d(string, gVar, this.f728c, this.f729d));
    }
}
