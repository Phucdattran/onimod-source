package androidx.fragment.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import java.io.PrintWriter;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public class o extends w implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
    public final k V;
    public final l W;
    public int X;
    public int Y;
    public boolean Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public boolean f677a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public int f678b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public boolean f679c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public final m f680d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public Dialog f681e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public boolean f682f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public boolean f683g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public boolean f684h0;

    public o() {
        new a2.i(4, this);
        this.V = new k(this);
        this.W = new l(this);
        this.X = 0;
        this.Y = 0;
        this.Z = true;
        this.f677a0 = true;
        this.f678b0 = -1;
        this.f680d0 = new m(this);
        this.f684h0 = false;
    }

    @Override // androidx.fragment.app.w
    public final LayoutInflater A(Bundle bundle) {
        LayoutInflater layoutInflaterA = super.A(bundle);
        boolean z4 = this.f677a0;
        if (z4 && !this.f679c0) {
            if (z4 && !this.f684h0) {
                try {
                    this.f679c0 = true;
                    Dialog dialogO = O();
                    this.f681e0 = dialogO;
                    if (this.f677a0) {
                        int i3 = this.X;
                        if (i3 == 1 || i3 == 2) {
                            dialogO.requestWindowFeature(1);
                        } else if (i3 == 3) {
                            Window window = dialogO.getWindow();
                            if (window != null) {
                                window.addFlags(24);
                            }
                            dialogO.requestWindowFeature(1);
                        }
                        Context contextI = i();
                        if (g0.e.g(contextI)) {
                            this.f681e0.setOwnerActivity((Activity) contextI);
                        }
                        this.f681e0.setCancelable(this.Z);
                        this.f681e0.setOnCancelListener(this.V);
                        this.f681e0.setOnDismissListener(this.W);
                        this.f684h0 = true;
                    } else {
                        this.f681e0 = null;
                    }
                    this.f679c0 = false;
                } catch (Throwable th) {
                    this.f679c0 = false;
                    throw th;
                }
            }
            if (o0.F(2)) {
                toString();
            }
            Dialog dialog = this.f681e0;
            if (dialog != null) {
                return layoutInflaterA.cloneInContext(dialog.getContext());
            }
        } else if (o0.F(2)) {
            toString();
        }
        return layoutInflaterA;
    }

    @Override // androidx.fragment.app.w
    public void C(Bundle bundle) {
        Dialog dialog = this.f681e0;
        if (dialog != null) {
            Bundle bundleOnSaveInstanceState = dialog.onSaveInstanceState();
            bundleOnSaveInstanceState.putBoolean("android:dialogShowing", false);
            bundle.putBundle("android:savedDialogState", bundleOnSaveInstanceState);
        }
        int i3 = this.X;
        if (i3 != 0) {
            bundle.putInt("android:style", i3);
        }
        int i4 = this.Y;
        if (i4 != 0) {
            bundle.putInt("android:theme", i4);
        }
        boolean z4 = this.Z;
        if (!z4) {
            bundle.putBoolean("android:cancelable", z4);
        }
        boolean z5 = this.f677a0;
        if (!z5) {
            bundle.putBoolean("android:showsDialog", z5);
        }
        int i5 = this.f678b0;
        if (i5 != -1) {
            bundle.putInt("android:backStackId", i5);
        }
    }

    @Override // androidx.fragment.app.w
    public void D() {
        this.C = true;
        Dialog dialog = this.f681e0;
        if (dialog != null) {
            this.f682f0 = false;
            dialog.show();
            View decorView = this.f681e0.getWindow().getDecorView();
            androidx.lifecycle.f0.e(decorView, this);
            decorView.setTag(R.id.view_tree_view_model_store_owner, this);
            a3.a.d0(decorView, this);
        }
    }

    @Override // androidx.fragment.app.w
    public void E() {
        this.C = true;
        Dialog dialog = this.f681e0;
        if (dialog != null) {
            dialog.hide();
        }
    }

    @Override // androidx.fragment.app.w
    public final void G(Bundle bundle) {
        Bundle bundle2;
        this.C = true;
        if (this.f681e0 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.f681e0.onRestoreInstanceState(bundle2);
    }

    @Override // androidx.fragment.app.w
    public final void H(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Bundle bundle2;
        super.H(layoutInflater, viewGroup, bundle);
        if (this.E != null || this.f681e0 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.f681e0.onRestoreInstanceState(bundle2);
    }

    public Dialog O() {
        if (o0.F(3)) {
            toString();
        }
        return new androidx.activity.m(J(), this.Y);
    }

    @Override // androidx.fragment.app.w
    public final a3.a d() {
        return new n(this, new r(this));
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialogInterface) {
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        if (this.f682f0) {
            return;
        }
        if (o0.F(3)) {
            toString();
        }
        if (this.f683g0) {
            return;
        }
        this.f683g0 = true;
        Dialog dialog = this.f681e0;
        if (dialog != null) {
            dialog.setOnDismissListener(null);
            this.f681e0.dismiss();
        }
        this.f682f0 = true;
        if (this.f678b0 >= 0) {
            o0 o0VarK = k();
            int i3 = this.f678b0;
            if (i3 < 0) {
                throw new IllegalArgumentException(g0.e.b(i3, "Bad id: "));
            }
            o0VarK.v(new n0(o0VarK, i3), true);
            this.f678b0 = -1;
            return;
        }
        a aVar = new a(k());
        aVar.f606o = true;
        aVar.g(this);
        if (aVar.f608q) {
            throw new IllegalStateException("commit already called");
        }
        if (o0.F(2)) {
            aVar.toString();
            PrintWriter printWriter = new PrintWriter(new x0());
            aVar.f("  ", printWriter, true);
            printWriter.close();
        }
        aVar.f608q = true;
        boolean z4 = aVar.f598g;
        o0 o0Var = aVar.f607p;
        if (z4) {
            aVar.f609r = o0Var.f692i.getAndIncrement();
        } else {
            aVar.f609r = -1;
        }
        o0Var.v(aVar, true);
    }

    @Override // androidx.fragment.app.w
    public final void u() {
        this.C = true;
    }

    @Override // androidx.fragment.app.w
    public final void v(Context context) {
        super.v(context);
        this.P.e(this.f680d0);
        this.f683g0 = false;
    }

    @Override // androidx.fragment.app.w
    public void w(Bundle bundle) {
        super.w(bundle);
        new Handler();
        this.f677a0 = this.f795w == 0;
        if (bundle != null) {
            this.X = bundle.getInt("android:style", 0);
            this.Y = bundle.getInt("android:theme", 0);
            this.Z = bundle.getBoolean("android:cancelable", true);
            this.f677a0 = bundle.getBoolean("android:showsDialog", this.f677a0);
            this.f678b0 = bundle.getInt("android:backStackId", -1);
        }
    }

    @Override // androidx.fragment.app.w
    public final void y() {
        this.C = true;
        Dialog dialog = this.f681e0;
        if (dialog != null) {
            this.f682f0 = true;
            dialog.setOnDismissListener(null);
            this.f681e0.dismiss();
            if (!this.f683g0) {
                onDismiss(this.f681e0);
            }
            this.f681e0 = null;
            this.f684h0 = false;
        }
    }

    @Override // androidx.fragment.app.w
    public final void z() {
        this.C = true;
        if (!this.f683g0) {
            this.f683g0 = true;
        }
        androidx.lifecycle.w wVar = this.P;
        wVar.getClass();
        androidx.lifecycle.w.a("removeObserver");
        androidx.lifecycle.v vVar = (androidx.lifecycle.v) wVar.f892b.b(this.f680d0);
        if (vVar == null) {
            return;
        }
        vVar.d();
        vVar.c(false);
    }
}
