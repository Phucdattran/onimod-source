package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class c implements Parcelable {
    public static final Parcelable.Creator<c> CREATOR = new androidx.activity.result.a(3);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f630a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f631b;

    public c(Parcel parcel) {
        this.f630a = parcel.createStringArrayList();
        this.f631b = parcel.createTypedArrayList(b.CREATOR);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i3) {
        parcel.writeStringList(this.f630a);
        parcel.writeTypedList(this.f631b);
    }
}
