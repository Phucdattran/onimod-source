package androidx.fragment.app;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class y0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f811a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ z0 f812b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f813c;

    public /* synthetic */ y0(j jVar, z0 z0Var, int i3) {
        this.f811a = i3;
        this.f813c = jVar;
        this.f812b = z0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f811a) {
            case 0:
                ArrayList arrayList = ((j) this.f813c).f662b;
                z0 z0Var = this.f812b;
                if (arrayList.contains(z0Var)) {
                    z0Var.f819a.a(z0Var.f821c.E);
                }
                break;
            case 1:
                j jVar = (j) this.f813c;
                ArrayList arrayList2 = jVar.f662b;
                z0 z0Var2 = this.f812b;
                arrayList2.remove(z0Var2);
                jVar.f663c.remove(z0Var2);
                break;
            default:
                ArrayList arrayList3 = (ArrayList) this.f813c;
                z0 z0Var3 = this.f812b;
                if (arrayList3.contains(z0Var3)) {
                    arrayList3.remove(z0Var3);
                    z0Var3.f819a.a(z0Var3.f821c.E);
                }
                break;
        }
    }

    public y0(j jVar, ArrayList arrayList, z0 z0Var) {
        this.f811a = 2;
        this.f813c = arrayList;
        this.f812b = z0Var;
    }
}
