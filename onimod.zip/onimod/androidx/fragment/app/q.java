package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
public final class q extends u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ w f718a;

    public q(w wVar) {
        this.f718a = wVar;
    }

    @Override // androidx.fragment.app.u
    public final void a() {
        w wVar = this.f718a;
        wVar.Q.a();
        androidx.lifecycle.f0.b(wVar);
    }
}
