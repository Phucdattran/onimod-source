package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
public final class h0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ o0 f658a;

    public h0(o0 o0Var) {
        this.f658a = o0Var;
    }
}
