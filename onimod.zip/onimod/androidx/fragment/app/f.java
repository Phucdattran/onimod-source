package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class f implements Animation.AnimationListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ z0 f643a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ViewGroup f644b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f645c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ g f646d;

    public f(z0 z0Var, ViewGroup viewGroup, View view, g gVar) {
        this.f643a = z0Var;
        this.f644b = viewGroup;
        this.f645c = view;
        this.f646d = gVar;
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationEnd(Animation animation) {
        this.f644b.post(new a2.i(3, this));
        if (o0.F(2)) {
            Objects.toString(this.f643a);
        }
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationRepeat(Animation animation) {
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationStart(Animation animation) {
        if (o0.F(2)) {
            Objects.toString(this.f643a);
        }
    }
}
