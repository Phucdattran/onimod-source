package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new androidx.activity.result.a(2);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int[] f615a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f616b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int[] f617c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int[] f618d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f619e;
    public final String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f620g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f621h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final CharSequence f622i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f623j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final CharSequence f624k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final ArrayList f625l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ArrayList f626m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final boolean f627n;

    public b(a aVar) {
        int size = aVar.f593a.size();
        this.f615a = new int[size * 6];
        if (!aVar.f598g) {
            throw new IllegalStateException("Not on back stack");
        }
        this.f616b = new ArrayList(size);
        this.f617c = new int[size];
        this.f618d = new int[size];
        int i3 = 0;
        for (int i4 = 0; i4 < size; i4++) {
            v0 v0Var = (v0) aVar.f593a.get(i4);
            int i5 = i3 + 1;
            this.f615a[i3] = v0Var.f766a;
            ArrayList arrayList = this.f616b;
            w wVar = v0Var.f767b;
            arrayList.add(wVar != null ? wVar.f778e : null);
            int[] iArr = this.f615a;
            iArr[i5] = v0Var.f768c ? 1 : 0;
            iArr[i3 + 2] = v0Var.f769d;
            iArr[i3 + 3] = v0Var.f770e;
            int i6 = i3 + 5;
            iArr[i3 + 4] = v0Var.f;
            i3 += 6;
            iArr[i6] = v0Var.f771g;
            this.f617c[i4] = v0Var.f772h.ordinal();
            this.f618d[i4] = v0Var.f773i.ordinal();
        }
        this.f619e = aVar.f;
        this.f = aVar.f599h;
        this.f620g = aVar.f609r;
        this.f621h = aVar.f600i;
        this.f622i = aVar.f601j;
        this.f623j = aVar.f602k;
        this.f624k = aVar.f603l;
        this.f625l = aVar.f604m;
        this.f626m = aVar.f605n;
        this.f627n = aVar.f606o;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i3) {
        parcel.writeIntArray(this.f615a);
        parcel.writeStringList(this.f616b);
        parcel.writeIntArray(this.f617c);
        parcel.writeIntArray(this.f618d);
        parcel.writeInt(this.f619e);
        parcel.writeString(this.f);
        parcel.writeInt(this.f620g);
        parcel.writeInt(this.f621h);
        TextUtils.writeToParcel(this.f622i, parcel, 0);
        parcel.writeInt(this.f623j);
        TextUtils.writeToParcel(this.f624k, parcel, 0);
        parcel.writeStringList(this.f625l);
        parcel.writeStringList(this.f626m);
        parcel.writeInt(this.f627n ? 1 : 0);
    }

    public b(Parcel parcel) {
        this.f615a = parcel.createIntArray();
        this.f616b = parcel.createStringArrayList();
        this.f617c = parcel.createIntArray();
        this.f618d = parcel.createIntArray();
        this.f619e = parcel.readInt();
        this.f = parcel.readString();
        this.f620g = parcel.readInt();
        this.f621h = parcel.readInt();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.f622i = (CharSequence) creator.createFromParcel(parcel);
        this.f623j = parcel.readInt();
        this.f624k = (CharSequence) creator.createFromParcel(parcel);
        this.f625l = parcel.createStringArrayList();
        this.f626m = parcel.createStringArrayList();
        this.f627n = parcel.readInt() != 0;
    }
}
