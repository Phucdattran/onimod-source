package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
public final class j0 implements r0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ w f666a;

    public j0(w wVar) {
        this.f666a = wVar;
    }

    @Override // androidx.fragment.app.r0
    public final void a() {
        this.f666a.getClass();
    }
}
