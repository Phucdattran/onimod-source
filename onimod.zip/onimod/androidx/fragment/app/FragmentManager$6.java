package androidx.fragment.app;

import androidx.lifecycle.Lifecycle$Event;

/* JADX INFO: loaded from: classes.dex */
class FragmentManager$6 implements androidx.lifecycle.o {
    @Override // androidx.lifecycle.o
    public final void a(androidx.lifecycle.q qVar, Lifecycle$Event lifecycle$Event) {
        if (lifecycle$Event == Lifecycle$Event.ON_START || lifecycle$Event == Lifecycle$Event.ON_DESTROY) {
            throw null;
        }
    }
}
