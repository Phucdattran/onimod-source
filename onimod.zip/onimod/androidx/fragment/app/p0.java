package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class p0 implements Parcelable {
    public static final Parcelable.Creator<p0> CREATOR = new androidx.activity.result.a(5);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ArrayList f711a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList f712b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public b[] f713c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f714d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f715e;
    public ArrayList f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ArrayList f716g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ArrayList f717h;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i3) {
        parcel.writeStringList(this.f711a);
        parcel.writeStringList(this.f712b);
        parcel.writeTypedArray(this.f713c, i3);
        parcel.writeInt(this.f714d);
        parcel.writeString(this.f715e);
        parcel.writeStringList(this.f);
        parcel.writeTypedList(this.f716g);
        parcel.writeTypedList(this.f717h);
    }
}
