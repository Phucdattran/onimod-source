package androidx.fragment.app;

import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: classes.dex */
public final class i0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final q.i f659b = new q.i(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ o0 f660a;

    public i0(o0 o0Var) {
        this.f660a = o0Var;
    }

    public static Class b(String str, ClassLoader classLoader) throws ClassNotFoundException {
        q.i iVar = f659b;
        q.i iVar2 = (q.i) iVar.get(classLoader);
        if (iVar2 == null) {
            iVar2 = new q.i(0);
            iVar.put(classLoader, iVar2);
        }
        Class cls = (Class) iVar2.get(str);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        iVar2.put(str, cls2);
        return cls2;
    }

    public static Class c(String str, ClassLoader classLoader) {
        try {
            return b(str, classLoader);
        } catch (ClassCastException e4) {
            throw new Fragment$InstantiationException(g0.e.d("Unable to instantiate fragment ", str, ": make sure class is a valid subclass of Fragment"), e4);
        } catch (ClassNotFoundException e5) {
            throw new Fragment$InstantiationException(g0.e.d("Unable to instantiate fragment ", str, ": make sure class name exists"), e5);
        }
    }

    public final w a(String str) {
        try {
            return (w) c(str, this.f660a.f703t.f807p.getClassLoader()).getConstructor(null).newInstance(null);
        } catch (IllegalAccessException e4) {
            throw new Fragment$InstantiationException(g0.e.d("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e4);
        } catch (InstantiationException e5) {
            throw new Fragment$InstantiationException(g0.e.d("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e5);
        } catch (NoSuchMethodException e6) {
            throw new Fragment$InstantiationException(g0.e.d("Unable to instantiate fragment ", str, ": could not find Fragment constructor"), e6);
        } catch (InvocationTargetException e7) {
            throw new Fragment$InstantiationException(g0.e.d("Unable to instantiate fragment ", str, ": calling Fragment constructor caused an exception"), e7);
        }
    }
}
