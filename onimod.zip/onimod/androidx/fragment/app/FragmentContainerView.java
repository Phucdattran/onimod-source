package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import com.mod.menu.ModConfig;
import java.util.ArrayList;
import java.util.WeakHashMap;
import o0.f1;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentContainerView extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f580a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f581b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public View.OnApplyWindowInsetsListener f582c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f583d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet) {
        String str;
        super(context, attributeSet, 0);
        kotlin.jvm.internal.d.f(context, "context");
        this.f580a = new ArrayList();
        this.f581b = new ArrayList();
        this.f583d = true;
        if (attributeSet != null) {
            String classAttribute = attributeSet.getClassAttribute();
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, x0.a.f4733b, 0, 0);
            if (classAttribute == null) {
                classAttribute = typedArrayObtainStyledAttributes.getString(0);
                str = "android:name";
            } else {
                str = "class";
            }
            typedArrayObtainStyledAttributes.recycle();
            if (classAttribute == null || isInEditMode()) {
                return;
            }
            throw new UnsupportedOperationException("FragmentContainerView must be within a FragmentActivity to use " + str + "=\"" + classAttribute + '\"');
        }
    }

    public final void a(View view) {
        if (this.f581b.contains(view)) {
            this.f580a.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View child, int i3, ViewGroup.LayoutParams layoutParams) {
        kotlin.jvm.internal.d.f(child, "child");
        Object tag = child.getTag(R.id.fragment_container_view_tag);
        if ((tag instanceof w ? (w) tag : null) != null) {
            super.addView(child, i3, layoutParams);
            return;
        }
        throw new IllegalStateException(("Views added to a FragmentContainerView must be associated with a Fragment. View " + child + " is not associated with a Fragment.").toString());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final WindowInsets dispatchApplyWindowInsets(WindowInsets insets) {
        f1 f1VarG;
        kotlin.jvm.internal.d.f(insets, "insets");
        f1 f1VarG2 = f1.g(null, insets);
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.f582c;
        if (onApplyWindowInsetsListener != null) {
            WindowInsets windowInsetsOnApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(this, insets);
            kotlin.jvm.internal.d.e(windowInsetsOnApplyWindowInsets, "onApplyWindowInsetsListe…lyWindowInsets(v, insets)");
            f1VarG = f1.g(null, windowInsetsOnApplyWindowInsets);
        } else {
            WeakHashMap weakHashMap = o0.h0.f3558a;
            WindowInsets windowInsetsF = f1VarG2.f();
            if (windowInsetsF != null) {
                WindowInsets windowInsetsB = o0.x.b(this, windowInsetsF);
                if (!windowInsetsB.equals(windowInsetsF)) {
                    f1VarG2 = f1.g(this, windowInsetsB);
                }
            }
            f1VarG = f1VarG2;
        }
        if (!f1VarG.f3545a.m()) {
            int childCount = getChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                WeakHashMap weakHashMap2 = o0.h0.f3558a;
                WindowInsets windowInsetsF2 = f1VarG.f();
                if (windowInsetsF2 != null) {
                    WindowInsets windowInsetsA = o0.x.a(childAt, windowInsetsF2);
                    if (!windowInsetsA.equals(windowInsetsF2)) {
                        f1.g(childAt, windowInsetsA);
                    }
                }
            }
        }
        return insets;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        kotlin.jvm.internal.d.f(canvas, "canvas");
        if (this.f583d) {
            ArrayList arrayList = this.f580a;
            int size = arrayList.size();
            int i3 = 0;
            while (i3 < size) {
                Object obj = arrayList.get(i3);
                i3++;
                super.drawChild(canvas, (View) obj, getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View child, long j4) {
        kotlin.jvm.internal.d.f(canvas, "canvas");
        kotlin.jvm.internal.d.f(child, "child");
        if (this.f583d) {
            ArrayList arrayList = this.f580a;
            if (!arrayList.isEmpty() && arrayList.contains(child)) {
                return false;
            }
        }
        return super.drawChild(canvas, child, j4);
    }

    @Override // android.view.ViewGroup
    public final void endViewTransition(View view) {
        kotlin.jvm.internal.d.f(view, "view");
        this.f581b.remove(view);
        if (this.f580a.remove(view)) {
            this.f583d = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends w> F getFragment() {
        z zVar;
        w wVar;
        o0 o0VarH;
        View view = this;
        while (true) {
            zVar = null;
            if (view == null) {
                wVar = null;
                break;
            }
            Object tag = view.getTag(R.id.fragment_container_view_tag);
            wVar = tag instanceof w ? (w) tag : null;
            if (wVar != null) {
                break;
            }
            Object parent = view.getParent();
            view = parent instanceof View ? (View) parent : null;
        }
        if (wVar == null) {
            for (Context context = getContext(); context instanceof ContextWrapper; context = ((ContextWrapper) context).getBaseContext()) {
                if (context instanceof z) {
                    zVar = (z) context;
                    break;
                }
            }
            if (zVar == null) {
                throw new IllegalStateException("View " + this + " is not within a subclass of FragmentActivity.");
            }
            o0VarH = ((y) zVar.f814s.f3b).f809r;
        } else {
            if (!wVar.r()) {
                throw new IllegalStateException("The Fragment " + wVar + " that owns View " + this + " has already been destroyed. Nested fragments should always use the child FragmentManager.");
            }
            o0VarH = wVar.h();
        }
        return (F) o0VarH.A(getId());
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets insets) {
        kotlin.jvm.internal.d.f(insets, "insets");
        return insets;
    }

    @Override // android.view.ViewGroup
    public final void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 >= childCount) {
                super.removeAllViewsInLayout();
                return;
            } else {
                View view = getChildAt(childCount);
                kotlin.jvm.internal.d.e(view, "view");
                a(view);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void removeView(View view) {
        kotlin.jvm.internal.d.f(view, "view");
        a(view);
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViewAt(int i3) {
        View view = getChildAt(i3);
        kotlin.jvm.internal.d.e(view, "view");
        a(view);
        super.removeViewAt(i3);
    }

    @Override // android.view.ViewGroup
    public final void removeViewInLayout(View view) {
        kotlin.jvm.internal.d.f(view, "view");
        a(view);
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViews(int i3, int i4) {
        int i5 = i3 + i4;
        for (int i6 = i3; i6 < i5; i6++) {
            View view = getChildAt(i6);
            kotlin.jvm.internal.d.e(view, "view");
            a(view);
        }
        super.removeViews(i3, i4);
    }

    @Override // android.view.ViewGroup
    public final void removeViewsInLayout(int i3, int i4) {
        int i5 = i3 + i4;
        for (int i6 = i3; i6 < i5; i6++) {
            View view = getChildAt(i6);
            kotlin.jvm.internal.d.e(view, "view");
            a(view);
        }
        super.removeViewsInLayout(i3, i4);
    }

    public final void setDrawDisappearingViewsLast(boolean z4) {
        this.f583d = z4;
    }

    @Override // android.view.ViewGroup
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    @Override // android.view.View
    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener listener) {
        kotlin.jvm.internal.d.f(listener, "listener");
        this.f582c = listener;
    }

    @Override // android.view.ViewGroup
    public final void startViewTransition(View view) {
        kotlin.jvm.internal.d.f(view, "view");
        if (view.getParent() == this) {
            this.f581b.add(view);
        }
        super.startViewTransition(view);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attrs, o0 o0Var) {
        View view;
        super(context, attrs);
        kotlin.jvm.internal.d.f(context, "context");
        kotlin.jvm.internal.d.f(attrs, "attrs");
        this.f580a = new ArrayList();
        this.f581b = new ArrayList();
        this.f583d = true;
        String classAttribute = attrs.getClassAttribute();
        int i3 = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attrs, x0.a.f4733b, 0, 0);
        classAttribute = classAttribute == null ? typedArrayObtainStyledAttributes.getString(0) : classAttribute;
        String string = typedArrayObtainStyledAttributes.getString(1);
        typedArrayObtainStyledAttributes.recycle();
        int id = getId();
        w wVarA = o0Var.A(id);
        if (classAttribute != null && wVarA == null) {
            if (id == -1) {
                throw new IllegalStateException(g0.e.d("FragmentContainerView must have an android:id to add Fragment ", classAttribute, string != null ? " with tag ".concat(string) : ModConfig.PREFIX));
            }
            i0 i0VarD = o0Var.D();
            context.getClassLoader();
            w wVarA2 = i0VarD.a(classAttribute);
            kotlin.jvm.internal.d.e(wVarA2, "fm.fragmentFactory.insta…ontext.classLoader, name)");
            wVarA2.C = true;
            y yVar = wVarA2.f791s;
            if ((yVar == null ? null : yVar.f806o) != null) {
                wVarA2.C = true;
            }
            a aVar = new a(o0Var);
            aVar.f606o = true;
            wVarA2.D = this;
            aVar.e(getId(), wVarA2, string, 1);
            if (!aVar.f598g) {
                aVar.f607p.y(aVar, true);
            } else {
                throw new IllegalStateException("This transaction is already being added to the back stack");
            }
        }
        ArrayList arrayListF = o0Var.f687c.f();
        int size = arrayListF.size();
        while (i3 < size) {
            Object obj = arrayListF.get(i3);
            i3++;
            u0 u0Var = (u0) obj;
            w wVar = u0Var.f762c;
            if (wVar.f795w == getId() && (view = wVar.E) != null && view.getParent() == null) {
                wVar.D = this;
                u0Var.b();
            }
        }
    }
}
