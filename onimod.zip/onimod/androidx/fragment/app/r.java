package androidx.fragment.app;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class r extends a3.a {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ w f725o;

    public r(w wVar) {
        this.f725o = wVar;
    }

    @Override // a3.a
    public final View U(int i3) {
        w wVar = this.f725o;
        View view = wVar.E;
        if (view != null) {
            return view.findViewById(i3);
        }
        throw new IllegalStateException("Fragment " + wVar + " does not have a view");
    }

    @Override // a3.a
    public final boolean V() {
        return this.f725o.E != null;
    }
}
