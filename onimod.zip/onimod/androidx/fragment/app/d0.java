package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
public final class d0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final androidx.emoji2.text.q f638a;

    public d0(androidx.emoji2.text.q qVar) {
        this.f638a = qVar;
    }
}
