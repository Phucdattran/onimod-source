package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.strictmode.FragmentStrictMode$Flag;
import androidx.fragment.app.strictmode.FragmentTagUsageViolation;

/* JADX INFO: loaded from: classes.dex */
public final class c0 implements LayoutInflater.Factory2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final o0 f632a;

    public c0(o0 o0Var) {
        this.f632a = o0Var;
    }

    @Override // android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    @Override // android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        boolean zIsAssignableFrom;
        u0 u0VarF;
        boolean zEquals = FragmentContainerView.class.getName().equals(str);
        o0 o0Var = this.f632a;
        if (zEquals) {
            return new FragmentContainerView(context, attributeSet, o0Var);
        }
        if ("fragment".equals(str)) {
            String attributeValue = attributeSet.getAttributeValue(null, "class");
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, x0.a.f4732a);
            if (attributeValue == null) {
                attributeValue = typedArrayObtainStyledAttributes.getString(0);
            }
            int resourceId = typedArrayObtainStyledAttributes.getResourceId(1, -1);
            String string = typedArrayObtainStyledAttributes.getString(2);
            typedArrayObtainStyledAttributes.recycle();
            if (attributeValue != null) {
                try {
                    zIsAssignableFrom = w.class.isAssignableFrom(i0.b(attributeValue, context.getClassLoader()));
                } catch (ClassNotFoundException unused) {
                    zIsAssignableFrom = false;
                }
                if (zIsAssignableFrom) {
                    int id = view != null ? view.getId() : 0;
                    if (id == -1 && resourceId == -1 && string == null) {
                        throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
                    }
                    w wVarA = resourceId != -1 ? o0Var.A(resourceId) : null;
                    if (wVarA == null && string != null) {
                        wVarA = o0Var.B(string);
                    }
                    if (wVarA == null && id != -1) {
                        wVarA = o0Var.A(id);
                    }
                    if (wVarA == null) {
                        i0 i0VarD = o0Var.D();
                        context.getClassLoader();
                        wVarA = i0VarD.a(attributeValue);
                        wVarA.f785m = true;
                        wVarA.f794v = resourceId != 0 ? resourceId : id;
                        wVarA.f795w = id;
                        wVarA.f796x = string;
                        wVarA.f786n = true;
                        wVarA.f790r = o0Var;
                        y yVar = o0Var.f703t;
                        wVarA.f791s = yVar;
                        e.n nVar = yVar.f807p;
                        wVarA.C = true;
                        if ((yVar != null ? yVar.f806o : null) != null) {
                            wVarA.C = true;
                        }
                        u0VarF = o0Var.a(wVarA);
                        if (o0.F(2)) {
                            wVarA.toString();
                            Integer.toHexString(resourceId);
                        }
                    } else {
                        if (wVarA.f786n) {
                            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + attributeValue);
                        }
                        wVarA.f786n = true;
                        wVarA.f790r = o0Var;
                        y yVar2 = o0Var.f703t;
                        wVarA.f791s = yVar2;
                        e.n nVar2 = yVar2.f807p;
                        wVarA.C = true;
                        if ((yVar2 != null ? yVar2.f806o : null) != null) {
                            wVarA.C = true;
                        }
                        u0VarF = o0Var.f(wVarA);
                        if (o0.F(2)) {
                            wVarA.toString();
                            Integer.toHexString(resourceId);
                        }
                    }
                    ViewGroup viewGroup = (ViewGroup) view;
                    y0.a aVar = y0.b.f4907a;
                    FragmentTagUsageViolation fragmentTagUsageViolation = new FragmentTagUsageViolation(wVarA, viewGroup);
                    if (o0.F(3)) {
                        fragmentTagUsageViolation.a().getClass();
                    }
                    y0.a aVarA = y0.b.a(wVarA);
                    if (aVarA.f4905a.contains(FragmentStrictMode$Flag.f746d) && y0.b.d(aVarA, wVarA.getClass(), FragmentTagUsageViolation.class)) {
                        y0.b.b(aVarA, fragmentTagUsageViolation);
                    }
                    wVarA.D = viewGroup;
                    u0VarF.k();
                    u0VarF.j();
                    View view2 = wVarA.E;
                    if (view2 == null) {
                        throw new IllegalStateException(g0.e.d("Fragment ", attributeValue, " did not create a view."));
                    }
                    if (resourceId != 0) {
                        view2.setId(resourceId);
                    }
                    if (wVarA.E.getTag() == null) {
                        wVarA.E.setTag(string);
                    }
                    wVarA.E.addOnAttachStateChangeListener(new b0(this, u0VarF));
                    return wVarA.E;
                }
            }
        }
        return null;
    }
}
