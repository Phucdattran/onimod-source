package androidx.fragment.app.strictmode;

import androidx.fragment.app.w;
import kotlin.jvm.internal.d;

/* JADX INFO: loaded from: classes.dex */
public abstract class Violation extends RuntimeException {
    private final w fragment;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Violation(w fragment, String str) {
        super(str);
        d.f(fragment, "fragment");
        this.fragment = fragment;
    }

    public final w a() {
        return this.fragment;
    }
}
