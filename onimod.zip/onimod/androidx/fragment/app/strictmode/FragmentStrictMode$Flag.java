package androidx.fragment.app.strictmode;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class FragmentStrictMode$Flag {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final FragmentStrictMode$Flag f743a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final FragmentStrictMode$Flag f744b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final FragmentStrictMode$Flag f745c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final FragmentStrictMode$Flag f746d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final FragmentStrictMode$Flag f747e;
    public static final /* synthetic */ FragmentStrictMode$Flag[] f;

    static {
        FragmentStrictMode$Flag fragmentStrictMode$Flag = new FragmentStrictMode$Flag("PENALTY_LOG", 0);
        f743a = fragmentStrictMode$Flag;
        FragmentStrictMode$Flag fragmentStrictMode$Flag2 = new FragmentStrictMode$Flag("PENALTY_DEATH", 1);
        f744b = fragmentStrictMode$Flag2;
        FragmentStrictMode$Flag fragmentStrictMode$Flag3 = new FragmentStrictMode$Flag("DETECT_FRAGMENT_REUSE", 2);
        f745c = fragmentStrictMode$Flag3;
        FragmentStrictMode$Flag fragmentStrictMode$Flag4 = new FragmentStrictMode$Flag("DETECT_FRAGMENT_TAG_USAGE", 3);
        f746d = fragmentStrictMode$Flag4;
        FragmentStrictMode$Flag fragmentStrictMode$Flag5 = new FragmentStrictMode$Flag("DETECT_RETAIN_INSTANCE_USAGE", 4);
        FragmentStrictMode$Flag fragmentStrictMode$Flag6 = new FragmentStrictMode$Flag("DETECT_SET_USER_VISIBLE_HINT", 5);
        FragmentStrictMode$Flag fragmentStrictMode$Flag7 = new FragmentStrictMode$Flag("DETECT_TARGET_FRAGMENT_USAGE", 6);
        FragmentStrictMode$Flag fragmentStrictMode$Flag8 = new FragmentStrictMode$Flag("DETECT_WRONG_FRAGMENT_CONTAINER", 7);
        f747e = fragmentStrictMode$Flag8;
        f = new FragmentStrictMode$Flag[]{fragmentStrictMode$Flag, fragmentStrictMode$Flag2, fragmentStrictMode$Flag3, fragmentStrictMode$Flag4, fragmentStrictMode$Flag5, fragmentStrictMode$Flag6, fragmentStrictMode$Flag7, fragmentStrictMode$Flag8};
    }

    public static FragmentStrictMode$Flag valueOf(String str) {
        return (FragmentStrictMode$Flag) Enum.valueOf(FragmentStrictMode$Flag.class, str);
    }

    public static FragmentStrictMode$Flag[] values() {
        return (FragmentStrictMode$Flag[]) f.clone();
    }
}
