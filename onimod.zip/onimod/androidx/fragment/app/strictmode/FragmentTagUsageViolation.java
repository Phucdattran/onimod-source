package androidx.fragment.app.strictmode;

import android.view.ViewGroup;
import androidx.fragment.app.w;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentTagUsageViolation extends Violation {
    private final ViewGroup parentContainer;

    public FragmentTagUsageViolation(w wVar, ViewGroup viewGroup) {
        super(wVar, "Attempting to use <fragment> tag to add fragment " + wVar + " to container " + viewGroup);
        this.parentContainer = viewGroup;
    }
}
