package androidx.fragment.app.strictmode;

import android.view.ViewGroup;
import androidx.fragment.app.w;
import kotlin.jvm.internal.d;

/* JADX INFO: loaded from: classes.dex */
public final class WrongFragmentContainerViolation extends Violation {
    private final ViewGroup container;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public WrongFragmentContainerViolation(w fragment, ViewGroup viewGroup) {
        super(fragment, "Attempting to add fragment " + fragment + " to container " + viewGroup + " which is not a FragmentContainerView");
        d.f(fragment, "fragment");
        this.container = viewGroup;
    }
}
