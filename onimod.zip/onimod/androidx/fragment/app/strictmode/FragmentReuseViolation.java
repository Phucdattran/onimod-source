package androidx.fragment.app.strictmode;

import androidx.fragment.app.w;
import kotlin.jvm.internal.d;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentReuseViolation extends Violation {
    private final String previousFragmentId;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentReuseViolation(w wVar, String previousFragmentId) {
        super(wVar, "Attempting to reuse fragment " + wVar + " with previous ID " + previousFragmentId);
        d.f(previousFragmentId, "previousFragmentId");
        this.previousFragmentId = previousFragmentId;
    }
}
