package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class d extends AnimatorListenerAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ ViewGroup f633a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f634b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ boolean f635c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ z0 f636d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ g f637e;

    public d(ViewGroup viewGroup, View view, boolean z4, z0 z0Var, g gVar) {
        this.f633a = viewGroup;
        this.f634b = view;
        this.f635c = z4;
        this.f636d = z0Var;
        this.f637e = gVar;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        ViewGroup viewGroup = this.f633a;
        View view = this.f634b;
        viewGroup.endViewTransition(view);
        boolean z4 = this.f635c;
        z0 z0Var = this.f636d;
        if (z4) {
            z0Var.f819a.a(view);
        }
        this.f637e.e();
        if (o0.F(2)) {
            Objects.toString(z0Var);
        }
    }
}
