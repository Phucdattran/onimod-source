package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
public abstract class u {
    public abstract void a();
}
