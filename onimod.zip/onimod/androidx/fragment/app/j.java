package androidx.fragment.app;

import android.animation.Animator;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Objects;
import java.util.WeakHashMap;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ViewGroup f661a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f662b = new ArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f663c = new ArrayList();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f664d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f665e = false;

    public j(ViewGroup viewGroup) {
        this.f661a = viewGroup;
    }

    public static j f(ViewGroup viewGroup, s2.e eVar) {
        Object tag = viewGroup.getTag(R.id.special_effects_controller_view_tag);
        if (tag instanceof j) {
            return (j) tag;
        }
        eVar.getClass();
        j jVar = new j(viewGroup);
        viewGroup.setTag(R.id.special_effects_controller_view_tag, jVar);
        return jVar;
    }

    public final void a(SpecialEffectsController$Operation$State specialEffectsController$Operation$State, SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact, u0 u0Var) {
        synchronized (this.f662b) {
            try {
                k0.c cVar = new k0.c();
                z0 z0VarD = d(u0Var.f762c);
                if (z0VarD != null) {
                    z0VarD.c(specialEffectsController$Operation$State, specialEffectsController$Operation$LifecycleImpact);
                    return;
                }
                z0 z0Var = new z0(specialEffectsController$Operation$State, specialEffectsController$Operation$LifecycleImpact, u0Var, cVar);
                this.f662b.add(z0Var);
                z0Var.f822d.add(new y0(this, z0Var, 0));
                z0Var.f822d.add(new y0(this, z0Var, 1));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b(ArrayList arrayList, boolean z4) {
        SpecialEffectsController$Operation$State specialEffectsController$Operation$State;
        boolean z5;
        z0 z0Var;
        ArrayList arrayList2;
        int size = arrayList.size();
        boolean z6 = false;
        z0 z0Var2 = null;
        z0 z0Var3 = null;
        int i3 = 0;
        while (true) {
            specialEffectsController$Operation$State = SpecialEffectsController$Operation$State.f589b;
            if (i3 >= size) {
                break;
            }
            Object obj = arrayList.get(i3);
            i3++;
            z0 z0Var4 = (z0) obj;
            SpecialEffectsController$Operation$State specialEffectsController$Operation$StateC = SpecialEffectsController$Operation$State.c(z0Var4.f821c.E);
            int iOrdinal = z0Var4.f819a.ordinal();
            if (iOrdinal != 0) {
                if (iOrdinal != 1) {
                    if (iOrdinal == 2 || iOrdinal == 3) {
                    }
                } else if (specialEffectsController$Operation$StateC != specialEffectsController$Operation$State) {
                    z0Var3 = z0Var4;
                }
            }
            if (specialEffectsController$Operation$StateC == specialEffectsController$Operation$State && z0Var2 == null) {
                z0Var2 = z0Var4;
            }
        }
        if (o0.F(2)) {
            Objects.toString(z0Var2);
            Objects.toString(z0Var3);
        }
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList();
        ArrayList arrayList5 = new ArrayList(arrayList);
        w wVar = ((z0) arrayList.get(arrayList.size() - 1)).f821c;
        int size2 = arrayList.size();
        int i4 = 0;
        while (i4 < size2) {
            Object obj2 = arrayList.get(i4);
            i4++;
            t tVar = ((z0) obj2).f821c.H;
            t tVar2 = wVar.H;
            tVar.f749b = tVar2.f749b;
            tVar.f750c = tVar2.f750c;
            tVar.f751d = tVar2.f751d;
            tVar.f752e = tVar2.f752e;
        }
        int size3 = arrayList.size();
        int i5 = 0;
        while (i5 < size3) {
            Object obj3 = arrayList.get(i5);
            i5++;
            z0 z0Var5 = (z0) obj3;
            k0.c cVar = new k0.c();
            z0Var5.d();
            HashSet hashSet = z0Var5.f823e;
            hashSet.add(cVar);
            g gVar = new g(z0Var5, cVar);
            gVar.f650d = z6;
            gVar.f649c = z4;
            arrayList3.add(gVar);
            k0.c cVar2 = new k0.c();
            z0Var5.d();
            hashSet.add(cVar2);
            boolean z7 = !z4 ? z0Var5 != z0Var3 : z0Var5 != z0Var2;
            i iVar = new i(z0Var5, cVar2);
            SpecialEffectsController$Operation$State specialEffectsController$Operation$State2 = z0Var5.f819a;
            w wVar2 = z0Var5.f821c;
            if (specialEffectsController$Operation$State2 == specialEffectsController$Operation$State) {
                if (z4) {
                    t tVar3 = wVar2.H;
                } else {
                    wVar2.getClass();
                }
                if (z4) {
                    t tVar4 = wVar2.H;
                } else {
                    t tVar5 = wVar2.H;
                }
            } else if (z4) {
                t tVar6 = wVar2.H;
            } else {
                wVar2.getClass();
            }
            if (z7) {
                if (z4) {
                    t tVar7 = wVar2.H;
                } else {
                    wVar2.getClass();
                }
            }
            arrayList4.add(iVar);
            z0Var5.f822d.add(new y0(this, arrayList5, z0Var5));
            z6 = false;
        }
        HashMap map = new HashMap();
        int size4 = arrayList4.size();
        int i6 = 0;
        while (i6 < size4) {
            Object obj4 = arrayList4.get(i6);
            i6++;
            z0 z0Var6 = (z0) ((i) obj4).f656a;
            SpecialEffectsController$Operation$State.c(z0Var6.f821c.E);
            SpecialEffectsController$Operation$State specialEffectsController$Operation$State3 = z0Var6.f819a;
        }
        int size5 = arrayList4.size();
        int i7 = 0;
        while (i7 < size5) {
            Object obj5 = arrayList4.get(i7);
            i7++;
            i iVar2 = (i) obj5;
            map.put((z0) iVar2.f656a, Boolean.FALSE);
            iVar2.e();
        }
        boolean zContainsValue = map.containsValue(Boolean.TRUE);
        ViewGroup viewGroup = this.f661a;
        Context context = viewGroup.getContext();
        ArrayList arrayList6 = new ArrayList();
        int size6 = arrayList3.size();
        boolean z8 = false;
        int i8 = 0;
        while (i8 < size6) {
            Object obj6 = arrayList3.get(i8);
            i8++;
            g gVar2 = (g) obj6;
            z0 z0Var7 = (z0) gVar2.f656a;
            SpecialEffectsController$Operation$State specialEffectsController$Operation$StateC2 = SpecialEffectsController$Operation$State.c(z0Var7.f821c.E);
            SpecialEffectsController$Operation$State specialEffectsController$Operation$State4 = z0Var7.f819a;
            if (specialEffectsController$Operation$StateC2 == specialEffectsController$Operation$State4 || !(specialEffectsController$Operation$StateC2 == specialEffectsController$Operation$State || specialEffectsController$Operation$State4 == specialEffectsController$Operation$State)) {
                z5 = zContainsValue;
                arrayList2 = arrayList3;
                z0Var = z0Var2;
                gVar2.e();
                zContainsValue = z5;
                arrayList3 = arrayList2;
                z0Var2 = z0Var;
            } else {
                e eVarQ = gVar2.q(context);
                if (eVarQ == null) {
                    gVar2.e();
                } else {
                    Animator animator = (Animator) eVarQ.f639a;
                    if (animator == null) {
                        arrayList6.add(gVar2);
                    } else {
                        z0 z0Var8 = (z0) gVar2.f656a;
                        z5 = zContainsValue;
                        w wVar3 = z0Var8.f821c;
                        arrayList2 = arrayList3;
                        z0Var = z0Var2;
                        if (Boolean.TRUE.equals(map.get(z0Var8))) {
                            if (o0.F(2)) {
                                Objects.toString(wVar3);
                            }
                            gVar2.e();
                            zContainsValue = z5;
                            arrayList3 = arrayList2;
                            z0Var2 = z0Var;
                        } else {
                            boolean z9 = z0Var8.f819a == SpecialEffectsController$Operation$State.f590c;
                            if (z9) {
                                arrayList5.remove(z0Var8);
                            }
                            View view = wVar3.E;
                            viewGroup.startViewTransition(view);
                            animator.addListener(new d(viewGroup, view, z9, z0Var8, gVar2));
                            animator.setTarget(view);
                            animator.start();
                            if (o0.F(2)) {
                                z0Var8.toString();
                            }
                            ((k0.c) gVar2.f657b).a(new e(animator, z0Var8));
                            zContainsValue = z5;
                            arrayList3 = arrayList2;
                            z0Var2 = z0Var;
                            z8 = true;
                        }
                    }
                }
                z5 = zContainsValue;
                arrayList2 = arrayList3;
                z0Var = z0Var2;
                zContainsValue = z5;
                arrayList3 = arrayList2;
                z0Var2 = z0Var;
            }
        }
        boolean z10 = zContainsValue;
        z0 z0Var9 = z0Var2;
        int size7 = arrayList6.size();
        int i9 = 0;
        while (i9 < size7) {
            Object obj7 = arrayList6.get(i9);
            i9++;
            g gVar3 = (g) obj7;
            z0 z0Var10 = (z0) gVar3.f656a;
            w wVar4 = z0Var10.f821c;
            if (z10) {
                if (o0.F(2)) {
                    Objects.toString(wVar4);
                }
                gVar3.e();
            } else if (z8) {
                if (o0.F(2)) {
                    Objects.toString(wVar4);
                }
                gVar3.e();
            } else {
                View view2 = wVar4.E;
                e eVarQ2 = gVar3.q(context);
                eVarQ2.getClass();
                Animation animation = (Animation) eVarQ2.f640b;
                animation.getClass();
                if (z0Var10.f819a != SpecialEffectsController$Operation$State.f588a) {
                    view2.startAnimation(animation);
                    gVar3.e();
                } else {
                    viewGroup.startViewTransition(view2);
                    a0 a0Var = new a0(animation, viewGroup, view2);
                    a0Var.setAnimationListener(new f(z0Var10, viewGroup, view2, gVar3));
                    view2.startAnimation(a0Var);
                    if (o0.F(2)) {
                        z0Var10.toString();
                    }
                }
                ((k0.c) gVar3.f657b).a(new a0.k(view2, viewGroup, gVar3, z0Var10));
            }
        }
        int size8 = arrayList5.size();
        int i10 = 0;
        while (i10 < size8) {
            Object obj8 = arrayList5.get(i10);
            i10++;
            z0 z0Var11 = (z0) obj8;
            z0Var11.f819a.a(z0Var11.f821c.E);
        }
        arrayList5.clear();
        if (o0.F(2)) {
            Objects.toString(z0Var9);
            Objects.toString(z0Var3);
        }
    }

    public final void c() {
        if (this.f665e) {
            return;
        }
        ViewGroup viewGroup = this.f661a;
        WeakHashMap weakHashMap = o0.h0.f3558a;
        if (!viewGroup.isAttachedToWindow()) {
            e();
            this.f664d = false;
            return;
        }
        synchronized (this.f662b) {
            try {
                if (!this.f662b.isEmpty()) {
                    ArrayList arrayList = new ArrayList(this.f663c);
                    this.f663c.clear();
                    int size = arrayList.size();
                    int i3 = 0;
                    while (i3 < size) {
                        Object obj = arrayList.get(i3);
                        i3++;
                        z0 z0Var = (z0) obj;
                        if (o0.F(2)) {
                            Objects.toString(z0Var);
                        }
                        z0Var.a();
                        if (!z0Var.f824g) {
                            this.f663c.add(z0Var);
                        }
                    }
                    g();
                    ArrayList arrayList2 = new ArrayList(this.f662b);
                    this.f662b.clear();
                    this.f663c.addAll(arrayList2);
                    int size2 = arrayList2.size();
                    int i4 = 0;
                    while (i4 < size2) {
                        Object obj2 = arrayList2.get(i4);
                        i4++;
                        ((z0) obj2).d();
                    }
                    b(arrayList2, this.f664d);
                    this.f664d = false;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final z0 d(w wVar) {
        ArrayList arrayList = this.f662b;
        int size = arrayList.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayList.get(i3);
            i3++;
            z0 z0Var = (z0) obj;
            if (z0Var.f821c.equals(wVar) && !z0Var.f) {
                return z0Var;
            }
        }
        return null;
    }

    public final void e() {
        ViewGroup viewGroup = this.f661a;
        WeakHashMap weakHashMap = o0.h0.f3558a;
        boolean zIsAttachedToWindow = viewGroup.isAttachedToWindow();
        synchronized (this.f662b) {
            try {
                g();
                ArrayList arrayList = this.f662b;
                int size = arrayList.size();
                int i3 = 0;
                int i4 = 0;
                while (i4 < size) {
                    Object obj = arrayList.get(i4);
                    i4++;
                    ((z0) obj).d();
                }
                ArrayList arrayList2 = new ArrayList(this.f663c);
                int size2 = arrayList2.size();
                int i5 = 0;
                while (i5 < size2) {
                    Object obj2 = arrayList2.get(i5);
                    i5++;
                    z0 z0Var = (z0) obj2;
                    if (o0.F(2)) {
                        if (!zIsAttachedToWindow) {
                            StringBuilder sb = new StringBuilder();
                            sb.append("Container ");
                            sb.append(this.f661a);
                            sb.append(" is not attached to window. ");
                        }
                        Objects.toString(z0Var);
                    }
                    z0Var.a();
                }
                ArrayList arrayList3 = new ArrayList(this.f662b);
                int size3 = arrayList3.size();
                while (i3 < size3) {
                    Object obj3 = arrayList3.get(i3);
                    i3++;
                    z0 z0Var2 = (z0) obj3;
                    if (o0.F(2)) {
                        if (!zIsAttachedToWindow) {
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("Container ");
                            sb2.append(this.f661a);
                            sb2.append(" is not attached to window. ");
                        }
                        Objects.toString(z0Var2);
                    }
                    z0Var2.a();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void g() {
        ArrayList arrayList = this.f662b;
        int size = arrayList.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayList.get(i3);
            i3++;
            z0 z0Var = (z0) obj;
            if (z0Var.f820b == SpecialEffectsController$Operation$LifecycleImpact.f585b) {
                z0Var.c(SpecialEffectsController$Operation$State.b(z0Var.f821c.K().getVisibility()), SpecialEffectsController$Operation$LifecycleImpact.f584a);
            }
        }
    }
}
