package androidx.fragment.app;

import android.view.View;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityManager;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class t0 implements View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f758a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f759b;

    public /* synthetic */ t0(int i3, Object obj) {
        this.f758a = i3;
        this.f759b = obj;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        int i3 = this.f758a;
        Object obj = this.f759b;
        switch (i3) {
            case 0:
                View view2 = (View) obj;
                view2.removeOnAttachStateChangeListener(this);
                WeakHashMap weakHashMap = o0.h0.f3558a;
                o0.x.c(view2);
                break;
            case 1:
            case 2:
                break;
            default:
                v2.n nVar = (v2.n) obj;
                AccessibilityManager accessibilityManager = nVar.f4599t;
                if (nVar.f4600u != null && accessibilityManager != null) {
                    WeakHashMap weakHashMap2 = o0.h0.f3558a;
                    if (nVar.isAttachedToWindow()) {
                        accessibilityManager.addTouchExplorationStateChangeListener(new p0.b(nVar.f4600u));
                    }
                    break;
                }
                break;
        }
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        AccessibilityManager accessibilityManager;
        switch (this.f758a) {
            case 0:
                break;
            case 1:
                k.g gVar = (k.g) this.f759b;
                ViewTreeObserver viewTreeObserver = gVar.f2686x;
                if (viewTreeObserver != null) {
                    if (!viewTreeObserver.isAlive()) {
                        gVar.f2686x = view.getViewTreeObserver();
                    }
                    gVar.f2686x.removeGlobalOnLayoutListener(gVar.f2671i);
                }
                view.removeOnAttachStateChangeListener(this);
                break;
            case 2:
                k.d0 d0Var = (k.d0) this.f759b;
                ViewTreeObserver viewTreeObserver2 = d0Var.f2651o;
                if (viewTreeObserver2 != null) {
                    if (!viewTreeObserver2.isAlive()) {
                        d0Var.f2651o = view.getViewTreeObserver();
                    }
                    d0Var.f2651o.removeGlobalOnLayoutListener(d0Var.f2645i);
                }
                view.removeOnAttachStateChangeListener(this);
                break;
            default:
                v2.n nVar = (v2.n) this.f759b;
                q0.c cVar = nVar.f4600u;
                if (cVar != null && (accessibilityManager = nVar.f4599t) != null) {
                    accessibilityManager.removeTouchExplorationStateChangeListener(new p0.b(cVar));
                    break;
                }
                break;
        }
    }

    private final void a(View view) {
    }

    private final void b(View view) {
    }

    private final void c(View view) {
    }
}
