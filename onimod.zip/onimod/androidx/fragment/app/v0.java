package androidx.fragment.app;

import androidx.lifecycle.Lifecycle$State;

/* JADX INFO: loaded from: classes.dex */
public final class v0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f766a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public w f767b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f768c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f769d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f770e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f771g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Lifecycle$State f772h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Lifecycle$State f773i;

    public v0(int i3, w wVar) {
        this.f766a = i3;
        this.f767b = wVar;
        Lifecycle$State lifecycle$State = Lifecycle$State.f833e;
        this.f772h = lifecycle$State;
        this.f773i = lifecycle$State;
    }

    public v0(int i3, w wVar, int i4) {
        this.f766a = i3;
        this.f767b = wVar;
        Lifecycle$State lifecycle$State = Lifecycle$State.f833e;
        this.f772h = lifecycle$State;
        this.f773i = lifecycle$State;
    }
}
