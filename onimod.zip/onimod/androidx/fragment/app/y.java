package androidx.fragment.app;

import android.os.Handler;
import android.view.View;
import android.view.Window;

/* JADX INFO: loaded from: classes.dex */
public final class y extends a3.a implements androidx.lifecycle.m0, androidx.activity.u, f1.e, r0 {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final e.n f806o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final e.n f807p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final Handler f808q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final o0 f809r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ e.n f810s;

    public y(e.n nVar) {
        this.f810s = nVar;
        Handler handler = new Handler();
        this.f809r = new o0();
        this.f806o = nVar;
        this.f807p = nVar;
        this.f808q = handler;
    }

    @Override // a3.a
    public final View U(int i3) {
        return this.f810s.findViewById(i3);
    }

    @Override // a3.a
    public final boolean V() {
        Window window = this.f810s.getWindow();
        return (window == null || window.peekDecorView() == null) ? false : true;
    }

    @Override // androidx.lifecycle.m0
    public final androidx.lifecycle.l0 b() {
        return this.f810s.b();
    }

    @Override // f1.e
    public final f1.d c() {
        return (f1.d) this.f810s.f139e.f157c;
    }

    @Override // androidx.lifecycle.q
    public final androidx.lifecycle.s e() {
        return this.f810s.f815t;
    }

    @Override // androidx.fragment.app.r0
    public final void a() {
    }
}
