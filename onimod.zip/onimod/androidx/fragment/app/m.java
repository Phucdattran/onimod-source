package androidx.fragment.app;

import android.view.View;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class m implements androidx.lifecycle.x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ o f672a;

    public m(o oVar) {
        this.f672a = oVar;
    }

    @Override // androidx.lifecycle.x
    public final void a(Object obj) {
        if (((androidx.lifecycle.q) obj) != null) {
            o oVar = this.f672a;
            if (oVar.f677a0) {
                View viewK = oVar.K();
                if (viewK.getParent() != null) {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                }
                if (oVar.f681e0 != null) {
                    if (o0.F(3)) {
                        Objects.toString(oVar.f681e0);
                    }
                    oVar.f681e0.setContentView(viewK);
                }
            }
        }
    }
}
