package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.content.Context;
import android.content.res.Resources;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public final class g extends h {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f649c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f650d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public e f651e;

    /* JADX WARN: Code duplicated, block: B:17:0x0028  */
    /* JADX WARN: Code duplicated, block: B:79:0x00f8 A[Catch: RuntimeException -> 0x00fe, TRY_LEAVE, TryCatch #1 {RuntimeException -> 0x00fe, blocks: (B:77:0x00f2, B:79:0x00f8), top: B:90:0x00f2 }] */
    public final e q(Context context) {
        int i3;
        e eVar;
        Animator animatorLoadAnimator;
        int iJ0;
        if (this.f650d) {
            return this.f651e;
        }
        z0 z0Var = (z0) this.f656a;
        w wVar = z0Var.f821c;
        boolean z4 = z0Var.f819a == SpecialEffectsController$Operation$State.f589b;
        boolean z5 = this.f649c;
        t tVar = wVar.H;
        int i4 = tVar == null ? 0 : tVar.f;
        if (z5) {
            if (z4) {
                if (tVar == null) {
                    i3 = 0;
                } else {
                    i3 = tVar.f751d;
                }
            } else if (tVar == null) {
                i3 = 0;
            } else {
                i3 = tVar.f752e;
            }
        } else if (z4) {
            if (tVar == null) {
                i3 = 0;
            } else {
                i3 = tVar.f749b;
            }
        } else if (tVar == null) {
            i3 = 0;
        } else {
            i3 = tVar.f750c;
        }
        wVar.L(0, 0, 0, 0);
        ViewGroup viewGroup = wVar.D;
        e eVar2 = null;
        if (viewGroup != null && viewGroup.getTag(R.id.visible_removing_fragment_view_tag) != null) {
            wVar.D.setTag(R.id.visible_removing_fragment_view_tag, null);
        }
        ViewGroup viewGroup2 = wVar.D;
        if (viewGroup2 == null || viewGroup2.getLayoutTransition() == null) {
            if (i3 == 0 && i4 != 0) {
                if (i4 == 4097) {
                    i3 = z4 ? R.animator.fragment_open_enter : R.animator.fragment_open_exit;
                } else if (i4 != 8194) {
                    if (i4 == 8197) {
                        iJ0 = z4 ? a3.a.j0(context, android.R.attr.activityCloseEnterAnimation) : a3.a.j0(context, android.R.attr.activityCloseExitAnimation);
                    } else if (i4 == 4099) {
                        i3 = z4 ? R.animator.fragment_fade_enter : R.animator.fragment_fade_exit;
                    } else if (i4 != 4100) {
                        i3 = -1;
                    } else {
                        iJ0 = z4 ? a3.a.j0(context, android.R.attr.activityOpenEnterAnimation) : a3.a.j0(context, android.R.attr.activityOpenExitAnimation);
                    }
                    i3 = iJ0;
                } else {
                    i3 = z4 ? R.animator.fragment_close_enter : R.animator.fragment_close_exit;
                }
            }
            if (i3 != 0) {
                boolean zEquals = "anim".equals(context.getResources().getResourceTypeName(i3));
                if (zEquals) {
                    try {
                        Animation animationLoadAnimation = AnimationUtils.loadAnimation(context, i3);
                        if (animationLoadAnimation != null) {
                            eVar = new e(animationLoadAnimation);
                            eVar2 = eVar;
                        }
                    } catch (Resources.NotFoundException e4) {
                        throw e4;
                    } catch (RuntimeException unused) {
                        try {
                            animatorLoadAnimator = AnimatorInflater.loadAnimator(context, i3);
                            if (animatorLoadAnimator != null) {
                                eVar = new e(animatorLoadAnimator);
                                eVar2 = eVar;
                            }
                        } catch (RuntimeException e5) {
                            if (zEquals) {
                                throw e5;
                            }
                            Animation animationLoadAnimation2 = AnimationUtils.loadAnimation(context, i3);
                            if (animationLoadAnimation2 != null) {
                                eVar2 = new e(animationLoadAnimation2);
                            }
                        }
                    }
                } else {
                    animatorLoadAnimator = AnimatorInflater.loadAnimator(context, i3);
                    if (animatorLoadAnimator != null) {
                        eVar = new e(animatorLoadAnimator);
                        eVar2 = eVar;
                    }
                }
            }
        }
        this.f651e = eVar2;
        this.f650d = true;
        return eVar2;
    }
}
