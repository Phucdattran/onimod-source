package androidx.fragment.app;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import androidx.lifecycle.Lifecycle$Event;
import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class w0 implements androidx.lifecycle.i, f1.e, androidx.lifecycle.m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final w f799a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final androidx.lifecycle.l0 f800b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public androidx.lifecycle.s f801c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public androidx.activity.n f802d = null;

    public w0(w wVar, androidx.lifecycle.l0 l0Var) {
        this.f799a = wVar;
        this.f800b = l0Var;
    }

    @Override // androidx.lifecycle.i
    public final a1.c a() {
        Application application;
        w wVar = this.f799a;
        Context applicationContext = wVar.J().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            }
            if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            }
            applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
        }
        a1.c cVar = new a1.c();
        LinkedHashMap linkedHashMap = cVar.f30a;
        if (application != null) {
            linkedHashMap.put(androidx.lifecycle.j0.f870a, application);
        }
        linkedHashMap.put(androidx.lifecycle.f0.f859a, this);
        linkedHashMap.put(androidx.lifecycle.f0.f860b, this);
        Bundle bundle = wVar.f;
        if (bundle != null) {
            linkedHashMap.put(androidx.lifecycle.f0.f861c, bundle);
        }
        return cVar;
    }

    @Override // androidx.lifecycle.m0
    public final androidx.lifecycle.l0 b() {
        f();
        return this.f800b;
    }

    @Override // f1.e
    public final f1.d c() {
        f();
        return (f1.d) this.f802d.f157c;
    }

    public final void d(Lifecycle$Event lifecycle$Event) {
        this.f801c.d(lifecycle$Event);
    }

    @Override // androidx.lifecycle.q
    public final androidx.lifecycle.s e() {
        f();
        return this.f801c;
    }

    public final void f() {
        if (this.f801c == null) {
            this.f801c = new androidx.lifecycle.s(this);
            androidx.activity.n nVar = new androidx.activity.n(this);
            this.f802d = nVar;
            nVar.a();
            androidx.lifecycle.f0.b(this);
        }
    }
}
