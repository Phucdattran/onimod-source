package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.Transformation;

/* JADX INFO: loaded from: classes.dex */
public final class a0 extends AnimationSet implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ViewGroup f610a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final View f611b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f612c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f613d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f614e;

    public a0(Animation animation, ViewGroup viewGroup, View view) {
        super(false);
        this.f614e = true;
        this.f610a = viewGroup;
        this.f611b = view;
        addAnimation(animation);
        viewGroup.post(this);
    }

    @Override // android.view.animation.AnimationSet, android.view.animation.Animation
    public final boolean getTransformation(long j4, Transformation transformation) {
        this.f614e = true;
        if (this.f612c) {
            return !this.f613d;
        }
        if (!super.getTransformation(j4, transformation)) {
            this.f612c = true;
            o0.o.a(this.f610a, this);
        }
        return true;
    }

    @Override // java.lang.Runnable
    public final void run() {
        boolean z4 = this.f612c;
        ViewGroup viewGroup = this.f610a;
        if (z4 || !this.f614e) {
            viewGroup.endViewTransition(this.f611b);
            this.f613d = true;
        } else {
            this.f614e = false;
            viewGroup.post(this);
        }
    }

    @Override // android.view.animation.Animation
    public final boolean getTransformation(long j4, Transformation transformation, float f) {
        this.f614e = true;
        if (this.f612c) {
            return !this.f613d;
        }
        if (!super.getTransformation(j4, transformation, f)) {
            this.f612c = true;
            o0.o.a(this.f610a, this);
        }
        return true;
    }
}
