package androidx.fragment.app;

import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class q0 extends androidx.lifecycle.i0 {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final s2.e f719j = new s2.e(6);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f722g;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final HashMap f720d = new HashMap();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final HashMap f721e = new HashMap();
    public final HashMap f = new HashMap();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f723h = false;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f724i = false;

    public q0(boolean z4) {
        this.f722g = z4;
    }

    @Override // androidx.lifecycle.i0
    public final void c() {
        if (o0.F(3)) {
            toString();
        }
        this.f723h = true;
    }

    public final void d(String str) {
        HashMap map = this.f721e;
        q0 q0Var = (q0) map.get(str);
        if (q0Var != null) {
            q0Var.c();
            map.remove(str);
        }
        HashMap map2 = this.f;
        androidx.lifecycle.l0 l0Var = (androidx.lifecycle.l0) map2.get(str);
        if (l0Var != null) {
            l0Var.a();
            map2.remove(str);
        }
    }

    public final void e(w wVar) {
        if (this.f724i || this.f720d.remove(wVar.f778e) == null || !o0.F(2)) {
            return;
        }
        wVar.toString();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && q0.class == obj.getClass()) {
            q0 q0Var = (q0) obj;
            if (this.f720d.equals(q0Var.f720d) && this.f721e.equals(q0Var.f721e) && this.f.equals(q0Var.f)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f.hashCode() + ((this.f721e.hashCode() + (this.f720d.hashCode() * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator it = this.f720d.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator it2 = this.f721e.keySet().iterator();
        while (it2.hasNext()) {
            sb.append((String) it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator it3 = this.f.keySet().iterator();
        while (it3.hasNext()) {
            sb.append((String) it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
