package androidx.fragment.app;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f748a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f749b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f750c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f751d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f752e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f753g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Object f754h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Object f755i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f756j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public View f757k;
}
