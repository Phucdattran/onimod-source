package androidx.fragment.app;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public interface m0 {
    boolean a(ArrayList arrayList, ArrayList arrayList2);
}
