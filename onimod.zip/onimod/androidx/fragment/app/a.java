package androidx.fragment.app;

import androidx.lifecycle.Lifecycle$State;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Objects;
import top.niunaijun.blackbox.core.system.JarConfig;
import top.niunaijun.blackbox.entity.location.BCell;

/* JADX INFO: loaded from: classes.dex */
public final class a implements m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f593a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f594b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f595c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f596d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f597e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f598g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public String f599h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f600i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f601j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f602k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public CharSequence f603l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public ArrayList f604m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public ArrayList f605n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f606o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final o0 f607p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f608q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f609r;

    public a(o0 o0Var) {
        o0Var.D();
        y yVar = o0Var.f703t;
        if (yVar != null) {
            yVar.f807p.getClassLoader();
        }
        this.f593a = new ArrayList();
        this.f606o = false;
        this.f609r = -1;
        this.f607p = o0Var;
    }

    @Override // androidx.fragment.app.m0
    public final boolean a(ArrayList arrayList, ArrayList arrayList2) {
        if (o0.F(2)) {
            toString();
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (!this.f598g) {
            return true;
        }
        o0 o0Var = this.f607p;
        if (o0Var.f688d == null) {
            o0Var.f688d = new ArrayList();
        }
        o0Var.f688d.add(this);
        return true;
    }

    public final void b(v0 v0Var) {
        this.f593a.add(v0Var);
        v0Var.f769d = this.f594b;
        v0Var.f770e = this.f595c;
        v0Var.f = this.f596d;
        v0Var.f771g = this.f597e;
    }

    public final void c(int i3) {
        if (this.f598g) {
            if (o0.F(2)) {
                toString();
            }
            ArrayList arrayList = this.f593a;
            int size = arrayList.size();
            for (int i4 = 0; i4 < size; i4++) {
                v0 v0Var = (v0) arrayList.get(i4);
                w wVar = v0Var.f767b;
                if (wVar != null) {
                    wVar.f789q += i3;
                    if (o0.F(2)) {
                        Objects.toString(v0Var.f767b);
                        int i5 = v0Var.f767b.f789q;
                    }
                }
            }
        }
    }

    public final void d() {
        if (this.f598g) {
            throw new IllegalStateException("This transaction is already being added to the back stack");
        }
        this.f607p.y(this, false);
    }

    public final void e(int i3, w wVar, String str, int i4) {
        String str2 = wVar.L;
        if (str2 != null) {
            y0.b.c(wVar, str2);
        }
        Class<?> cls = wVar.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from instance state.");
        }
        if (str != null) {
            String str3 = wVar.f796x;
            if (str3 != null && !str.equals(str3)) {
                throw new IllegalStateException("Can't change tag of fragment " + wVar + ": was " + wVar.f796x + " now " + str);
            }
            wVar.f796x = str;
        }
        if (i3 != 0) {
            if (i3 == -1) {
                throw new IllegalArgumentException("Can't add fragment " + wVar + " with tag " + str + " to container view with no id");
            }
            int i5 = wVar.f794v;
            if (i5 != 0 && i5 != i3) {
                throw new IllegalStateException("Can't change container ID of fragment " + wVar + ": was " + wVar.f794v + " now " + i3);
            }
            wVar.f794v = i3;
            wVar.f795w = i3;
        }
        b(new v0(i4, wVar));
        wVar.f790r = this.f607p;
    }

    public final void f(String str, PrintWriter printWriter, boolean z4) {
        String str2;
        if (z4) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f599h);
            printWriter.print(" mIndex=");
            printWriter.print(this.f609r);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f608q);
            if (this.f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f));
            }
            if (this.f594b != 0 || this.f595c != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f594b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f595c));
            }
            if (this.f596d != 0 || this.f597e != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f596d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f597e));
            }
            if (this.f600i != 0 || this.f601j != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f600i));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f601j);
            }
            if (this.f602k != 0 || this.f603l != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f602k));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f603l);
            }
        }
        ArrayList arrayList = this.f593a;
        if (arrayList.isEmpty()) {
            return;
        }
        printWriter.print(str);
        printWriter.println("Operations:");
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            v0 v0Var = (v0) arrayList.get(i3);
            switch (v0Var.f766a) {
                case 0:
                    str2 = "NULL";
                    break;
                case 1:
                    str2 = "ADD";
                    break;
                case 2:
                    str2 = "REPLACE";
                    break;
                case 3:
                    str2 = "REMOVE";
                    break;
                case 4:
                    str2 = "HIDE";
                    break;
                case 5:
                    str2 = "SHOW";
                    break;
                case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                    str2 = "DETACH";
                    break;
                case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                    str2 = "ATTACH";
                    break;
                case 8:
                    str2 = "SET_PRIMARY_NAV";
                    break;
                case 9:
                    str2 = "UNSET_PRIMARY_NAV";
                    break;
                case JarConfig.MAX_CACHE_SIZE /* 10 */:
                    str2 = "OP_SET_MAX_LIFECYCLE";
                    break;
                default:
                    str2 = "cmd=" + v0Var.f766a;
                    break;
            }
            printWriter.print(str);
            printWriter.print("  Op #");
            printWriter.print(i3);
            printWriter.print(": ");
            printWriter.print(str2);
            printWriter.print(" ");
            printWriter.println(v0Var.f767b);
            if (z4) {
                if (v0Var.f769d != 0 || v0Var.f770e != 0) {
                    printWriter.print(str);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(v0Var.f769d));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(v0Var.f770e));
                }
                if (v0Var.f != 0 || v0Var.f771g != 0) {
                    printWriter.print(str);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(v0Var.f));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(v0Var.f771g));
                }
            }
        }
    }

    public final void g(w wVar) {
        o0 o0Var = wVar.f790r;
        if (o0Var == null || o0Var == this.f607p) {
            b(new v0(3, wVar));
            return;
        }
        throw new IllegalStateException("Cannot remove Fragment attached to a different FragmentManager. Fragment " + wVar.toString() + " is already attached to a FragmentManager.");
    }

    public final void h(w wVar, Lifecycle$State lifecycle$State) {
        o0 o0Var = wVar.f790r;
        o0 o0Var2 = this.f607p;
        if (o0Var != o0Var2) {
            throw new IllegalArgumentException("Cannot setMaxLifecycle for Fragment not attached to FragmentManager " + o0Var2);
        }
        if (lifecycle$State == Lifecycle$State.f830b && wVar.f774a > -1) {
            throw new IllegalArgumentException("Cannot set maximum Lifecycle to " + lifecycle$State + " after the Fragment has been created");
        }
        if (lifecycle$State == Lifecycle$State.f829a) {
            throw new IllegalArgumentException("Cannot set maximum Lifecycle to " + lifecycle$State + ". Use remove() to remove the fragment from the FragmentManager and trigger its destruction.");
        }
        v0 v0Var = new v0();
        v0Var.f766a = 10;
        v0Var.f767b = wVar;
        v0Var.f768c = false;
        v0Var.f772h = wVar.M;
        v0Var.f773i = lifecycle$State;
        b(v0Var);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f609r >= 0) {
            sb.append(" #");
            sb.append(this.f609r);
        }
        if (this.f599h != null) {
            sb.append(" ");
            sb.append(this.f599h);
        }
        sb.append("}");
        return sb.toString();
    }
}
