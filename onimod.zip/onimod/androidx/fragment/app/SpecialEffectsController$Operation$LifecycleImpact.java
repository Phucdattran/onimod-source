package androidx.fragment.app;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
final class SpecialEffectsController$Operation$LifecycleImpact {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final SpecialEffectsController$Operation$LifecycleImpact f584a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final SpecialEffectsController$Operation$LifecycleImpact f585b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final SpecialEffectsController$Operation$LifecycleImpact f586c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final /* synthetic */ SpecialEffectsController$Operation$LifecycleImpact[] f587d;

    static {
        SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact = new SpecialEffectsController$Operation$LifecycleImpact("NONE", 0);
        f584a = specialEffectsController$Operation$LifecycleImpact;
        SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact2 = new SpecialEffectsController$Operation$LifecycleImpact("ADDING", 1);
        f585b = specialEffectsController$Operation$LifecycleImpact2;
        SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact3 = new SpecialEffectsController$Operation$LifecycleImpact("REMOVING", 2);
        f586c = specialEffectsController$Operation$LifecycleImpact3;
        f587d = new SpecialEffectsController$Operation$LifecycleImpact[]{specialEffectsController$Operation$LifecycleImpact, specialEffectsController$Operation$LifecycleImpact2, specialEffectsController$Operation$LifecycleImpact3};
    }

    public static SpecialEffectsController$Operation$LifecycleImpact valueOf(String str) {
        return (SpecialEffectsController$Operation$LifecycleImpact) Enum.valueOf(SpecialEffectsController$Operation$LifecycleImpact.class, str);
    }

    public static SpecialEffectsController$Operation$LifecycleImpact[] values() {
        return (SpecialEffectsController$Operation$LifecycleImpact[]) f587d.clone();
    }
}
