package androidx.fragment.app;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class n extends a3.a {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ r f673o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ o f674p;

    public n(o oVar, r rVar) {
        this.f674p = oVar;
        this.f673o = rVar;
    }

    @Override // a3.a
    public final View U(int i3) {
        r rVar = this.f673o;
        if (rVar.V()) {
            return rVar.U(i3);
        }
        Dialog dialog = this.f674p.f681e0;
        if (dialog != null) {
            return dialog.findViewById(i3);
        }
        return null;
    }

    @Override // a3.a
    public final boolean V() {
        return this.f673o.V() || this.f674p.f684h0;
    }
}
