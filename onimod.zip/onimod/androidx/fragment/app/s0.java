package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class s0 implements Parcelable {
    public static final Parcelable.Creator<s0> CREATOR = new androidx.activity.result.a(6);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f731a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f732b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f733c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f734d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f735e;
    public final String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f736g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f737h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f738i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Bundle f739j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final boolean f740k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final int f741l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Bundle f742m;

    public s0(w wVar) {
        this.f731a = wVar.getClass().getName();
        this.f732b = wVar.f778e;
        this.f733c = wVar.f785m;
        this.f734d = wVar.f794v;
        this.f735e = wVar.f795w;
        this.f = wVar.f796x;
        this.f736g = wVar.A;
        this.f737h = wVar.f784l;
        this.f738i = wVar.f798z;
        this.f739j = wVar.f;
        this.f740k = wVar.f797y;
        this.f741l = wVar.M.ordinal();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.f731a);
        sb.append(" (");
        sb.append(this.f732b);
        sb.append(")}:");
        if (this.f733c) {
            sb.append(" fromLayout");
        }
        int i3 = this.f735e;
        if (i3 != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(i3));
        }
        String str = this.f;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(str);
        }
        if (this.f736g) {
            sb.append(" retainInstance");
        }
        if (this.f737h) {
            sb.append(" removing");
        }
        if (this.f738i) {
            sb.append(" detached");
        }
        if (this.f740k) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i3) {
        parcel.writeString(this.f731a);
        parcel.writeString(this.f732b);
        parcel.writeInt(this.f733c ? 1 : 0);
        parcel.writeInt(this.f734d);
        parcel.writeInt(this.f735e);
        parcel.writeString(this.f);
        parcel.writeInt(this.f736g ? 1 : 0);
        parcel.writeInt(this.f737h ? 1 : 0);
        parcel.writeInt(this.f738i ? 1 : 0);
        parcel.writeBundle(this.f739j);
        parcel.writeInt(this.f740k ? 1 : 0);
        parcel.writeBundle(this.f742m);
        parcel.writeInt(this.f741l);
    }

    public s0(Parcel parcel) {
        this.f731a = parcel.readString();
        this.f732b = parcel.readString();
        this.f733c = parcel.readInt() != 0;
        this.f734d = parcel.readInt();
        this.f735e = parcel.readInt();
        this.f = parcel.readString();
        this.f736g = parcel.readInt() != 0;
        this.f737h = parcel.readInt() != 0;
        this.f738i = parcel.readInt() != 0;
        this.f739j = parcel.readBundle();
        this.f740k = parcel.readInt() != 0;
        this.f742m = parcel.readBundle();
        this.f741l = parcel.readInt();
    }
}
