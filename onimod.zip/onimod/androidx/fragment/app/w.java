package androidx.fragment.app;

import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.Lifecycle$State;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public abstract class w implements ComponentCallbacks, View.OnCreateContextMenuListener, androidx.lifecycle.q, androidx.lifecycle.m0, androidx.lifecycle.i, f1.e {
    public static final Object U = new Object();
    public boolean A;
    public boolean C;
    public ViewGroup D;
    public View E;
    public boolean F;
    public t H;
    public boolean I;
    public LayoutInflater J;
    public boolean K;
    public String L;
    public androidx.lifecycle.s N;
    public w0 O;
    public androidx.activity.n Q;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Bundle f775b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public SparseArray f776c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Bundle f777d;
    public Bundle f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public w f779g;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f781i;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f783k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f784l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f785m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f786n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f787o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f788p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f789q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public o0 f790r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public y f791s;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public w f793u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f794v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f795w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public String f796x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f797y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f798z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f774a = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f778e = UUID.randomUUID().toString();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public String f780h = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Boolean f782j = null;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public o0 f792t = new o0();
    public boolean B = true;
    public boolean G = true;
    public Lifecycle$State M = Lifecycle$State.f833e;
    public final androidx.lifecycle.w P = new androidx.lifecycle.w();
    public final AtomicInteger R = new AtomicInteger();
    public final ArrayList S = new ArrayList();
    public final q T = new q(this);

    public w() {
        p();
    }

    public LayoutInflater A(Bundle bundle) {
        y yVar = this.f791s;
        if (yVar == null) {
            throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
        }
        e.n nVar = yVar.f810s;
        LayoutInflater layoutInflaterCloneInContext = nVar.getLayoutInflater().cloneInContext(nVar);
        layoutInflaterCloneInContext.setFactory2(this.f792t.f);
        return layoutInflaterCloneInContext;
    }

    public void B() {
        this.C = true;
    }

    public void C(Bundle bundle) {
    }

    public void D() {
        this.C = true;
    }

    public void E() {
        this.C = true;
    }

    public void G(Bundle bundle) {
        this.C = true;
    }

    public void H(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f792t.M();
        this.f788p = true;
        this.O = new w0(this, b());
        View viewX = x(layoutInflater, viewGroup);
        this.E = viewX;
        if (viewX == null) {
            if (this.O.f801c != null) {
                throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
            }
            this.O = null;
            return;
        }
        this.O.f();
        androidx.lifecycle.f0.e(this.E, this.O);
        View view = this.E;
        w0 w0Var = this.O;
        kotlin.jvm.internal.d.f(view, "<this>");
        view.setTag(R.id.view_tree_view_model_store_owner, w0Var);
        a3.a.d0(this.E, this.O);
        this.P.g(this.O);
    }

    public final z I() {
        z zVarG = g();
        if (zVarG != null) {
            return zVarG;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to an activity.");
    }

    public final Context J() {
        Context contextI = i();
        if (contextI != null) {
            return contextI;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to a context.");
    }

    public final View K() {
        View view = this.E;
        if (view != null) {
            return view;
        }
        throw new IllegalStateException("Fragment " + this + " did not return a View from onCreateView() or this was called before onCreateView().");
    }

    public final void L(int i3, int i4, int i5, int i6) {
        if (this.H == null && i3 == 0 && i4 == 0 && i5 == 0 && i6 == 0) {
            return;
        }
        f().f749b = i3;
        f().f750c = i4;
        f().f751d = i5;
        f().f752e = i6;
    }

    public final void M(Bundle bundle) {
        o0 o0Var = this.f790r;
        if (o0Var != null) {
            if (o0Var == null ? false : o0Var.K()) {
                throw new IllegalStateException("Fragment already added and state has been saved");
            }
        }
        this.f = bundle;
    }

    public final void N(Intent intent) {
        y yVar = this.f791s;
        if (yVar != null) {
            yVar.f807p.startActivity(intent, null);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    @Override // androidx.lifecycle.i
    public final a1.c a() {
        Application application;
        Context applicationContext = J().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            }
            if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            }
            applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
        }
        if (application == null && o0.F(3)) {
            Objects.toString(J().getApplicationContext());
        }
        a1.c cVar = new a1.c();
        LinkedHashMap linkedHashMap = cVar.f30a;
        if (application != null) {
            linkedHashMap.put(androidx.lifecycle.j0.f870a, application);
        }
        linkedHashMap.put(androidx.lifecycle.f0.f859a, this);
        linkedHashMap.put(androidx.lifecycle.f0.f860b, this);
        Bundle bundle = this.f;
        if (bundle != null) {
            linkedHashMap.put(androidx.lifecycle.f0.f861c, bundle);
        }
        return cVar;
    }

    @Override // androidx.lifecycle.m0
    public final androidx.lifecycle.l0 b() {
        if (this.f790r == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        }
        if (j() == 1) {
            throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
        }
        HashMap map = this.f790r.L.f;
        androidx.lifecycle.l0 l0Var = (androidx.lifecycle.l0) map.get(this.f778e);
        if (l0Var != null) {
            return l0Var;
        }
        androidx.lifecycle.l0 l0Var2 = new androidx.lifecycle.l0();
        map.put(this.f778e, l0Var2);
        return l0Var2;
    }

    @Override // f1.e
    public final f1.d c() {
        return (f1.d) this.Q.f157c;
    }

    public a3.a d() {
        return new r(this);
    }

    @Override // androidx.lifecycle.q
    public final androidx.lifecycle.s e() {
        return this.N;
    }

    public final t f() {
        if (this.H == null) {
            t tVar = new t();
            Object obj = U;
            tVar.f753g = obj;
            tVar.f754h = obj;
            tVar.f755i = obj;
            tVar.f756j = 1.0f;
            tVar.f757k = null;
            this.H = tVar;
        }
        return this.H;
    }

    public final z g() {
        y yVar = this.f791s;
        if (yVar == null) {
            return null;
        }
        return yVar.f806o;
    }

    public final o0 h() {
        if (this.f791s != null) {
            return this.f792t;
        }
        throw new IllegalStateException("Fragment " + this + " has not been attached yet.");
    }

    public final Context i() {
        y yVar = this.f791s;
        if (yVar == null) {
            return null;
        }
        return yVar.f807p;
    }

    public final int j() {
        Lifecycle$State lifecycle$State = this.M;
        return (lifecycle$State == Lifecycle$State.f830b || this.f793u == null) ? lifecycle$State.ordinal() : Math.min(lifecycle$State.ordinal(), this.f793u.j());
    }

    public final o0 k() {
        o0 o0Var = this.f790r;
        if (o0Var != null) {
            return o0Var;
        }
        throw new IllegalStateException("Fragment " + this + " not associated with a fragment manager.");
    }

    public final Resources l() {
        return J().getResources();
    }

    public final String m(int i3) {
        return l().getString(i3);
    }

    public final String n(Object[] objArr, int i3) {
        return l().getString(i3, objArr);
    }

    public final w0 o() {
        w0 w0Var = this.O;
        if (w0Var != null) {
            return w0Var;
        }
        throw new IllegalStateException("Can't access the Fragment View's LifecycleOwner when getView() is null i.e., before onCreateView() or after onDestroyView()");
    }

    @Override // android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        this.C = true;
    }

    @Override // android.view.View.OnCreateContextMenuListener
    public final void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        I().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    @Override // android.content.ComponentCallbacks
    public final void onLowMemory() {
        this.C = true;
    }

    public final void p() {
        this.N = new androidx.lifecycle.s(this);
        this.Q = new androidx.activity.n(this);
        ArrayList arrayList = this.S;
        q qVar = this.T;
        if (arrayList.contains(qVar)) {
            return;
        }
        if (this.f774a >= 0) {
            qVar.a();
        } else {
            arrayList.add(qVar);
        }
    }

    public final void q() {
        p();
        this.L = this.f778e;
        this.f778e = UUID.randomUUID().toString();
        this.f783k = false;
        this.f784l = false;
        this.f785m = false;
        this.f786n = false;
        this.f787o = false;
        this.f789q = 0;
        this.f790r = null;
        this.f792t = new o0();
        this.f791s = null;
        this.f794v = 0;
        this.f795w = 0;
        this.f796x = null;
        this.f797y = false;
        this.f798z = false;
    }

    public final boolean r() {
        return this.f791s != null && this.f783k;
    }

    public final boolean s() {
        if (this.f797y) {
            return true;
        }
        o0 o0Var = this.f790r;
        if (o0Var != null) {
            w wVar = this.f793u;
            o0Var.getClass();
            if (wVar == null ? false : wVar.s()) {
                return true;
            }
        }
        return false;
    }

    public final boolean t() {
        return this.f789q > 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} (");
        sb.append(this.f778e);
        if (this.f794v != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f794v));
        }
        if (this.f796x != null) {
            sb.append(" tag=");
            sb.append(this.f796x);
        }
        sb.append(")");
        return sb.toString();
    }

    public void u() {
        this.C = true;
    }

    public void v(Context context) {
        this.C = true;
        y yVar = this.f791s;
        if ((yVar == null ? null : yVar.f806o) != null) {
            this.C = true;
        }
    }

    public void w(Bundle bundle) {
        Parcelable parcelable;
        this.C = true;
        if (bundle != null && (parcelable = bundle.getParcelable("android:support:fragments")) != null) {
            this.f792t.S(parcelable);
            o0 o0Var = this.f792t;
            o0Var.E = false;
            o0Var.F = false;
            o0Var.L.f724i = false;
            o0Var.t(1);
        }
        o0 o0Var2 = this.f792t;
        if (o0Var2.f702s >= 1) {
            return;
        }
        o0Var2.E = false;
        o0Var2.F = false;
        o0Var2.L.f724i = false;
        o0Var2.t(1);
    }

    public View x(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return null;
    }

    public void y() {
        this.C = true;
    }

    public void z() {
        this.C = true;
    }

    public void F(View view) {
    }
}
