package androidx.fragment.app;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import androidx.lifecycle.Lifecycle$Event;
import androidx.lifecycle.Lifecycle$State;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: loaded from: classes.dex */
public abstract class z extends androidx.activity.k implements c0.b, c0.c {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final a0.b f814s;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f816u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f817v;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final androidx.lifecycle.s f815t = new androidx.lifecycle.s(this);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f818w = true;

    public z() {
        final e.n nVar = (e.n) this;
        this.f814s = new a0.b(3, new y(nVar));
        ((f1.d) this.f139e.f157c).e("android:support:lifecycle", new androidx.activity.e(1, nVar));
        final int i3 = 0;
        g(new n0.a() { // from class: androidx.fragment.app.x
            @Override // n0.a
            public final void accept(Object obj) {
                switch (i3) {
                    case 0:
                        nVar.f814s.u();
                        break;
                    default:
                        nVar.f814s.u();
                        break;
                }
            }
        });
        final int i4 = 1;
        this.f147n.add(new n0.a() { // from class: androidx.fragment.app.x
            @Override // n0.a
            public final void accept(Object obj) {
                switch (i4) {
                    case 0:
                        nVar.f814s.u();
                        break;
                    default:
                        nVar.f814s.u();
                        break;
                }
            }
        });
        h(new androidx.activity.f(nVar, 1));
    }

    public static boolean j(o0 o0Var) {
        boolean zJ = false;
        for (w wVar : o0Var.f687c.h()) {
            if (wVar != null) {
                y yVar = wVar.f791s;
                if ((yVar == null ? null : yVar.f810s) != null) {
                    zJ |= j(wVar.h());
                }
                w0 w0Var = wVar.O;
                Lifecycle$State lifecycle$State = Lifecycle$State.f832d;
                if (w0Var != null) {
                    w0Var.f();
                    if (w0Var.f801c.f879c.compareTo(lifecycle$State) >= 0) {
                        wVar.O.f801c.g();
                        zJ = true;
                    }
                }
                if (wVar.N.f879c.compareTo(lifecycle$State) >= 0) {
                    wVar.N.g();
                    zJ = true;
                }
            }
        }
        return zJ;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:28:0x0046  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // android.app.Activity
    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        if (strArr != null && strArr.length != 0) {
            String str2 = strArr[0];
            switch (str2.hashCode()) {
                case -645125871:
                    if (str2.equals("--translation") && Build.VERSION.SDK_INT >= 31) {
                    }
                    break;
                case 100470631:
                    if (str2.equals("--dump-dumpable")) {
                        if (Build.VERSION.SDK_INT >= 33) {
                        }
                    }
                    break;
                case 472614934:
                    if (str2.equals("--list-dumpables")) {
                        if (Build.VERSION.SDK_INT >= 33) {
                        }
                    }
                    break;
                case 1159329357:
                    if (str2.equals("--contentcapture") && Build.VERSION.SDK_INT >= 29) {
                    }
                    break;
                case 1455016274:
                    if (str2.equals("--autofill") && Build.VERSION.SDK_INT >= 26) {
                    }
                    break;
            }
            return;
        }
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str3 = str + "  ";
        printWriter.print(str3);
        printWriter.print("mCreated=");
        printWriter.print(this.f816u);
        printWriter.print(" mResumed=");
        printWriter.print(this.f817v);
        printWriter.print(" mStopped=");
        printWriter.print(this.f818w);
        if (getApplication() != null) {
            androidx.emoji2.text.q.l(this).i(str3, printWriter);
        }
        ((y) this.f814s.f3b).f809r.u(str, fileDescriptor, printWriter, strArr);
    }

    @Override // androidx.activity.k, android.app.Activity
    public final void onActivityResult(int i3, int i4, Intent intent) {
        this.f814s.u();
        super.onActivityResult(i3, i4, intent);
    }

    @Override // androidx.activity.k, c0.i, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f815t.d(Lifecycle$Event.ON_CREATE);
        o0 o0Var = ((y) this.f814s.f3b).f809r;
        o0Var.E = false;
        o0Var.F = false;
        o0Var.L.f724i = false;
        o0Var.t(1);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((y) this.f814s.f3b).f809r.f.onCreateView(view, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(view, str, context, attributeSet) : viewOnCreateView;
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        ((y) this.f814s.f3b).f809r.k();
        this.f815t.d(Lifecycle$Event.ON_DESTROY);
    }

    @Override // androidx.activity.k, android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i3, MenuItem menuItem) {
        if (super.onMenuItemSelected(i3, menuItem)) {
            return true;
        }
        if (i3 == 6) {
            return ((y) this.f814s.f3b).f809r.i();
        }
        return false;
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        this.f817v = false;
        ((y) this.f814s.f3b).f809r.t(5);
        this.f815t.d(Lifecycle$Event.ON_PAUSE);
    }

    @Override // android.app.Activity
    public void onPostResume() {
        super.onPostResume();
        this.f815t.d(Lifecycle$Event.ON_RESUME);
        o0 o0Var = ((y) this.f814s.f3b).f809r;
        o0Var.E = false;
        o0Var.F = false;
        o0Var.L.f724i = false;
        o0Var.t(7);
    }

    @Override // androidx.activity.k, android.app.Activity
    public void onRequestPermissionsResult(int i3, String[] strArr, int[] iArr) {
        this.f814s.u();
        super.onRequestPermissionsResult(i3, strArr, iArr);
    }

    @Override // android.app.Activity
    public void onResume() {
        a0.b bVar = this.f814s;
        bVar.u();
        super.onResume();
        this.f817v = true;
        ((y) bVar.f3b).f809r.x(true);
    }

    @Override // android.app.Activity
    public void onStart() {
        a0.b bVar = this.f814s;
        bVar.u();
        y yVar = (y) bVar.f3b;
        super.onStart();
        this.f818w = false;
        if (!this.f816u) {
            this.f816u = true;
            o0 o0Var = yVar.f809r;
            o0Var.E = false;
            o0Var.F = false;
            o0Var.L.f724i = false;
            o0Var.t(4);
        }
        yVar.f809r.x(true);
        this.f815t.d(Lifecycle$Event.ON_START);
        o0 o0Var2 = yVar.f809r;
        o0Var2.E = false;
        o0Var2.F = false;
        o0Var2.L.f724i = false;
        o0Var2.t(5);
    }

    @Override // android.app.Activity
    public final void onStateNotSaved() {
        this.f814s.u();
    }

    @Override // android.app.Activity
    public void onStop() {
        a0.b bVar;
        super.onStop();
        this.f818w = true;
        do {
            bVar = this.f814s;
        } while (j(((y) bVar.f3b).f809r));
        o0 o0Var = ((y) bVar.f3b).f809r;
        o0Var.F = true;
        o0Var.L.f724i = true;
        o0Var.t(4);
        this.f815t.d(Lifecycle$Event.ON_STOP);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((y) this.f814s.f3b).f809r.f.onCreateView(null, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(str, context, attributeSet) : viewOnCreateView;
    }
}
