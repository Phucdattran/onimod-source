package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class z0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public SpecialEffectsController$Operation$State f819a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public SpecialEffectsController$Operation$LifecycleImpact f820b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final w f821c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f822d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final HashSet f823e;
    public boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f824g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final u0 f825h;

    public z0(SpecialEffectsController$Operation$State specialEffectsController$Operation$State, SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact, u0 u0Var, k0.c cVar) {
        w wVar = u0Var.f762c;
        this.f822d = new ArrayList();
        this.f823e = new HashSet();
        this.f = false;
        this.f824g = false;
        this.f819a = specialEffectsController$Operation$State;
        this.f820b = specialEffectsController$Operation$LifecycleImpact;
        this.f821c = wVar;
        cVar.a(new a0.b(4, this));
        this.f825h = u0Var;
    }

    public final void a() {
        HashSet hashSet = this.f823e;
        if (this.f) {
            return;
        }
        this.f = true;
        if (hashSet.isEmpty()) {
            b();
            return;
        }
        ArrayList arrayList = new ArrayList(hashSet);
        int size = arrayList.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayList.get(i3);
            i3++;
            k0.c cVar = (k0.c) obj;
            synchronized (cVar) {
                try {
                    if (!cVar.f2775a) {
                        cVar.f2775a = true;
                        cVar.f2777c = true;
                        k0.b bVar = cVar.f2776b;
                        if (bVar != null) {
                            try {
                                bVar.onCancel();
                            } catch (Throwable th) {
                                synchronized (cVar) {
                                    cVar.f2777c = false;
                                    cVar.notifyAll();
                                    throw th;
                                }
                            }
                        }
                        synchronized (cVar) {
                            cVar.f2777c = false;
                            cVar.notifyAll();
                        }
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
    }

    public final void b() {
        if (!this.f824g) {
            if (o0.F(2)) {
                toString();
            }
            this.f824g = true;
            ArrayList arrayList = this.f822d;
            int size = arrayList.size();
            int i3 = 0;
            while (i3 < size) {
                Object obj = arrayList.get(i3);
                i3++;
                ((Runnable) obj).run();
            }
        }
        this.f825h.k();
    }

    public final void c(SpecialEffectsController$Operation$State specialEffectsController$Operation$State, SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact) {
        int iOrdinal = specialEffectsController$Operation$LifecycleImpact.ordinal();
        w wVar = this.f821c;
        SpecialEffectsController$Operation$State specialEffectsController$Operation$State2 = SpecialEffectsController$Operation$State.f588a;
        if (iOrdinal == 0) {
            if (this.f819a != specialEffectsController$Operation$State2) {
                if (o0.F(2)) {
                    Objects.toString(wVar);
                    Objects.toString(this.f819a);
                    Objects.toString(specialEffectsController$Operation$State);
                }
                this.f819a = specialEffectsController$Operation$State;
                return;
            }
            return;
        }
        if (iOrdinal == 1) {
            if (this.f819a == specialEffectsController$Operation$State2) {
                if (o0.F(2)) {
                    Objects.toString(wVar);
                    Objects.toString(this.f820b);
                }
                this.f819a = SpecialEffectsController$Operation$State.f589b;
                this.f820b = SpecialEffectsController$Operation$LifecycleImpact.f585b;
                return;
            }
            return;
        }
        if (iOrdinal != 2) {
            return;
        }
        if (o0.F(2)) {
            Objects.toString(wVar);
            Objects.toString(this.f819a);
            Objects.toString(this.f820b);
        }
        this.f819a = specialEffectsController$Operation$State2;
        this.f820b = SpecialEffectsController$Operation$LifecycleImpact.f586c;
    }

    public final void d() {
        SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact = this.f820b;
        SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact2 = SpecialEffectsController$Operation$LifecycleImpact.f585b;
        u0 u0Var = this.f825h;
        if (specialEffectsController$Operation$LifecycleImpact != specialEffectsController$Operation$LifecycleImpact2) {
            if (specialEffectsController$Operation$LifecycleImpact == SpecialEffectsController$Operation$LifecycleImpact.f586c) {
                w wVar = u0Var.f762c;
                View viewK = wVar.K();
                if (o0.F(2)) {
                    Objects.toString(viewK.findFocus());
                    viewK.toString();
                    wVar.toString();
                }
                viewK.clearFocus();
                return;
            }
            return;
        }
        w wVar2 = u0Var.f762c;
        View viewFindFocus = wVar2.E.findFocus();
        if (viewFindFocus != null) {
            wVar2.f().f757k = viewFindFocus;
            if (o0.F(2)) {
                viewFindFocus.toString();
                wVar2.toString();
            }
        }
        View viewK2 = this.f821c.K();
        if (viewK2.getParent() == null) {
            u0Var.b();
            viewK2.setAlpha(0.0f);
        }
        if (viewK2.getAlpha() == 0.0f && viewK2.getVisibility() == 0) {
            viewK2.setVisibility(4);
        }
        t tVar = wVar2.H;
        viewK2.setAlpha(tVar == null ? 1.0f : tVar.f756j);
    }

    public final String toString() {
        return "Operation {" + Integer.toHexString(System.identityHashCode(this)) + "} {mFinalState = " + this.f819a + "} {mLifecycleImpact = " + this.f820b + "} {mFragment = " + this.f821c + "}";
    }
}
