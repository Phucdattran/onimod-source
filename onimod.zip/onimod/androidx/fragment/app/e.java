package androidx.fragment.app;

import android.animation.Animator;
import android.view.View;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class e implements k0.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Cloneable f639a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f640b;

    public e(o0 o0Var) {
        this.f639a = new CopyOnWriteArrayList();
        this.f640b = o0Var;
    }

    public void a(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.a(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void b(boolean z4) {
        o0 o0Var = (o0) this.f640b;
        e.n nVar = o0Var.f703t.f807p;
        w wVar = o0Var.f705v;
        if (wVar != null) {
            wVar.k().f695l.b(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void c(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.c(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void d(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.d(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void e(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.e(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void f(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.f(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void g(boolean z4) {
        o0 o0Var = (o0) this.f640b;
        e.n nVar = o0Var.f703t.f807p;
        w wVar = o0Var.f705v;
        if (wVar != null) {
            wVar.k().f695l.g(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void h(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.h(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void i(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.i(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void j(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.j(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void k(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.k(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void l(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.l(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    public void m(w wVar, View view, boolean z4) {
        w wVar2 = ((o0) this.f640b).f705v;
        if (wVar2 != null) {
            wVar2.k().f695l.m(wVar, view, true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
                o0 o0Var = (o0) this.f640b;
                if (wVar == ((w) qVar.f551b)) {
                    e eVar = o0Var.f695l;
                    synchronized (((CopyOnWriteArrayList) eVar.f639a)) {
                        try {
                            int size = ((CopyOnWriteArrayList) eVar.f639a).size();
                            for (int i3 = 0; i3 < size; i3++) {
                                if (((d0) ((CopyOnWriteArrayList) eVar.f639a).get(i3)).f638a == qVar) {
                                    ((CopyOnWriteArrayList) eVar.f639a).remove(i3);
                                    break;
                                }
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    androidx.viewpager2.adapter.e.m(view, (FrameLayout) qVar.f552c);
                } else {
                    continue;
                }
            }
        }
    }

    public void n(boolean z4) {
        w wVar = ((o0) this.f640b).f705v;
        if (wVar != null) {
            wVar.k().f695l.n(true);
        }
        for (d0 d0Var : (CopyOnWriteArrayList) this.f639a) {
            if (z4) {
                d0Var.getClass();
            } else {
                androidx.emoji2.text.q qVar = d0Var.f638a;
            }
        }
    }

    @Override // k0.b
    public void onCancel() {
        ((Animator) this.f639a).end();
        if (o0.F(2)) {
            Objects.toString((z0) this.f640b);
        }
    }

    public e(Animation animation) {
        this.f640b = animation;
        this.f639a = null;
    }

    public e(Animator animator) {
        this.f640b = null;
        this.f639a = animator;
    }

    public e(Animator animator, z0 z0Var) {
        this.f639a = animator;
        this.f640b = z0Var;
    }
}
