package androidx.fragment.app;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class n0 implements m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f675a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ o0 f676b;

    public n0(o0 o0Var, int i3) {
        this.f676b = o0Var;
        this.f675a = i3;
    }

    @Override // androidx.fragment.app.m0
    public final boolean a(ArrayList arrayList, ArrayList arrayList2) {
        o0 o0Var = this.f676b;
        w wVar = o0Var.f706w;
        int i3 = this.f675a;
        if (wVar == null || i3 >= 0 || !wVar.h().O(-1, 0)) {
            return o0Var.P(arrayList, arrayList2, i3, 1);
        }
        return false;
    }
}
