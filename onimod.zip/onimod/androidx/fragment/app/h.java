package androidx.fragment.app;

import android.content.Context;
import android.content.IntentFilter;
import android.view.MenuItem;
import java.util.ArrayList;
import java.util.HashSet;

/* JADX INFO: loaded from: classes.dex */
public abstract class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f656a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f657b;

    public h(Context context) {
        this.f656a = context;
    }

    public static float h(int i3, int i4, int i5) {
        return (i3 - i4) / i5;
    }

    public abstract void c();

    public void d() {
        e.c0 c0Var = (e.c0) this.f656a;
        if (c0Var != null) {
            try {
                ((e.f0) this.f657b).f1686k.unregisterReceiver(c0Var);
            } catch (IllegalArgumentException unused) {
            }
            this.f656a = null;
        }
    }

    public void e() {
        z0 z0Var = (z0) this.f656a;
        k0.c cVar = (k0.c) this.f657b;
        HashSet hashSet = z0Var.f823e;
        if (hashSet.remove(cVar) && hashSet.isEmpty()) {
            z0Var.b();
        }
    }

    public abstract IntentFilter f();

    public abstract int g();

    public MenuItem i(MenuItem menuItem) {
        if (!(menuItem instanceof i0.a)) {
            return menuItem;
        }
        i0.a aVar = (i0.a) menuItem;
        if (((q.i) this.f657b) == null) {
            this.f657b = new q.i(0);
        }
        MenuItem menuItem2 = (MenuItem) ((q.i) this.f657b).get(aVar);
        if (menuItem2 != null) {
            return menuItem2;
        }
        k.t tVar = new k.t((Context) this.f656a, aVar);
        ((q.i) this.f657b).put(aVar, tVar);
        return tVar;
    }

    public abstract void j();

    public abstract void k();

    public abstract void l(n2.c cVar);

    public abstract void m();

    public void n() {
        d();
        IntentFilter intentFilterF = f();
        if (intentFilterF.countActions() == 0) {
            return;
        }
        if (((e.c0) this.f656a) == null) {
            this.f656a = new e.c0(this);
        }
        ((e.f0) this.f657b).f1686k.registerReceiver((e.c0) this.f656a, intentFilterF);
    }

    public abstract void o();

    public abstract void p();

    public h(int i3) {
        this.f657b = new ArrayList();
        for (int i4 = 0; i4 < i3; i4++) {
            ((ArrayList) this.f657b).add(new n2.n());
        }
    }

    public h(z0 z0Var, k0.c cVar) {
        this.f656a = z0Var;
        this.f657b = cVar;
    }

    public h(e.f0 f0Var) {
        this.f657b = f0Var;
    }
}
