package androidx.fragment.app;

import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.fragment.app.strictmode.FragmentStrictMode$Flag;
import androidx.fragment.app.strictmode.WrongFragmentContainerViolation;
import androidx.lifecycle.Lifecycle$Event;
import androidx.lifecycle.Lifecycle$State;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;
import java.util.WeakHashMap;
import top.niunaijun.blackbox.R;
import top.niunaijun.blackbox.entity.location.BCell;

/* JADX INFO: loaded from: classes.dex */
public final class u0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e f760a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a0.k f761b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final w f762c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f763d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f764e = -1;

    public u0(e eVar, a0.k kVar, w wVar) {
        this.f760a = eVar;
        this.f761b = kVar;
        this.f762c = wVar;
    }

    public final void a() {
        boolean zF = o0.F(3);
        w wVar = this.f762c;
        if (zF) {
            Objects.toString(wVar);
        }
        Bundle bundle = wVar.f775b;
        wVar.f792t.M();
        wVar.f774a = 3;
        wVar.C = false;
        wVar.u();
        if (!wVar.C) {
            throw new SuperNotCalledException("Fragment " + wVar + " did not call through to super.onActivityCreated()");
        }
        if (o0.F(3)) {
            wVar.toString();
        }
        View view = wVar.E;
        if (view != null) {
            Bundle bundle2 = wVar.f775b;
            SparseArray<Parcelable> sparseArray = wVar.f776c;
            if (sparseArray != null) {
                view.restoreHierarchyState(sparseArray);
                wVar.f776c = null;
            }
            if (wVar.E != null) {
                wVar.O.f802d.b(wVar.f777d);
                wVar.f777d = null;
            }
            wVar.C = false;
            wVar.G(bundle2);
            if (!wVar.C) {
                throw new SuperNotCalledException("Fragment " + wVar + " did not call through to super.onViewStateRestored()");
            }
            if (wVar.E != null) {
                wVar.O.d(Lifecycle$Event.ON_CREATE);
            }
        }
        wVar.f775b = null;
        o0 o0Var = wVar.f792t;
        o0Var.E = false;
        o0Var.F = false;
        o0Var.L.f724i = false;
        o0Var.t(4);
        this.f760a.a(false);
    }

    public final void b() {
        View view;
        View view2;
        ArrayList arrayList = (ArrayList) this.f761b.f25c;
        w wVar = this.f762c;
        ViewGroup viewGroup = wVar.D;
        int iIndexOfChild = -1;
        if (viewGroup != null) {
            int iIndexOf = arrayList.indexOf(wVar);
            for (int i3 = iIndexOf - 1; i3 >= 0; i3--) {
                w wVar2 = (w) arrayList.get(i3);
                if (wVar2.D == viewGroup && (view2 = wVar2.E) != null) {
                    iIndexOfChild = viewGroup.indexOfChild(view2) + 1;
                }
            }
            while (true) {
                iIndexOf++;
                if (iIndexOf >= arrayList.size()) {
                    break;
                }
                w wVar3 = (w) arrayList.get(iIndexOf);
                if (wVar3.D == viewGroup && (view = wVar3.E) != null) {
                    iIndexOfChild = viewGroup.indexOfChild(view);
                    break;
                }
            }
        }
        wVar.D.addView(wVar.E, iIndexOfChild);
    }

    public final void c() {
        boolean zF = o0.F(3);
        w wVar = this.f762c;
        if (zF) {
            Objects.toString(wVar);
        }
        w wVar2 = wVar.f779g;
        u0 u0Var = null;
        a0.k kVar = this.f761b;
        if (wVar2 != null) {
            u0 u0Var2 = (u0) ((HashMap) kVar.f23a).get(wVar2.f778e);
            if (u0Var2 == null) {
                throw new IllegalStateException("Fragment " + wVar + " declared target fragment " + wVar.f779g + " that does not belong to this FragmentManager!");
            }
            wVar.f780h = wVar.f779g.f778e;
            wVar.f779g = null;
            u0Var = u0Var2;
        } else {
            String str = wVar.f780h;
            if (str != null && (u0Var = (u0) ((HashMap) kVar.f23a).get(str)) == null) {
                throw new IllegalStateException("Fragment " + wVar + " declared target fragment " + wVar.f780h + " that does not belong to this FragmentManager!");
            }
        }
        if (u0Var != null) {
            u0Var.k();
        }
        o0 o0Var = wVar.f790r;
        wVar.f791s = o0Var.f703t;
        wVar.f793u = o0Var.f705v;
        e eVar = this.f760a;
        eVar.g(false);
        ArrayList arrayList = wVar.S;
        int size = arrayList.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayList.get(i3);
            i3++;
            ((u) obj).a();
        }
        arrayList.clear();
        wVar.f792t.b(wVar.f791s, wVar.d(), wVar);
        wVar.f774a = 0;
        wVar.C = false;
        wVar.v(wVar.f791s.f807p);
        if (!wVar.C) {
            throw new SuperNotCalledException("Fragment " + wVar + " did not call through to super.onAttach()");
        }
        Iterator it = wVar.f790r.f696m.iterator();
        while (it.hasNext()) {
            ((r0) it.next()).a();
        }
        o0 o0Var2 = wVar.f792t;
        o0Var2.E = false;
        o0Var2.F = false;
        o0Var2.L.f724i = false;
        o0Var2.t(0);
        eVar.b(false);
    }

    public final int d() {
        w wVar = this.f762c;
        if (wVar.f790r == null) {
            return wVar.f774a;
        }
        int iMin = this.f764e;
        int iOrdinal = wVar.M.ordinal();
        int i3 = 0;
        if (iOrdinal == 1) {
            iMin = Math.min(iMin, 0);
        } else if (iOrdinal == 2) {
            iMin = Math.min(iMin, 1);
        } else if (iOrdinal == 3) {
            iMin = Math.min(iMin, 5);
        } else if (iOrdinal != 4) {
            iMin = Math.min(iMin, -1);
        }
        if (wVar.f785m) {
            if (wVar.f786n) {
                iMin = Math.max(this.f764e, 2);
                View view = wVar.E;
                if (view != null && view.getParent() == null) {
                    iMin = Math.min(iMin, 2);
                }
            } else {
                iMin = this.f764e < 4 ? Math.min(iMin, wVar.f774a) : Math.min(iMin, 1);
            }
        }
        if (!wVar.f783k) {
            iMin = Math.min(iMin, 1);
        }
        ViewGroup viewGroup = wVar.D;
        SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact = null;
        z0 z0Var = null;
        if (viewGroup != null) {
            j jVarF = j.f(viewGroup, wVar.k().E());
            z0 z0VarD = jVarF.d(wVar);
            SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact2 = z0VarD != null ? z0VarD.f820b : null;
            ArrayList arrayList = jVarF.f663c;
            int size = arrayList.size();
            while (i3 < size) {
                Object obj = arrayList.get(i3);
                i3++;
                z0 z0Var2 = (z0) obj;
                if (z0Var2.f821c.equals(wVar) && !z0Var2.f) {
                    z0Var = z0Var2;
                    break;
                }
            }
            specialEffectsController$Operation$LifecycleImpact = (z0Var == null || !(specialEffectsController$Operation$LifecycleImpact2 == null || specialEffectsController$Operation$LifecycleImpact2 == SpecialEffectsController$Operation$LifecycleImpact.f584a)) ? specialEffectsController$Operation$LifecycleImpact2 : z0Var.f820b;
        }
        if (specialEffectsController$Operation$LifecycleImpact == SpecialEffectsController$Operation$LifecycleImpact.f585b) {
            iMin = Math.min(iMin, 6);
        } else if (specialEffectsController$Operation$LifecycleImpact == SpecialEffectsController$Operation$LifecycleImpact.f586c) {
            iMin = Math.max(iMin, 3);
        } else if (wVar.f784l) {
            iMin = wVar.t() ? Math.min(iMin, 1) : Math.min(iMin, -1);
        }
        if (wVar.F && wVar.f774a < 5) {
            iMin = Math.min(iMin, 4);
        }
        if (o0.F(2)) {
            Objects.toString(wVar);
        }
        return iMin;
    }

    public final void e() {
        Parcelable parcelable;
        boolean zF = o0.F(3);
        final w wVar = this.f762c;
        if (zF) {
            Objects.toString(wVar);
        }
        if (wVar.K) {
            Bundle bundle = wVar.f775b;
            if (bundle != null && (parcelable = bundle.getParcelable("android:support:fragments")) != null) {
                wVar.f792t.S(parcelable);
                o0 o0Var = wVar.f792t;
                o0Var.E = false;
                o0Var.F = false;
                o0Var.L.f724i = false;
                o0Var.t(1);
            }
            wVar.f774a = 1;
            return;
        }
        e eVar = this.f760a;
        eVar.h(false);
        Bundle bundle2 = wVar.f775b;
        wVar.f792t.M();
        wVar.f774a = 1;
        wVar.C = false;
        wVar.N.a(new androidx.lifecycle.o() { // from class: androidx.fragment.app.Fragment$6
            @Override // androidx.lifecycle.o
            public final void a(androidx.lifecycle.q qVar, Lifecycle$Event lifecycle$Event) {
                View view;
                if (lifecycle$Event != Lifecycle$Event.ON_STOP || (view = wVar.E) == null) {
                    return;
                }
                view.cancelPendingInputEvents();
            }
        });
        wVar.Q.b(bundle2);
        wVar.w(bundle2);
        wVar.K = true;
        if (wVar.C) {
            wVar.N.d(Lifecycle$Event.ON_CREATE);
            eVar.c(false);
        } else {
            throw new SuperNotCalledException("Fragment " + wVar + " did not call through to super.onCreate()");
        }
    }

    public final void f() {
        String resourceName;
        w wVar = this.f762c;
        if (wVar.f785m) {
            return;
        }
        if (o0.F(3)) {
            Objects.toString(wVar);
        }
        LayoutInflater layoutInflaterA = wVar.A(wVar.f775b);
        wVar.J = layoutInflaterA;
        ViewGroup viewGroup = wVar.D;
        if (viewGroup == null) {
            int i3 = wVar.f795w;
            if (i3 == 0) {
                viewGroup = null;
            } else {
                if (i3 == -1) {
                    throw new IllegalArgumentException("Cannot create fragment " + wVar + " for a container view with no id");
                }
                viewGroup = (ViewGroup) wVar.f790r.f704u.U(i3);
                if (viewGroup == null) {
                    if (!wVar.f787o) {
                        try {
                            resourceName = wVar.l().getResourceName(wVar.f795w);
                        } catch (Resources.NotFoundException unused) {
                            resourceName = "unknown";
                        }
                        throw new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(wVar.f795w) + " (" + resourceName + ") for fragment " + wVar);
                    }
                } else if (!(viewGroup instanceof FragmentContainerView)) {
                    y0.a aVar = y0.b.f4907a;
                    WrongFragmentContainerViolation wrongFragmentContainerViolation = new WrongFragmentContainerViolation(wVar, viewGroup);
                    if (o0.F(3)) {
                        wrongFragmentContainerViolation.a().getClass();
                    }
                    y0.a aVarA = y0.b.a(wVar);
                    if (aVarA.f4905a.contains(FragmentStrictMode$Flag.f747e) && y0.b.d(aVarA, wVar.getClass(), WrongFragmentContainerViolation.class)) {
                        y0.b.b(aVarA, wrongFragmentContainerViolation);
                    }
                }
            }
        }
        wVar.D = viewGroup;
        wVar.H(layoutInflaterA, viewGroup, wVar.f775b);
        View view = wVar.E;
        if (view != null) {
            int i4 = 0;
            view.setSaveFromParentEnabled(false);
            wVar.E.setTag(R.id.fragment_container_view_tag, wVar);
            if (viewGroup != null) {
                b();
            }
            if (wVar.f797y) {
                wVar.E.setVisibility(8);
            }
            View view2 = wVar.E;
            WeakHashMap weakHashMap = o0.h0.f3558a;
            if (view2.isAttachedToWindow()) {
                o0.x.c(wVar.E);
            } else {
                View view3 = wVar.E;
                view3.addOnAttachStateChangeListener(new t0(i4, view3));
            }
            wVar.F(wVar.E);
            wVar.f792t.t(2);
            this.f760a.m(wVar, wVar.E, false);
            int visibility = wVar.E.getVisibility();
            wVar.f().f756j = wVar.E.getAlpha();
            if (wVar.D != null && visibility == 0) {
                View viewFindFocus = wVar.E.findFocus();
                if (viewFindFocus != null) {
                    wVar.f().f757k = viewFindFocus;
                    if (o0.F(2)) {
                        viewFindFocus.toString();
                        Objects.toString(wVar);
                    }
                }
                wVar.E.setAlpha(0.0f);
            }
        }
        wVar.f774a = 2;
    }

    public final void g() {
        boolean z4;
        w wVarC;
        boolean zF = o0.F(3);
        w wVar = this.f762c;
        if (zF) {
            Objects.toString(wVar);
        }
        int i3 = 0;
        boolean z5 = wVar.f784l && !wVar.t();
        a0.k kVar = this.f761b;
        if (z5) {
        }
        if (!z5) {
            q0 q0Var = (q0) kVar.f26d;
            if (!((q0Var.f720d.containsKey(wVar.f778e) && q0Var.f722g) ? q0Var.f723h : true)) {
                String str = wVar.f780h;
                if (str != null && (wVarC = kVar.c(str)) != null && wVarC.A) {
                    wVar.f779g = wVarC;
                }
                wVar.f774a = 0;
                return;
            }
        }
        y yVar = wVar.f791s;
        if (yVar != null) {
            z4 = ((q0) kVar.f26d).f723h;
        } else {
            e.n nVar = yVar.f807p;
            z4 = g0.e.g(nVar) ? !nVar.isChangingConfigurations() : true;
        }
        if (z5 || z4) {
            q0 q0Var2 = (q0) kVar.f26d;
            q0Var2.getClass();
            if (o0.F(3)) {
                Objects.toString(wVar);
            }
            q0Var2.d(wVar.f778e);
        }
        wVar.f792t.k();
        wVar.N.d(Lifecycle$Event.ON_DESTROY);
        wVar.f774a = 0;
        wVar.K = false;
        wVar.C = true;
        this.f760a.d(false);
        ArrayList arrayListF = kVar.f();
        int size = arrayListF.size();
        while (i3 < size) {
            Object obj = arrayListF.get(i3);
            i3++;
            u0 u0Var = (u0) obj;
            if (u0Var != null) {
                w wVar2 = u0Var.f762c;
                if (wVar.f778e.equals(wVar2.f780h)) {
                    wVar2.f779g = wVar;
                    wVar2.f780h = null;
                }
            }
        }
        String str2 = wVar.f780h;
        if (str2 != null) {
            wVar.f779g = kVar.c(str2);
        }
        kVar.j(this);
    }

    public final void h() {
        View view;
        boolean zF = o0.F(3);
        w wVar = this.f762c;
        if (zF) {
            Objects.toString(wVar);
        }
        ViewGroup viewGroup = wVar.D;
        if (viewGroup != null && (view = wVar.E) != null) {
            viewGroup.removeView(view);
        }
        wVar.f792t.t(1);
        if (wVar.E != null) {
            w0 w0Var = wVar.O;
            w0Var.f();
            if (w0Var.f801c.f879c.compareTo(Lifecycle$State.f831c) >= 0) {
                wVar.O.d(Lifecycle$Event.ON_DESTROY);
            }
        }
        wVar.f774a = 1;
        wVar.C = false;
        wVar.y();
        if (!wVar.C) {
            throw new SuperNotCalledException("Fragment " + wVar + " did not call through to super.onDestroyView()");
        }
        q.j jVar = ((b1.a) androidx.emoji2.text.q.l(wVar).f552c).f1037d;
        if (jVar.f3745c > 0) {
            jVar.f3744b[0].getClass();
            throw new ClassCastException();
        }
        wVar.f788p = false;
        this.f760a.n(false);
        wVar.D = null;
        wVar.E = null;
        wVar.O = null;
        wVar.P.g(null);
        wVar.f786n = false;
    }

    public final void i() {
        boolean zF = o0.F(3);
        w wVar = this.f762c;
        if (zF) {
            Objects.toString(wVar);
        }
        wVar.f774a = -1;
        wVar.C = false;
        wVar.z();
        wVar.J = null;
        if (!wVar.C) {
            throw new SuperNotCalledException("Fragment " + wVar + " did not call through to super.onDetach()");
        }
        o0 o0Var = wVar.f792t;
        if (!o0Var.G) {
            o0Var.k();
            wVar.f792t = new o0();
        }
        this.f760a.e(false);
        wVar.f774a = -1;
        wVar.f791s = null;
        wVar.f793u = null;
        wVar.f790r = null;
        if (!wVar.f784l || wVar.t()) {
            q0 q0Var = (q0) this.f761b.f26d;
            if (!((q0Var.f720d.containsKey(wVar.f778e) && q0Var.f722g) ? q0Var.f723h : true)) {
                return;
            }
        }
        if (o0.F(3)) {
            Objects.toString(wVar);
        }
        wVar.q();
    }

    public final void j() {
        w wVar = this.f762c;
        if (wVar.f785m && wVar.f786n && !wVar.f788p) {
            if (o0.F(3)) {
                Objects.toString(wVar);
            }
            LayoutInflater layoutInflaterA = wVar.A(wVar.f775b);
            wVar.J = layoutInflaterA;
            wVar.H(layoutInflaterA, null, wVar.f775b);
            View view = wVar.E;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                wVar.E.setTag(R.id.fragment_container_view_tag, wVar);
                if (wVar.f797y) {
                    wVar.E.setVisibility(8);
                }
                wVar.F(wVar.E);
                wVar.f792t.t(2);
                this.f760a.m(wVar, wVar.E, false);
                wVar.f774a = 2;
            }
        }
    }

    public final void k() {
        ViewGroup viewGroup;
        ViewGroup viewGroup2;
        ViewGroup viewGroup3;
        a0.k kVar = this.f761b;
        boolean z4 = this.f763d;
        w wVar = this.f762c;
        if (z4) {
            if (o0.F(2)) {
                Objects.toString(wVar);
                return;
            }
            return;
        }
        try {
            this.f763d = true;
            boolean z5 = false;
            while (true) {
                int iD = d();
                int i3 = wVar.f774a;
                if (iD == i3) {
                    if (!z5 && i3 == -1 && wVar.f784l && !wVar.t()) {
                        if (o0.F(3)) {
                            Objects.toString(wVar);
                        }
                        q0 q0Var = (q0) kVar.f26d;
                        q0Var.getClass();
                        if (o0.F(3)) {
                            Objects.toString(wVar);
                        }
                        q0Var.d(wVar.f778e);
                        kVar.j(this);
                        if (o0.F(3)) {
                            Objects.toString(wVar);
                        }
                        wVar.q();
                    }
                    if (wVar.I) {
                        if (wVar.E != null && (viewGroup = wVar.D) != null) {
                            j jVarF = j.f(viewGroup, wVar.k().E());
                            boolean z6 = wVar.f797y;
                            SpecialEffectsController$Operation$LifecycleImpact specialEffectsController$Operation$LifecycleImpact = SpecialEffectsController$Operation$LifecycleImpact.f584a;
                            if (z6) {
                                if (o0.F(2)) {
                                    Objects.toString(wVar);
                                }
                                jVarF.a(SpecialEffectsController$Operation$State.f590c, specialEffectsController$Operation$LifecycleImpact, this);
                            } else {
                                if (o0.F(2)) {
                                    Objects.toString(wVar);
                                }
                                jVarF.a(SpecialEffectsController$Operation$State.f589b, specialEffectsController$Operation$LifecycleImpact, this);
                            }
                        }
                        o0 o0Var = wVar.f790r;
                        if (o0Var != null && wVar.f783k && o0.G(wVar)) {
                            o0Var.D = true;
                        }
                        wVar.I = false;
                        wVar.f792t.n();
                    }
                    return;
                }
                if (iD <= i3) {
                    switch (i3 - 1) {
                        case -1:
                            i();
                            break;
                        case 0:
                            g();
                            break;
                        case 1:
                            h();
                            wVar.f774a = 1;
                            break;
                        case 2:
                            wVar.f786n = false;
                            wVar.f774a = 2;
                            break;
                        case 3:
                            if (o0.F(3)) {
                                Objects.toString(wVar);
                            }
                            if (wVar.E != null && wVar.f776c == null) {
                                p();
                            }
                            if (wVar.E != null && (viewGroup2 = wVar.D) != null) {
                                j jVarF2 = j.f(viewGroup2, wVar.k().E());
                                if (o0.F(2)) {
                                    Objects.toString(wVar);
                                }
                                jVarF2.a(SpecialEffectsController$Operation$State.f588a, SpecialEffectsController$Operation$LifecycleImpact.f586c, this);
                            }
                            wVar.f774a = 3;
                            break;
                        case 4:
                            r();
                            break;
                        case 5:
                            wVar.f774a = 5;
                            break;
                        case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                            l();
                            break;
                    }
                } else {
                    switch (i3 + 1) {
                        case 0:
                            c();
                            break;
                        case 1:
                            e();
                            break;
                        case 2:
                            j();
                            f();
                            break;
                        case 3:
                            a();
                            break;
                        case 4:
                            if (wVar.E != null && (viewGroup3 = wVar.D) != null) {
                                j jVarF3 = j.f(viewGroup3, wVar.k().E());
                                SpecialEffectsController$Operation$State specialEffectsController$Operation$StateB = SpecialEffectsController$Operation$State.b(wVar.E.getVisibility());
                                if (o0.F(2)) {
                                    Objects.toString(wVar);
                                }
                                jVarF3.a(specialEffectsController$Operation$StateB, SpecialEffectsController$Operation$LifecycleImpact.f585b, this);
                            }
                            wVar.f774a = 4;
                            break;
                        case 5:
                            q();
                            break;
                        case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                            wVar.f774a = 6;
                            break;
                        case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                            n();
                            break;
                    }
                }
                z5 = true;
            }
        } finally {
            this.f763d = false;
        }
    }

    public final void l() {
        boolean zF = o0.F(3);
        w wVar = this.f762c;
        if (zF) {
            Objects.toString(wVar);
        }
        wVar.f792t.t(5);
        if (wVar.E != null) {
            wVar.O.d(Lifecycle$Event.ON_PAUSE);
        }
        wVar.N.d(Lifecycle$Event.ON_PAUSE);
        wVar.f774a = 6;
        wVar.C = true;
        this.f760a.f(false);
    }

    public final void m(ClassLoader classLoader) {
        w wVar = this.f762c;
        Bundle bundle = wVar.f775b;
        if (bundle == null) {
            return;
        }
        bundle.setClassLoader(classLoader);
        wVar.f776c = wVar.f775b.getSparseParcelableArray("android:view_state");
        wVar.f777d = wVar.f775b.getBundle("android:view_registry_state");
        String string = wVar.f775b.getString("android:target_state");
        wVar.f780h = string;
        if (string != null) {
            wVar.f781i = wVar.f775b.getInt("android:target_req_state", 0);
        }
        boolean z4 = wVar.f775b.getBoolean("android:user_visible_hint", true);
        wVar.G = z4;
        if (z4) {
            return;
        }
        wVar.F = true;
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0030  */
    public final void n() {
        boolean zF = o0.F(3);
        w wVar = this.f762c;
        if (zF) {
            Objects.toString(wVar);
        }
        t tVar = wVar.H;
        View view = tVar == null ? null : tVar.f757k;
        if (view != null) {
            if (view == wVar.E) {
                view.requestFocus();
                if (o0.F(2)) {
                    view.toString();
                    Objects.toString(wVar);
                    Objects.toString(wVar.E.findFocus());
                }
            } else {
                ViewParent parent = view.getParent();
                while (true) {
                    if (parent != null) {
                        if (parent == wVar.E) {
                            view.requestFocus();
                            if (o0.F(2)) {
                                view.toString();
                                Objects.toString(wVar);
                                Objects.toString(wVar.E.findFocus());
                            }
                        } else {
                            parent = parent.getParent();
                        }
                    }
                }
            }
        }
        wVar.f().f757k = null;
        wVar.f792t.M();
        wVar.f792t.x(true);
        wVar.f774a = 7;
        wVar.C = false;
        wVar.B();
        if (!wVar.C) {
            throw new SuperNotCalledException("Fragment " + wVar + " did not call through to super.onResume()");
        }
        androidx.lifecycle.s sVar = wVar.N;
        Lifecycle$Event lifecycle$Event = Lifecycle$Event.ON_RESUME;
        sVar.d(lifecycle$Event);
        if (wVar.E != null) {
            wVar.O.f801c.d(lifecycle$Event);
        }
        o0 o0Var = wVar.f792t;
        o0Var.E = false;
        o0Var.F = false;
        o0Var.L.f724i = false;
        o0Var.t(7);
        this.f760a.i(false);
        wVar.f775b = null;
        wVar.f776c = null;
        wVar.f777d = null;
    }

    public final Bundle o() {
        Bundle bundle = new Bundle();
        w wVar = this.f762c;
        wVar.C(bundle);
        wVar.Q.c(bundle);
        bundle.putParcelable("android:support:fragments", wVar.f792t.T());
        this.f760a.j(false);
        if (bundle.isEmpty()) {
            bundle = null;
        }
        if (wVar.E != null) {
            p();
        }
        if (wVar.f776c != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", wVar.f776c);
        }
        if (wVar.f777d != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBundle("android:view_registry_state", wVar.f777d);
        }
        if (!wVar.G) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", wVar.G);
        }
        return bundle;
    }

    public final void p() {
        w wVar = this.f762c;
        if (wVar.E == null) {
            return;
        }
        if (o0.F(2)) {
            Objects.toString(wVar);
            Objects.toString(wVar.E);
        }
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        wVar.E.saveHierarchyState(sparseArray);
        if (sparseArray.size() > 0) {
            wVar.f776c = sparseArray;
        }
        Bundle bundle = new Bundle();
        wVar.O.f802d.c(bundle);
        if (bundle.isEmpty()) {
            return;
        }
        wVar.f777d = bundle;
    }

    public final void q() {
        boolean zF = o0.F(3);
        w wVar = this.f762c;
        if (zF) {
            Objects.toString(wVar);
        }
        wVar.f792t.M();
        wVar.f792t.x(true);
        wVar.f774a = 5;
        wVar.C = false;
        wVar.D();
        if (!wVar.C) {
            throw new SuperNotCalledException("Fragment " + wVar + " did not call through to super.onStart()");
        }
        androidx.lifecycle.s sVar = wVar.N;
        Lifecycle$Event lifecycle$Event = Lifecycle$Event.ON_START;
        sVar.d(lifecycle$Event);
        if (wVar.E != null) {
            wVar.O.f801c.d(lifecycle$Event);
        }
        o0 o0Var = wVar.f792t;
        o0Var.E = false;
        o0Var.F = false;
        o0Var.L.f724i = false;
        o0Var.t(5);
        this.f760a.k(false);
    }

    public final void r() {
        boolean zF = o0.F(3);
        w wVar = this.f762c;
        if (zF) {
            Objects.toString(wVar);
        }
        o0 o0Var = wVar.f792t;
        o0Var.F = true;
        o0Var.L.f724i = true;
        o0Var.t(4);
        if (wVar.E != null) {
            wVar.O.d(Lifecycle$Event.ON_STOP);
        }
        wVar.N.d(Lifecycle$Event.ON_STOP);
        wVar.f774a = 4;
        wVar.C = false;
        wVar.E();
        if (wVar.C) {
            this.f760a.l(false);
            return;
        }
        throw new SuperNotCalledException("Fragment " + wVar + " did not call through to super.onStop()");
    }

    public u0(e eVar, a0.k kVar, ClassLoader classLoader, i0 i0Var, s0 s0Var) {
        this.f760a = eVar;
        this.f761b = kVar;
        w wVarA = i0Var.a(s0Var.f731a);
        Bundle bundle = s0Var.f739j;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
        }
        wVarA.M(bundle);
        wVarA.f778e = s0Var.f732b;
        wVarA.f785m = s0Var.f733c;
        wVarA.f787o = true;
        wVarA.f794v = s0Var.f734d;
        wVarA.f795w = s0Var.f735e;
        wVarA.f796x = s0Var.f;
        wVarA.A = s0Var.f736g;
        wVarA.f784l = s0Var.f737h;
        wVarA.f798z = s0Var.f738i;
        wVarA.f797y = s0Var.f740k;
        wVarA.M = Lifecycle$State.values()[s0Var.f741l];
        Bundle bundle2 = s0Var.f742m;
        if (bundle2 != null) {
            wVarA.f775b = bundle2;
        } else {
            wVarA.f775b = new Bundle();
        }
        this.f762c = wVarA;
        if (o0.F(2)) {
            Objects.toString(wVarA);
        }
    }

    public u0(e eVar, a0.k kVar, w wVar, s0 s0Var) {
        this.f760a = eVar;
        this.f761b = kVar;
        this.f762c = wVar;
        wVar.f776c = null;
        wVar.f777d = null;
        wVar.f789q = 0;
        wVar.f786n = false;
        wVar.f783k = false;
        w wVar2 = wVar.f779g;
        wVar.f780h = wVar2 != null ? wVar2.f778e : null;
        wVar.f779g = null;
        Bundle bundle = s0Var.f742m;
        if (bundle != null) {
            wVar.f775b = bundle;
        } else {
            wVar.f775b = new Bundle();
        }
    }
}
