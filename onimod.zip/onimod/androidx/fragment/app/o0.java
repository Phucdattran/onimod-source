package androidx.fragment.app;

import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.Lifecycle$State;
import com.mod.menu.ModConfig;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import top.niunaijun.blackbox.R;
import top.niunaijun.blackbox.core.system.JarConfig;
import top.niunaijun.blackbox.entity.location.BCell;

/* JADX INFO: loaded from: classes.dex */
public final class o0 {
    public androidx.activity.result.e A;
    public androidx.activity.result.e B;
    public ArrayDeque C;
    public boolean D;
    public boolean E;
    public boolean F;
    public boolean G;
    public boolean H;
    public ArrayList I;
    public ArrayList J;
    public ArrayList K;
    public q0 L;
    public final a2.i M;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f686b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList f688d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ArrayList f689e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public androidx.activity.t f690g;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final e f695l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final CopyOnWriteArrayList f696m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final e0 f697n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final e0 f698o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final e0 f699p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final e0 f700q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final h0 f701r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f702s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public y f703t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public a3.a f704u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public w f705v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public w f706w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final i0 f707x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final s2.e f708y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public androidx.activity.result.e f709z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f685a = new ArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a0.k f687c = new a0.k(3);
    public final c0 f = new c0(this);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final g0 f691h = new g0(this);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final AtomicInteger f692i = new AtomicInteger();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Map f693j = Collections.synchronizedMap(new HashMap());

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Map f694k = Collections.synchronizedMap(new HashMap());

    /* JADX WARN: Type inference failed for: r0v12, types: [androidx.fragment.app.e0] */
    /* JADX WARN: Type inference failed for: r0v13, types: [androidx.fragment.app.e0] */
    /* JADX WARN: Type inference failed for: r0v14, types: [androidx.fragment.app.e0] */
    /* JADX WARN: Type inference failed for: r0v15, types: [androidx.fragment.app.e0] */
    public o0() {
        Collections.synchronizedMap(new HashMap());
        this.f695l = new e(this);
        this.f696m = new CopyOnWriteArrayList();
        final int i3 = 0;
        this.f697n = new n0.a(this) { // from class: androidx.fragment.app.e0

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ o0 f642b;

            {
                this.f642b = this;
            }

            @Override // n0.a
            public final void accept(Object obj) {
                switch (i3) {
                    case 0:
                        o0 o0Var = this.f642b;
                        if (o0Var.H()) {
                            o0Var.h(false);
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        o0 o0Var2 = this.f642b;
                        if (o0Var2.H() && num.intValue() == 80) {
                            o0Var2.l(false);
                            break;
                        }
                        break;
                    case 2:
                        c0.j jVar = (c0.j) obj;
                        o0 o0Var3 = this.f642b;
                        if (o0Var3.H()) {
                            boolean z4 = jVar.f1087a;
                            o0Var3.m(false);
                        }
                        break;
                    default:
                        c0.o oVar = (c0.o) obj;
                        o0 o0Var4 = this.f642b;
                        if (o0Var4.H()) {
                            boolean z5 = oVar.f1102a;
                            o0Var4.r(false);
                        }
                        break;
                }
            }
        };
        final int i4 = 1;
        this.f698o = new n0.a(this) { // from class: androidx.fragment.app.e0

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ o0 f642b;

            {
                this.f642b = this;
            }

            @Override // n0.a
            public final void accept(Object obj) {
                switch (i4) {
                    case 0:
                        o0 o0Var = this.f642b;
                        if (o0Var.H()) {
                            o0Var.h(false);
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        o0 o0Var2 = this.f642b;
                        if (o0Var2.H() && num.intValue() == 80) {
                            o0Var2.l(false);
                            break;
                        }
                        break;
                    case 2:
                        c0.j jVar = (c0.j) obj;
                        o0 o0Var3 = this.f642b;
                        if (o0Var3.H()) {
                            boolean z4 = jVar.f1087a;
                            o0Var3.m(false);
                        }
                        break;
                    default:
                        c0.o oVar = (c0.o) obj;
                        o0 o0Var4 = this.f642b;
                        if (o0Var4.H()) {
                            boolean z5 = oVar.f1102a;
                            o0Var4.r(false);
                        }
                        break;
                }
            }
        };
        final int i5 = 2;
        this.f699p = new n0.a(this) { // from class: androidx.fragment.app.e0

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ o0 f642b;

            {
                this.f642b = this;
            }

            @Override // n0.a
            public final void accept(Object obj) {
                switch (i5) {
                    case 0:
                        o0 o0Var = this.f642b;
                        if (o0Var.H()) {
                            o0Var.h(false);
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        o0 o0Var2 = this.f642b;
                        if (o0Var2.H() && num.intValue() == 80) {
                            o0Var2.l(false);
                            break;
                        }
                        break;
                    case 2:
                        c0.j jVar = (c0.j) obj;
                        o0 o0Var3 = this.f642b;
                        if (o0Var3.H()) {
                            boolean z4 = jVar.f1087a;
                            o0Var3.m(false);
                        }
                        break;
                    default:
                        c0.o oVar = (c0.o) obj;
                        o0 o0Var4 = this.f642b;
                        if (o0Var4.H()) {
                            boolean z5 = oVar.f1102a;
                            o0Var4.r(false);
                        }
                        break;
                }
            }
        };
        final int i6 = 3;
        this.f700q = new n0.a(this) { // from class: androidx.fragment.app.e0

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ o0 f642b;

            {
                this.f642b = this;
            }

            @Override // n0.a
            public final void accept(Object obj) {
                switch (i6) {
                    case 0:
                        o0 o0Var = this.f642b;
                        if (o0Var.H()) {
                            o0Var.h(false);
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        o0 o0Var2 = this.f642b;
                        if (o0Var2.H() && num.intValue() == 80) {
                            o0Var2.l(false);
                            break;
                        }
                        break;
                    case 2:
                        c0.j jVar = (c0.j) obj;
                        o0 o0Var3 = this.f642b;
                        if (o0Var3.H()) {
                            boolean z4 = jVar.f1087a;
                            o0Var3.m(false);
                        }
                        break;
                    default:
                        c0.o oVar = (c0.o) obj;
                        o0 o0Var4 = this.f642b;
                        if (o0Var4.H()) {
                            boolean z5 = oVar.f1102a;
                            o0Var4.r(false);
                        }
                        break;
                }
            }
        };
        this.f701r = new h0(this);
        this.f702s = -1;
        this.f707x = new i0(this);
        int i7 = 5;
        this.f708y = new s2.e(i7);
        this.C = new ArrayDeque();
        this.M = new a2.i(i7, this);
    }

    public static boolean F(int i3) {
        return Log.isLoggable("FragmentManager", i3);
    }

    public static boolean G(w wVar) {
        wVar.getClass();
        ArrayList arrayListG = wVar.f792t.f687c.g();
        int size = arrayListG.size();
        boolean zG = false;
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayListG.get(i3);
            i3++;
            w wVar2 = (w) obj;
            if (wVar2 != null) {
                zG = G(wVar2);
            }
            if (zG) {
                return true;
            }
        }
        return false;
    }

    public static boolean I(w wVar) {
        if (wVar == null) {
            return true;
        }
        if (wVar.B) {
            return wVar.f790r == null || I(wVar.f793u);
        }
        return false;
    }

    public static boolean J(w wVar) {
        if (wVar == null) {
            return true;
        }
        o0 o0Var = wVar.f790r;
        return wVar.equals(o0Var.f706w) && J(o0Var.f705v);
    }

    public final w A(int i3) {
        a0.k kVar = this.f687c;
        ArrayList arrayList = (ArrayList) kVar.f25c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            w wVar = (w) arrayList.get(size);
            if (wVar != null && wVar.f794v == i3) {
                return wVar;
            }
        }
        for (u0 u0Var : ((HashMap) kVar.f23a).values()) {
            if (u0Var != null) {
                w wVar2 = u0Var.f762c;
                if (wVar2.f794v == i3) {
                    return wVar2;
                }
            }
        }
        return null;
    }

    public final w B(String str) {
        a0.k kVar = this.f687c;
        ArrayList arrayList = (ArrayList) kVar.f25c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            w wVar = (w) arrayList.get(size);
            if (wVar != null && str.equals(wVar.f796x)) {
                return wVar;
            }
        }
        for (u0 u0Var : ((HashMap) kVar.f23a).values()) {
            if (u0Var != null) {
                w wVar2 = u0Var.f762c;
                if (str.equals(wVar2.f796x)) {
                    return wVar2;
                }
            }
        }
        return null;
    }

    public final ViewGroup C(w wVar) {
        ViewGroup viewGroup = wVar.D;
        if (viewGroup != null) {
            return viewGroup;
        }
        if (wVar.f795w <= 0 || !this.f704u.V()) {
            return null;
        }
        View viewU = this.f704u.U(wVar.f795w);
        if (viewU instanceof ViewGroup) {
            return (ViewGroup) viewU;
        }
        return null;
    }

    public final i0 D() {
        w wVar = this.f705v;
        return wVar != null ? wVar.f790r.D() : this.f707x;
    }

    public final s2.e E() {
        w wVar = this.f705v;
        return wVar != null ? wVar.f790r.E() : this.f708y;
    }

    public final boolean H() {
        w wVar = this.f705v;
        if (wVar == null) {
            return true;
        }
        return wVar.r() && this.f705v.k().H();
    }

    public final boolean K() {
        return this.E || this.F;
    }

    public final void L(int i3, boolean z4) {
        y yVar;
        if (this.f703t == null && i3 != -1) {
            throw new IllegalStateException("No activity");
        }
        if (z4 || i3 != this.f702s) {
            this.f702s = i3;
            a0.k kVar = this.f687c;
            HashMap map = (HashMap) kVar.f23a;
            ArrayList arrayList = (ArrayList) kVar.f25c;
            int size = arrayList.size();
            int i4 = 0;
            while (i4 < size) {
                Object obj = arrayList.get(i4);
                i4++;
                u0 u0Var = (u0) map.get(((w) obj).f778e);
                if (u0Var != null) {
                    u0Var.k();
                }
            }
            for (u0 u0Var2 : map.values()) {
                if (u0Var2 != null) {
                    u0Var2.k();
                    w wVar = u0Var2.f762c;
                    if (wVar.f784l && !wVar.t()) {
                        kVar.j(u0Var2);
                    }
                }
            }
            Z();
            if (this.D && (yVar = this.f703t) != null && this.f702s == 7) {
                yVar.f810s.invalidateOptionsMenu();
                this.D = false;
            }
        }
    }

    public final void M() {
        if (this.f703t == null) {
            return;
        }
        this.E = false;
        this.F = false;
        this.L.f724i = false;
        for (w wVar : this.f687c.h()) {
            if (wVar != null) {
                wVar.f792t.M();
            }
        }
    }

    public final boolean N() {
        return O(-1, 0);
    }

    public final boolean O(int i3, int i4) {
        x(false);
        w(true);
        w wVar = this.f706w;
        if (wVar != null && i3 < 0 && wVar.h().N()) {
            return true;
        }
        boolean zP = P(this.I, this.J, i3, i4);
        if (zP) {
            this.f686b = true;
            try {
                R(this.I, this.J);
                d();
            } catch (Throwable th) {
                d();
                throw th;
            }
        }
        b0();
        if (this.H) {
            this.H = false;
            Z();
        }
        ((HashMap) this.f687c.f23a).values().removeAll(Collections.singleton(null));
        return zP;
    }

    public final boolean P(ArrayList arrayList, ArrayList arrayList2, int i3, int i4) {
        boolean z4 = (i4 & 1) != 0;
        ArrayList arrayList3 = this.f688d;
        int size = -1;
        if (arrayList3 != null && !arrayList3.isEmpty()) {
            if (i3 < 0) {
                size = z4 ? 0 : this.f688d.size() - 1;
            } else {
                int size2 = this.f688d.size() - 1;
                while (size2 >= 0) {
                    a aVar = (a) this.f688d.get(size2);
                    if (i3 >= 0 && i3 == aVar.f609r) {
                        break;
                    }
                    size2--;
                }
                if (size2 < 0) {
                    size = size2;
                } else if (z4) {
                    size = size2;
                    while (size > 0) {
                        a aVar2 = (a) this.f688d.get(size - 1);
                        if (i3 < 0 || i3 != aVar2.f609r) {
                            break;
                        }
                        size--;
                    }
                } else if (size2 != this.f688d.size() - 1) {
                    size = size2 + 1;
                }
            }
        }
        if (size < 0) {
            return false;
        }
        for (int size3 = this.f688d.size() - 1; size3 >= size; size3--) {
            arrayList.add((a) this.f688d.remove(size3));
            arrayList2.add(Boolean.TRUE);
        }
        return true;
    }

    public final void Q(w wVar) {
        if (F(2)) {
            Objects.toString(wVar);
        }
        boolean zT = wVar.t();
        if (wVar.f798z && zT) {
            return;
        }
        a0.k kVar = this.f687c;
        synchronized (((ArrayList) kVar.f25c)) {
            ((ArrayList) kVar.f25c).remove(wVar);
        }
        wVar.f783k = false;
        if (G(wVar)) {
            this.D = true;
        }
        wVar.f784l = true;
        Y(wVar);
    }

    public final void R(ArrayList arrayList, ArrayList arrayList2) {
        if (arrayList.isEmpty()) {
            return;
        }
        if (arrayList.size() != arrayList2.size()) {
            throw new IllegalStateException("Internal error with the back stack records");
        }
        int size = arrayList.size();
        int i3 = 0;
        int i4 = 0;
        while (i3 < size) {
            if (!((a) arrayList.get(i3)).f606o) {
                if (i4 != i3) {
                    z(arrayList, arrayList2, i4, i3);
                }
                i4 = i3 + 1;
                if (((Boolean) arrayList2.get(i3)).booleanValue()) {
                    while (i4 < size && ((Boolean) arrayList2.get(i4)).booleanValue() && !((a) arrayList.get(i4)).f606o) {
                        i4++;
                    }
                }
                z(arrayList, arrayList2, i3, i4);
                i3 = i4 - 1;
            }
            i3++;
        }
        if (i4 != size) {
            z(arrayList, arrayList2, i4, size);
        }
    }

    public final void S(Parcelable parcelable) {
        e eVar;
        int i3;
        u0 u0Var;
        Bundle bundle;
        Bundle bundle2;
        Bundle bundle3 = (Bundle) parcelable;
        for (String str : bundle3.keySet()) {
            if (str.startsWith("result_") && (bundle2 = bundle3.getBundle(str)) != null) {
                bundle2.setClassLoader(this.f703t.f807p.getClassLoader());
                this.f694k.put(str.substring(7), bundle2);
            }
        }
        ArrayList arrayList = new ArrayList();
        for (String str2 : bundle3.keySet()) {
            if (str2.startsWith("fragment_") && (bundle = bundle3.getBundle(str2)) != null) {
                bundle.setClassLoader(this.f703t.f807p.getClassLoader());
                arrayList.add((s0) bundle.getParcelable("state"));
            }
        }
        a0.k kVar = this.f687c;
        HashMap map = (HashMap) kVar.f24b;
        HashMap map2 = (HashMap) kVar.f23a;
        map.clear();
        int size = arrayList.size();
        int i4 = 0;
        while (i4 < size) {
            Object obj = arrayList.get(i4);
            i4++;
            s0 s0Var = (s0) obj;
            map.put(s0Var.f732b, s0Var);
        }
        p0 p0Var = (p0) bundle3.getParcelable("state");
        if (p0Var == null) {
            return;
        }
        map2.clear();
        ArrayList arrayList2 = p0Var.f711a;
        int size2 = arrayList2.size();
        int i5 = 0;
        while (true) {
            eVar = this.f695l;
            i3 = 2;
            if (i5 >= size2) {
                break;
            }
            Object obj2 = arrayList2.get(i5);
            i5++;
            s0 s0Var2 = (s0) ((HashMap) kVar.f24b).remove((String) obj2);
            if (s0Var2 != null) {
                w wVar = (w) this.L.f720d.get(s0Var2.f732b);
                if (wVar != null) {
                    if (F(2)) {
                        wVar.toString();
                    }
                    u0Var = new u0(eVar, kVar, wVar, s0Var2);
                } else {
                    u0Var = new u0(this.f695l, this.f687c, this.f703t.f807p.getClassLoader(), D(), s0Var2);
                }
                w wVar2 = u0Var.f762c;
                wVar2.f790r = this;
                if (F(2)) {
                    wVar2.toString();
                }
                u0Var.m(this.f703t.f807p.getClassLoader());
                kVar.i(u0Var);
                u0Var.f764e = this.f702s;
            }
        }
        q0 q0Var = this.L;
        q0Var.getClass();
        ArrayList arrayList3 = new ArrayList(q0Var.f720d.values());
        int size3 = arrayList3.size();
        int i6 = 0;
        while (i6 < size3) {
            Object obj3 = arrayList3.get(i6);
            i6++;
            w wVar3 = (w) obj3;
            if (map2.get(wVar3.f778e) == null) {
                if (F(2)) {
                    wVar3.toString();
                    Objects.toString(p0Var.f711a);
                }
                this.L.e(wVar3);
                wVar3.f790r = this;
                u0 u0Var2 = new u0(eVar, kVar, wVar3);
                u0Var2.f764e = 1;
                u0Var2.k();
                wVar3.f784l = true;
                u0Var2.k();
            }
        }
        ArrayList arrayList4 = p0Var.f712b;
        ((ArrayList) kVar.f25c).clear();
        if (arrayList4 != null) {
            int size4 = arrayList4.size();
            int i7 = 0;
            while (i7 < size4) {
                Object obj4 = arrayList4.get(i7);
                i7++;
                String str3 = (String) obj4;
                w wVarC = kVar.c(str3);
                if (wVarC == null) {
                    throw new IllegalStateException(g0.e.d("No instantiated fragment for (", str3, ")"));
                }
                if (F(2)) {
                    wVarC.toString();
                }
                kVar.a(wVarC);
            }
        }
        if (p0Var.f713c != null) {
            this.f688d = new ArrayList(p0Var.f713c.length);
            int i8 = 0;
            while (true) {
                b[] bVarArr = p0Var.f713c;
                if (i8 >= bVarArr.length) {
                    break;
                }
                b bVar = bVarArr[i8];
                ArrayList arrayList5 = bVar.f616b;
                a aVar = new a(this);
                int[] iArr = bVar.f615a;
                int i9 = 0;
                int i10 = 0;
                while (i9 < iArr.length) {
                    v0 v0Var = new v0();
                    int i11 = i9 + 1;
                    v0Var.f766a = iArr[i9];
                    if (F(i3)) {
                        Objects.toString(aVar);
                        int i12 = iArr[i11];
                    }
                    v0Var.f772h = Lifecycle$State.values()[bVar.f617c[i10]];
                    v0Var.f773i = Lifecycle$State.values()[bVar.f618d[i10]];
                    int i13 = i9 + 2;
                    v0Var.f768c = iArr[i11] != 0;
                    int i14 = iArr[i13];
                    v0Var.f769d = i14;
                    int i15 = iArr[i9 + 3];
                    v0Var.f770e = i15;
                    int i16 = i9 + 5;
                    int i17 = iArr[i9 + 4];
                    v0Var.f = i17;
                    i9 += 6;
                    int i18 = iArr[i16];
                    v0Var.f771g = i18;
                    aVar.f594b = i14;
                    aVar.f595c = i15;
                    aVar.f596d = i17;
                    aVar.f597e = i18;
                    aVar.b(v0Var);
                    i10++;
                    i3 = 2;
                }
                aVar.f = bVar.f619e;
                aVar.f599h = bVar.f;
                aVar.f598g = true;
                aVar.f600i = bVar.f621h;
                aVar.f601j = bVar.f622i;
                aVar.f602k = bVar.f623j;
                aVar.f603l = bVar.f624k;
                aVar.f604m = bVar.f625l;
                aVar.f605n = bVar.f626m;
                aVar.f606o = bVar.f627n;
                aVar.f609r = bVar.f620g;
                for (int i19 = 0; i19 < arrayList5.size(); i19++) {
                    String str4 = (String) arrayList5.get(i19);
                    if (str4 != null) {
                        ((v0) aVar.f593a.get(i19)).f767b = kVar.c(str4);
                    }
                }
                aVar.c(1);
                if (F(2)) {
                    aVar.toString();
                    PrintWriter printWriter = new PrintWriter(new x0());
                    aVar.f("  ", printWriter, false);
                    printWriter.close();
                }
                this.f688d.add(aVar);
                i8++;
                i3 = 2;
            }
        } else {
            this.f688d = null;
        }
        this.f692i.set(p0Var.f714d);
        String str5 = p0Var.f715e;
        if (str5 != null) {
            w wVarC2 = kVar.c(str5);
            this.f706w = wVarC2;
            q(wVarC2);
        }
        ArrayList arrayList6 = p0Var.f;
        if (arrayList6 != null) {
            for (int i20 = 0; i20 < arrayList6.size(); i20++) {
                this.f693j.put((String) arrayList6.get(i20), (c) p0Var.f716g.get(i20));
            }
        }
        this.C = new ArrayDeque(p0Var.f717h);
    }

    public final Bundle T() {
        int i3;
        ArrayList arrayList;
        b[] bVarArr;
        int size;
        Bundle bundle = new Bundle();
        Iterator it = e().iterator();
        while (true) {
            i3 = 0;
            if (!it.hasNext()) {
                break;
            }
            j jVar = (j) it.next();
            if (jVar.f665e) {
                jVar.f665e = false;
                jVar.c();
            }
        }
        Iterator it2 = e().iterator();
        while (it2.hasNext()) {
            ((j) it2.next()).e();
        }
        x(true);
        this.E = true;
        this.L.f724i = true;
        a0.k kVar = this.f687c;
        kVar.getClass();
        HashMap map = (HashMap) kVar.f23a;
        ArrayList arrayList2 = new ArrayList(map.size());
        for (u0 u0Var : map.values()) {
            if (u0Var != null) {
                w wVar = u0Var.f762c;
                w wVar2 = u0Var.f762c;
                s0 s0Var = new s0(wVar2);
                if (wVar2.f774a <= -1 || s0Var.f742m != null) {
                    s0Var.f742m = wVar2.f775b;
                } else {
                    Bundle bundleO = u0Var.o();
                    s0Var.f742m = bundleO;
                    if (wVar2.f780h != null) {
                        if (bundleO == null) {
                            s0Var.f742m = new Bundle();
                        }
                        s0Var.f742m.putString("android:target_state", wVar2.f780h);
                        int i4 = wVar2.f781i;
                        if (i4 != 0) {
                            s0Var.f742m.putInt("android:target_req_state", i4);
                        }
                    }
                }
                arrayList2.add(wVar.f778e);
                if (F(2)) {
                    wVar.toString();
                    Objects.toString(wVar.f775b);
                }
            }
        }
        a0.k kVar2 = this.f687c;
        kVar2.getClass();
        ArrayList arrayList3 = new ArrayList(((HashMap) kVar2.f24b).values());
        if (!arrayList3.isEmpty()) {
            a0.k kVar3 = this.f687c;
            synchronized (((ArrayList) kVar3.f25c)) {
                try {
                    if (((ArrayList) kVar3.f25c).isEmpty()) {
                        arrayList = null;
                    } else {
                        arrayList = new ArrayList(((ArrayList) kVar3.f25c).size());
                        ArrayList arrayList4 = (ArrayList) kVar3.f25c;
                        int size2 = arrayList4.size();
                        int i5 = 0;
                        while (i5 < size2) {
                            Object obj = arrayList4.get(i5);
                            i5++;
                            w wVar3 = (w) obj;
                            arrayList.add(wVar3.f778e);
                            if (F(2)) {
                                wVar3.toString();
                            }
                        }
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            ArrayList arrayList5 = this.f688d;
            if (arrayList5 == null || (size = arrayList5.size()) <= 0) {
                bVarArr = null;
            } else {
                bVarArr = new b[size];
                for (int i6 = 0; i6 < size; i6++) {
                    bVarArr[i6] = new b((a) this.f688d.get(i6));
                    if (F(2)) {
                        Objects.toString(this.f688d.get(i6));
                    }
                }
            }
            p0 p0Var = new p0();
            p0Var.f715e = null;
            ArrayList arrayList6 = new ArrayList();
            p0Var.f = arrayList6;
            ArrayList arrayList7 = new ArrayList();
            p0Var.f716g = arrayList7;
            p0Var.f711a = arrayList2;
            p0Var.f712b = arrayList;
            p0Var.f713c = bVarArr;
            p0Var.f714d = this.f692i.get();
            w wVar4 = this.f706w;
            if (wVar4 != null) {
                p0Var.f715e = wVar4.f778e;
            }
            arrayList6.addAll(this.f693j.keySet());
            arrayList7.addAll(this.f693j.values());
            p0Var.f717h = new ArrayList(this.C);
            bundle.putParcelable("state", p0Var);
            for (String str : this.f694k.keySet()) {
                bundle.putBundle(g0.e.h("result_", str), (Bundle) this.f694k.get(str));
            }
            int size3 = arrayList3.size();
            while (i3 < size3) {
                Object obj2 = arrayList3.get(i3);
                i3++;
                s0 s0Var2 = (s0) obj2;
                Bundle bundle2 = new Bundle();
                bundle2.putParcelable("state", s0Var2);
                bundle.putBundle("fragment_" + s0Var2.f732b, bundle2);
            }
        }
        return bundle;
    }

    public final void U() {
        synchronized (this.f685a) {
            try {
                if (this.f685a.size() == 1) {
                    this.f703t.f808q.removeCallbacks(this.M);
                    this.f703t.f808q.post(this.M);
                    b0();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void V(w wVar, boolean z4) {
        ViewGroup viewGroupC = C(wVar);
        if (viewGroupC == null || !(viewGroupC instanceof FragmentContainerView)) {
            return;
        }
        ((FragmentContainerView) viewGroupC).setDrawDisappearingViewsLast(!z4);
    }

    public final void W(w wVar, Lifecycle$State lifecycle$State) {
        if (wVar.equals(this.f687c.c(wVar.f778e)) && (wVar.f791s == null || wVar.f790r == this)) {
            wVar.M = lifecycle$State;
            return;
        }
        throw new IllegalArgumentException("Fragment " + wVar + " is not an active fragment of FragmentManager " + this);
    }

    public final void X(w wVar) {
        if (wVar != null) {
            if (!wVar.equals(this.f687c.c(wVar.f778e)) || (wVar.f791s != null && wVar.f790r != this)) {
                throw new IllegalArgumentException("Fragment " + wVar + " is not an active fragment of FragmentManager " + this);
            }
        }
        w wVar2 = this.f706w;
        this.f706w = wVar;
        q(wVar2);
        q(this.f706w);
    }

    public final void Y(w wVar) {
        ViewGroup viewGroupC = C(wVar);
        if (viewGroupC != null) {
            t tVar = wVar.H;
            if ((tVar == null ? 0 : tVar.f752e) + (tVar == null ? 0 : tVar.f751d) + (tVar == null ? 0 : tVar.f750c) + (tVar == null ? 0 : tVar.f749b) > 0) {
                if (viewGroupC.getTag(R.id.visible_removing_fragment_view_tag) == null) {
                    viewGroupC.setTag(R.id.visible_removing_fragment_view_tag, wVar);
                }
                w wVar2 = (w) viewGroupC.getTag(R.id.visible_removing_fragment_view_tag);
                t tVar2 = wVar.H;
                boolean z4 = tVar2 != null ? tVar2.f748a : false;
                if (wVar2.H == null) {
                    return;
                }
                wVar2.f().f748a = z4;
            }
        }
    }

    public final void Z() {
        ArrayList arrayListF = this.f687c.f();
        int size = arrayListF.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayListF.get(i3);
            i3++;
            u0 u0Var = (u0) obj;
            w wVar = u0Var.f762c;
            if (wVar.F) {
                if (this.f686b) {
                    this.H = true;
                } else {
                    wVar.F = false;
                    u0Var.k();
                }
            }
        }
    }

    public final u0 a(w wVar) {
        String str = wVar.L;
        if (str != null) {
            y0.b.c(wVar, str);
        }
        if (F(2)) {
            wVar.toString();
        }
        u0 u0VarF = f(wVar);
        wVar.f790r = this;
        a0.k kVar = this.f687c;
        kVar.i(u0VarF);
        if (!wVar.f798z) {
            kVar.a(wVar);
            wVar.f784l = false;
            if (wVar.E == null) {
                wVar.I = false;
            }
            if (G(wVar)) {
                this.D = true;
            }
        }
        return u0VarF;
    }

    public final void a0(IllegalStateException illegalStateException) {
        illegalStateException.getMessage();
        PrintWriter printWriter = new PrintWriter(new x0());
        y yVar = this.f703t;
        try {
            if (yVar != null) {
                yVar.f810s.dump("  ", null, printWriter, new String[0]);
            } else {
                u("  ", null, printWriter, new String[0]);
            }
            throw illegalStateException;
        } catch (Exception unused) {
            throw illegalStateException;
        }
    }

    public final void b(y yVar, a3.a aVar, w wVar) {
        String str;
        if (this.f703t != null) {
            throw new IllegalStateException("Already attached");
        }
        this.f703t = yVar;
        this.f704u = aVar;
        this.f705v = wVar;
        CopyOnWriteArrayList copyOnWriteArrayList = this.f696m;
        if (wVar != null) {
            copyOnWriteArrayList.add(new j0(wVar));
        } else if (yVar != null) {
            copyOnWriteArrayList.add(yVar);
        }
        if (this.f705v != null) {
            b0();
        }
        if (yVar != null) {
            androidx.activity.t tVarI = yVar.f810s.i();
            this.f690g = tVarI;
            tVarI.a(wVar != null ? wVar : yVar, this.f691h);
        }
        if (wVar != null) {
            q0 q0Var = wVar.f790r.L;
            HashMap map = q0Var.f721e;
            q0 q0Var2 = (q0) map.get(wVar.f778e);
            if (q0Var2 == null) {
                q0Var2 = new q0(q0Var.f722g);
                map.put(wVar.f778e, q0Var2);
            }
            this.L = q0Var2;
        } else if (yVar != null) {
            this.L = (q0) new androidx.emoji2.text.u(yVar.f810s.b(), q0.f719j).k(q0.class);
        } else {
            this.L = new q0(false);
        }
        this.L.f724i = K();
        this.f687c.f26d = this.L;
        y yVar2 = this.f703t;
        if (yVar2 != null && wVar == null) {
            f1.d dVarC = yVar2.c();
            dVarC.e("android:support:fragments", new androidx.activity.e(2, this));
            Bundle bundleC = dVarC.c("android:support:fragments");
            if (bundleC != null) {
                S(bundleC);
            }
        }
        y yVar3 = this.f703t;
        if (yVar3 != null) {
            androidx.activity.g gVar = yVar3.f810s.f144k;
            if (wVar != null) {
                str = wVar.f778e + ":";
            } else {
                str = ModConfig.PREFIX;
            }
            String strH = g0.e.h("FragmentManager:", str);
            this.f709z = gVar.c(g0.e.c(strH, "StartActivityForResult"), new k0(3), new f0(this, 1));
            this.A = gVar.c(g0.e.c(strH, "StartIntentSenderForResult"), new k0(0), new f0(this, 2));
            this.B = gVar.c(g0.e.c(strH, "RequestPermissions"), new k0(2), new f0(this, 0));
        }
        y yVar4 = this.f703t;
        if (yVar4 != null) {
            yVar4.f810s.g(this.f697n);
        }
        y yVar5 = this.f703t;
        if (yVar5 != null) {
            yVar5.f810s.f146m.add(this.f698o);
        }
        y yVar6 = this.f703t;
        if (yVar6 != null) {
            yVar6.f810s.f148o.add(this.f699p);
        }
        y yVar7 = this.f703t;
        if (yVar7 != null) {
            yVar7.f810s.f149p.add(this.f700q);
        }
        y yVar8 = this.f703t;
        if (yVar8 == null || wVar != null) {
            return;
        }
        androidx.emoji2.text.u uVar = yVar8.f810s.f137c;
        ((CopyOnWriteArrayList) uVar.f563c).add(this.f701r);
        ((Runnable) uVar.f562b).run();
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [j3.a, kotlin.jvm.internal.FunctionReferenceImpl] */
    /* JADX WARN: Type inference failed for: r1v10, types: [j3.a, kotlin.jvm.internal.FunctionReferenceImpl] */
    public final void b0() {
        synchronized (this.f685a) {
            try {
                if (!this.f685a.isEmpty()) {
                    g0 g0Var = this.f691h;
                    g0Var.f652a = true;
                    ?? r1 = g0Var.f654c;
                    if (r1 != 0) {
                        r1.b();
                    }
                    return;
                }
                g0 g0Var2 = this.f691h;
                ArrayList arrayList = this.f688d;
                g0Var2.f652a = (arrayList != null ? arrayList.size() : 0) > 0 && J(this.f705v);
                ?? r4 = g0Var2.f654c;
                if (r4 != 0) {
                    r4.b();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void c(w wVar) {
        if (F(2)) {
            Objects.toString(wVar);
        }
        if (wVar.f798z) {
            wVar.f798z = false;
            if (wVar.f783k) {
                return;
            }
            this.f687c.a(wVar);
            if (F(2)) {
                wVar.toString();
            }
            if (G(wVar)) {
                this.D = true;
            }
        }
    }

    public final void d() {
        this.f686b = false;
        this.J.clear();
        this.I.clear();
    }

    public final HashSet e() {
        HashSet hashSet = new HashSet();
        ArrayList arrayListF = this.f687c.f();
        int size = arrayListF.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayListF.get(i3);
            i3++;
            ViewGroup viewGroup = ((u0) obj).f762c.D;
            if (viewGroup != null) {
                hashSet.add(j.f(viewGroup, E()));
            }
        }
        return hashSet;
    }

    public final u0 f(w wVar) {
        String str = wVar.f778e;
        a0.k kVar = this.f687c;
        u0 u0Var = (u0) ((HashMap) kVar.f23a).get(str);
        if (u0Var != null) {
            return u0Var;
        }
        u0 u0Var2 = new u0(this.f695l, kVar, wVar);
        u0Var2.m(this.f703t.f807p.getClassLoader());
        u0Var2.f764e = this.f702s;
        return u0Var2;
    }

    public final void g(w wVar) {
        if (F(2)) {
            Objects.toString(wVar);
        }
        if (wVar.f798z) {
            return;
        }
        wVar.f798z = true;
        if (wVar.f783k) {
            if (F(2)) {
                wVar.toString();
            }
            a0.k kVar = this.f687c;
            synchronized (((ArrayList) kVar.f25c)) {
                ((ArrayList) kVar.f25c).remove(wVar);
            }
            wVar.f783k = false;
            if (G(wVar)) {
                this.D = true;
            }
            Y(wVar);
        }
    }

    public final void h(boolean z4) {
        if (z4 && this.f703t != null) {
            a0(new IllegalStateException("Do not call dispatchConfigurationChanged() on host. Host implements OnConfigurationChangedProvider and automatically dispatches configuration changes to fragments."));
            throw null;
        }
        for (w wVar : this.f687c.h()) {
            if (wVar != null) {
                wVar.C = true;
                if (z4) {
                    wVar.f792t.h(true);
                }
            }
        }
    }

    public final boolean i() {
        if (this.f702s >= 1) {
            for (w wVar : this.f687c.h()) {
                if (wVar != null) {
                    if (!wVar.f797y ? wVar.f792t.i() : false) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public final boolean j() {
        if (this.f702s < 1) {
            return false;
        }
        ArrayList arrayList = null;
        boolean z4 = false;
        for (w wVar : this.f687c.h()) {
            if (wVar != null && I(wVar)) {
                if (!wVar.f797y ? wVar.f792t.j() : false) {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.add(wVar);
                    z4 = true;
                }
            }
        }
        if (this.f689e != null) {
            for (int i3 = 0; i3 < this.f689e.size(); i3++) {
                w wVar2 = (w) this.f689e.get(i3);
                if (arrayList == null || !arrayList.contains(wVar2)) {
                    wVar2.getClass();
                }
            }
        }
        this.f689e = arrayList;
        return z4;
    }

    public final void k() {
        boolean z4;
        this.G = true;
        x(true);
        Iterator it = e().iterator();
        while (it.hasNext()) {
            ((j) it.next()).e();
        }
        y yVar = this.f703t;
        a0.k kVar = this.f687c;
        if (yVar != null) {
            z4 = ((q0) kVar.f26d).f723h;
        } else {
            e.n nVar = yVar.f807p;
            z4 = g0.e.g(nVar) ? !nVar.isChangingConfigurations() : true;
        }
        if (z4) {
            Iterator it2 = this.f693j.values().iterator();
            while (it2.hasNext()) {
                ArrayList arrayList = ((c) it2.next()).f630a;
                int size = arrayList.size();
                int i3 = 0;
                while (i3 < size) {
                    Object obj = arrayList.get(i3);
                    i3++;
                    ((q0) kVar.f26d).d((String) obj);
                }
            }
        }
        t(-1);
        y yVar2 = this.f703t;
        if (yVar2 != null) {
            yVar2.f810s.f146m.remove(this.f698o);
        }
        y yVar3 = this.f703t;
        if (yVar3 != null) {
            yVar3.f810s.f145l.remove(this.f697n);
        }
        y yVar4 = this.f703t;
        if (yVar4 != null) {
            yVar4.f810s.f148o.remove(this.f699p);
        }
        y yVar5 = this.f703t;
        if (yVar5 != null) {
            yVar5.f810s.f149p.remove(this.f700q);
        }
        y yVar6 = this.f703t;
        if (yVar6 != null) {
            androidx.emoji2.text.u uVar = yVar6.f810s.f137c;
            CopyOnWriteArrayList copyOnWriteArrayList = (CopyOnWriteArrayList) uVar.f563c;
            h0 h0Var = this.f701r;
            copyOnWriteArrayList.remove(h0Var);
            if (((HashMap) uVar.f564d).remove(h0Var) != null) {
                throw new ClassCastException();
            }
            ((Runnable) uVar.f562b).run();
        }
        this.f703t = null;
        this.f704u = null;
        this.f705v = null;
        if (this.f690g != null) {
            Iterator it3 = this.f691h.f653b.iterator();
            while (it3.hasNext()) {
                ((androidx.activity.c) it3.next()).cancel();
            }
            this.f690g = null;
        }
        androidx.activity.result.e eVar = this.f709z;
        if (eVar != null) {
            eVar.b();
            this.A.b();
            this.B.b();
        }
    }

    public final void l(boolean z4) {
        if (z4 && this.f703t != null) {
            a0(new IllegalStateException("Do not call dispatchLowMemory() on host. Host implements OnTrimMemoryProvider and automatically dispatches low memory callbacks to fragments."));
            throw null;
        }
        for (w wVar : this.f687c.h()) {
            if (wVar != null) {
                wVar.C = true;
                if (z4) {
                    wVar.f792t.l(true);
                }
            }
        }
    }

    public final void m(boolean z4) {
        if (z4 && this.f703t != null) {
            a0(new IllegalStateException("Do not call dispatchMultiWindowModeChanged() on host. Host implements OnMultiWindowModeChangedProvider and automatically dispatches multi-window mode changes to fragments."));
            throw null;
        }
        for (w wVar : this.f687c.h()) {
            if (wVar != null && z4) {
                wVar.f792t.m(true);
            }
        }
    }

    public final void n() {
        ArrayList arrayListG = this.f687c.g();
        int size = arrayListG.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayListG.get(i3);
            i3++;
            w wVar = (w) obj;
            if (wVar != null) {
                wVar.s();
                wVar.f792t.n();
            }
        }
    }

    public final boolean o() {
        if (this.f702s >= 1) {
            for (w wVar : this.f687c.h()) {
                if (wVar != null) {
                    if (!wVar.f797y ? wVar.f792t.o() : false) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public final void p() {
        if (this.f702s < 1) {
            return;
        }
        for (w wVar : this.f687c.h()) {
            if (wVar != null && !wVar.f797y) {
                wVar.f792t.p();
            }
        }
    }

    public final void q(w wVar) {
        if (wVar != null) {
            if (wVar.equals(this.f687c.c(wVar.f778e))) {
                wVar.f790r.getClass();
                boolean zJ = J(wVar);
                Boolean bool = wVar.f782j;
                if (bool == null || bool.booleanValue() != zJ) {
                    wVar.f782j = Boolean.valueOf(zJ);
                    o0 o0Var = wVar.f792t;
                    o0Var.b0();
                    o0Var.q(o0Var.f706w);
                }
            }
        }
    }

    public final void r(boolean z4) {
        if (z4 && this.f703t != null) {
            a0(new IllegalStateException("Do not call dispatchPictureInPictureModeChanged() on host. Host implements OnPictureInPictureModeChangedProvider and automatically dispatches picture-in-picture mode changes to fragments."));
            throw null;
        }
        for (w wVar : this.f687c.h()) {
            if (wVar != null && z4) {
                wVar.f792t.r(true);
            }
        }
    }

    public final boolean s() {
        if (this.f702s < 1) {
            return false;
        }
        boolean z4 = false;
        for (w wVar : this.f687c.h()) {
            if (wVar != null && I(wVar)) {
                if (!wVar.f797y ? wVar.f792t.s() : false) {
                    z4 = true;
                }
            }
        }
        return z4;
    }

    public final void t(int i3) {
        try {
            this.f686b = true;
            for (u0 u0Var : ((HashMap) this.f687c.f23a).values()) {
                if (u0Var != null) {
                    u0Var.f764e = i3;
                }
            }
            L(i3, false);
            Iterator it = e().iterator();
            while (it.hasNext()) {
                ((j) it.next()).e();
            }
            this.f686b = false;
            x(true);
        } catch (Throwable th) {
            this.f686b = false;
            throw th;
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        w wVar = this.f705v;
        if (wVar != null) {
            sb.append(wVar.getClass().getSimpleName());
            sb.append("{");
            sb.append(Integer.toHexString(System.identityHashCode(this.f705v)));
            sb.append("}");
        } else {
            y yVar = this.f703t;
            if (yVar != null) {
                sb.append(yVar.getClass().getSimpleName());
                sb.append("{");
                sb.append(Integer.toHexString(System.identityHashCode(this.f703t)));
                sb.append("}");
            } else {
                sb.append("null");
            }
        }
        sb.append("}}");
        return sb.toString();
    }

    public final void u(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        String str2;
        String strC = g0.e.c(str, "    ");
        a0.k kVar = this.f687c;
        ArrayList arrayList = (ArrayList) kVar.f25c;
        String strC2 = g0.e.c(str, "    ");
        HashMap map = (HashMap) kVar.f23a;
        if (!map.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Active Fragments:");
            for (u0 u0Var : map.values()) {
                printWriter.print(str);
                if (u0Var != null) {
                    w wVar = u0Var.f762c;
                    printWriter.println(wVar);
                    wVar.getClass();
                    printWriter.print(strC2);
                    printWriter.print("mFragmentId=#");
                    printWriter.print(Integer.toHexString(wVar.f794v));
                    printWriter.print(" mContainerId=#");
                    printWriter.print(Integer.toHexString(wVar.f795w));
                    printWriter.print(" mTag=");
                    printWriter.println(wVar.f796x);
                    printWriter.print(strC2);
                    printWriter.print("mState=");
                    printWriter.print(wVar.f774a);
                    printWriter.print(" mWho=");
                    printWriter.print(wVar.f778e);
                    printWriter.print(" mBackStackNesting=");
                    printWriter.println(wVar.f789q);
                    printWriter.print(strC2);
                    printWriter.print("mAdded=");
                    printWriter.print(wVar.f783k);
                    printWriter.print(" mRemoving=");
                    printWriter.print(wVar.f784l);
                    printWriter.print(" mFromLayout=");
                    printWriter.print(wVar.f785m);
                    printWriter.print(" mInLayout=");
                    printWriter.println(wVar.f786n);
                    printWriter.print(strC2);
                    printWriter.print("mHidden=");
                    printWriter.print(wVar.f797y);
                    printWriter.print(" mDetached=");
                    printWriter.print(wVar.f798z);
                    printWriter.print(" mMenuVisible=");
                    printWriter.print(wVar.B);
                    printWriter.print(" mHasMenu=");
                    printWriter.println(false);
                    printWriter.print(strC2);
                    printWriter.print("mRetainInstance=");
                    printWriter.print(wVar.A);
                    printWriter.print(" mUserVisibleHint=");
                    printWriter.println(wVar.G);
                    if (wVar.f790r != null) {
                        printWriter.print(strC2);
                        printWriter.print("mFragmentManager=");
                        printWriter.println(wVar.f790r);
                    }
                    if (wVar.f791s != null) {
                        printWriter.print(strC2);
                        printWriter.print("mHost=");
                        printWriter.println(wVar.f791s);
                    }
                    if (wVar.f793u != null) {
                        printWriter.print(strC2);
                        printWriter.print("mParentFragment=");
                        printWriter.println(wVar.f793u);
                    }
                    if (wVar.f != null) {
                        printWriter.print(strC2);
                        printWriter.print("mArguments=");
                        printWriter.println(wVar.f);
                    }
                    if (wVar.f775b != null) {
                        printWriter.print(strC2);
                        printWriter.print("mSavedFragmentState=");
                        printWriter.println(wVar.f775b);
                    }
                    if (wVar.f776c != null) {
                        printWriter.print(strC2);
                        printWriter.print("mSavedViewState=");
                        printWriter.println(wVar.f776c);
                    }
                    if (wVar.f777d != null) {
                        printWriter.print(strC2);
                        printWriter.print("mSavedViewRegistryState=");
                        printWriter.println(wVar.f777d);
                    }
                    Object objC = wVar.f779g;
                    if (objC == null) {
                        o0 o0Var = wVar.f790r;
                        objC = (o0Var == null || (str2 = wVar.f780h) == null) ? null : o0Var.f687c.c(str2);
                    }
                    if (objC != null) {
                        printWriter.print(strC2);
                        printWriter.print("mTarget=");
                        printWriter.print(objC);
                        printWriter.print(" mTargetRequestCode=");
                        printWriter.println(wVar.f781i);
                    }
                    printWriter.print(strC2);
                    printWriter.print("mPopDirection=");
                    t tVar = wVar.H;
                    printWriter.println(tVar == null ? false : tVar.f748a);
                    t tVar2 = wVar.H;
                    if ((tVar2 == null ? 0 : tVar2.f749b) != 0) {
                        printWriter.print(strC2);
                        printWriter.print("getEnterAnim=");
                        t tVar3 = wVar.H;
                        printWriter.println(tVar3 == null ? 0 : tVar3.f749b);
                    }
                    t tVar4 = wVar.H;
                    if ((tVar4 == null ? 0 : tVar4.f750c) != 0) {
                        printWriter.print(strC2);
                        printWriter.print("getExitAnim=");
                        t tVar5 = wVar.H;
                        printWriter.println(tVar5 == null ? 0 : tVar5.f750c);
                    }
                    t tVar6 = wVar.H;
                    if ((tVar6 == null ? 0 : tVar6.f751d) != 0) {
                        printWriter.print(strC2);
                        printWriter.print("getPopEnterAnim=");
                        t tVar7 = wVar.H;
                        printWriter.println(tVar7 == null ? 0 : tVar7.f751d);
                    }
                    t tVar8 = wVar.H;
                    if ((tVar8 == null ? 0 : tVar8.f752e) != 0) {
                        printWriter.print(strC2);
                        printWriter.print("getPopExitAnim=");
                        t tVar9 = wVar.H;
                        printWriter.println(tVar9 == null ? 0 : tVar9.f752e);
                    }
                    if (wVar.D != null) {
                        printWriter.print(strC2);
                        printWriter.print("mContainer=");
                        printWriter.println(wVar.D);
                    }
                    if (wVar.E != null) {
                        printWriter.print(strC2);
                        printWriter.print("mView=");
                        printWriter.println(wVar.E);
                    }
                    if (wVar.i() != null) {
                        androidx.emoji2.text.q.l(wVar).i(strC2, printWriter);
                    }
                    printWriter.print(strC2);
                    printWriter.println("Child " + wVar.f792t + ":");
                    wVar.f792t.u(g0.e.c(strC2, "  "), fileDescriptor, printWriter, strArr);
                } else {
                    printWriter.println("null");
                }
            }
        }
        int size3 = arrayList.size();
        if (size3 > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i3 = 0; i3 < size3; i3++) {
                w wVar2 = (w) arrayList.get(i3);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i3);
                printWriter.print(": ");
                printWriter.println(wVar2.toString());
            }
        }
        ArrayList arrayList2 = this.f689e;
        if (arrayList2 != null && (size2 = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i4 = 0; i4 < size2; i4++) {
                w wVar3 = (w) this.f689e.get(i4);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i4);
                printWriter.print(": ");
                printWriter.println(wVar3.toString());
            }
        }
        ArrayList arrayList3 = this.f688d;
        if (arrayList3 != null && (size = arrayList3.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i5 = 0; i5 < size; i5++) {
                a aVar = (a) this.f688d.get(i5);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i5);
                printWriter.print(": ");
                printWriter.println(aVar.toString());
                aVar.f(strC, printWriter, true);
            }
        }
        printWriter.print(str);
        printWriter.println("Back Stack Index: " + this.f692i.get());
        synchronized (this.f685a) {
            try {
                int size4 = this.f685a.size();
                if (size4 > 0) {
                    printWriter.print(str);
                    printWriter.println("Pending Actions:");
                    for (int i6 = 0; i6 < size4; i6++) {
                        Object obj = (m0) this.f685a.get(i6);
                        printWriter.print(str);
                        printWriter.print("  #");
                        printWriter.print(i6);
                        printWriter.print(": ");
                        printWriter.println(obj);
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f703t);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f704u);
        if (this.f705v != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f705v);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f702s);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.E);
        printWriter.print(" mStopped=");
        printWriter.print(this.F);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.G);
        if (this.D) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.D);
        }
    }

    public final void v(m0 m0Var, boolean z4) {
        if (!z4) {
            if (this.f703t == null) {
                if (!this.G) {
                    throw new IllegalStateException("FragmentManager has not been attached to a host.");
                }
                throw new IllegalStateException("FragmentManager has been destroyed");
            }
            if (K()) {
                throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
            }
        }
        synchronized (this.f685a) {
            try {
                if (this.f703t == null) {
                    if (!z4) {
                        throw new IllegalStateException("Activity has been destroyed");
                    }
                } else {
                    this.f685a.add(m0Var);
                    U();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void w(boolean z4) {
        if (this.f686b) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        }
        if (this.f703t == null) {
            if (!this.G) {
                throw new IllegalStateException("FragmentManager has not been attached to a host.");
            }
            throw new IllegalStateException("FragmentManager has been destroyed");
        }
        if (Looper.myLooper() != this.f703t.f808q.getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
        if (!z4 && K()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
        if (this.I == null) {
            this.I = new ArrayList();
            this.J = new ArrayList();
        }
    }

    public final boolean x(boolean z4) {
        boolean zA;
        w(z4);
        boolean z5 = false;
        while (true) {
            ArrayList arrayList = this.I;
            ArrayList arrayList2 = this.J;
            synchronized (this.f685a) {
                if (this.f685a.isEmpty()) {
                    zA = false;
                } else {
                    try {
                        int size = this.f685a.size();
                        zA = false;
                        for (int i3 = 0; i3 < size; i3++) {
                            zA |= ((m0) this.f685a.get(i3)).a(arrayList, arrayList2);
                        }
                        this.f685a.clear();
                        this.f703t.f808q.removeCallbacks(this.M);
                    } catch (Throwable th) {
                        this.f685a.clear();
                        this.f703t.f808q.removeCallbacks(this.M);
                        throw th;
                    }
                }
            }
            if (!zA) {
                break;
            }
            z5 = true;
            this.f686b = true;
            try {
                R(this.I, this.J);
                d();
            } catch (Throwable th2) {
                d();
                throw th2;
            }
        }
        b0();
        if (this.H) {
            this.H = false;
            Z();
        }
        ((HashMap) this.f687c.f23a).values().removeAll(Collections.singleton(null));
        return z5;
    }

    public final void y(a aVar, boolean z4) {
        if (z4 && (this.f703t == null || this.G)) {
            return;
        }
        w(z4);
        aVar.a(this.I, this.J);
        this.f686b = true;
        try {
            R(this.I, this.J);
            d();
            b0();
            if (this.H) {
                this.H = false;
                Z();
            }
            ((HashMap) this.f687c.f23a).values().removeAll(Collections.singleton(null));
        } catch (Throwable th) {
            d();
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:29:0x0089  */
    /* JADX WARN: Code duplicated, block: B:62:0x017d  */
    /* JADX WARN: Code duplicated, block: B:63:0x0183  */
    public final void z(ArrayList arrayList, ArrayList arrayList2, int i3, int i4) {
        ViewGroup viewGroup;
        boolean z4;
        int i5;
        boolean z5;
        boolean z6;
        int i6;
        boolean z7;
        int i7;
        int i8;
        a0.k kVar = this.f687c;
        boolean z8 = ((a) arrayList.get(i3)).f606o;
        ArrayList arrayList3 = this.K;
        if (arrayList3 == null) {
            this.K = new ArrayList();
        } else {
            arrayList3.clear();
        }
        this.K.addAll(kVar.h());
        w wVar = this.f706w;
        int i9 = i3;
        boolean z9 = false;
        while (true) {
            int i10 = 1;
            if (i9 >= i4) {
                boolean z10 = z8;
                this.K.clear();
                if (!z10 && this.f702s >= 1) {
                    for (int i11 = i3; i11 < i4; i11++) {
                        ArrayList arrayList4 = ((a) arrayList.get(i11)).f593a;
                        int size = arrayList4.size();
                        int i12 = 0;
                        while (i12 < size) {
                            Object obj = arrayList4.get(i12);
                            i12++;
                            w wVar2 = ((v0) obj).f767b;
                            if (wVar2 != null && wVar2.f790r != null) {
                                kVar.i(f(wVar2));
                            }
                        }
                    }
                }
                for (int i13 = i3; i13 < i4; i13++) {
                    a aVar = (a) arrayList.get(i13);
                    if (((Boolean) arrayList2.get(i13)).booleanValue()) {
                        aVar.c(-1);
                        o0 o0Var = aVar.f607p;
                        ArrayList arrayList5 = aVar.f593a;
                        boolean z11 = true;
                        for (int size2 = arrayList5.size() - 1; size2 >= 0; size2--) {
                            v0 v0Var = (v0) arrayList5.get(size2);
                            w wVar3 = v0Var.f767b;
                            if (wVar3 != null) {
                                if (wVar3.H != null) {
                                    wVar3.f().f748a = z11;
                                }
                                int i14 = aVar.f;
                                int i15 = 8194;
                                if (i14 != 4097) {
                                    if (i14 != 8194) {
                                        i15 = 4100;
                                        if (i14 != 8197) {
                                            i15 = i14 != 4099 ? i14 != 4100 ? 0 : 8197 : 4099;
                                        }
                                    } else {
                                        i15 = 4097;
                                    }
                                }
                                if (wVar3.H != null || i15 != 0) {
                                    wVar3.f();
                                    wVar3.H.f = i15;
                                }
                                wVar3.f();
                                wVar3.H.getClass();
                            }
                            switch (v0Var.f766a) {
                                case 1:
                                    wVar3.L(v0Var.f769d, v0Var.f770e, v0Var.f, v0Var.f771g);
                                    z11 = true;
                                    o0Var.V(wVar3, true);
                                    o0Var.Q(wVar3);
                                    break;
                                case 2:
                                default:
                                    throw new IllegalArgumentException("Unknown cmd: " + v0Var.f766a);
                                case 3:
                                    wVar3.L(v0Var.f769d, v0Var.f770e, v0Var.f, v0Var.f771g);
                                    o0Var.a(wVar3);
                                    z11 = true;
                                    break;
                                case 4:
                                    wVar3.L(v0Var.f769d, v0Var.f770e, v0Var.f, v0Var.f771g);
                                    o0Var.getClass();
                                    if (F(2)) {
                                        Objects.toString(wVar3);
                                    }
                                    if (wVar3.f797y) {
                                        wVar3.f797y = false;
                                        wVar3.I = !wVar3.I;
                                    }
                                    z11 = true;
                                    break;
                                case 5:
                                    wVar3.L(v0Var.f769d, v0Var.f770e, v0Var.f, v0Var.f771g);
                                    o0Var.V(wVar3, true);
                                    if (F(2)) {
                                        Objects.toString(wVar3);
                                    }
                                    if (!wVar3.f797y) {
                                        wVar3.f797y = true;
                                        wVar3.I = !wVar3.I;
                                        o0Var.Y(wVar3);
                                    }
                                    z11 = true;
                                    break;
                                case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                                    wVar3.L(v0Var.f769d, v0Var.f770e, v0Var.f, v0Var.f771g);
                                    o0Var.c(wVar3);
                                    z11 = true;
                                    break;
                                case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                                    wVar3.L(v0Var.f769d, v0Var.f770e, v0Var.f, v0Var.f771g);
                                    o0Var.V(wVar3, true);
                                    o0Var.g(wVar3);
                                    z11 = true;
                                    break;
                                case 8:
                                    o0Var.X(null);
                                    z11 = true;
                                    break;
                                case 9:
                                    o0Var.X(wVar3);
                                    z11 = true;
                                    break;
                                case JarConfig.MAX_CACHE_SIZE /* 10 */:
                                    o0Var.W(wVar3, v0Var.f772h);
                                    z11 = true;
                                    break;
                            }
                        }
                    } else {
                        aVar.c(1);
                        o0 o0Var2 = aVar.f607p;
                        ArrayList arrayList6 = aVar.f593a;
                        int size3 = arrayList6.size();
                        for (int i16 = 0; i16 < size3; i16++) {
                            v0 v0Var2 = (v0) arrayList6.get(i16);
                            w wVar4 = v0Var2.f767b;
                            if (wVar4 != null) {
                                if (wVar4.H != null) {
                                    wVar4.f().f748a = false;
                                }
                                int i17 = aVar.f;
                                if (wVar4.H != null || i17 != 0) {
                                    wVar4.f();
                                    wVar4.H.f = i17;
                                }
                                wVar4.f();
                                wVar4.H.getClass();
                            }
                            switch (v0Var2.f766a) {
                                case 1:
                                    wVar4.L(v0Var2.f769d, v0Var2.f770e, v0Var2.f, v0Var2.f771g);
                                    o0Var2.V(wVar4, false);
                                    o0Var2.a(wVar4);
                                    break;
                                case 2:
                                default:
                                    throw new IllegalArgumentException("Unknown cmd: " + v0Var2.f766a);
                                case 3:
                                    wVar4.L(v0Var2.f769d, v0Var2.f770e, v0Var2.f, v0Var2.f771g);
                                    o0Var2.Q(wVar4);
                                    break;
                                case 4:
                                    wVar4.L(v0Var2.f769d, v0Var2.f770e, v0Var2.f, v0Var2.f771g);
                                    o0Var2.getClass();
                                    if (F(2)) {
                                        Objects.toString(wVar4);
                                    }
                                    if (!wVar4.f797y) {
                                        wVar4.f797y = true;
                                        wVar4.I = !wVar4.I;
                                        o0Var2.Y(wVar4);
                                    }
                                    break;
                                case 5:
                                    wVar4.L(v0Var2.f769d, v0Var2.f770e, v0Var2.f, v0Var2.f771g);
                                    o0Var2.V(wVar4, false);
                                    if (F(2)) {
                                        Objects.toString(wVar4);
                                    }
                                    if (wVar4.f797y) {
                                        wVar4.f797y = false;
                                        wVar4.I = !wVar4.I;
                                    }
                                    break;
                                case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                                    wVar4.L(v0Var2.f769d, v0Var2.f770e, v0Var2.f, v0Var2.f771g);
                                    o0Var2.g(wVar4);
                                    break;
                                case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                                    wVar4.L(v0Var2.f769d, v0Var2.f770e, v0Var2.f, v0Var2.f771g);
                                    o0Var2.V(wVar4, false);
                                    o0Var2.c(wVar4);
                                    break;
                                case 8:
                                    o0Var2.X(wVar4);
                                    break;
                                case 9:
                                    o0Var2.X(null);
                                    break;
                                case JarConfig.MAX_CACHE_SIZE /* 10 */:
                                    o0Var2.W(wVar4, v0Var2.f773i);
                                    break;
                            }
                        }
                    }
                }
                boolean zBooleanValue = ((Boolean) arrayList2.get(i4 - 1)).booleanValue();
                for (int i18 = i3; i18 < i4; i18++) {
                    a aVar2 = (a) arrayList.get(i18);
                    if (zBooleanValue) {
                        for (int size4 = aVar2.f593a.size() - 1; size4 >= 0; size4--) {
                            w wVar5 = ((v0) aVar2.f593a.get(size4)).f767b;
                            if (wVar5 != null) {
                                f(wVar5).k();
                            }
                        }
                    } else {
                        ArrayList arrayList7 = aVar2.f593a;
                        int size5 = arrayList7.size();
                        int i19 = 0;
                        while (i19 < size5) {
                            Object obj2 = arrayList7.get(i19);
                            i19++;
                            w wVar6 = ((v0) obj2).f767b;
                            if (wVar6 != null) {
                                f(wVar6).k();
                            }
                        }
                    }
                }
                L(this.f702s, true);
                HashSet<j> hashSet = new HashSet();
                for (int i20 = i3; i20 < i4; i20++) {
                    ArrayList arrayList8 = ((a) arrayList.get(i20)).f593a;
                    int size6 = arrayList8.size();
                    int i21 = 0;
                    while (i21 < size6) {
                        Object obj3 = arrayList8.get(i21);
                        i21++;
                        w wVar7 = ((v0) obj3).f767b;
                        if (wVar7 != null && (viewGroup = wVar7.D) != null) {
                            hashSet.add(j.f(viewGroup, E()));
                        }
                    }
                }
                for (j jVar : hashSet) {
                    jVar.f664d = zBooleanValue;
                    synchronized (jVar.f662b) {
                        try {
                            jVar.g();
                            jVar.f665e = false;
                            for (int size7 = jVar.f662b.size() - 1; size7 >= 0; size7--) {
                                z0 z0Var = (z0) jVar.f662b.get(size7);
                                SpecialEffectsController$Operation$State specialEffectsController$Operation$StateC = SpecialEffectsController$Operation$State.c(z0Var.f821c.E);
                                SpecialEffectsController$Operation$State specialEffectsController$Operation$State = z0Var.f819a;
                                SpecialEffectsController$Operation$State specialEffectsController$Operation$State2 = SpecialEffectsController$Operation$State.f589b;
                                if (specialEffectsController$Operation$State == specialEffectsController$Operation$State2 && specialEffectsController$Operation$StateC != specialEffectsController$Operation$State2) {
                                    t tVar = z0Var.f821c.H;
                                    jVar.f665e = false;
                                }
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    jVar.c();
                }
                for (int i22 = i3; i22 < i4; i22++) {
                    a aVar3 = (a) arrayList.get(i22);
                    if (((Boolean) arrayList2.get(i22)).booleanValue() && aVar3.f609r >= 0) {
                        aVar3.f609r = -1;
                    }
                    aVar3.getClass();
                }
                return;
            }
            a aVar4 = (a) arrayList.get(i9);
            if (((Boolean) arrayList2.get(i9)).booleanValue()) {
                z4 = z8;
                i5 = i9;
                z5 = z9;
                int i23 = 1;
                ArrayList arrayList9 = this.K;
                ArrayList arrayList10 = aVar4.f593a;
                int size8 = arrayList10.size() - 1;
                while (size8 >= 0) {
                    v0 v0Var3 = (v0) arrayList10.get(size8);
                    int i24 = v0Var3.f766a;
                    if (i24 == i23) {
                        arrayList9.remove(v0Var3.f767b);
                    } else if (i24 != 3) {
                        switch (i24) {
                            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                                arrayList9.add(v0Var3.f767b);
                                break;
                            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                                arrayList9.remove(v0Var3.f767b);
                                break;
                            case 8:
                                wVar = null;
                                break;
                            case 9:
                                wVar = v0Var3.f767b;
                                break;
                            case JarConfig.MAX_CACHE_SIZE /* 10 */:
                                v0Var3.f773i = v0Var3.f772h;
                                break;
                        }
                    } else {
                        arrayList9.add(v0Var3.f767b);
                    }
                    size8--;
                    i23 = 1;
                }
            } else {
                ArrayList arrayList11 = this.K;
                ArrayList arrayList12 = aVar4.f593a;
                int i25 = 0;
                while (i25 < arrayList12.size()) {
                    v0 v0Var4 = (v0) arrayList12.get(i25);
                    int i26 = v0Var4.f766a;
                    if (i26 == i10) {
                        z6 = z8;
                        i6 = i9;
                        z7 = z9;
                        i7 = 1;
                        arrayList11.add(v0Var4.f767b);
                    } else if (i26 != 2) {
                        if (i26 == 3 || i26 == 6) {
                            z6 = z8;
                            arrayList11.remove(v0Var4.f767b);
                            w wVar8 = v0Var4.f767b;
                            if (wVar8 == wVar) {
                                arrayList12.add(i25, new v0(9, wVar8));
                                i25++;
                                i6 = i9;
                                z7 = z9;
                                i7 = 1;
                                wVar = null;
                            }
                        } else if (i26 == 7) {
                            z6 = z8;
                            i6 = i9;
                            z7 = z9;
                            i7 = 1;
                            arrayList11.add(v0Var4.f767b);
                        } else if (i26 != 8) {
                            z6 = z8;
                        } else {
                            z6 = z8;
                            arrayList12.add(i25, new v0(9, wVar, 0));
                            v0Var4.f768c = true;
                            i25++;
                            wVar = v0Var4.f767b;
                        }
                        i6 = i9;
                        z7 = z9;
                        i7 = 1;
                    } else {
                        z6 = z8;
                        w wVar9 = v0Var4.f767b;
                        int i27 = wVar9.f795w;
                        int size9 = arrayList11.size() - 1;
                        boolean z12 = false;
                        while (size9 >= 0) {
                            int i28 = i9;
                            w wVar10 = (w) arrayList11.get(size9);
                            boolean z13 = z9;
                            if (wVar10.f795w != i27) {
                                i27 = i27;
                            } else if (wVar10 == wVar9) {
                                i27 = i27;
                                z12 = true;
                            } else {
                                if (wVar10 == wVar) {
                                    i8 = 0;
                                    arrayList12.add(i25, new v0(9, wVar10, 0));
                                    i25++;
                                    wVar = null;
                                } else {
                                    i8 = 0;
                                }
                                v0 v0Var5 = new v0(3, wVar10, i8);
                                v0Var5.f769d = v0Var4.f769d;
                                v0Var5.f = v0Var4.f;
                                v0Var5.f770e = v0Var4.f770e;
                                v0Var5.f771g = v0Var4.f771g;
                                arrayList12.add(i25, v0Var5);
                                arrayList11.remove(wVar10);
                                i25++;
                                wVar = wVar;
                            }
                            size9--;
                            i27 = i27;
                            z9 = z13;
                            i9 = i28;
                        }
                        i6 = i9;
                        z7 = z9;
                        i7 = 1;
                        if (z12) {
                            arrayList12.remove(i25);
                            i25--;
                        } else {
                            v0Var4.f766a = 1;
                            v0Var4.f768c = true;
                            arrayList11.add(wVar9);
                        }
                    }
                    i25 += i7;
                    z8 = z6;
                    z9 = z7;
                    i9 = i6;
                    i10 = 1;
                }
                z4 = z8;
                i5 = i9;
                z5 = z9;
            }
            z9 = z5 || aVar4.f598g;
            i9 = i5 + 1;
            z8 = z4;
        }
    }
}
