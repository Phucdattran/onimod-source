package androidx.fragment.app;

import android.content.Intent;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class f0 implements androidx.activity.result.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f647a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ o0 f648b;

    public /* synthetic */ f0(o0 o0Var, int i3) {
        this.f647a = i3;
        this.f648b = o0Var;
    }

    @Override // androidx.activity.result.c
    public final void a(Object obj) {
        switch (this.f647a) {
            case 0:
                Map map = (Map) obj;
                ArrayList arrayList = new ArrayList(map.values());
                int[] iArr = new int[arrayList.size()];
                for (int i3 = 0; i3 < arrayList.size(); i3++) {
                    iArr[i3] = ((Boolean) arrayList.get(i3)).booleanValue() ? 0 : -1;
                }
                o0 o0Var = this.f648b;
                l0 l0Var = (l0) o0Var.C.pollFirst();
                if (l0Var != null) {
                    o0Var.f687c.d(l0Var.f670a);
                    break;
                }
                break;
            case 1:
                androidx.activity.result.b bVar = (androidx.activity.result.b) obj;
                o0 o0Var2 = this.f648b;
                l0 l0Var2 = (l0) o0Var2.C.pollFirst();
                if (l0Var2 != null) {
                    w wVarD = o0Var2.f687c.d(l0Var2.f670a);
                    if (wVarD != null) {
                        int i4 = bVar.f171a;
                        Intent intent = bVar.f172b;
                        if (o0.F(2)) {
                            wVarD.toString();
                            Objects.toString(intent);
                        }
                        break;
                    }
                }
                break;
            default:
                androidx.activity.result.b bVar2 = (androidx.activity.result.b) obj;
                o0 o0Var3 = this.f648b;
                l0 l0Var3 = (l0) o0Var3.C.pollFirst();
                if (l0Var3 != null) {
                    w wVarD2 = o0Var3.f687c.d(l0Var3.f670a);
                    if (wVarD2 != null) {
                        int i5 = bVar2.f171a;
                        Intent intent2 = bVar2.f172b;
                        if (o0.F(2)) {
                            wVarD2.toString();
                            Objects.toString(intent2);
                        }
                        break;
                    }
                }
                break;
        }
    }
}
