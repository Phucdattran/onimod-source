package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class l0 implements Parcelable {
    public static final Parcelable.Creator<l0> CREATOR = new androidx.activity.result.a(4);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f670a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f671b;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i3) {
        parcel.writeString(this.f670a);
        parcel.writeInt(this.f671b);
    }
}
