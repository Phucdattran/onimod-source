package androidx.fragment.app;

import android.content.Intent;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import kotlin.Pair;

/* JADX INFO: loaded from: classes.dex */
public final class k0 extends a3.a {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ int f668o;

    public /* synthetic */ k0(int i3) {
        this.f668o = i3;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // a3.a
    public b.a J(z zVar, Cloneable cloneable) {
        switch (this.f668o) {
            case 1:
                return null;
            case 2:
                String[] strArr = (String[]) cloneable;
                if (strArr.length == 0) {
                    return new b.a(kotlin.collections.r.R());
                }
                for (String str : strArr) {
                    if (c0.g.a(zVar, str) != 0) {
                        return null;
                    }
                }
                int iT = kotlin.collections.r.T(strArr.length);
                if (iT < 16) {
                    iT = 16;
                }
                LinkedHashMap linkedHashMap = new LinkedHashMap(iT);
                for (String str2 : strArr) {
                    Pair pair = new Pair(str2, Boolean.TRUE);
                    linkedHashMap.put(pair.c(), pair.d());
                }
                return new b.a(linkedHashMap);
            default:
                return super.J(zVar, cloneable);
        }
    }

    @Override // a3.a
    public final Object X(int i3, Intent intent) {
        switch (this.f668o) {
            case 0:
                return new androidx.activity.result.b(i3, intent);
            case 1:
                if (i3 != -1) {
                    intent = null;
                }
                if (intent != null) {
                    return intent.getData();
                }
                return null;
            case 2:
                if (i3 != -1) {
                    return kotlin.collections.r.R();
                }
                if (intent == null) {
                    return kotlin.collections.r.R();
                }
                String[] stringArrayExtra = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                int[] intArrayExtra = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
                if (intArrayExtra == null || stringArrayExtra == null) {
                    return kotlin.collections.r.R();
                }
                ArrayList arrayList = new ArrayList(intArrayExtra.length);
                for (int i4 : intArrayExtra) {
                    arrayList.add(Boolean.valueOf(i4 == 0));
                }
                ArrayList arrayList2 = new ArrayList();
                for (String str : stringArrayExtra) {
                    if (str != null) {
                        arrayList2.add(str);
                    }
                }
                Iterator it = arrayList2.iterator();
                Iterator it2 = arrayList.iterator();
                ArrayList arrayList3 = new ArrayList(Math.min(kotlin.collections.l.S(arrayList2, 10), kotlin.collections.l.S(arrayList, 10)));
                while (it.hasNext() && it2.hasNext()) {
                    arrayList3.add(new Pair(it.next(), it2.next()));
                }
                return kotlin.collections.r.U(arrayList3);
            default:
                return new androidx.activity.result.b(i3, intent);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // a3.a
    public final Intent x(z zVar, Cloneable cloneable) {
        Bundle bundleExtra;
        switch (this.f668o) {
            case 0:
                androidx.activity.result.i iVar = (androidx.activity.result.i) cloneable;
                Intent intent = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
                Intent intent2 = iVar.f188b;
                if (intent2 != null && (bundleExtra = intent2.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) != null) {
                    intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundleExtra);
                    intent2.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                    if (intent2.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false)) {
                        iVar = new androidx.activity.result.i(iVar.f187a, null, iVar.f189c, iVar.f190d);
                    }
                }
                intent.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", iVar);
                if (o0.F(2)) {
                    intent.toString();
                }
                return intent;
            case 1:
                Intent type = new Intent("android.intent.action.OPEN_DOCUMENT").putExtra("android.intent.extra.MIME_TYPES", (String[]) cloneable).setType("*/*");
                kotlin.jvm.internal.d.e(type, "Intent(Intent.ACTION_OPE…          .setType(\"*/*\")");
                return type;
            case 2:
                Intent intentPutExtra = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", (String[]) cloneable);
                kotlin.jvm.internal.d.e(intentPutExtra, "Intent(ACTION_REQUEST_PE…EXTRA_PERMISSIONS, input)");
                return intentPutExtra;
            default:
                return (Intent) cloneable;
        }
    }
}
