package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public final class b0 implements View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ u0 f628a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ c0 f629b;

    public b0(c0 c0Var, u0 u0Var) {
        this.f629b = c0Var;
        this.f628a = u0Var;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        u0 u0Var = this.f628a;
        w wVar = u0Var.f762c;
        u0Var.k();
        j.f((ViewGroup) wVar.E.getParent(), this.f629b.f632a.E()).e();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
    }
}
