package androidx.fragment.app;

import android.util.AndroidRuntimeException;

/* JADX INFO: loaded from: classes.dex */
final class SuperNotCalledException extends AndroidRuntimeException {
}
