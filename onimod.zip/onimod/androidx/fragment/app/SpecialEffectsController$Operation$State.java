package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import java.util.Objects;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
final class SpecialEffectsController$Operation$State {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final SpecialEffectsController$Operation$State f588a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final SpecialEffectsController$Operation$State f589b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final SpecialEffectsController$Operation$State f590c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final SpecialEffectsController$Operation$State f591d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final /* synthetic */ SpecialEffectsController$Operation$State[] f592e;

    static {
        SpecialEffectsController$Operation$State specialEffectsController$Operation$State = new SpecialEffectsController$Operation$State("REMOVED", 0);
        f588a = specialEffectsController$Operation$State;
        SpecialEffectsController$Operation$State specialEffectsController$Operation$State2 = new SpecialEffectsController$Operation$State("VISIBLE", 1);
        f589b = specialEffectsController$Operation$State2;
        SpecialEffectsController$Operation$State specialEffectsController$Operation$State3 = new SpecialEffectsController$Operation$State("GONE", 2);
        f590c = specialEffectsController$Operation$State3;
        SpecialEffectsController$Operation$State specialEffectsController$Operation$State4 = new SpecialEffectsController$Operation$State("INVISIBLE", 3);
        f591d = specialEffectsController$Operation$State4;
        f592e = new SpecialEffectsController$Operation$State[]{specialEffectsController$Operation$State, specialEffectsController$Operation$State2, specialEffectsController$Operation$State3, specialEffectsController$Operation$State4};
    }

    public static SpecialEffectsController$Operation$State b(int i3) {
        if (i3 == 0) {
            return f589b;
        }
        if (i3 == 4) {
            return f591d;
        }
        if (i3 == 8) {
            return f590c;
        }
        throw new IllegalArgumentException(g0.e.b(i3, "Unknown visibility "));
    }

    public static SpecialEffectsController$Operation$State c(View view) {
        return (view.getAlpha() == 0.0f && view.getVisibility() == 0) ? f591d : b(view.getVisibility());
    }

    public static SpecialEffectsController$Operation$State valueOf(String str) {
        return (SpecialEffectsController$Operation$State) Enum.valueOf(SpecialEffectsController$Operation$State.class, str);
    }

    public static SpecialEffectsController$Operation$State[] values() {
        return (SpecialEffectsController$Operation$State[]) f592e.clone();
    }

    public final void a(View view) {
        int iOrdinal = ordinal();
        if (iOrdinal == 0) {
            ViewGroup viewGroup = (ViewGroup) view.getParent();
            if (viewGroup != null) {
                if (o0.F(2)) {
                    view.toString();
                    viewGroup.toString();
                }
                viewGroup.removeView(view);
                return;
            }
            return;
        }
        if (iOrdinal == 1) {
            if (o0.F(2)) {
                Objects.toString(view);
            }
            view.setVisibility(0);
        } else if (iOrdinal == 2) {
            if (o0.F(2)) {
                Objects.toString(view);
            }
            view.setVisibility(8);
        } else {
            if (iOrdinal != 3) {
                return;
            }
            if (o0.F(2)) {
                Objects.toString(view);
            }
            view.setVisibility(4);
        }
    }
}
