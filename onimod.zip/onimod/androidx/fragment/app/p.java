package androidx.fragment.app;

import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: classes.dex */
public final class p extends androidx.activity.result.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ AtomicReference f710a;

    public p(AtomicReference atomicReference) {
        this.f710a = atomicReference;
    }

    @Override // androidx.activity.result.d
    public final void a(Object obj) {
        androidx.activity.result.d dVar = (androidx.activity.result.d) this.f710a.get();
        if (dVar == null) {
            throw new IllegalStateException("Operation cannot be started before fragment is in created state");
        }
        dVar.a(obj);
    }
}
