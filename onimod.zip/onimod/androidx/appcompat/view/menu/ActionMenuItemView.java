package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import d.a;
import i1.m;
import k.b;
import k.c;
import k.o;
import k.z;
import l.a1;
import l.l;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuItemView extends a1 implements z, View.OnClickListener, l {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public o f201h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public CharSequence f202i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Drawable f203j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public k.l f204k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public b f205l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public c f206m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f207n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f208o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f209p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f210q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f211r;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.f207n = g();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f1596c, 0, 0);
        this.f209p = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.f211r = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f210q = -1;
        setSaveEnabled(false);
    }

    @Override // l.l
    public final boolean a() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // l.l
    public final boolean b() {
        return !TextUtils.isEmpty(getText()) && this.f201h.getIcon() == null;
    }

    @Override // k.z
    public final void c(o oVar) {
        this.f201h = oVar;
        setIcon(oVar.getIcon());
        setTitle(oVar.getTitleCondensed());
        setId(oVar.f2728a);
        setVisibility(oVar.isVisible() ? 0 : 8);
        setEnabled(oVar.isEnabled());
        if (oVar.hasSubMenu() && this.f205l == null) {
            this.f205l = new b(this);
        }
    }

    public final boolean g() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i3 = configuration.screenWidthDp;
        int i4 = configuration.screenHeightDp;
        if (i3 < 480) {
            return (i3 >= 640 && i4 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // k.z
    public o getItemData() {
        return this.f201h;
    }

    public final void h() {
        boolean z4 = true;
        boolean z5 = !TextUtils.isEmpty(this.f202i);
        if (this.f203j != null && ((this.f201h.f2751y & 4) != 4 || (!this.f207n && !this.f208o))) {
            z4 = false;
        }
        boolean z6 = z5 & z4;
        setText(z6 ? this.f202i : null);
        CharSequence charSequence = this.f201h.f2743q;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z6 ? null : this.f201h.f2732e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f201h.f2744r;
        if (TextUtils.isEmpty(charSequence2)) {
            m.P(this, z6 ? null : this.f201h.f2732e);
        } else {
            m.P(this, charSequence2);
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        k.l lVar = this.f204k;
        if (lVar != null) {
            lVar.a(this.f201h);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f207n = g();
        h();
    }

    @Override // l.a1, android.widget.TextView, android.view.View
    public final void onMeasure(int i3, int i4) {
        int i5;
        boolean zIsEmpty = TextUtils.isEmpty(getText());
        if (!zIsEmpty && (i5 = this.f210q) >= 0) {
            super.setPadding(i5, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i3, i4);
        int mode = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i3);
        int measuredWidth = getMeasuredWidth();
        int i6 = this.f209p;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i6) : i6;
        if (mode != 1073741824 && i6 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i4);
        }
        if (!zIsEmpty || this.f203j == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f203j.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        b bVar;
        if (this.f201h.hasSubMenu() && (bVar = this.f205l) != null && bVar.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z4) {
    }

    public void setChecked(boolean z4) {
    }

    public void setExpandedFormat(boolean z4) {
        if (this.f208o != z4) {
            this.f208o = z4;
            o oVar = this.f201h;
            if (oVar != null) {
                k.m mVar = oVar.f2740n;
                mVar.f2711k = true;
                mVar.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f203j = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i3 = this.f211r;
            if (intrinsicWidth > i3) {
                intrinsicHeight = (int) (intrinsicHeight * (i3 / intrinsicWidth));
                intrinsicWidth = i3;
            }
            if (intrinsicHeight > i3) {
                intrinsicWidth = (int) (intrinsicWidth * (i3 / intrinsicHeight));
            } else {
                i3 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i3);
        }
        setCompoundDrawables(drawable, null, null, null);
        h();
    }

    public void setItemInvoker(k.l lVar) {
        this.f204k = lVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i3, int i4, int i5, int i6) {
        this.f210q = i3;
        super.setPadding(i3, i4, i5, i6);
    }

    public void setPopupCallback(c cVar) {
        this.f206m = cVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f202i = charSequence;
        h();
    }
}
