package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.emoji2.text.u;
import k.a0;
import k.l;
import k.m;
import k.o;

/* JADX INFO: loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements l, a0, AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int[] f212b = {R.attr.background, R.attr.divider};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public m f213a;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        u uVarX = u.x(context, attributeSet, f212b, R.attr.listViewStyle);
        TypedArray typedArray = (TypedArray) uVarX.f563c;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(uVarX.o(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(uVarX.o(1));
        }
        uVarX.z();
    }

    @Override // k.l
    public final boolean a(o oVar) {
        return this.f213a.q(oVar, null, 0);
    }

    @Override // k.a0
    public final void b(m mVar) {
        this.f213a = mVar;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i3, long j4) {
        a((o) getAdapter().getItem(i3));
    }
}
