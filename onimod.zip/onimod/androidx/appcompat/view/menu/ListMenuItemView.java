package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.emoji2.text.u;
import com.mod.menu.ModConfig;
import d.a;
import k.m;
import k.o;
import k.z;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements z, AbsListView.SelectionBoundsAdjuster {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public o f214a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ImageView f215b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public RadioButton f216c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TextView f217d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public CheckBox f218e;
    public TextView f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ImageView f219g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ImageView f220h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public LinearLayout f221i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Drawable f222j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f223k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Context f224l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f225m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Drawable f226n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final boolean f227o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public LayoutInflater f228p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f229q;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        u uVarX = u.x(getContext(), attributeSet, a.f1610r, R.attr.listMenuViewStyle);
        this.f222j = uVarX.o(5);
        TypedArray typedArray = (TypedArray) uVarX.f563c;
        this.f223k = typedArray.getResourceId(1, -1);
        this.f225m = typedArray.getBoolean(7, false);
        this.f224l = context;
        this.f226n = uVarX.o(8);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{android.R.attr.divider}, R.attr.dropDownListViewStyle, 0);
        this.f227o = typedArrayObtainStyledAttributes.hasValue(0);
        uVarX.z();
        typedArrayObtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f228p == null) {
            this.f228p = LayoutInflater.from(getContext());
        }
        return this.f228p;
    }

    private void setSubMenuArrowVisible(boolean z4) {
        ImageView imageView = this.f219g;
        if (imageView != null) {
            imageView.setVisibility(z4 ? 0 : 8);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f220h;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f220h.getLayoutParams();
        rect.top = this.f220h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0036  */
    /* JADX WARN: Code duplicated, block: B:25:0x0055  */
    /* JADX WARN: Code duplicated, block: B:28:0x0059  */
    @Override // k.z
    public final void c(o oVar) {
        boolean z4;
        int i3;
        String string;
        boolean z5;
        this.f214a = oVar;
        boolean zIsVisible = oVar.isVisible();
        m mVar = oVar.f2740n;
        setVisibility(zIsVisible ? 0 : 8);
        setTitle(oVar.f2732e);
        setCheckable(oVar.isCheckable());
        if (mVar.o()) {
            if ((mVar.n() ? oVar.f2736j : oVar.f2734h) != 0) {
                z4 = true;
            } else {
                z4 = false;
            }
        } else {
            z4 = false;
        }
        mVar.n();
        if (z4) {
            o oVar2 = this.f214a;
            m mVar2 = oVar2.f2740n;
            if (mVar2.o()) {
                if ((mVar2.n() ? oVar2.f2736j : oVar2.f2734h) != 0) {
                    z5 = true;
                } else {
                    z5 = false;
                }
            } else {
                z5 = false;
            }
            i3 = z5 ? 0 : 8;
        }
        if (i3 == 0) {
            TextView textView = this.f;
            o oVar3 = this.f214a;
            m mVar3 = oVar3.f2740n;
            Context context = mVar3.f2702a;
            char c3 = mVar3.n() ? oVar3.f2736j : oVar3.f2734h;
            if (c3 == 0) {
                string = ModConfig.PREFIX;
            } else {
                Resources resources = context.getResources();
                StringBuilder sb = new StringBuilder();
                if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
                    sb.append(resources.getString(R.string.abc_prepend_shortcut_label));
                }
                int i4 = mVar3.n() ? oVar3.f2737k : oVar3.f2735i;
                o.c(i4, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label), sb);
                o.c(i4, 4096, resources.getString(R.string.abc_menu_ctrl_shortcut_label), sb);
                o.c(i4, 2, resources.getString(R.string.abc_menu_alt_shortcut_label), sb);
                o.c(i4, 1, resources.getString(R.string.abc_menu_shift_shortcut_label), sb);
                o.c(i4, 4, resources.getString(R.string.abc_menu_sym_shortcut_label), sb);
                o.c(i4, 8, resources.getString(R.string.abc_menu_function_shortcut_label), sb);
                if (c3 == '\b') {
                    sb.append(resources.getString(R.string.abc_menu_delete_shortcut_label));
                } else if (c3 == '\n') {
                    sb.append(resources.getString(R.string.abc_menu_enter_shortcut_label));
                } else if (c3 != ' ') {
                    sb.append(c3);
                } else {
                    sb.append(resources.getString(R.string.abc_menu_space_shortcut_label));
                }
                string = sb.toString();
            }
            textView.setText(string);
        }
        if (this.f.getVisibility() != i3) {
            this.f.setVisibility(i3);
        }
        setIcon(oVar.getIcon());
        setEnabled(oVar.isEnabled());
        setSubMenuArrowVisible(oVar.hasSubMenu());
        setContentDescription(oVar.f2743q);
    }

    @Override // k.z
    public o getItemData() {
        return this.f214a;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.f222j);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f217d = textView;
        int i3 = this.f223k;
        if (i3 != -1) {
            textView.setTextAppearance(this.f224l, i3);
        }
        this.f = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f219g = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f226n);
        }
        this.f220h = (ImageView) findViewById(R.id.group_divider);
        this.f221i = (LinearLayout) findViewById(R.id.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i3, int i4) {
        if (this.f215b != null && this.f225m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f215b.getLayoutParams();
            int i5 = layoutParams.height;
            if (i5 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i5;
            }
        }
        super.onMeasure(i3, i4);
    }

    public void setCheckable(boolean z4) {
        CompoundButton compoundButton;
        View view;
        if (!z4 && this.f216c == null && this.f218e == null) {
            return;
        }
        if ((this.f214a.f2750x & 4) != 0) {
            if (this.f216c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f216c = radioButton;
                LinearLayout linearLayout = this.f221i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f216c;
            view = this.f218e;
        } else {
            if (this.f218e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f218e = checkBox;
                LinearLayout linearLayout2 = this.f221i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f218e;
            view = this.f216c;
        }
        if (z4) {
            compoundButton.setChecked(this.f214a.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.f218e;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f216c;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z4) {
        CompoundButton compoundButton;
        if ((this.f214a.f2750x & 4) != 0) {
            if (this.f216c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f216c = radioButton;
                LinearLayout linearLayout = this.f221i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f216c;
        } else {
            if (this.f218e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f218e = checkBox;
                LinearLayout linearLayout2 = this.f221i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f218e;
        }
        compoundButton.setChecked(z4);
    }

    public void setForceShowIcon(boolean z4) {
        this.f229q = z4;
        this.f225m = z4;
    }

    public void setGroupDividerEnabled(boolean z4) {
        ImageView imageView = this.f220h;
        if (imageView != null) {
            imageView.setVisibility((this.f227o || !z4) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        m mVar = this.f214a.f2740n;
        boolean z4 = this.f229q;
        if (z4 || this.f225m) {
            ImageView imageView = this.f215b;
            if (imageView == null && drawable == null && !this.f225m) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.f215b = imageView2;
                LinearLayout linearLayout = this.f221i;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f225m) {
                this.f215b.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f215b;
            if (!z4) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f215b.getVisibility() != 0) {
                this.f215b.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f217d.getVisibility() != 8) {
                this.f217d.setVisibility(8);
            }
        } else {
            this.f217d.setText(charSequence);
            if (this.f217d.getVisibility() != 0) {
                this.f217d.setVisibility(0);
            }
        }
    }
}
