package androidx.appcompat.widget;

import a0.b;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import k.a0;
import k.l;
import k.m;
import k.o;
import l.g;
import l.j;
import l.k;
import l.n;
import l.o3;
import l.w1;
import l.x1;
import l.z2;
import s2.e;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuView extends x1 implements l, a0 {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public m f282p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Context f283q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f284r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f285s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public k f286t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public z2 f287u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f288v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f289w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f290x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f291y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public n f292z;

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        setBaselineAligned(false);
        float f = context.getResources().getDisplayMetrics().density;
        this.f290x = (int) (56.0f * f);
        this.f291y = (int) (f * 4.0f);
        this.f283q = context;
        this.f284r = 0;
    }

    public static l.m j() {
        l.m mVar = new l.m(-2, -2);
        mVar.f3166a = false;
        ((LinearLayout.LayoutParams) mVar).gravity = 16;
        return mVar;
    }

    public static l.m k(ViewGroup.LayoutParams layoutParams) {
        l.m mVar;
        if (layoutParams == null) {
            return j();
        }
        if (layoutParams instanceof l.m) {
            l.m mVar2 = (l.m) layoutParams;
            mVar = new l.m(mVar2);
            mVar.f3166a = mVar2.f3166a;
        } else {
            mVar = new l.m(layoutParams);
        }
        if (((LinearLayout.LayoutParams) mVar).gravity <= 0) {
            ((LinearLayout.LayoutParams) mVar).gravity = 16;
        }
        return mVar;
    }

    @Override // k.l
    public final boolean a(o oVar) {
        return this.f282p.q(oVar, null, 0);
    }

    @Override // k.a0
    public final void b(m mVar) {
        this.f282p = mVar;
    }

    @Override // l.x1, android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof l.m;
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    @Override // l.x1
    /* JADX INFO: renamed from: f */
    public final /* bridge */ /* synthetic */ w1 generateDefaultLayoutParams() {
        return j();
    }

    @Override // l.x1
    /* JADX INFO: renamed from: g */
    public final w1 generateLayoutParams(AttributeSet attributeSet) {
        return new l.m(getContext(), attributeSet);
    }

    @Override // l.x1, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return j();
    }

    @Override // l.x1, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return k(layoutParams);
    }

    public Menu getMenu() {
        if (this.f282p == null) {
            Context context = getContext();
            m mVar = new m(context);
            this.f282p = mVar;
            mVar.f2706e = new b(16, this);
            k kVar = new k(context);
            this.f286t = kVar;
            kVar.f3138l = true;
            kVar.f3139m = true;
            kVar.f3132e = new e(16);
            this.f282p.b(kVar, this.f283q);
            k kVar2 = this.f286t;
            kVar2.f3134h = this;
            this.f282p = kVar2.f3130c;
        }
        return this.f282p;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        k kVar = this.f286t;
        j jVar = kVar.f3135i;
        if (jVar != null) {
            return jVar.getDrawable();
        }
        if (kVar.f3137k) {
            return kVar.f3136j;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f284r;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // l.x1
    /* JADX INFO: renamed from: h */
    public final /* bridge */ /* synthetic */ w1 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return k(layoutParams);
    }

    public final boolean l(int i3) {
        boolean zA = false;
        if (i3 == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i3 - 1);
        KeyEvent.Callback childAt2 = getChildAt(i3);
        if (i3 < getChildCount() && (childAt instanceof l.l)) {
            zA = ((l.l) childAt).a();
        }
        return (i3 <= 0 || !(childAt2 instanceof l.l)) ? zA : ((l.l) childAt2).b() | zA;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        k kVar = this.f286t;
        if (kVar != null) {
            kVar.i();
            if (this.f286t.j()) {
                this.f286t.h();
                this.f286t.l();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        k kVar = this.f286t;
        if (kVar != null) {
            kVar.h();
            g gVar = kVar.f3146t;
            if (gVar == null || !gVar.b()) {
                return;
            }
            gVar.f2772i.dismiss();
        }
    }

    @Override // l.x1, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        int width;
        int paddingLeft;
        if (!this.f288v) {
            super.onLayout(z4, i3, i4, i5, i6);
            return;
        }
        int childCount = getChildCount();
        int i7 = (i6 - i4) / 2;
        int dividerWidth = getDividerWidth();
        int i8 = i5 - i3;
        int paddingRight = (i8 - getPaddingRight()) - getPaddingLeft();
        boolean z5 = o3.f3193a;
        boolean z6 = getLayoutDirection() == 1;
        int i9 = 0;
        int i10 = 0;
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (childAt.getVisibility() != 8) {
                l.m mVar = (l.m) childAt.getLayoutParams();
                if (mVar.f3166a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (l(i11)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (z6) {
                        paddingLeft = getPaddingLeft() + ((LinearLayout.LayoutParams) mVar).leftMargin;
                        width = paddingLeft + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((LinearLayout.LayoutParams) mVar).rightMargin;
                        paddingLeft = width - measuredWidth;
                    }
                    int i12 = i7 - (measuredHeight / 2);
                    childAt.layout(paddingLeft, i12, width, measuredHeight + i12);
                    paddingRight -= measuredWidth;
                    i9 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((LinearLayout.LayoutParams) mVar).leftMargin) + ((LinearLayout.LayoutParams) mVar).rightMargin;
                    l(i11);
                    i10++;
                }
            }
        }
        if (childCount == 1 && i9 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i13 = (i8 / 2) - (measuredWidth2 / 2);
            int i14 = i7 - (measuredHeight2 / 2);
            childAt2.layout(i13, i14, measuredWidth2 + i13, measuredHeight2 + i14);
            return;
        }
        int i15 = i10 - (i9 ^ 1);
        int iMax = Math.max(0, i15 > 0 ? paddingRight / i15 : 0);
        if (z6) {
            int width2 = getWidth() - getPaddingRight();
            for (int i16 = 0; i16 < childCount; i16++) {
                View childAt3 = getChildAt(i16);
                l.m mVar2 = (l.m) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !mVar2.f3166a) {
                    int i17 = width2 - ((LinearLayout.LayoutParams) mVar2).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i18 = i7 - (measuredHeight3 / 2);
                    childAt3.layout(i17 - measuredWidth3, i18, i17, measuredHeight3 + i18);
                    width2 = i17 - ((measuredWidth3 + ((LinearLayout.LayoutParams) mVar2).leftMargin) + iMax);
                }
            }
            return;
        }
        int paddingLeft2 = getPaddingLeft();
        for (int i19 = 0; i19 < childCount; i19++) {
            View childAt4 = getChildAt(i19);
            l.m mVar3 = (l.m) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !mVar3.f3166a) {
                int i20 = paddingLeft2 + ((LinearLayout.LayoutParams) mVar3).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i21 = i7 - (measuredHeight4 / 2);
                childAt4.layout(i20, i21, i20 + measuredWidth4, measuredHeight4 + i21);
                paddingLeft2 = measuredWidth4 + ((LinearLayout.LayoutParams) mVar3).rightMargin + iMax + i20;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r11v15 */
    /* JADX WARN: Type inference failed for: r11v16, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r11v18 */
    /* JADX WARN: Type inference failed for: r11v41 */
    @Override // l.x1, android.view.View
    public final void onMeasure(int i3, int i4) {
        int i5;
        int i6;
        ?? r11;
        int i7;
        int i8;
        m mVar;
        boolean z4 = this.f288v;
        boolean z5 = View.MeasureSpec.getMode(i3) == 1073741824;
        this.f288v = z5;
        if (z4 != z5) {
            this.f289w = 0;
        }
        int size = View.MeasureSpec.getSize(i3);
        if (this.f288v && (mVar = this.f282p) != null && size != this.f289w) {
            this.f289w = size;
            mVar.p(true);
        }
        int childCount = getChildCount();
        if (!this.f288v || childCount <= 0) {
            for (int i9 = 0; i9 < childCount; i9++) {
                l.m mVar2 = (l.m) getChildAt(i9).getLayoutParams();
                ((LinearLayout.LayoutParams) mVar2).rightMargin = 0;
                ((LinearLayout.LayoutParams) mVar2).leftMargin = 0;
            }
            super.onMeasure(i3, i4);
            return;
        }
        int mode = View.MeasureSpec.getMode(i4);
        int size2 = View.MeasureSpec.getSize(i3);
        int size3 = View.MeasureSpec.getSize(i4);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i4, paddingBottom, -2);
        int i10 = size2 - paddingRight;
        int i11 = this.f290x;
        int i12 = i10 / i11;
        int i13 = i10 % i11;
        if (i12 == 0) {
            setMeasuredDimension(i10, 0);
            return;
        }
        int i14 = (i13 / i12) + i11;
        int childCount2 = getChildCount();
        int iMax = 0;
        int i15 = 0;
        int iMax2 = 0;
        int i16 = 0;
        boolean z6 = false;
        int i17 = 0;
        long j4 = 0;
        while (true) {
            i5 = this.f291y;
            if (i16 >= childCount2) {
                break;
            }
            View childAt = getChildAt(i16);
            int i18 = size3;
            int i19 = paddingBottom;
            if (childAt.getVisibility() == 8) {
                i7 = i14;
            } else {
                boolean z7 = childAt instanceof ActionMenuItemView;
                i15++;
                if (z7) {
                    childAt.setPadding(i5, 0, i5, 0);
                }
                l.m mVar3 = (l.m) childAt.getLayoutParams();
                mVar3.f = false;
                mVar3.f3168c = 0;
                mVar3.f3167b = 0;
                mVar3.f3169d = false;
                ((LinearLayout.LayoutParams) mVar3).leftMargin = 0;
                ((LinearLayout.LayoutParams) mVar3).rightMargin = 0;
                mVar3.f3170e = z7 && !TextUtils.isEmpty(((ActionMenuItemView) childAt).getText());
                int i20 = mVar3.f3166a ? 1 : i12;
                l.m mVar4 = (l.m) childAt.getLayoutParams();
                int i21 = i12;
                i7 = i14;
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - i19, View.MeasureSpec.getMode(childMeasureSpec));
                ActionMenuItemView actionMenuItemView = z7 ? (ActionMenuItemView) childAt : null;
                boolean z8 = (actionMenuItemView == null || TextUtils.isEmpty(actionMenuItemView.getText())) ? false : true;
                boolean z9 = z8;
                if (i20 <= 0 || (z8 && i20 < 2)) {
                    i8 = 0;
                } else {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i7 * i20, Integer.MIN_VALUE), iMakeMeasureSpec);
                    int measuredWidth = childAt.getMeasuredWidth();
                    i8 = measuredWidth / i7;
                    if (measuredWidth % i7 != 0) {
                        i8++;
                    }
                    if (z9 && i8 < 2) {
                        i8 = 2;
                    }
                }
                mVar4.f3169d = !mVar4.f3166a && z9;
                mVar4.f3167b = i8;
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i8 * i7, 1073741824), iMakeMeasureSpec);
                iMax2 = Math.max(iMax2, i8);
                if (mVar3.f3169d) {
                    i17++;
                }
                if (mVar3.f3166a) {
                    z6 = true;
                }
                i12 = i21 - i8;
                iMax = Math.max(iMax, childAt.getMeasuredHeight());
                if (i8 == 1) {
                    j4 |= (long) (1 << i16);
                }
            }
            i16++;
            size3 = i18;
            paddingBottom = i19;
            i14 = i7;
        }
        int i22 = size3;
        int i23 = i12;
        int i24 = i14;
        boolean z10 = z6 && i15 == 2;
        int i25 = i23;
        boolean z11 = false;
        while (true) {
            if (i17 <= 0 || i25 <= 0) {
                i6 = iMax;
                break;
            }
            int i26 = Integer.MAX_VALUE;
            long j5 = 0;
            int i27 = 0;
            int i28 = 0;
            while (i28 < childCount2) {
                int i29 = iMax;
                l.m mVar5 = (l.m) getChildAt(i28).getLayoutParams();
                boolean z12 = z10;
                if (mVar5.f3169d) {
                    int i30 = mVar5.f3167b;
                    if (i30 < i26) {
                        j5 = 1 << i28;
                        i26 = i30;
                        i27 = 1;
                    } else if (i30 == i26) {
                        j5 |= 1 << i28;
                        i27++;
                    }
                }
                i28++;
                z10 = z12;
                iMax = i29;
            }
            i6 = iMax;
            boolean z13 = z10;
            j4 |= j5;
            if (i27 > i25) {
                break;
            }
            int i31 = i26 + 1;
            int i32 = 0;
            while (i32 < childCount2) {
                View childAt2 = getChildAt(i32);
                l.m mVar6 = (l.m) childAt2.getLayoutParams();
                boolean z14 = z6;
                long j6 = 1 << i32;
                if ((j5 & j6) != 0) {
                    if (z13 && mVar6.f3170e) {
                        r11 = 1;
                        r11 = 1;
                        if (i25 == 1) {
                            childAt2.setPadding(i5 + i24, 0, i5, 0);
                        }
                    } else {
                        r11 = 1;
                    }
                    mVar6.f3167b += r11;
                    mVar6.f = r11;
                    i25--;
                } else if (mVar6.f3167b == i31) {
                    j4 |= j6;
                }
                i32++;
                z6 = z14;
            }
            z10 = z13;
            iMax = i6;
            z11 = true;
        }
        boolean z15 = !z6 && i15 == 1;
        if (i25 > 0 && j4 != 0 && (i25 < i15 - 1 || z15 || iMax2 > 1)) {
            float fBitCount = Long.bitCount(j4);
            if (!z15) {
                if ((j4 & 1) != 0 && !((l.m) getChildAt(0).getLayoutParams()).f3170e) {
                    fBitCount -= 0.5f;
                }
                int i33 = childCount2 - 1;
                if ((j4 & ((long) (1 << i33))) != 0 && !((l.m) getChildAt(i33).getLayoutParams()).f3170e) {
                    fBitCount -= 0.5f;
                }
            }
            int i34 = fBitCount > 0.0f ? (int) ((i25 * i24) / fBitCount) : 0;
            boolean z16 = z11;
            for (int i35 = 0; i35 < childCount2; i35++) {
                if ((j4 & ((long) (1 << i35))) != 0) {
                    View childAt3 = getChildAt(i35);
                    l.m mVar7 = (l.m) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        mVar7.f3168c = i34;
                        mVar7.f = true;
                        if (i35 == 0 && !mVar7.f3170e) {
                            ((LinearLayout.LayoutParams) mVar7).leftMargin = (-i34) / 2;
                        }
                        z16 = true;
                    } else if (mVar7.f3166a) {
                        mVar7.f3168c = i34;
                        mVar7.f = true;
                        ((LinearLayout.LayoutParams) mVar7).rightMargin = (-i34) / 2;
                        z16 = true;
                    } else {
                        if (i35 != 0) {
                            ((LinearLayout.LayoutParams) mVar7).leftMargin = i34 / 2;
                        }
                        if (i35 != childCount2 - 1) {
                            ((LinearLayout.LayoutParams) mVar7).rightMargin = i34 / 2;
                        }
                    }
                }
            }
            z11 = z16;
        }
        if (z11) {
            for (int i36 = 0; i36 < childCount2; i36++) {
                View childAt4 = getChildAt(i36);
                l.m mVar8 = (l.m) childAt4.getLayoutParams();
                if (mVar8.f) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((mVar8.f3167b * i24) + mVar8.f3168c, 1073741824), childMeasureSpec);
                }
            }
        }
        setMeasuredDimension(i10, mode != 1073741824 ? i6 : i22);
    }

    public void setExpandedActionViewsExclusive(boolean z4) {
        this.f286t.f3143q = z4;
    }

    public void setOnMenuItemClickListener(n nVar) {
        this.f292z = nVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        k kVar = this.f286t;
        j jVar = kVar.f3135i;
        if (jVar != null) {
            jVar.setImageDrawable(drawable);
        } else {
            kVar.f3137k = true;
            kVar.f3136j = drawable;
        }
    }

    public void setOverflowReserved(boolean z4) {
        this.f285s = z4;
    }

    public void setPopupTheme(int i3) {
        if (this.f284r != i3) {
            this.f284r = i3;
            if (i3 == 0) {
                this.f283q = getContext();
            } else {
                this.f283q = new ContextThemeWrapper(getContext(), i3);
            }
        }
    }

    public void setPresenter(k kVar) {
        this.f286t = kVar;
        kVar.f3134h = this;
        this.f282p = kVar.f3130c;
    }

    @Override // l.x1, android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new l.m(getContext(), attributeSet);
    }
}
