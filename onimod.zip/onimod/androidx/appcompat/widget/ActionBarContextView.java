package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import k.a0;
import k.m;
import l.a;
import l.g;
import l.k;
import l.o3;
import o0.h0;
import o0.j0;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContextView extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f238a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Context f239b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ActionMenuView f240c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public k f241d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f242e;
    public j0 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f243g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f244h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public CharSequence f245i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f246j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public View f247k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public View f248l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public View f249m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public LinearLayout f250n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public TextView f251o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public TextView f252p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f253q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f254r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f255s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f256t;

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        int resourceId;
        super(context, attributeSet, R.attr.actionModeStyle);
        this.f238a = new a(this);
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f239b = context;
        } else {
            this.f239b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, d.a.f1597d, R.attr.actionModeStyle, 0);
        setBackground((!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(0) : a3.a.G(context, resourceId));
        this.f253q = typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f254r = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        this.f242e = typedArrayObtainStyledAttributes.getLayoutDimension(3, 0);
        this.f256t = typedArrayObtainStyledAttributes.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static int f(View view, int i3, int i4) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i3, Integer.MIN_VALUE), i4);
        return Math.max(0, i3 - view.getMeasuredWidth());
    }

    public static int g(View view, int i3, int i4, int i5, boolean z4) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i6 = ((i5 - measuredHeight) / 2) + i4;
        if (z4) {
            view.layout(i3 - measuredWidth, i6, i3, measuredHeight + i6);
        } else {
            view.layout(i3, i6, i3 + measuredWidth, measuredHeight + i6);
        }
        return z4 ? -measuredWidth : measuredWidth;
    }

    public final void c(j.a aVar) {
        View view = this.f247k;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.f256t, (ViewGroup) this, false);
            this.f247k = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.f247k);
        }
        View viewFindViewById = this.f247k.findViewById(R.id.action_mode_close_button);
        this.f248l = viewFindViewById;
        viewFindViewById.setOnClickListener(new e.a(1, aVar));
        m mVarC = aVar.c();
        k kVar = this.f241d;
        if (kVar != null) {
            kVar.h();
            g gVar = kVar.f3146t;
            if (gVar != null && gVar.b()) {
                gVar.f2772i.dismiss();
            }
        }
        k kVar2 = new k(getContext());
        this.f241d = kVar2;
        kVar2.f3138l = true;
        kVar2.f3139m = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        mVarC.b(this.f241d, this.f239b);
        k kVar3 = this.f241d;
        a0 a0Var = kVar3.f3134h;
        if (a0Var == null) {
            a0 a0Var2 = (a0) kVar3.f3131d.inflate(kVar3.f, (ViewGroup) this, false);
            kVar3.f3134h = a0Var2;
            a0Var2.b(kVar3.f3130c);
            kVar3.i();
        }
        a0 a0Var3 = kVar3.f3134h;
        if (a0Var != a0Var3) {
            ((ActionMenuView) a0Var3).setPresenter(kVar3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) a0Var3;
        this.f240c = actionMenuView;
        actionMenuView.setBackground(null);
        addView(this.f240c, layoutParams);
    }

    public final void d() {
        if (this.f250n == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f250n = linearLayout;
            this.f251o = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.f252p = (TextView) this.f250n.findViewById(R.id.action_bar_subtitle);
            int i3 = this.f253q;
            if (i3 != 0) {
                this.f251o.setTextAppearance(getContext(), i3);
            }
            int i4 = this.f254r;
            if (i4 != 0) {
                this.f252p.setTextAppearance(getContext(), i4);
            }
        }
        this.f251o.setText(this.f245i);
        this.f252p.setText(this.f246j);
        boolean zIsEmpty = TextUtils.isEmpty(this.f245i);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.f246j);
        this.f252p.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.f250n.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.f250n.getParent() == null) {
            addView(this.f250n);
        }
    }

    public final void e() {
        removeAllViews();
        this.f249m = null;
        this.f240c = null;
        this.f241d = null;
        View view = this.f248l;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        return this.f != null ? this.f238a.f3007b : getVisibility();
    }

    public int getContentHeight() {
        return this.f242e;
    }

    public CharSequence getSubtitle() {
        return this.f246j;
    }

    public CharSequence getTitle() {
        return this.f245i;
    }

    @Override // android.view.View
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public final void setVisibility(int i3) {
        if (i3 != getVisibility()) {
            j0 j0Var = this.f;
            if (j0Var != null) {
                j0Var.b();
            }
            super.setVisibility(i3);
        }
    }

    public final j0 i(int i3, long j4) {
        j0 j0Var = this.f;
        if (j0Var != null) {
            j0Var.b();
        }
        a aVar = this.f238a;
        if (i3 != 0) {
            j0 j0VarA = h0.a(this);
            j0VarA.a(0.0f);
            j0VarA.c(j4);
            aVar.f3008c.f = j0VarA;
            aVar.f3007b = i3;
            j0VarA.d(aVar);
            return j0VarA;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        j0 j0VarA2 = h0.a(this);
        j0VarA2.a(1.0f);
        j0VarA2.c(j4);
        aVar.f3008c.f = j0VarA2;
        aVar.f3007b = i3;
        j0VarA2.d(aVar);
        return j0VarA2;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        int i3;
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, d.a.f1594a, R.attr.actionBarStyle, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(13, 0));
        typedArrayObtainStyledAttributes.recycle();
        k kVar = this.f241d;
        if (kVar != null) {
            Configuration configuration2 = kVar.f3129b.getResources().getConfiguration();
            int i4 = configuration2.screenWidthDp;
            int i5 = configuration2.screenHeightDp;
            if (configuration2.smallestScreenWidthDp > 600 || i4 > 600 || ((i4 > 960 && i5 > 720) || (i4 > 720 && i5 > 960))) {
                i3 = 5;
            } else if (i4 >= 500 || ((i4 > 640 && i5 > 480) || (i4 > 480 && i5 > 640))) {
                i3 = 4;
            } else {
                i3 = i4 >= 360 ? 3 : 2;
            }
            kVar.f3142p = i3;
            m mVar = kVar.f3130c;
            if (mVar != null) {
                mVar.p(true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        k kVar = this.f241d;
        if (kVar != null) {
            kVar.h();
            g gVar = this.f241d.f3146t;
            if (gVar == null || !gVar.b()) {
                return;
            }
            gVar.f2772i.dismiss();
        }
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f244h = false;
        }
        if (!this.f244h) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f244h = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f244h = false;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        boolean z5 = o3.f3193a;
        boolean z6 = getLayoutDirection() == 1;
        int paddingRight = z6 ? (i5 - i3) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i6 - i4) - getPaddingTop()) - getPaddingBottom();
        View view = this.f247k;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f247k.getLayoutParams();
            int i7 = z6 ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i8 = z6 ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i9 = z6 ? paddingRight - i7 : paddingRight + i7;
            int iG = g(this.f247k, i9, paddingTop, paddingTop2, z6) + i9;
            paddingRight = z6 ? iG - i8 : iG + i8;
        }
        LinearLayout linearLayout = this.f250n;
        if (linearLayout != null && this.f249m == null && linearLayout.getVisibility() != 8) {
            paddingRight += g(this.f250n, paddingRight, paddingTop, paddingTop2, z6);
        }
        View view2 = this.f249m;
        if (view2 != null) {
            g(view2, paddingRight, paddingTop, paddingTop2, z6);
        }
        int paddingLeft = z6 ? getPaddingLeft() : (i5 - i3) - getPaddingRight();
        ActionMenuView actionMenuView = this.f240c;
        if (actionMenuView != null) {
            g(actionMenuView, paddingLeft, paddingTop, paddingTop2, !z6);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i3, int i4) {
        if (View.MeasureSpec.getMode(i3) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
        }
        if (View.MeasureSpec.getMode(i4) == 0) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
        }
        int size = View.MeasureSpec.getSize(i3);
        int size2 = this.f242e;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i4);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingBottom;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.f247k;
        if (view != null) {
            int iF = f(view, paddingLeft, iMakeMeasureSpec);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f247k.getLayoutParams();
            paddingLeft = iF - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f240c;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = f(this.f240c, paddingLeft, iMakeMeasureSpec);
        }
        LinearLayout linearLayout = this.f250n;
        if (linearLayout != null && this.f249m == null) {
            if (this.f255s) {
                this.f250n.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f250n.getMeasuredWidth();
                boolean z4 = measuredWidth <= paddingLeft;
                if (z4) {
                    paddingLeft -= measuredWidth;
                }
                this.f250n.setVisibility(z4 ? 0 : 8);
            } else {
                paddingLeft = f(linearLayout, paddingLeft, iMakeMeasureSpec);
            }
        }
        View view2 = this.f249m;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i5 = layoutParams.width;
            int i6 = i5 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i5 >= 0) {
                paddingLeft = Math.min(i5, paddingLeft);
            }
            int i7 = layoutParams.height;
            int i8 = i7 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i7 >= 0) {
                iMin = Math.min(i7, iMin);
            }
            this.f249m.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i6), View.MeasureSpec.makeMeasureSpec(iMin, i8));
        }
        if (this.f242e > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i9 = 0;
        for (int i10 = 0; i10 < childCount; i10++) {
            int measuredHeight = getChildAt(i10).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i9) {
                i9 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i9);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f243g = false;
        }
        if (!this.f243g) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f243g = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f243g = false;
        return true;
    }

    public void setContentHeight(int i3) {
        this.f242e = i3;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f249m;
        if (view2 != null) {
            removeView(view2);
        }
        this.f249m = view;
        if (view != null && (linearLayout = this.f250n) != null) {
            removeView(linearLayout);
            this.f250n = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f246j = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.f245i = charSequence;
        d();
        h0.q(this, charSequence);
    }

    public void setTitleOptional(boolean z4) {
        if (z4 != this.f255s) {
            requestLayout();
        }
        this.f255s = z4;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
