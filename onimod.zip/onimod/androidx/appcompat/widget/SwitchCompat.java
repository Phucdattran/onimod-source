package androidx.appcompat.widget;

import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import androidx.emoji2.text.m;
import c0.g;
import i.a;
import i1.b;
import java.util.WeakHashMap;
import l.m1;
import l.o3;
import l.t2;
import l.u2;
import l.v;
import l.w0;
import o0.h0;
import o0.u;

/* JADX INFO: loaded from: classes.dex */
public class SwitchCompat extends CompoundButton {
    public static final b R = new b(Float.class, "thumbPos", 7);
    public static final int[] S = {R.attr.state_checked};
    public int A;
    public int B;
    public int C;
    public int D;
    public int E;
    public int F;
    public int G;
    public boolean H;
    public final TextPaint I;
    public final ColorStateList J;
    public StaticLayout K;
    public StaticLayout L;
    public final a M;
    public ObjectAnimator N;
    public v O;
    public t2 P;
    public final Rect Q;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Drawable f314a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ColorStateList f315b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public PorterDuff.Mode f316c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f317d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f318e;
    public Drawable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f319g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f320h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f321i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f322j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f323k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f324l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f325m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f326n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public CharSequence f327o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public CharSequence f328p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public CharSequence f329q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public CharSequence f330r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f331s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f332t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final int f333u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public float f334v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public float f335w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final VelocityTracker f336x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f337y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public float f338z;

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private v getEmojiTextViewHelper() {
        if (this.O == null) {
            this.O = new v(this);
        }
        return this.O;
    }

    private boolean getTargetCheckedState() {
        return this.f338z > 0.5f;
    }

    private int getThumbOffset() {
        boolean z4 = o3.f3193a;
        return (int) (((getLayoutDirection() == 1 ? 1.0f - this.f338z : this.f338z) * getThumbScrollRange()) + 0.5f);
    }

    private int getThumbScrollRange() {
        Drawable drawable = this.f;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.Q;
        drawable.getPadding(rect);
        Drawable drawable2 = this.f314a;
        Rect rectB = drawable2 != null ? m1.b(drawable2) : m1.f3173c;
        return ((((this.A - this.C) - rect.left) - rect.right) - rectB.left) - rectB.right;
    }

    private void setTextOffInternal(CharSequence charSequence) {
        this.f329q = charSequence;
        TransformationMethod transformationMethodQ0 = ((q1.b) getEmojiTextViewHelper().f3261b.f4705a).q0(this.M);
        if (transformationMethodQ0 != null) {
            charSequence = transformationMethodQ0.getTransformation(charSequence, this);
        }
        this.f330r = charSequence;
        this.L = null;
        if (this.f331s) {
            d();
        }
    }

    private void setTextOnInternal(CharSequence charSequence) {
        this.f327o = charSequence;
        TransformationMethod transformationMethodQ0 = ((q1.b) getEmojiTextViewHelper().f3261b.f4705a).q0(this.M);
        if (transformationMethodQ0 != null) {
            charSequence = transformationMethodQ0.getTransformation(charSequence, this);
        }
        this.f328p = charSequence;
        this.K = null;
        if (this.f331s) {
            d();
        }
    }

    public final void a() {
        Drawable drawable = this.f314a;
        if (drawable != null) {
            if (this.f317d || this.f318e) {
                Drawable drawableMutate = a3.a.k0(drawable).mutate();
                this.f314a = drawableMutate;
                if (this.f317d) {
                    drawableMutate.setTintList(this.f315b);
                }
                if (this.f318e) {
                    this.f314a.setTintMode(this.f316c);
                }
                if (this.f314a.isStateful()) {
                    this.f314a.setState(getDrawableState());
                }
            }
        }
    }

    public final void b() {
        Drawable drawable = this.f;
        if (drawable != null) {
            if (this.f321i || this.f322j) {
                Drawable drawableMutate = a3.a.k0(drawable).mutate();
                this.f = drawableMutate;
                if (this.f321i) {
                    drawableMutate.setTintList(this.f319g);
                }
                if (this.f322j) {
                    this.f.setTintMode(this.f320h);
                }
                if (this.f.isStateful()) {
                    this.f.setState(getDrawableState());
                }
            }
        }
    }

    public final void c() {
        setTextOnInternal(this.f327o);
        setTextOffInternal(this.f329q);
        requestLayout();
    }

    public final void d() {
        if (this.P == null && ((q1.b) this.O.f3261b.f4705a).G() && m.f539k != null) {
            m mVarA = m.a();
            int iB = mVarA.b();
            if (iB == 3 || iB == 0) {
                t2 t2Var = new t2(this);
                this.P = t2Var;
                mVarA.f(t2Var);
            }
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i3;
        int i4;
        int i5 = this.D;
        int i6 = this.E;
        int i7 = this.F;
        int i8 = this.G;
        int thumbOffset = getThumbOffset() + i5;
        Drawable drawable = this.f314a;
        Rect rectB = drawable != null ? m1.b(drawable) : m1.f3173c;
        Drawable drawable2 = this.f;
        Rect rect = this.Q;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            int i9 = rect.left;
            thumbOffset += i9;
            if (rectB != null) {
                int i10 = rectB.left;
                if (i10 > i9) {
                    i5 += i10 - i9;
                }
                int i11 = rectB.top;
                int i12 = rect.top;
                i3 = i11 > i12 ? (i11 - i12) + i6 : i6;
                int i13 = rectB.right;
                int i14 = rect.right;
                if (i13 > i14) {
                    i7 -= i13 - i14;
                }
                int i15 = rectB.bottom;
                int i16 = rect.bottom;
                if (i15 > i16) {
                    i4 = i8 - (i15 - i16);
                }
                this.f.setBounds(i5, i3, i7, i4);
            } else {
                i3 = i6;
            }
            i4 = i8;
            this.f.setBounds(i5, i3, i7, i4);
        }
        Drawable drawable3 = this.f314a;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            int i17 = thumbOffset - rect.left;
            int i18 = thumbOffset + this.C + rect.right;
            this.f314a.setBounds(i17, i6, i18, i8);
            Drawable background = getBackground();
            if (background != null) {
                background.setHotspotBounds(i17, i6, i18, i8);
            }
        }
        super.draw(canvas);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableHotspotChanged(float f, float f4) {
        super.drawableHotspotChanged(f, f4);
        Drawable drawable = this.f314a;
        if (drawable != null) {
            drawable.setHotspot(f, f4);
        }
        Drawable drawable2 = this.f;
        if (drawable2 != null) {
            drawable2.setHotspot(f, f4);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f314a;
        boolean state = (drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState);
        Drawable drawable2 = this.f;
        if (drawable2 != null && drawable2.isStateful()) {
            state |= drawable2.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        boolean z4 = o3.f3193a;
        if (getLayoutDirection() != 1) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.A;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.f325m : compoundPaddingLeft;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingRight() {
        boolean z4 = o3.f3193a;
        if (getLayoutDirection() == 1) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.A;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.f325m : compoundPaddingRight;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return q1.b.n0(super.getCustomSelectionActionModeCallback());
    }

    public boolean getShowText() {
        return this.f331s;
    }

    public boolean getSplitTrack() {
        return this.f326n;
    }

    public int getSwitchMinWidth() {
        return this.f324l;
    }

    public int getSwitchPadding() {
        return this.f325m;
    }

    public CharSequence getTextOff() {
        return this.f329q;
    }

    public CharSequence getTextOn() {
        return this.f327o;
    }

    public Drawable getThumbDrawable() {
        return this.f314a;
    }

    public final float getThumbPosition() {
        return this.f338z;
    }

    public int getThumbTextPadding() {
        return this.f323k;
    }

    public ColorStateList getThumbTintList() {
        return this.f315b;
    }

    public PorterDuff.Mode getThumbTintMode() {
        return this.f316c;
    }

    public Drawable getTrackDrawable() {
        return this.f;
    }

    public ColorStateList getTrackTintList() {
        return this.f319g;
    }

    public PorterDuff.Mode getTrackTintMode() {
        return this.f320h;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f314a;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.N;
        if (objectAnimator == null || !objectAnimator.isStarted()) {
            return;
        }
        this.N.end();
        this.N = null;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final int[] onCreateDrawableState(int i3) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i3 + 1);
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, S);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void onDraw(Canvas canvas) {
        int width;
        super.onDraw(canvas);
        Drawable drawable = this.f;
        Rect rect = this.Q;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i3 = this.E;
        int i4 = this.G;
        int i5 = i3 + rect.top;
        int i6 = i4 - rect.bottom;
        Drawable drawable2 = this.f314a;
        if (drawable != null) {
            if (!this.f326n || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect rectB = m1.b(drawable2);
                drawable2.copyBounds(rect);
                rect.left += rectB.left;
                rect.right -= rectB.right;
                int iSave = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(iSave);
            }
        }
        int iSave2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        StaticLayout staticLayout = getTargetCheckedState() ? this.K : this.L;
        if (staticLayout != null) {
            int[] drawableState = getDrawableState();
            TextPaint textPaint = this.I;
            ColorStateList colorStateList = this.J;
            if (colorStateList != null) {
                textPaint.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            textPaint.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                width = bounds.left + bounds.right;
            } else {
                width = getWidth();
            }
            canvas.translate((width / 2) - (staticLayout.getWidth() / 2), ((i5 + i6) / 2) - (staticLayout.getHeight() / 2));
            staticLayout.draw(canvas);
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        if (Build.VERSION.SDK_INT < 30) {
            CharSequence charSequence = isChecked() ? this.f327o : this.f329q;
            if (TextUtils.isEmpty(charSequence)) {
                return;
            }
            CharSequence text = accessibilityNodeInfo.getText();
            if (TextUtils.isEmpty(text)) {
                accessibilityNodeInfo.setText(charSequence);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(text);
            sb.append(' ');
            sb.append(charSequence);
            accessibilityNodeInfo.setText(sb);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        int iMax;
        int width;
        int paddingLeft;
        int height;
        int paddingTop;
        super.onLayout(z4, i3, i4, i5, i6);
        int iMax2 = 0;
        if (this.f314a != null) {
            Drawable drawable = this.f;
            Rect rect = this.Q;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect rectB = m1.b(this.f314a);
            iMax = Math.max(0, rectB.left - rect.left);
            iMax2 = Math.max(0, rectB.right - rect.right);
        } else {
            iMax = 0;
        }
        boolean z5 = o3.f3193a;
        if (getLayoutDirection() == 1) {
            paddingLeft = getPaddingLeft() + iMax;
            width = ((this.A + paddingLeft) - iMax) - iMax2;
        } else {
            width = (getWidth() - getPaddingRight()) - iMax2;
            paddingLeft = (width - this.A) + iMax + iMax2;
        }
        int gravity = getGravity() & 112;
        if (gravity == 16) {
            int height2 = ((getHeight() + getPaddingTop()) - getPaddingBottom()) / 2;
            int i7 = this.B;
            int i8 = height2 - (i7 / 2);
            height = i7 + i8;
            paddingTop = i8;
        } else if (gravity != 80) {
            paddingTop = getPaddingTop();
            height = this.B + paddingTop;
        } else {
            height = getHeight() - getPaddingBottom();
            paddingTop = height - this.B;
        }
        this.D = paddingLeft;
        this.E = paddingTop;
        this.G = height;
        this.F = width;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onMeasure(int i3, int i4) {
        int intrinsicWidth;
        int intrinsicHeight;
        int iMax;
        int intrinsicHeight2 = 0;
        if (this.f331s) {
            StaticLayout staticLayout = this.K;
            TextPaint textPaint = this.I;
            if (staticLayout == null) {
                CharSequence charSequence = this.f328p;
                this.K = new StaticLayout(charSequence, textPaint, charSequence != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            }
            if (this.L == null) {
                CharSequence charSequence2 = this.f330r;
                this.L = new StaticLayout(charSequence2, textPaint, charSequence2 != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence2, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            }
        }
        Drawable drawable = this.f314a;
        Rect rect = this.Q;
        if (drawable != null) {
            drawable.getPadding(rect);
            intrinsicWidth = (this.f314a.getIntrinsicWidth() - rect.left) - rect.right;
            intrinsicHeight = this.f314a.getIntrinsicHeight();
        } else {
            intrinsicWidth = 0;
            intrinsicHeight = 0;
        }
        if (this.f331s) {
            iMax = (this.f323k * 2) + Math.max(this.K.getWidth(), this.L.getWidth());
        } else {
            iMax = 0;
        }
        this.C = Math.max(iMax, intrinsicWidth);
        Drawable drawable2 = this.f;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            intrinsicHeight2 = this.f.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int iMax2 = rect.left;
        int iMax3 = rect.right;
        Drawable drawable3 = this.f314a;
        if (drawable3 != null) {
            Rect rectB = m1.b(drawable3);
            iMax2 = Math.max(iMax2, rectB.left);
            iMax3 = Math.max(iMax3, rectB.right);
        }
        int iMax4 = this.H ? Math.max(this.f324l, (this.C * 2) + iMax2 + iMax3) : this.f324l;
        int iMax5 = Math.max(intrinsicHeight2, intrinsicHeight);
        this.A = iMax4;
        this.B = iMax5;
        super.onMeasure(i3, i4);
        if (getMeasuredHeight() < iMax5) {
            setMeasuredDimension(getMeasuredWidthAndState(), iMax5);
        }
    }

    @Override // android.view.View
    public final void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.f327o : this.f329q;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARN: Code duplicated, block: B:40:0x0091  */
    /* JADX WARN: Code duplicated, block: B:42:0x0096  */
    /* JADX WARN: Code duplicated, block: B:47:0x00a6  */
    /* JADX WARN: Code duplicated, block: B:50:0x00ad  */
    /* JADX WARN: Code duplicated, block: B:52:0x00c1  */
    /* JADX WARN: Code duplicated, block: B:61:0x00d6  */
    /* JADX WARN: Code duplicated, block: B:62:0x00db  */
    /* JADX WARN: Code duplicated, block: B:64:0x00de  */
    /* JADX WARN: Code duplicated, block: B:67:0x00f5  */
    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z4;
        boolean zIsChecked;
        boolean targetCheckedState;
        float xVelocity;
        float f;
        VelocityTracker velocityTracker = this.f336x;
        velocityTracker.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int i3 = this.f333u;
        if (actionMasked != 0) {
            float f4 = 0.0f;
            if (actionMasked == 1) {
                if (this.f332t == 2) {
                    this.f332t = 0;
                    if (motionEvent.getAction() == 1 || !isEnabled()) {
                        z4 = false;
                    } else {
                        z4 = true;
                    }
                    zIsChecked = isChecked();
                    if (z4) {
                        velocityTracker.computeCurrentVelocity(1000);
                        xVelocity = velocityTracker.getXVelocity();
                        if (Math.abs(xVelocity) > this.f337y) {
                            boolean z5 = o3.f3193a;
                            targetCheckedState = getLayoutDirection() == 1 ? xVelocity > 0.0f : xVelocity < 0.0f;
                        } else {
                            targetCheckedState = getTargetCheckedState();
                        }
                    } else {
                        targetCheckedState = zIsChecked;
                    }
                    if (targetCheckedState != zIsChecked) {
                        playSoundEffect(0);
                    }
                    setChecked(targetCheckedState);
                    MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                    motionEventObtain.setAction(3);
                    super.onTouchEvent(motionEventObtain);
                    motionEventObtain.recycle();
                    super.onTouchEvent(motionEvent);
                    return true;
                }
                this.f332t = 0;
                velocityTracker.clear();
            } else if (actionMasked == 2) {
                int i4 = this.f332t;
                if (i4 == 1) {
                    float x3 = motionEvent.getX();
                    float y4 = motionEvent.getY();
                    float f5 = i3;
                    if (Math.abs(x3 - this.f334v) > f5 || Math.abs(y4 - this.f335w) > f5) {
                        this.f332t = 2;
                        getParent().requestDisallowInterceptTouchEvent(true);
                        this.f334v = x3;
                        this.f335w = y4;
                        return true;
                    }
                } else if (i4 == 2) {
                    float x4 = motionEvent.getX();
                    int thumbScrollRange = getThumbScrollRange();
                    float f6 = x4 - this.f334v;
                    if (thumbScrollRange != 0) {
                        f = f6 / thumbScrollRange;
                    } else {
                        f = f6 > 0.0f ? 1.0f : -1.0f;
                    }
                    boolean z6 = o3.f3193a;
                    if (getLayoutDirection() == 1) {
                        f = -f;
                    }
                    float f7 = this.f338z;
                    float f8 = f + f7;
                    if (f8 >= 0.0f) {
                        f4 = f8 > 1.0f ? 1.0f : f8;
                    }
                    if (f4 != f7) {
                        this.f334v = x4;
                        setThumbPosition(f4);
                    }
                    return true;
                }
            } else if (actionMasked == 3) {
                if (this.f332t == 2) {
                    this.f332t = 0;
                    if (motionEvent.getAction() == 1) {
                        z4 = false;
                    } else {
                        z4 = false;
                    }
                    zIsChecked = isChecked();
                    if (z4) {
                        velocityTracker.computeCurrentVelocity(1000);
                        xVelocity = velocityTracker.getXVelocity();
                        if (Math.abs(xVelocity) > this.f337y) {
                            boolean z7 = o3.f3193a;
                            if (getLayoutDirection() == 1) {
                            }
                        } else {
                            targetCheckedState = getTargetCheckedState();
                        }
                    } else {
                        targetCheckedState = zIsChecked;
                    }
                    if (targetCheckedState != zIsChecked) {
                        playSoundEffect(0);
                    }
                    setChecked(targetCheckedState);
                    MotionEvent motionEventObtain2 = MotionEvent.obtain(motionEvent);
                    motionEventObtain2.setAction(3);
                    super.onTouchEvent(motionEventObtain2);
                    motionEventObtain2.recycle();
                    super.onTouchEvent(motionEvent);
                    return true;
                }
                this.f332t = 0;
                velocityTracker.clear();
            }
        } else {
            float x5 = motionEvent.getX();
            float y5 = motionEvent.getY();
            if (isEnabled() && this.f314a != null) {
                int thumbOffset = getThumbOffset();
                Drawable drawable = this.f314a;
                Rect rect = this.Q;
                drawable.getPadding(rect);
                int i5 = this.E - i3;
                int i6 = (this.D + thumbOffset) - i3;
                int i7 = this.C + i6 + rect.left + rect.right + i3;
                int i8 = this.G + i3;
                if (x5 > i6 && x5 < i7 && y5 > i5 && y5 < i8) {
                    this.f332t = 1;
                    this.f334v = x5;
                    this.f335w = y5;
                }
            }
        }
        return super.onTouchEvent(motionEvent);
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z4) {
        super.setAllCaps(z4);
        getEmojiTextViewHelper().c(z4);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z4) {
        super.setChecked(z4);
        boolean zIsChecked = isChecked();
        if (zIsChecked) {
            if (Build.VERSION.SDK_INT >= 30) {
                Object string = this.f327o;
                if (string == null) {
                    string = getResources().getString(top.niunaijun.blackbox.R.string.abc_capital_on);
                }
                Object obj = string;
                WeakHashMap weakHashMap = h0.f3558a;
                new u(top.niunaijun.blackbox.R.id.tag_state_description, CharSequence.class, 64, 30, 2).d(this, obj);
            }
        } else if (Build.VERSION.SDK_INT >= 30) {
            Object string2 = this.f329q;
            if (string2 == null) {
                string2 = getResources().getString(top.niunaijun.blackbox.R.string.abc_capital_off);
            }
            Object obj2 = string2;
            WeakHashMap weakHashMap2 = h0.f3558a;
            new u(top.niunaijun.blackbox.R.id.tag_state_description, CharSequence.class, 64, 30, 2).d(this, obj2);
        }
        if (getWindowToken() == null || !isLaidOut()) {
            ObjectAnimator objectAnimator = this.N;
            if (objectAnimator != null) {
                objectAnimator.cancel();
            }
            setThumbPosition(zIsChecked ? 1.0f : 0.0f);
            return;
        }
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, R, zIsChecked ? 1.0f : 0.0f);
        this.N = objectAnimatorOfFloat;
        objectAnimatorOfFloat.setDuration(250L);
        this.N.setAutoCancel(true);
        this.N.start();
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(q1.b.p0(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        getEmojiTextViewHelper().d(z4);
        setTextOnInternal(this.f327o);
        setTextOffInternal(this.f329q);
        requestLayout();
    }

    public final void setEnforceSwitchWidth(boolean z4) {
        this.H = z4;
        invalidate();
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setShowText(boolean z4) {
        if (this.f331s != z4) {
            this.f331s = z4;
            requestLayout();
            if (z4) {
                d();
            }
        }
    }

    public void setSplitTrack(boolean z4) {
        this.f326n = z4;
        invalidate();
    }

    public void setSwitchMinWidth(int i3) {
        this.f324l = i3;
        requestLayout();
    }

    public void setSwitchPadding(int i3) {
        this.f325m = i3;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        TextPaint textPaint = this.I;
        if ((textPaint.getTypeface() == null || textPaint.getTypeface().equals(typeface)) && (textPaint.getTypeface() != null || typeface == null)) {
            return;
        }
        textPaint.setTypeface(typeface);
        requestLayout();
        invalidate();
    }

    public void setTextOff(CharSequence charSequence) {
        setTextOffInternal(charSequence);
        requestLayout();
        if (isChecked() || Build.VERSION.SDK_INT < 30) {
            return;
        }
        Object string = this.f329q;
        if (string == null) {
            string = getResources().getString(top.niunaijun.blackbox.R.string.abc_capital_off);
        }
        WeakHashMap weakHashMap = h0.f3558a;
        new u(top.niunaijun.blackbox.R.id.tag_state_description, CharSequence.class, 64, 30, 2).d(this, string);
    }

    public void setTextOn(CharSequence charSequence) {
        setTextOnInternal(charSequence);
        requestLayout();
        if (!isChecked() || Build.VERSION.SDK_INT < 30) {
            return;
        }
        Object string = this.f327o;
        if (string == null) {
            string = getResources().getString(top.niunaijun.blackbox.R.string.abc_capital_on);
        }
        WeakHashMap weakHashMap = h0.f3558a;
        new u(top.niunaijun.blackbox.R.id.tag_state_description, CharSequence.class, 64, 30, 2).d(this, string);
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.f314a;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f314a = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setThumbPosition(float f) {
        this.f338z = f;
        invalidate();
    }

    public void setThumbResource(int i3) {
        setThumbDrawable(a3.a.G(getContext(), i3));
    }

    public void setThumbTextPadding(int i3) {
        this.f323k = i3;
        requestLayout();
    }

    public void setThumbTintList(ColorStateList colorStateList) {
        this.f315b = colorStateList;
        this.f317d = true;
        a();
    }

    public void setThumbTintMode(PorterDuff.Mode mode) {
        this.f316c = mode;
        this.f318e = true;
        a();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.f;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i3) {
        setTrackDrawable(a3.a.G(getContext(), i3));
    }

    public void setTrackTintList(ColorStateList colorStateList) {
        this.f319g = colorStateList;
        this.f321i = true;
        b();
    }

    public void setTrackTintMode(PorterDuff.Mode mode) {
        this.f320h = mode;
        this.f322j = true;
        b();
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public final void toggle() {
        setChecked(!isChecked());
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f314a || drawable == this.f;
    }

    public SwitchCompat(Context context, AttributeSet attributeSet, int i3) {
        Typeface typeface;
        int resourceId;
        super(context, attributeSet, top.niunaijun.blackbox.R.attr.switchStyle);
        this.f315b = null;
        this.f316c = null;
        this.f317d = false;
        this.f318e = false;
        this.f319g = null;
        this.f320h = null;
        this.f321i = false;
        this.f322j = false;
        this.f336x = VelocityTracker.obtain();
        this.H = true;
        this.Q = new Rect();
        u2.a(getContext(), this);
        TextPaint textPaint = new TextPaint(1);
        this.I = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        int[] iArr = d.a.f1614v;
        androidx.emoji2.text.u uVarX = androidx.emoji2.text.u.x(context, attributeSet, iArr, top.niunaijun.blackbox.R.attr.switchStyle);
        TypedArray typedArray = (TypedArray) uVarX.f563c;
        h0.o(this, context, iArr, attributeSet, typedArray, top.niunaijun.blackbox.R.attr.switchStyle);
        Drawable drawableO = uVarX.o(2);
        this.f314a = drawableO;
        if (drawableO != null) {
            drawableO.setCallback(this);
        }
        Drawable drawableO2 = uVarX.o(11);
        this.f = drawableO2;
        if (drawableO2 != null) {
            drawableO2.setCallback(this);
        }
        setTextOnInternal(typedArray.getText(0));
        setTextOffInternal(typedArray.getText(1));
        this.f331s = typedArray.getBoolean(3, true);
        this.f323k = typedArray.getDimensionPixelSize(8, 0);
        this.f324l = typedArray.getDimensionPixelSize(5, 0);
        this.f325m = typedArray.getDimensionPixelSize(6, 0);
        this.f326n = typedArray.getBoolean(4, false);
        ColorStateList colorStateListN = uVarX.n(9);
        if (colorStateListN != null) {
            this.f315b = colorStateListN;
            this.f317d = true;
        }
        PorterDuff.Mode modeC = m1.c(typedArray.getInt(10, -1), null);
        if (this.f316c != modeC) {
            this.f316c = modeC;
            this.f318e = true;
        }
        if (this.f317d || this.f318e) {
            a();
        }
        ColorStateList colorStateListN2 = uVarX.n(12);
        if (colorStateListN2 != null) {
            this.f319g = colorStateListN2;
            this.f321i = true;
        }
        PorterDuff.Mode modeC2 = m1.c(typedArray.getInt(13, -1), null);
        if (this.f320h != modeC2) {
            this.f320h = modeC2;
            this.f322j = true;
        }
        if (this.f321i || this.f322j) {
            b();
        }
        int resourceId2 = typedArray.getResourceId(7, 0);
        if (resourceId2 != 0) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(resourceId2, d.a.f1615w);
            ColorStateList colorStateList = (!typedArrayObtainStyledAttributes.hasValue(3) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(3, 0)) == 0 || (colorStateList = g.c(context, resourceId)) == null) ? typedArrayObtainStyledAttributes.getColorStateList(3) : colorStateList;
            if (colorStateList != null) {
                this.J = colorStateList;
            } else {
                this.J = getTextColors();
            }
            int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
            if (dimensionPixelSize != 0) {
                float f = dimensionPixelSize;
                if (f != textPaint.getTextSize()) {
                    textPaint.setTextSize(f);
                    requestLayout();
                }
            }
            int i4 = typedArrayObtainStyledAttributes.getInt(1, -1);
            int i5 = typedArrayObtainStyledAttributes.getInt(2, -1);
            if (i4 == 1) {
                typeface = Typeface.SANS_SERIF;
            } else if (i4 != 2) {
                typeface = i4 != 3 ? null : Typeface.MONOSPACE;
            } else {
                typeface = Typeface.SERIF;
            }
            if (i5 > 0) {
                Typeface typefaceDefaultFromStyle = typeface == null ? Typeface.defaultFromStyle(i5) : Typeface.create(typeface, i5);
                setSwitchTypeface(typefaceDefaultFromStyle);
                int i6 = (~(typefaceDefaultFromStyle != null ? typefaceDefaultFromStyle.getStyle() : 0)) & i5;
                textPaint.setFakeBoldText((i6 & 1) != 0);
                textPaint.setTextSkewX((2 & i6) != 0 ? -0.25f : 0.0f);
            } else {
                textPaint.setFakeBoldText(false);
                textPaint.setTextSkewX(0.0f);
                setSwitchTypeface(typeface);
            }
            if (typedArrayObtainStyledAttributes.getBoolean(14, false)) {
                Context context2 = getContext();
                a aVar = new a();
                aVar.f2388a = context2.getResources().getConfiguration().locale;
                this.M = aVar;
            } else {
                this.M = null;
            }
            setTextOnInternal(this.f327o);
            setTextOffInternal(this.f329q);
            typedArrayObtainStyledAttributes.recycle();
        }
        new w0(this).f(attributeSet, top.niunaijun.blackbox.R.attr.switchStyle);
        uVarX.z();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f333u = viewConfiguration.getScaledTouchSlop();
        this.f337y = viewConfiguration.getScaledMinimumFlingVelocity();
        getEmojiTextViewHelper().b(attributeSet, top.niunaijun.blackbox.R.attr.switchStyle);
        refreshDrawableState();
        setChecked(isChecked());
    }
}
