package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import e.f0;
import e.v;
import k.m;
import l.g;
import l.g3;
import l.h1;
import l.i1;
import l.k;
import o0.j0;

/* JADX INFO: loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public TypedValue f305a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public TypedValue f306b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public TypedValue f307c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TypedValue f308d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public TypedValue f309e;
    public TypedValue f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Rect f310g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public h1 f311h;

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f310g = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f309e == null) {
            this.f309e = new TypedValue();
        }
        return this.f309e;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f == null) {
            this.f = new TypedValue();
        }
        return this.f;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f307c == null) {
            this.f307c = new TypedValue();
        }
        return this.f307c;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f308d == null) {
            this.f308d = new TypedValue();
        }
        return this.f308d;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f305a == null) {
            this.f305a = new TypedValue();
        }
        return this.f305a;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f306b == null) {
            this.f306b = new TypedValue();
        }
        return this.f306b;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        h1 h1Var = this.f311h;
        if (h1Var != null) {
            h1Var.getClass();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        k kVar;
        super.onDetachedFromWindow();
        h1 h1Var = this.f311h;
        if (h1Var != null) {
            f0 f0Var = ((v) h1Var).f1805b;
            i1 i1Var = f0Var.f1693r;
            if (i1Var != null) {
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) i1Var;
                actionBarOverlayLayout.k();
                ActionMenuView actionMenuView = ((g3) actionBarOverlayLayout.f261e).f3087a.f339a;
                if (actionMenuView != null && (kVar = actionMenuView.f286t) != null) {
                    kVar.h();
                    g gVar = kVar.f3146t;
                    if (gVar != null && gVar.b()) {
                        gVar.f2772i.dismiss();
                    }
                }
            }
            if (f0Var.f1698w != null) {
                f0Var.f1687l.getDecorView().removeCallbacks(f0Var.f1699x);
                if (f0Var.f1698w.isShowing()) {
                    try {
                        f0Var.f1698w.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                f0Var.f1698w = null;
            }
            j0 j0Var = f0Var.f1700y;
            if (j0Var != null) {
                j0Var.b();
            }
            m mVar = f0Var.y(0).f1664h;
            if (mVar != null) {
                mVar.c(true);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x004e  */
    /* JADX WARN: Code duplicated, block: B:22:0x0062  */
    /* JADX WARN: Code duplicated, block: B:37:0x008a  */
    /* JADX WARN: Code duplicated, block: B:38:0x009d  */
    /* JADX WARN: Code duplicated, block: B:55:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:57:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:58:0x00de  */
    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i3, int i4) {
        int iMakeMeasureSpec;
        boolean z4;
        int iMakeMeasureSpec2;
        int i5;
        int i6;
        float fraction;
        int i7;
        int i8;
        float fraction2;
        int i9;
        int i10;
        float fraction3;
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        boolean z5 = true;
        boolean z6 = displayMetrics.widthPixels < displayMetrics.heightPixels;
        int mode = View.MeasureSpec.getMode(i3);
        int mode2 = View.MeasureSpec.getMode(i4);
        Rect rect = this.f310g;
        if (mode != Integer.MIN_VALUE) {
            iMakeMeasureSpec = i3;
            z4 = false;
        } else {
            TypedValue typedValue = z6 ? this.f308d : this.f307c;
            if (typedValue == null || (i9 = typedValue.type) == 0) {
                iMakeMeasureSpec = i3;
                z4 = false;
            } else {
                if (i9 == 5) {
                    fraction3 = typedValue.getDimension(displayMetrics);
                } else {
                    if (i9 == 6) {
                        int i11 = displayMetrics.widthPixels;
                        fraction3 = typedValue.getFraction(i11, i11);
                    } else {
                        i10 = 0;
                    }
                    if (i10 > 0) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i10 - (rect.left + rect.right), View.MeasureSpec.getSize(i3)), 1073741824);
                        z4 = true;
                    } else {
                        iMakeMeasureSpec = i3;
                        z4 = false;
                    }
                }
                i10 = (int) fraction3;
                if (i10 > 0) {
                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i10 - (rect.left + rect.right), View.MeasureSpec.getSize(i3)), 1073741824);
                    z4 = true;
                } else {
                    iMakeMeasureSpec = i3;
                    z4 = false;
                }
            }
        }
        if (mode2 != Integer.MIN_VALUE) {
            iMakeMeasureSpec2 = i4;
        } else {
            TypedValue typedValue2 = z6 ? this.f309e : this.f;
            if (typedValue2 == null || (i7 = typedValue2.type) == 0) {
                iMakeMeasureSpec2 = i4;
            } else {
                if (i7 == 5) {
                    fraction2 = typedValue2.getDimension(displayMetrics);
                } else {
                    if (i7 == 6) {
                        int i12 = displayMetrics.heightPixels;
                        fraction2 = typedValue2.getFraction(i12, i12);
                    } else {
                        i8 = 0;
                    }
                    if (i8 > 0) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i8 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i4)), 1073741824);
                    } else {
                        iMakeMeasureSpec2 = i4;
                    }
                }
                i8 = (int) fraction2;
                if (i8 > 0) {
                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i8 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i4)), 1073741824);
                } else {
                    iMakeMeasureSpec2 = i4;
                }
            }
        }
        super.onMeasure(iMakeMeasureSpec, iMakeMeasureSpec2);
        int measuredWidth = getMeasuredWidth();
        int iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredWidth, 1073741824);
        if (z4 || mode != Integer.MIN_VALUE) {
            z5 = false;
        } else {
            TypedValue typedValue3 = z6 ? this.f306b : this.f305a;
            if (typedValue3 == null || (i5 = typedValue3.type) == 0) {
                z5 = false;
            } else {
                if (i5 == 5) {
                    fraction = typedValue3.getDimension(displayMetrics);
                } else {
                    if (i5 == 6) {
                        int i13 = displayMetrics.widthPixels;
                        fraction = typedValue3.getFraction(i13, i13);
                    } else {
                        i6 = 0;
                    }
                    if (i6 > 0) {
                        i6 -= rect.left + rect.right;
                    }
                    if (measuredWidth < i6) {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
                    } else {
                        z5 = false;
                    }
                }
                i6 = (int) fraction;
                if (i6 > 0) {
                    i6 -= rect.left + rect.right;
                }
                if (measuredWidth < i6) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
                } else {
                    z5 = false;
                }
            }
        }
        if (z5) {
            super.onMeasure(iMakeMeasureSpec3, iMakeMeasureSpec2);
        }
    }

    public void setAttachListener(h1 h1Var) {
        this.f311h = h1Var;
    }
}
