package androidx.appcompat.widget;

import a3.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.RadioButton;
import e1.b;
import f1.d;
import l.u2;
import l.v;
import l.v2;
import l.w0;
import r0.j;
import r0.k;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatRadioButton extends RadioButton implements j, k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d f298a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final b f299b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final w0 f300c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public v f301d;

    public AppCompatRadioButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private v getEmojiTextViewHelper() {
        if (this.f301d == null) {
            this.f301d = new v(this);
        }
        return this.f301d;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        b bVar = this.f299b;
        if (bVar != null) {
            bVar.a();
        }
        w0 w0Var = this.f300c;
        if (w0Var != null) {
            w0Var.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        b bVar = this.f299b;
        if (bVar != null) {
            return bVar.h();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        b bVar = this.f299b;
        if (bVar != null) {
            return bVar.i();
        }
        return null;
    }

    @Override // r0.j
    public ColorStateList getSupportButtonTintList() {
        d dVar = this.f298a;
        if (dVar != null) {
            return (ColorStateList) dVar.f2231e;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        d dVar = this.f298a;
        if (dVar != null) {
            return (PorterDuff.Mode) dVar.f;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f300c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f300c.e();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z4) {
        super.setAllCaps(z4);
        getEmojiTextViewHelper().c(z4);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        b bVar = this.f299b;
        if (bVar != null) {
            bVar.m();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i3) {
        super.setBackgroundResource(i3);
        b bVar = this.f299b;
        if (bVar != null) {
            bVar.n(i3);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        d dVar = this.f298a;
        if (dVar != null) {
            if (dVar.f2229c) {
                dVar.f2229c = false;
            } else {
                dVar.f2229c = true;
                dVar.a();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        w0 w0Var = this.f300c;
        if (w0Var != null) {
            w0Var.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        w0 w0Var = this.f300c;
        if (w0Var != null) {
            w0Var.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z4) {
        getEmojiTextViewHelper().d(z4);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        b bVar = this.f299b;
        if (bVar != null) {
            bVar.s(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        b bVar = this.f299b;
        if (bVar != null) {
            bVar.t(mode);
        }
    }

    @Override // r0.j
    public void setSupportButtonTintList(ColorStateList colorStateList) {
        d dVar = this.f298a;
        if (dVar != null) {
            dVar.f2231e = colorStateList;
            dVar.f2227a = true;
            dVar.a();
        }
    }

    @Override // r0.j
    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        d dVar = this.f298a;
        if (dVar != null) {
            dVar.f = mode;
            dVar.f2228b = true;
            dVar.a();
        }
    }

    @Override // r0.k
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        w0 w0Var = this.f300c;
        w0Var.l(colorStateList);
        w0Var.b();
    }

    @Override // r0.k
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        w0 w0Var = this.f300c;
        w0Var.m(mode);
        w0Var.b();
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatRadioButton(Context context, AttributeSet attributeSet, int i3) {
        super(context, attributeSet, R.attr.radioButtonStyle);
        v2.a(context);
        u2.a(getContext(), this);
        d dVar = new d(this);
        this.f298a = dVar;
        dVar.d(attributeSet, R.attr.radioButtonStyle);
        b bVar = new b(this);
        this.f299b = bVar;
        bVar.k(attributeSet, R.attr.radioButtonStyle);
        w0 w0Var = new w0(this);
        this.f300c = w0Var;
        w0Var.f(attributeSet, R.attr.radioButtonStyle);
        getEmojiTextViewHelper().b(attributeSet, R.attr.radioButtonStyle);
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i3) {
        setButtonDrawable(a.G(getContext(), i3));
    }
}
