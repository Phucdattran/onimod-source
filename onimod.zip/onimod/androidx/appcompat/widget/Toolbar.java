package androidx.appcompat.widget;

import a2.i;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.emoji2.text.u;
import e.a;
import j.h;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import k.m;
import k.o;
import l.a1;
import l.a3;
import l.b3;
import l.c3;
import l.d3;
import l.e3;
import l.f3;
import l.g3;
import l.j1;
import l.k;
import l.o3;
import l.q2;
import l.w;
import l.y;
import l.y2;
import l.z2;
import o0.h0;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public class Toolbar extends ViewGroup {
    public ColorStateList A;
    public boolean B;
    public boolean C;
    public final ArrayList D;
    public final ArrayList E;
    public final int[] F;
    public final u G;
    public ArrayList H;
    public final z2 I;
    public g3 J;
    public k K;
    public b3 L;
    public boolean M;
    public OnBackInvokedCallback N;
    public OnBackInvokedDispatcher O;
    public boolean P;
    public final i Q;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ActionMenuView f339a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public a1 f340b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public a1 f341c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public w f342d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public y f343e;
    public final Drawable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final CharSequence f344g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public w f345h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public View f346i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Context f347j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f348k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f349l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f350m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f351n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f352o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f353p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f354q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f355r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f356s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public q2 f357t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f358u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f359v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f360w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public CharSequence f361x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public CharSequence f362y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public ColorStateList f363z;

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i3 = 0; i3 < menu.size(); i3++) {
            arrayList.add(menu.getItem(i3));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new h(getContext());
    }

    public static c3 h() {
        c3 c3Var = new c3(-2, -2);
        c3Var.f3030b = 0;
        c3Var.f3029a = 8388627;
        return c3Var;
    }

    public static c3 i(ViewGroup.LayoutParams layoutParams) {
        boolean z4 = layoutParams instanceof c3;
        if (z4) {
            c3 c3Var = (c3) layoutParams;
            c3 c3Var2 = new c3(c3Var);
            c3Var2.f3030b = 0;
            c3Var2.f3030b = c3Var.f3030b;
            return c3Var2;
        }
        if (z4) {
            c3 c3Var3 = new c3((c3) layoutParams);
            c3Var3.f3030b = 0;
            return c3Var3;
        }
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            c3 c3Var4 = new c3(layoutParams);
            c3Var4.f3030b = 0;
            return c3Var4;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        c3 c3Var5 = new c3(marginLayoutParams);
        c3Var5.f3030b = 0;
        ((ViewGroup.MarginLayoutParams) c3Var5).leftMargin = marginLayoutParams.leftMargin;
        ((ViewGroup.MarginLayoutParams) c3Var5).topMargin = marginLayoutParams.topMargin;
        ((ViewGroup.MarginLayoutParams) c3Var5).rightMargin = marginLayoutParams.rightMargin;
        ((ViewGroup.MarginLayoutParams) c3Var5).bottomMargin = marginLayoutParams.bottomMargin;
        return c3Var5;
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginEnd() + marginLayoutParams.getMarginStart();
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(ArrayList arrayList, int i3) {
        boolean z4 = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i3, getLayoutDirection());
        arrayList.clear();
        if (!z4) {
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt = getChildAt(i4);
                c3 c3Var = (c3) childAt.getLayoutParams();
                if (c3Var.f3030b == 0 && t(childAt)) {
                    int i5 = c3Var.f3029a;
                    int layoutDirection = getLayoutDirection();
                    int absoluteGravity2 = Gravity.getAbsoluteGravity(i5, layoutDirection) & 7;
                    if (absoluteGravity2 != 1 && absoluteGravity2 != 3 && absoluteGravity2 != 5) {
                        absoluteGravity2 = layoutDirection == 1 ? 5 : 3;
                    }
                    if (absoluteGravity2 == absoluteGravity) {
                        arrayList.add(childAt);
                    }
                }
            }
            return;
        }
        for (int i6 = childCount - 1; i6 >= 0; i6--) {
            View childAt2 = getChildAt(i6);
            c3 c3Var2 = (c3) childAt2.getLayoutParams();
            if (c3Var2.f3030b == 0 && t(childAt2)) {
                int i7 = c3Var2.f3029a;
                int layoutDirection2 = getLayoutDirection();
                int absoluteGravity3 = Gravity.getAbsoluteGravity(i7, layoutDirection2) & 7;
                if (absoluteGravity3 != 1 && absoluteGravity3 != 3 && absoluteGravity3 != 5) {
                    absoluteGravity3 = layoutDirection2 == 1 ? 5 : 3;
                }
                if (absoluteGravity3 == absoluteGravity) {
                    arrayList.add(childAt2);
                }
            }
        }
    }

    public final void b(View view, boolean z4) {
        c3 c3VarI;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            c3VarI = h();
        } else {
            c3VarI = !checkLayoutParams(layoutParams) ? i(layoutParams) : (c3) layoutParams;
        }
        c3VarI.f3030b = 1;
        if (!z4 || this.f346i == null) {
            addView(view, c3VarI);
        } else {
            view.setLayoutParams(c3VarI);
            this.E.add(view);
        }
    }

    public final void c() {
        if (this.f345h == null) {
            w wVar = new w(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            this.f345h = wVar;
            wVar.setImageDrawable(this.f);
            this.f345h.setContentDescription(this.f344g);
            c3 c3VarH = h();
            c3VarH.f3029a = (this.f351n & 112) | 8388611;
            c3VarH.f3030b = 2;
            this.f345h.setLayoutParams(c3VarH);
            this.f345h.setOnClickListener(new a(2, this));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof c3);
    }

    public final void d() {
        if (this.f357t == null) {
            q2 q2Var = new q2();
            q2Var.f3213a = 0;
            q2Var.f3214b = 0;
            q2Var.f3215c = Integer.MIN_VALUE;
            q2Var.f3216d = Integer.MIN_VALUE;
            q2Var.f3217e = 0;
            q2Var.f = 0;
            q2Var.f3218g = false;
            q2Var.f3219h = false;
            this.f357t = q2Var;
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.f339a;
        if (actionMenuView.f282p == null) {
            m mVar = (m) actionMenuView.getMenu();
            if (this.L == null) {
                this.L = new b3(this);
            }
            this.f339a.setExpandedActionViewsExclusive(true);
            mVar.b(this.L, this.f347j);
            u();
        }
    }

    public final void f() {
        if (this.f339a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.f339a = actionMenuView;
            actionMenuView.setPopupTheme(this.f348k);
            this.f339a.setOnMenuItemClickListener(this.I);
            ActionMenuView actionMenuView2 = this.f339a;
            z2 z2Var = new z2(this);
            actionMenuView2.getClass();
            actionMenuView2.f287u = z2Var;
            c3 c3VarH = h();
            c3VarH.f3029a = (this.f351n & 112) | 8388613;
            this.f339a.setLayoutParams(c3VarH);
            b(this.f339a, false);
        }
    }

    public final void g() {
        if (this.f342d == null) {
            this.f342d = new w(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            c3 c3VarH = h();
            c3VarH.f3029a = (this.f351n & 112) | 8388611;
            this.f342d.setLayoutParams(c3VarH);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        w wVar = this.f345h;
        if (wVar != null) {
            return wVar.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        w wVar = this.f345h;
        if (wVar != null) {
            return wVar.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        q2 q2Var = this.f357t;
        if (q2Var != null) {
            return q2Var.f3218g ? q2Var.f3213a : q2Var.f3214b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i3 = this.f359v;
        return i3 != Integer.MIN_VALUE ? i3 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        q2 q2Var = this.f357t;
        if (q2Var != null) {
            return q2Var.f3213a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        q2 q2Var = this.f357t;
        if (q2Var != null) {
            return q2Var.f3214b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        q2 q2Var = this.f357t;
        if (q2Var != null) {
            return q2Var.f3218g ? q2Var.f3214b : q2Var.f3213a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i3 = this.f358u;
        return i3 != Integer.MIN_VALUE ? i3 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        m mVar;
        ActionMenuView actionMenuView = this.f339a;
        return (actionMenuView == null || (mVar = actionMenuView.f282p) == null || !mVar.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f359v, 0));
    }

    public int getCurrentContentInsetLeft() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f358u, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        y yVar = this.f343e;
        if (yVar != null) {
            return yVar.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        y yVar = this.f343e;
        if (yVar != null) {
            return yVar.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f339a.getMenu();
    }

    public View getNavButtonView() {
        return this.f342d;
    }

    public CharSequence getNavigationContentDescription() {
        w wVar = this.f342d;
        if (wVar != null) {
            return wVar.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        w wVar = this.f342d;
        if (wVar != null) {
            return wVar.getDrawable();
        }
        return null;
    }

    public k getOuterActionMenuPresenter() {
        return this.K;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f339a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f347j;
    }

    public int getPopupTheme() {
        return this.f348k;
    }

    public CharSequence getSubtitle() {
        return this.f362y;
    }

    public final TextView getSubtitleTextView() {
        return this.f341c;
    }

    public CharSequence getTitle() {
        return this.f361x;
    }

    public int getTitleMarginBottom() {
        return this.f356s;
    }

    public int getTitleMarginEnd() {
        return this.f354q;
    }

    public int getTitleMarginStart() {
        return this.f353p;
    }

    public int getTitleMarginTop() {
        return this.f355r;
    }

    public final TextView getTitleTextView() {
        return this.f340b;
    }

    public j1 getWrapper() {
        Drawable drawable;
        if (this.J == null) {
            g3 g3Var = new g3();
            g3Var.f3099n = 0;
            g3Var.f3087a = this;
            g3Var.f3093h = getTitle();
            g3Var.f3094i = getSubtitle();
            g3Var.f3092g = g3Var.f3093h != null;
            g3Var.f = getNavigationIcon();
            u uVarX = u.x(getContext(), null, d.a.f1594a, R.attr.actionBarStyle);
            TypedArray typedArray = (TypedArray) uVarX.f563c;
            g3Var.f3100o = uVarX.o(15);
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                g3Var.f3092g = true;
                g3Var.f3093h = text;
                if ((g3Var.f3088b & 8) != 0) {
                    setTitle(text);
                    if (g3Var.f3092g) {
                        h0.q(getRootView(), text);
                    }
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                g3Var.f3094i = text2;
                if ((g3Var.f3088b & 8) != 0) {
                    setSubtitle(text2);
                }
            }
            Drawable drawableO = uVarX.o(20);
            if (drawableO != null) {
                g3Var.f3091e = drawableO;
                g3Var.c();
            }
            Drawable drawableO2 = uVarX.o(17);
            if (drawableO2 != null) {
                g3Var.f3090d = drawableO2;
                g3Var.c();
            }
            if (g3Var.f == null && (drawable = g3Var.f3100o) != null) {
                g3Var.f = drawable;
                if ((g3Var.f3088b & 4) != 0) {
                    setNavigationIcon(drawable);
                } else {
                    setNavigationIcon((Drawable) null);
                }
            }
            g3Var.a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View viewInflate = LayoutInflater.from(getContext()).inflate(resourceId, (ViewGroup) this, false);
                View view = g3Var.f3089c;
                if (view != null && (g3Var.f3088b & 16) != 0) {
                    removeView(view);
                }
                g3Var.f3089c = viewInflate;
                if (viewInflate != null && (g3Var.f3088b & 16) != 0) {
                    addView(viewInflate);
                }
                g3Var.a(g3Var.f3088b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                layoutParams.height = layoutDimension;
                setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int iMax = Math.max(dimensionPixelOffset, 0);
                int iMax2 = Math.max(dimensionPixelOffset2, 0);
                d();
                this.f357t.a(iMax, iMax2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = getContext();
                this.f349l = resourceId2;
                a1 a1Var = this.f340b;
                if (a1Var != null) {
                    a1Var.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = getContext();
                this.f350m = resourceId3;
                a1 a1Var2 = this.f341c;
                if (a1Var2 != null) {
                    a1Var2.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                setPopupTheme(resourceId4);
            }
            uVarX.z();
            if (R.string.abc_action_bar_up_description != g3Var.f3099n) {
                g3Var.f3099n = R.string.abc_action_bar_up_description;
                if (TextUtils.isEmpty(getNavigationContentDescription())) {
                    int i3 = g3Var.f3099n;
                    g3Var.f3095j = i3 != 0 ? getContext().getString(i3) : null;
                    g3Var.b();
                }
            }
            g3Var.f3095j = getNavigationContentDescription();
            setNavigationOnClickListener(new f3(g3Var));
            this.J = g3Var;
        }
        return this.J;
    }

    public final int j(View view, int i3) {
        c3 c3Var = (c3) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i4 = i3 > 0 ? (measuredHeight - i3) / 2 : 0;
        int i5 = c3Var.f3029a & 112;
        if (i5 != 16 && i5 != 48 && i5 != 80) {
            i5 = this.f360w & 112;
        }
        if (i5 == 48) {
            return getPaddingTop() - i4;
        }
        if (i5 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) c3Var).bottomMargin) - i4;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i6 = ((ViewGroup.MarginLayoutParams) c3Var).topMargin;
        if (iMax < i6) {
            iMax = i6;
        } else {
            int i7 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i8 = ((ViewGroup.MarginLayoutParams) c3Var).bottomMargin;
            if (i7 < i8) {
                iMax = Math.max(0, iMax - (i8 - i7));
            }
        }
        return paddingTop + iMax;
    }

    public void m(int i3) {
        getMenuInflater().inflate(i3, getMenu());
    }

    public final void n() {
        ArrayList arrayList = this.H;
        int size = arrayList.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayList.get(i3);
            i3++;
            getMenu().removeItem(((MenuItem) obj).getItemId());
        }
        getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        getMenuInflater();
        Iterator it = ((CopyOnWriteArrayList) this.G.f563c).iterator();
        while (it.hasNext()) {
            ((androidx.fragment.app.h0) it.next()).f658a.j();
        }
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.H = currentMenuItems2;
    }

    public final boolean o(View view) {
        return view.getParent() == this || this.E.contains(view);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        u();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.Q);
        u();
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.C = false;
        }
        if (!this.C) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.C = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.C = false;
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x027d  */
    /* JADX WARN: Code duplicated, block: B:103:0x028f A[LOOP:0: B:102:0x028d->B:103:0x028f, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:106:0x02a7 A[LOOP:1: B:105:0x02a5->B:106:0x02a7, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:109:0x02c6 A[LOOP:2: B:108:0x02c4->B:109:0x02c6, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:113:0x030c A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:114:0x030e  */
    /* JADX WARN: Code duplicated, block: B:115:0x0312  */
    /* JADX WARN: Code duplicated, block: B:118:0x0319 A[LOOP:3: B:117:0x0317->B:118:0x0319, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:19:0x0062 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:20:0x0064  */
    /* JADX WARN: Code duplicated, block: B:21:0x006b  */
    /* JADX WARN: Code duplicated, block: B:24:0x0079 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:25:0x007b  */
    /* JADX WARN: Code duplicated, block: B:26:0x0082  */
    /* JADX WARN: Code duplicated, block: B:29:0x00b6 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:30:0x00b8  */
    /* JADX WARN: Code duplicated, block: B:31:0x00bf  */
    /* JADX WARN: Code duplicated, block: B:34:0x00cd A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:35:0x00cf  */
    /* JADX WARN: Code duplicated, block: B:36:0x00d6  */
    /* JADX WARN: Code duplicated, block: B:39:0x00ea  */
    /* JADX WARN: Code duplicated, block: B:40:0x0101  */
    /* JADX WARN: Code duplicated, block: B:42:0x0106  */
    /* JADX WARN: Code duplicated, block: B:43:0x011f  */
    /* JADX WARN: Code duplicated, block: B:46:0x0125 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:47:0x0127  */
    /* JADX WARN: Code duplicated, block: B:48:0x012a  */
    /* JADX WARN: Code duplicated, block: B:50:0x012e  */
    /* JADX WARN: Code duplicated, block: B:51:0x0131  */
    /* JADX WARN: Code duplicated, block: B:54:0x0143  */
    /* JADX WARN: Code duplicated, block: B:56:0x014b A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:63:0x0164  */
    /* JADX WARN: Code duplicated, block: B:65:0x0168  */
    /* JADX WARN: Code duplicated, block: B:67:0x0179  */
    /* JADX WARN: Code duplicated, block: B:68:0x017b  */
    /* JADX WARN: Code duplicated, block: B:70:0x0187  */
    /* JADX WARN: Code duplicated, block: B:72:0x0193  */
    /* JADX WARN: Code duplicated, block: B:73:0x019d  */
    /* JADX WARN: Code duplicated, block: B:75:0x01aa A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:76:0x01ac  */
    /* JADX WARN: Code duplicated, block: B:77:0x01af  */
    /* JADX WARN: Code duplicated, block: B:80:0x01c2  */
    /* JADX WARN: Code duplicated, block: B:81:0x01e6  */
    /* JADX WARN: Code duplicated, block: B:83:0x01e9  */
    /* JADX WARN: Code duplicated, block: B:84:0x020d  */
    /* JADX WARN: Code duplicated, block: B:86:0x0210  */
    /* JADX WARN: Code duplicated, block: B:88:0x0218 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:89:0x021a  */
    /* JADX WARN: Code duplicated, block: B:91:0x021e  */
    /* JADX WARN: Code duplicated, block: B:94:0x0232  */
    /* JADX WARN: Code duplicated, block: B:95:0x0255  */
    /* JADX WARN: Code duplicated, block: B:97:0x0258  */
    /* JADX WARN: Code duplicated, block: B:98:0x027a  */
    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        int iP;
        int iQ;
        int iMax;
        int iMin;
        boolean zT;
        boolean zT2;
        int measuredHeight;
        a1 a1Var;
        a1 a1Var2;
        c3 c3Var;
        c3 c3Var2;
        int i7;
        boolean z5;
        int i8;
        int i9;
        int paddingTop;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int iMax2;
        int i16;
        int i17;
        int i18;
        int i19;
        ArrayList arrayList;
        int size;
        int iP2;
        int i20;
        int size2;
        int i21;
        int i22;
        int size3;
        int i23;
        int i24;
        int measuredWidth;
        int i25;
        int i26;
        int i27;
        int size4;
        boolean z6 = getLayoutDirection() == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i28 = width - paddingRight;
        int[] iArr = this.F;
        iArr[1] = 0;
        iArr[0] = 0;
        WeakHashMap weakHashMap = h0.f3558a;
        int minimumHeight = getMinimumHeight();
        int iMin2 = minimumHeight >= 0 ? Math.min(minimumHeight, i6 - i4) : 0;
        if (t(this.f342d)) {
            if (z6) {
                iQ = q(this.f342d, i28, iMin2, iArr);
                iP = paddingLeft;
            } else {
                iP = p(this.f342d, paddingLeft, iMin2, iArr);
            }
            if (t(this.f345h)) {
                if (z6) {
                    iQ = q(this.f345h, iQ, iMin2, iArr);
                } else {
                    iP = p(this.f345h, iP, iMin2, iArr);
                }
            }
            if (t(this.f339a)) {
                if (z6) {
                    iP = p(this.f339a, iP, iMin2, iArr);
                } else {
                    iQ = q(this.f339a, iQ, iMin2, iArr);
                }
            }
            int currentContentInsetLeft = getCurrentContentInsetLeft();
            int currentContentInsetRight = getCurrentContentInsetRight();
            iArr[0] = Math.max(0, currentContentInsetLeft - iP);
            iArr[1] = Math.max(0, currentContentInsetRight - (i28 - iQ));
            iMax = Math.max(iP, currentContentInsetLeft);
            iMin = Math.min(iQ, i28 - currentContentInsetRight);
            if (t(this.f346i)) {
                if (z6) {
                    iMin = q(this.f346i, iMin, iMin2, iArr);
                } else {
                    iMax = p(this.f346i, iMax, iMin2, iArr);
                }
            }
            if (t(this.f343e)) {
                if (z6) {
                    iMin = q(this.f343e, iMin, iMin2, iArr);
                } else {
                    iMax = p(this.f343e, iMax, iMin2, iArr);
                }
            }
            zT = t(this.f340b);
            zT2 = t(this.f341c);
            if (zT) {
                c3 c3Var3 = (c3) this.f340b.getLayoutParams();
                measuredHeight = this.f340b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c3Var3).topMargin + ((ViewGroup.MarginLayoutParams) c3Var3).bottomMargin;
            } else {
                measuredHeight = 0;
            }
            if (zT2) {
                c3 c3Var4 = (c3) this.f341c.getLayoutParams();
                measuredHeight = this.f341c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c3Var4).topMargin + ((ViewGroup.MarginLayoutParams) c3Var4).bottomMargin + measuredHeight;
            }
            if (zT || zT2) {
                if (zT) {
                    a1Var = this.f340b;
                } else {
                    a1Var = this.f341c;
                }
                if (zT2) {
                    a1Var2 = this.f341c;
                } else {
                    a1Var2 = this.f340b;
                }
                c3Var = (c3) a1Var.getLayoutParams();
                c3Var2 = (c3) a1Var2.getLayoutParams();
                i7 = measuredHeight;
                z5 = (!zT && this.f340b.getMeasuredWidth() > 0) || (zT2 && this.f341c.getMeasuredWidth() > 0);
                i8 = this.f360w & 112;
                i9 = iMax;
                if (i8 == 48) {
                    paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) c3Var).topMargin + this.f355r;
                } else if (i8 != 80) {
                    iMax2 = (((height - paddingTop2) - paddingBottom) - i7) / 2;
                    i16 = ((ViewGroup.MarginLayoutParams) c3Var).topMargin + this.f355r;
                    if (iMax2 < i16) {
                        iMax2 = i16;
                    } else {
                        i17 = (((height - paddingBottom) - i7) - iMax2) - paddingTop2;
                        i18 = ((ViewGroup.MarginLayoutParams) c3Var).bottomMargin;
                        i19 = this.f356s;
                        if (i17 < i18 + i19) {
                            iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) c3Var2).bottomMargin + i19) - i17));
                        }
                    }
                    paddingTop = paddingTop2 + iMax2;
                } else {
                    paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) c3Var2).bottomMargin) - this.f356s) - i7;
                }
                if (z6) {
                    if (z5) {
                        i13 = this.f353p;
                    } else {
                        i13 = 0;
                    }
                    int i29 = i13 - iArr[1];
                    iMin -= Math.max(0, i29);
                    iArr[1] = Math.max(0, -i29);
                    if (zT) {
                        c3 c3Var5 = (c3) this.f340b.getLayoutParams();
                        int measuredWidth2 = iMin - this.f340b.getMeasuredWidth();
                        int measuredHeight2 = this.f340b.getMeasuredHeight() + paddingTop;
                        this.f340b.layout(measuredWidth2, paddingTop, iMin, measuredHeight2);
                        i14 = measuredWidth2 - this.f354q;
                        paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) c3Var5).bottomMargin;
                    } else {
                        i14 = iMin;
                    }
                    if (zT2) {
                        int i30 = paddingTop + ((ViewGroup.MarginLayoutParams) ((c3) this.f341c.getLayoutParams())).topMargin;
                        this.f341c.layout(iMin - this.f341c.getMeasuredWidth(), i30, iMin, this.f341c.getMeasuredHeight() + i30);
                        i15 = iMin - this.f354q;
                    } else {
                        i15 = iMin;
                    }
                    if (z5) {
                        iMin = Math.min(i14, i15);
                    }
                    iMax = i9;
                } else {
                    if (z5) {
                        i10 = this.f353p;
                    } else {
                        i10 = 0;
                    }
                    int i31 = i10 - iArr[0];
                    iMax = Math.max(0, i31) + i9;
                    iArr[0] = Math.max(0, -i31);
                    if (zT) {
                        c3 c3Var6 = (c3) this.f340b.getLayoutParams();
                        int measuredWidth3 = this.f340b.getMeasuredWidth() + iMax;
                        int measuredHeight3 = this.f340b.getMeasuredHeight() + paddingTop;
                        this.f340b.layout(iMax, paddingTop, measuredWidth3, measuredHeight3);
                        i11 = measuredWidth3 + this.f354q;
                        paddingTop = measuredHeight3 + ((ViewGroup.MarginLayoutParams) c3Var6).bottomMargin;
                    } else {
                        i11 = iMax;
                    }
                    if (zT2) {
                        int i32 = paddingTop + ((ViewGroup.MarginLayoutParams) ((c3) this.f341c.getLayoutParams())).topMargin;
                        int measuredWidth4 = this.f341c.getMeasuredWidth() + iMax;
                        this.f341c.layout(iMax, i32, measuredWidth4, this.f341c.getMeasuredHeight() + i32);
                        i12 = measuredWidth4 + this.f354q;
                    } else {
                        i12 = iMax;
                    }
                    if (z5) {
                        iMax = Math.max(i11, i12);
                    }
                }
            }
            arrayList = this.D;
            a(arrayList, 3);
            size = arrayList.size();
            iP2 = iMax;
            for (i20 = 0; i20 < size; i20++) {
                iP2 = p((View) arrayList.get(i20), iP2, iMin2, iArr);
            }
            a(arrayList, 5);
            size2 = arrayList.size();
            for (i21 = 0; i21 < size2; i21++) {
                iMin = q((View) arrayList.get(i21), iMin, iMin2, iArr);
            }
            a(arrayList, 1);
            int i33 = iArr[0];
            i22 = iArr[1];
            size3 = arrayList.size();
            i23 = i33;
            i24 = 0;
            measuredWidth = 0;
            while (i24 < size3) {
                View view = (View) arrayList.get(i24);
                c3 c3Var7 = (c3) view.getLayoutParams();
                int i34 = i22;
                int i35 = ((ViewGroup.MarginLayoutParams) c3Var7).leftMargin - i23;
                int i36 = ((ViewGroup.MarginLayoutParams) c3Var7).rightMargin - i34;
                int iMax3 = Math.max(0, i35);
                int iMax4 = Math.max(0, i36);
                int iMax5 = Math.max(0, -i35);
                int iMax6 = Math.max(0, -i36);
                measuredWidth += view.getMeasuredWidth() + iMax3 + iMax4;
                i24++;
                i23 = iMax5;
                i22 = iMax6;
            }
            i26 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (measuredWidth / 2);
            i27 = measuredWidth + i26;
            if (i26 >= iP2) {
                if (i27 > iMin) {
                    iP2 = i26 - (i27 - iMin);
                } else {
                    iP2 = i26;
                }
            }
            size4 = arrayList.size();
            for (i25 = 0; i25 < size4; i25++) {
                iP2 = p((View) arrayList.get(i25), iP2, iMin2, iArr);
            }
            arrayList.clear();
        }
        iP = paddingLeft;
        iQ = i28;
        if (t(this.f345h)) {
            if (z6) {
                iQ = q(this.f345h, iQ, iMin2, iArr);
            } else {
                iP = p(this.f345h, iP, iMin2, iArr);
            }
        }
        if (t(this.f339a)) {
            if (z6) {
                iP = p(this.f339a, iP, iMin2, iArr);
            } else {
                iQ = q(this.f339a, iQ, iMin2, iArr);
            }
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - iP);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i28 - iQ));
        iMax = Math.max(iP, currentContentInsetLeft2);
        iMin = Math.min(iQ, i28 - currentContentInsetRight2);
        if (t(this.f346i)) {
            if (z6) {
                iMin = q(this.f346i, iMin, iMin2, iArr);
            } else {
                iMax = p(this.f346i, iMax, iMin2, iArr);
            }
        }
        if (t(this.f343e)) {
            if (z6) {
                iMin = q(this.f343e, iMin, iMin2, iArr);
            } else {
                iMax = p(this.f343e, iMax, iMin2, iArr);
            }
        }
        zT = t(this.f340b);
        zT2 = t(this.f341c);
        if (zT) {
            c3 c3Var8 = (c3) this.f340b.getLayoutParams();
            measuredHeight = this.f340b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c3Var8).topMargin + ((ViewGroup.MarginLayoutParams) c3Var8).bottomMargin;
        } else {
            measuredHeight = 0;
        }
        if (zT2) {
            c3 c3Var9 = (c3) this.f341c.getLayoutParams();
            measuredHeight = this.f341c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c3Var9).topMargin + ((ViewGroup.MarginLayoutParams) c3Var9).bottomMargin + measuredHeight;
        }
        if (zT) {
            if (zT) {
                a1Var = this.f340b;
            } else {
                a1Var = this.f341c;
            }
            if (zT2) {
                a1Var2 = this.f341c;
            } else {
                a1Var2 = this.f340b;
            }
            c3Var = (c3) a1Var.getLayoutParams();
            c3Var2 = (c3) a1Var2.getLayoutParams();
            i7 = measuredHeight;
            if (zT) {
            }
            i8 = this.f360w & 112;
            i9 = iMax;
            if (i8 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) c3Var).topMargin + this.f355r;
            } else if (i8 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - i7) / 2;
                i16 = ((ViewGroup.MarginLayoutParams) c3Var).topMargin + this.f355r;
                if (iMax2 < i16) {
                    iMax2 = i16;
                } else {
                    i17 = (((height - paddingBottom) - i7) - iMax2) - paddingTop2;
                    i18 = ((ViewGroup.MarginLayoutParams) c3Var).bottomMargin;
                    i19 = this.f356s;
                    if (i17 < i18 + i19) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) c3Var2).bottomMargin + i19) - i17));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) c3Var2).bottomMargin) - this.f356s) - i7;
            }
            if (z6) {
                if (z5) {
                    i13 = this.f353p;
                } else {
                    i13 = 0;
                }
                int i210 = i13 - iArr[1];
                iMin -= Math.max(0, i210);
                iArr[1] = Math.max(0, -i210);
                if (zT) {
                    c3 c3Var10 = (c3) this.f340b.getLayoutParams();
                    int measuredWidth5 = iMin - this.f340b.getMeasuredWidth();
                    int measuredHeight4 = this.f340b.getMeasuredHeight() + paddingTop;
                    this.f340b.layout(measuredWidth5, paddingTop, iMin, measuredHeight4);
                    i14 = measuredWidth5 - this.f354q;
                    paddingTop = measuredHeight4 + ((ViewGroup.MarginLayoutParams) c3Var10).bottomMargin;
                } else {
                    i14 = iMin;
                }
                if (zT2) {
                    int i37 = paddingTop + ((ViewGroup.MarginLayoutParams) ((c3) this.f341c.getLayoutParams())).topMargin;
                    this.f341c.layout(iMin - this.f341c.getMeasuredWidth(), i37, iMin, this.f341c.getMeasuredHeight() + i37);
                    i15 = iMin - this.f354q;
                } else {
                    i15 = iMin;
                }
                if (z5) {
                    iMin = Math.min(i14, i15);
                }
                iMax = i9;
            } else {
                if (z5) {
                    i10 = this.f353p;
                } else {
                    i10 = 0;
                }
                int i38 = i10 - iArr[0];
                iMax = Math.max(0, i38) + i9;
                iArr[0] = Math.max(0, -i38);
                if (zT) {
                    c3 c3Var11 = (c3) this.f340b.getLayoutParams();
                    int measuredWidth6 = this.f340b.getMeasuredWidth() + iMax;
                    int measuredHeight5 = this.f340b.getMeasuredHeight() + paddingTop;
                    this.f340b.layout(iMax, paddingTop, measuredWidth6, measuredHeight5);
                    i11 = measuredWidth6 + this.f354q;
                    paddingTop = measuredHeight5 + ((ViewGroup.MarginLayoutParams) c3Var11).bottomMargin;
                } else {
                    i11 = iMax;
                }
                if (zT2) {
                    int i39 = paddingTop + ((ViewGroup.MarginLayoutParams) ((c3) this.f341c.getLayoutParams())).topMargin;
                    int measuredWidth7 = this.f341c.getMeasuredWidth() + iMax;
                    this.f341c.layout(iMax, i39, measuredWidth7, this.f341c.getMeasuredHeight() + i39);
                    i12 = measuredWidth7 + this.f354q;
                } else {
                    i12 = iMax;
                }
                if (z5) {
                    iMax = Math.max(i11, i12);
                }
            }
        } else {
            if (zT) {
                a1Var = this.f340b;
            } else {
                a1Var = this.f341c;
            }
            if (zT2) {
                a1Var2 = this.f341c;
            } else {
                a1Var2 = this.f340b;
            }
            c3Var = (c3) a1Var.getLayoutParams();
            c3Var2 = (c3) a1Var2.getLayoutParams();
            i7 = measuredHeight;
            if (zT) {
            }
            i8 = this.f360w & 112;
            i9 = iMax;
            if (i8 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) c3Var).topMargin + this.f355r;
            } else if (i8 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - i7) / 2;
                i16 = ((ViewGroup.MarginLayoutParams) c3Var).topMargin + this.f355r;
                if (iMax2 < i16) {
                    iMax2 = i16;
                } else {
                    i17 = (((height - paddingBottom) - i7) - iMax2) - paddingTop2;
                    i18 = ((ViewGroup.MarginLayoutParams) c3Var).bottomMargin;
                    i19 = this.f356s;
                    if (i17 < i18 + i19) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) c3Var2).bottomMargin + i19) - i17));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) c3Var2).bottomMargin) - this.f356s) - i7;
            }
            if (z6) {
                if (z5) {
                    i13 = this.f353p;
                } else {
                    i13 = 0;
                }
                int i211 = i13 - iArr[1];
                iMin -= Math.max(0, i211);
                iArr[1] = Math.max(0, -i211);
                if (zT) {
                    c3 c3Var12 = (c3) this.f340b.getLayoutParams();
                    int measuredWidth8 = iMin - this.f340b.getMeasuredWidth();
                    int measuredHeight6 = this.f340b.getMeasuredHeight() + paddingTop;
                    this.f340b.layout(measuredWidth8, paddingTop, iMin, measuredHeight6);
                    i14 = measuredWidth8 - this.f354q;
                    paddingTop = measuredHeight6 + ((ViewGroup.MarginLayoutParams) c3Var12).bottomMargin;
                } else {
                    i14 = iMin;
                }
                if (zT2) {
                    int i310 = paddingTop + ((ViewGroup.MarginLayoutParams) ((c3) this.f341c.getLayoutParams())).topMargin;
                    this.f341c.layout(iMin - this.f341c.getMeasuredWidth(), i310, iMin, this.f341c.getMeasuredHeight() + i310);
                    i15 = iMin - this.f354q;
                } else {
                    i15 = iMin;
                }
                if (z5) {
                    iMin = Math.min(i14, i15);
                }
                iMax = i9;
            } else {
                if (z5) {
                    i10 = this.f353p;
                } else {
                    i10 = 0;
                }
                int i311 = i10 - iArr[0];
                iMax = Math.max(0, i311) + i9;
                iArr[0] = Math.max(0, -i311);
                if (zT) {
                    c3 c3Var13 = (c3) this.f340b.getLayoutParams();
                    int measuredWidth9 = this.f340b.getMeasuredWidth() + iMax;
                    int measuredHeight7 = this.f340b.getMeasuredHeight() + paddingTop;
                    this.f340b.layout(iMax, paddingTop, measuredWidth9, measuredHeight7);
                    i11 = measuredWidth9 + this.f354q;
                    paddingTop = measuredHeight7 + ((ViewGroup.MarginLayoutParams) c3Var13).bottomMargin;
                } else {
                    i11 = iMax;
                }
                if (zT2) {
                    int i312 = paddingTop + ((ViewGroup.MarginLayoutParams) ((c3) this.f341c.getLayoutParams())).topMargin;
                    int measuredWidth10 = this.f341c.getMeasuredWidth() + iMax;
                    this.f341c.layout(iMax, i312, measuredWidth10, this.f341c.getMeasuredHeight() + i312);
                    i12 = measuredWidth10 + this.f354q;
                } else {
                    i12 = iMax;
                }
                if (z5) {
                    iMax = Math.max(i11, i12);
                }
            }
        }
        arrayList = this.D;
        a(arrayList, 3);
        size = arrayList.size();
        iP2 = iMax;
        while (i20 < size) {
            iP2 = p((View) arrayList.get(i20), iP2, iMin2, iArr);
        }
        a(arrayList, 5);
        size2 = arrayList.size();
        while (i21 < size2) {
            iMin = q((View) arrayList.get(i21), iMin, iMin2, iArr);
        }
        a(arrayList, 1);
        int i313 = iArr[0];
        i22 = iArr[1];
        size3 = arrayList.size();
        i23 = i313;
        i24 = 0;
        measuredWidth = 0;
        while (i24 < size3) {
            View view2 = (View) arrayList.get(i24);
            c3 c3Var14 = (c3) view2.getLayoutParams();
            int i314 = i22;
            int i315 = ((ViewGroup.MarginLayoutParams) c3Var14).leftMargin - i23;
            int i316 = ((ViewGroup.MarginLayoutParams) c3Var14).rightMargin - i314;
            int iMax7 = Math.max(0, i315);
            int iMax8 = Math.max(0, i316);
            int iMax9 = Math.max(0, -i315);
            int iMax10 = Math.max(0, -i316);
            measuredWidth += view2.getMeasuredWidth() + iMax7 + iMax8;
            i24++;
            i23 = iMax9;
            i22 = iMax10;
        }
        i26 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (measuredWidth / 2);
        i27 = measuredWidth + i26;
        if (i26 >= iP2) {
            if (i27 > iMin) {
                iP2 = i26 - (i27 - iMin);
            } else {
                iP2 = i26;
            }
        }
        size4 = arrayList.size();
        while (i25 < size4) {
            iP2 = p((View) arrayList.get(i25), iP2, iMin2, iArr);
        }
        arrayList.clear();
    }

    @Override // android.view.View
    public final void onMeasure(int i3, int i4) {
        boolean z4;
        char c3;
        int iK;
        int iMax;
        int iCombineMeasuredStates;
        int iK2;
        int iCombineMeasuredStates2;
        int iMax2;
        int iL;
        boolean z5 = o3.f3193a;
        int i5 = 0;
        if (getLayoutDirection() == 1) {
            z4 = true;
            c3 = 0;
        } else {
            z4 = false;
            c3 = 1;
        }
        if (t(this.f342d)) {
            s(this.f342d, i3, 0, i4, this.f352o);
            iK = k(this.f342d) + this.f342d.getMeasuredWidth();
            iMax = Math.max(0, l(this.f342d) + this.f342d.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.f342d.getMeasuredState());
        } else {
            iK = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (t(this.f345h)) {
            s(this.f345h, i3, 0, i4, this.f352o);
            iK = k(this.f345h) + this.f345h.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f345h) + this.f345h.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f345h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = Math.max(currentContentInsetStart, iK);
        int iMax4 = Math.max(0, currentContentInsetStart - iK);
        boolean z6 = z4;
        int[] iArr = this.F;
        iArr[z6 ? 1 : 0] = iMax4;
        if (t(this.f339a)) {
            s(this.f339a, i3, iMax3, i4, this.f352o);
            iK2 = k(this.f339a) + this.f339a.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f339a) + this.f339a.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f339a.getMeasuredState());
        } else {
            iK2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax5 = iMax3 + Math.max(currentContentInsetEnd, iK2);
        iArr[c3] = Math.max(0, currentContentInsetEnd - iK2);
        if (t(this.f346i)) {
            iMax5 += r(this.f346i, i3, iMax5, i4, 0, iArr);
            iMax = Math.max(iMax, l(this.f346i) + this.f346i.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f346i.getMeasuredState());
        }
        if (t(this.f343e)) {
            iMax5 += r(this.f343e, i3, iMax5, i4, 0, iArr);
            iMax = Math.max(iMax, l(this.f343e) + this.f343e.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f343e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (((c3) childAt.getLayoutParams()).f3030b == 0 && t(childAt)) {
                iMax5 += r(childAt, i3, iMax5, i4, 0, iArr);
                int iMax6 = Math.max(iMax, l(childAt) + childAt.getMeasuredHeight());
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
                iMax = iMax6;
            } else {
                iMax5 = iMax5;
            }
        }
        int i7 = iMax5;
        int i8 = this.f355r + this.f356s;
        int i9 = this.f353p + this.f354q;
        if (t(this.f340b)) {
            r(this.f340b, i3, i7 + i9, i4, i8, iArr);
            int iK3 = k(this.f340b) + this.f340b.getMeasuredWidth();
            iL = l(this.f340b) + this.f340b.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f340b.getMeasuredState());
            iMax2 = iK3;
        } else {
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
            iL = 0;
        }
        if (t(this.f341c)) {
            iMax2 = Math.max(iMax2, r(this.f341c, i3, i7 + i9, i4, i8 + iL, iArr));
            iL += l(this.f341c) + this.f341c.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.f341c.getMeasuredState());
        }
        int iMax7 = Math.max(iMax, iL);
        int paddingRight = getPaddingRight() + getPaddingLeft() + i7 + iMax2;
        int paddingBottom = getPaddingBottom() + getPaddingTop() + iMax7;
        int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i3, (-16777216) & iCombineMeasuredStates2);
        int iResolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i4, iCombineMeasuredStates2 << 16);
        if (!this.M) {
            i5 = iResolveSizeAndState2;
            break;
        }
        int childCount2 = getChildCount();
        for (int i10 = 0; i10 < childCount2; i10++) {
            View childAt2 = getChildAt(i10);
            if (t(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                i5 = iResolveSizeAndState2;
                break;
            }
        }
        setMeasuredDimension(iResolveSizeAndState, i5);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof e3)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        e3 e3Var = (e3) parcelable;
        super.onRestoreInstanceState(e3Var.f3827a);
        ActionMenuView actionMenuView = this.f339a;
        m mVar = actionMenuView != null ? actionMenuView.f282p : null;
        int i3 = e3Var.f3034c;
        if (i3 != 0 && this.L != null && mVar != null && (menuItemFindItem = mVar.findItem(i3)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (e3Var.f3035d) {
            i iVar = this.Q;
            removeCallbacks(iVar);
            post(iVar);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i3) {
        super.onRtlPropertiesChanged(i3);
        d();
        q2 q2Var = this.f357t;
        boolean z4 = i3 == 1;
        if (z4 == q2Var.f3218g) {
            return;
        }
        q2Var.f3218g = z4;
        if (!q2Var.f3219h) {
            q2Var.f3213a = q2Var.f3217e;
            q2Var.f3214b = q2Var.f;
            return;
        }
        if (z4) {
            int i4 = q2Var.f3216d;
            if (i4 == Integer.MIN_VALUE) {
                i4 = q2Var.f3217e;
            }
            q2Var.f3213a = i4;
            int i5 = q2Var.f3215c;
            if (i5 == Integer.MIN_VALUE) {
                i5 = q2Var.f;
            }
            q2Var.f3214b = i5;
            return;
        }
        int i6 = q2Var.f3215c;
        if (i6 == Integer.MIN_VALUE) {
            i6 = q2Var.f3217e;
        }
        q2Var.f3213a = i6;
        int i7 = q2Var.f3216d;
        if (i7 == Integer.MIN_VALUE) {
            i7 = q2Var.f;
        }
        q2Var.f3214b = i7;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        k kVar;
        o oVar;
        e3 e3Var = new e3(super.onSaveInstanceState());
        b3 b3Var = this.L;
        if (b3Var != null && (oVar = b3Var.f3023b) != null) {
            e3Var.f3034c = oVar.f2728a;
        }
        ActionMenuView actionMenuView = this.f339a;
        e3Var.f3035d = (actionMenuView == null || (kVar = actionMenuView.f286t) == null || !kVar.j()) ? false : true;
        return e3Var;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.B = false;
        }
        if (!this.B) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.B = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.B = false;
        return true;
    }

    public final int p(View view, int i3, int i4, int[] iArr) {
        c3 c3Var = (c3) view.getLayoutParams();
        int i5 = ((ViewGroup.MarginLayoutParams) c3Var).leftMargin - iArr[0];
        int iMax = Math.max(0, i5) + i3;
        iArr[0] = Math.max(0, -i5);
        int iJ = j(view, i4);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, iJ, iMax + measuredWidth, view.getMeasuredHeight() + iJ);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) c3Var).rightMargin + iMax;
    }

    public final int q(View view, int i3, int i4, int[] iArr) {
        c3 c3Var = (c3) view.getLayoutParams();
        int i5 = ((ViewGroup.MarginLayoutParams) c3Var).rightMargin - iArr[1];
        int iMax = i3 - Math.max(0, i5);
        iArr[1] = Math.max(0, -i5);
        int iJ = j(view, i4);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, iJ, iMax, view.getMeasuredHeight() + iJ);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) c3Var).leftMargin);
    }

    public final int r(View view, int i3, int i4, int i5, int i6, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i7 = marginLayoutParams.leftMargin - iArr[0];
        int i8 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i8) + Math.max(0, i7);
        iArr[0] = Math.max(0, -i7);
        iArr[1] = Math.max(0, -i8);
        view.measure(ViewGroup.getChildMeasureSpec(i3, getPaddingRight() + getPaddingLeft() + iMax + i4, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i5, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i6, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    public final void s(View view, int i3, int i4, int i5, int i6) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i3, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i4, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i5, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i6 >= 0) {
            if (mode != 0) {
                i6 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i6);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public void setBackInvokedCallbackEnabled(boolean z4) {
        if (this.P != z4) {
            this.P = z4;
            u();
        }
    }

    public void setCollapseContentDescription(int i3) {
        setCollapseContentDescription(i3 != 0 ? getContext().getText(i3) : null);
    }

    public void setCollapseIcon(int i3) {
        setCollapseIcon(a3.a.G(getContext(), i3));
    }

    public void setCollapsible(boolean z4) {
        this.M = z4;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i3) {
        if (i3 < 0) {
            i3 = Integer.MIN_VALUE;
        }
        if (i3 != this.f359v) {
            this.f359v = i3;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i3) {
        if (i3 < 0) {
            i3 = Integer.MIN_VALUE;
        }
        if (i3 != this.f358u) {
            this.f358u = i3;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i3) {
        setLogo(a3.a.G(getContext(), i3));
    }

    public void setLogoDescription(int i3) {
        setLogoDescription(getContext().getText(i3));
    }

    public void setNavigationContentDescription(int i3) {
        setNavigationContentDescription(i3 != 0 ? getContext().getText(i3) : null);
    }

    public void setNavigationIcon(int i3) {
        setNavigationIcon(a3.a.G(getContext(), i3));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.f342d.setOnClickListener(onClickListener);
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f339a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i3) {
        if (this.f348k != i3) {
            this.f348k = i3;
            if (i3 == 0) {
                this.f347j = getContext();
            } else {
                this.f347j = new ContextThemeWrapper(getContext(), i3);
            }
        }
    }

    public void setSubtitle(int i3) {
        setSubtitle(getContext().getText(i3));
    }

    public void setSubtitleTextColor(int i3) {
        setSubtitleTextColor(ColorStateList.valueOf(i3));
    }

    public void setTitle(int i3) {
        setTitle(getContext().getText(i3));
    }

    public void setTitleMarginBottom(int i3) {
        this.f356s = i3;
        requestLayout();
    }

    public void setTitleMarginEnd(int i3) {
        this.f354q = i3;
        requestLayout();
    }

    public void setTitleMarginStart(int i3) {
        this.f353p = i3;
        requestLayout();
    }

    public void setTitleMarginTop(int i3) {
        this.f355r = i3;
        requestLayout();
    }

    public void setTitleTextColor(int i3) {
        setTitleTextColor(ColorStateList.valueOf(i3));
    }

    public final boolean t(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public final void u() {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcherA = a3.a(this);
            b3 b3Var = this.L;
            boolean z4 = (b3Var == null || b3Var.f3023b == null || onBackInvokedDispatcherA == null || !isAttachedToWindow() || !this.P) ? false : true;
            if (z4 && this.O == null) {
                if (this.N == null) {
                    this.N = a3.b(new y2(this, 0));
                }
                a3.c(onBackInvokedDispatcherA, this.N);
                this.O = onBackInvokedDispatcherA;
                return;
            }
            if (z4 || (onBackInvokedDispatcher = this.O) == null) {
                return;
            }
            a3.d(onBackInvokedDispatcher, this.N);
            this.O = null;
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i3) {
        super(context, attributeSet, R.attr.toolbarStyle);
        this.f360w = 8388627;
        this.D = new ArrayList();
        this.E = new ArrayList();
        this.F = new int[2];
        this.G = new u(new y2(this, 1));
        this.H = new ArrayList();
        this.I = new z2(this);
        this.Q = new i(14, this);
        Context context2 = getContext();
        int[] iArr = d.a.f1616x;
        u uVarX = u.x(context2, attributeSet, iArr, R.attr.toolbarStyle);
        h0.o(this, context, iArr, attributeSet, (TypedArray) uVarX.f563c, R.attr.toolbarStyle);
        TypedArray typedArray = (TypedArray) uVarX.f563c;
        this.f349l = typedArray.getResourceId(28, 0);
        this.f350m = typedArray.getResourceId(19, 0);
        this.f360w = typedArray.getInteger(0, 8388627);
        this.f351n = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f356s = dimensionPixelOffset;
        this.f355r = dimensionPixelOffset;
        this.f354q = dimensionPixelOffset;
        this.f353p = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f353p = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f354q = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f355r = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f356s = dimensionPixelOffset5;
        }
        this.f352o = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        q2 q2Var = this.f357t;
        q2Var.f3219h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            q2Var.f3217e = dimensionPixelSize;
            q2Var.f3213a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            q2Var.f = dimensionPixelSize2;
            q2Var.f3214b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            q2Var.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f358u = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f359v = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f = uVarX.o(4);
        this.f344g = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f347j = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable drawableO = uVarX.o(16);
        if (drawableO != null) {
            setNavigationIcon(drawableO);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable drawableO2 = uVarX.o(11);
        if (drawableO2 != null) {
            setLogo(drawableO2);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(uVarX.n(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(uVarX.n(20));
        }
        if (typedArray.hasValue(14)) {
            m(typedArray.getResourceId(14, 0));
        }
        uVarX.z();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        c3 c3Var = new c3(context, attributeSet);
        c3Var.f3029a = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, d.a.f1595b);
        c3Var.f3029a = typedArrayObtainStyledAttributes.getInt(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        c3Var.f3030b = 0;
        return c3Var;
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        w wVar = this.f345h;
        if (wVar != null) {
            wVar.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.f345h.setImageDrawable(drawable);
        } else {
            w wVar = this.f345h;
            if (wVar != null) {
                wVar.setImageDrawable(this.f);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f343e == null) {
                this.f343e = new y(getContext(), null, 0);
            }
            if (!o(this.f343e)) {
                b(this.f343e, true);
            }
        } else {
            y yVar = this.f343e;
            if (yVar != null && o(yVar)) {
                removeView(this.f343e);
                this.E.remove(this.f343e);
            }
        }
        y yVar2 = this.f343e;
        if (yVar2 != null) {
            yVar2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f343e == null) {
            this.f343e = new y(getContext(), null, 0);
        }
        y yVar = this.f343e;
        if (yVar != null) {
            yVar.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        w wVar = this.f342d;
        if (wVar != null) {
            wVar.setContentDescription(charSequence);
            i1.m.P(this.f342d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!o(this.f342d)) {
                b(this.f342d, true);
            }
        } else {
            w wVar = this.f342d;
            if (wVar != null && o(wVar)) {
                removeView(this.f342d);
                this.E.remove(this.f342d);
            }
        }
        w wVar2 = this.f342d;
        if (wVar2 != null) {
            wVar2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            a1 a1Var = this.f341c;
            if (a1Var != null && o(a1Var)) {
                removeView(this.f341c);
                this.E.remove(this.f341c);
            }
        } else {
            if (this.f341c == null) {
                Context context = getContext();
                a1 a1Var2 = new a1(context, null);
                this.f341c = a1Var2;
                a1Var2.setSingleLine();
                this.f341c.setEllipsize(TextUtils.TruncateAt.END);
                int i3 = this.f350m;
                if (i3 != 0) {
                    this.f341c.setTextAppearance(context, i3);
                }
                ColorStateList colorStateList = this.A;
                if (colorStateList != null) {
                    this.f341c.setTextColor(colorStateList);
                }
            }
            if (!o(this.f341c)) {
                b(this.f341c, true);
            }
        }
        a1 a1Var3 = this.f341c;
        if (a1Var3 != null) {
            a1Var3.setText(charSequence);
        }
        this.f362y = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.A = colorStateList;
        a1 a1Var = this.f341c;
        if (a1Var != null) {
            a1Var.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            a1 a1Var = this.f340b;
            if (a1Var != null && o(a1Var)) {
                removeView(this.f340b);
                this.E.remove(this.f340b);
            }
        } else {
            if (this.f340b == null) {
                Context context = getContext();
                a1 a1Var2 = new a1(context, null);
                this.f340b = a1Var2;
                a1Var2.setSingleLine();
                this.f340b.setEllipsize(TextUtils.TruncateAt.END);
                int i3 = this.f349l;
                if (i3 != 0) {
                    this.f340b.setTextAppearance(context, i3);
                }
                ColorStateList colorStateList = this.f363z;
                if (colorStateList != null) {
                    this.f340b.setTextColor(colorStateList);
                }
            }
            if (!o(this.f340b)) {
                b(this.f340b, true);
            }
        }
        a1 a1Var3 = this.f340b;
        if (a1Var3 != null) {
            a1Var3.setText(charSequence);
        }
        this.f361x = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f363z = colorStateList;
        a1 a1Var = this.f340b;
        if (a1Var != null) {
            a1Var.setTextColor(colorStateList);
        }
    }

    public void setOnMenuItemClickListener(d3 d3Var) {
    }
}
