package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import d.a;
import l.b;
import l.r2;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f230a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public View f231b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public View f232c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Drawable f233d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Drawable f234e;
    public Drawable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f235g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f236h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f237i;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBackground(new b(this));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f1594a);
        boolean z4 = false;
        this.f233d = typedArrayObtainStyledAttributes.getDrawable(0);
        this.f234e = typedArrayObtainStyledAttributes.getDrawable(2);
        this.f237i = typedArrayObtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.f235g = true;
            this.f = typedArrayObtainStyledAttributes.getDrawable(1);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.f235g ? !(this.f233d != null || this.f234e != null) : this.f == null) {
            z4 = true;
        }
        setWillNotDraw(z4);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f233d;
        if (drawable != null && drawable.isStateful()) {
            this.f233d.setState(getDrawableState());
        }
        Drawable drawable2 = this.f234e;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f234e.setState(getDrawableState());
        }
        Drawable drawable3 = this.f;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f.setState(getDrawableState());
    }

    public View getTabContainer() {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f233d;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f234e;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f231b = findViewById(R.id.action_bar);
        this.f232c = findViewById(R.id.action_context_bar);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f230a || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        super.onLayout(z4, i3, i4, i5, i6);
        boolean z5 = true;
        if (this.f235g) {
            Drawable drawable = this.f;
            if (drawable != null) {
                drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z5 = false;
            }
        } else {
            if (this.f233d == null) {
                z5 = false;
            } else if (this.f231b.getVisibility() == 0) {
                this.f233d.setBounds(this.f231b.getLeft(), this.f231b.getTop(), this.f231b.getRight(), this.f231b.getBottom());
            } else {
                View view = this.f232c;
                if (view == null || view.getVisibility() != 0) {
                    this.f233d.setBounds(0, 0, 0, 0);
                } else {
                    this.f233d.setBounds(this.f232c.getLeft(), this.f232c.getTop(), this.f232c.getRight(), this.f232c.getBottom());
                }
            }
            this.f236h = false;
        }
        if (z5) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i3, int i4) {
        int i5;
        if (this.f231b == null && View.MeasureSpec.getMode(i4) == Integer.MIN_VALUE && (i5 = this.f237i) >= 0) {
            i4 = View.MeasureSpec.makeMeasureSpec(Math.min(i5, View.MeasureSpec.getSize(i4)), Integer.MIN_VALUE);
        }
        super.onMeasure(i3, i4);
        if (this.f231b == null) {
            return;
        }
        View.MeasureSpec.getMode(i4);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f233d;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f233d);
        }
        this.f233d = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f231b;
            if (view != null) {
                this.f233d.setBounds(view.getLeft(), this.f231b.getTop(), this.f231b.getRight(), this.f231b.getBottom());
            }
        }
        boolean z4 = false;
        if (!this.f235g ? !(this.f233d != null || this.f234e != null) : this.f == null) {
            z4 = true;
        }
        setWillNotDraw(z4);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f);
        }
        this.f = drawable;
        boolean z4 = this.f235g;
        boolean z5 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z4 && (drawable2 = this.f) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z4 ? !(this.f233d != null || this.f234e != null) : this.f == null) {
            z5 = true;
        }
        setWillNotDraw(z5);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.f234e;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f234e);
        }
        this.f234e = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f236h && this.f234e != null) {
                throw null;
            }
        }
        boolean z4 = false;
        if (!this.f235g ? !(this.f233d != null || this.f234e != null) : this.f == null) {
            z4 = true;
        }
        setWillNotDraw(z4);
        invalidate();
        invalidateOutline();
    }

    public void setTransitioning(boolean z4) {
        this.f230a = z4;
        setDescendantFocusability(z4 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i3) {
        super.setVisibility(i3);
        boolean z4 = i3 == 0;
        Drawable drawable = this.f233d;
        if (drawable != null) {
            drawable.setVisible(z4, false);
        }
        Drawable drawable2 = this.f234e;
        if (drawable2 != null) {
            drawable2.setVisible(z4, false);
        }
        Drawable drawable3 = this.f;
        if (drawable3 != null) {
            drawable3.setVisible(z4, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.f233d;
        boolean z4 = this.f235g;
        if (drawable == drawable2 && !z4) {
            return true;
        }
        if (drawable == this.f234e && this.f236h) {
            return true;
        }
        return (drawable == this.f && z4) || super.verifyDrawable(drawable);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i3) {
        if (i3 != 0) {
            return super.startActionModeForChild(view, callback, i3);
        }
        return null;
    }

    public void setTabContainer(r2 r2Var) {
    }
}
