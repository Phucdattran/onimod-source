package androidx.appcompat.widget;

import a3.a;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import e.p0;
import e1.t0;
import j.j;
import java.util.WeakHashMap;
import k.m;
import k.x;
import l.b3;
import l.c;
import l.d;
import l.e;
import l.f;
import l.g3;
import l.i1;
import l.j1;
import o0.d1;
import o0.f1;
import o0.h0;
import o0.k;
import o0.l;
import o0.u0;
import o0.v0;
import o0.w0;
import o0.z;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements i1, k, l {
    public static final int[] C = {R.attr.actionBarSize, android.R.attr.windowContentOverlay};
    public static final f1 D;
    public static final Rect E;
    public final t0 A;
    public final f B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f257a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f258b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ContentFrameLayout f259c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ActionBarContainer f260d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public j1 f261e;
    public Drawable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f262g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f263h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f264i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f265j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f266k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f267l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Rect f268m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Rect f269n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Rect f270o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final Rect f271p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public f1 f272q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public f1 f273r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public f1 f274s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public f1 f275t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public d f276u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public OverScroller f277v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public ViewPropertyAnimator f278w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final i1.k f279x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final c f280y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final c f281z;

    static {
        w0 u0Var;
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 30) {
            u0Var = new v0();
        } else {
            u0Var = i3 >= 29 ? new u0() : new o0.t0();
        }
        u0Var.g(g0.c.b(0, 1, 0, 1));
        D = u0Var.b();
        E = new Rect();
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f258b = 0;
        this.f268m = new Rect();
        this.f269n = new Rect();
        this.f270o = new Rect();
        this.f271p = new Rect();
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        f1 f1Var = f1.f3544b;
        this.f272q = f1Var;
        this.f273r = f1Var;
        this.f274s = f1Var;
        this.f275t = f1Var;
        this.f279x = new i1.k(2, this);
        this.f280y = new c(this, 0);
        this.f281z = new c(this, 1);
        i(context);
        this.A = new t0();
        f fVar = new f(context);
        fVar.setWillNotDraw(true);
        this.B = fVar;
        addView(fVar);
    }

    public static boolean g(View view, Rect rect, boolean z4) {
        boolean z5;
        e eVar = (e) view.getLayoutParams();
        int i3 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin;
        int i4 = rect.left;
        if (i3 != i4) {
            ((ViewGroup.MarginLayoutParams) eVar).leftMargin = i4;
            z5 = true;
        } else {
            z5 = false;
        }
        int i5 = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
        int i6 = rect.top;
        if (i5 != i6) {
            ((ViewGroup.MarginLayoutParams) eVar).topMargin = i6;
            z5 = true;
        }
        int i7 = ((ViewGroup.MarginLayoutParams) eVar).rightMargin;
        int i8 = rect.right;
        if (i7 != i8) {
            ((ViewGroup.MarginLayoutParams) eVar).rightMargin = i8;
            z5 = true;
        }
        if (z4) {
            int i9 = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
            int i10 = rect.bottom;
            if (i9 != i10) {
                ((ViewGroup.MarginLayoutParams) eVar).bottomMargin = i10;
                return true;
            }
        }
        return z5;
    }

    @Override // o0.l
    public final void a(View view, int i3, int i4, int i5, int i6, int i7, int[] iArr) {
        b(view, i3, i4, i5, i6, i7);
    }

    @Override // o0.k
    public final void b(View view, int i3, int i4, int i5, int i6, int i7) {
        if (i7 == 0) {
            onNestedScroll(view, i3, i4, i5, i6);
        }
    }

    @Override // o0.k
    public final boolean c(View view, View view2, int i3, int i4) {
        return i4 == 0 && onStartNestedScroll(view, view2, i3);
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    @Override // o0.k
    public final void d(View view, View view2, int i3, int i4) {
        if (i4 == 0) {
            onNestedScrollAccepted(view, view2, i3);
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int translationY;
        super.draw(canvas);
        if (this.f != null) {
            if (this.f260d.getVisibility() == 0) {
                translationY = (int) (this.f260d.getTranslationY() + this.f260d.getBottom() + 0.5f);
            } else {
                translationY = 0;
            }
            this.f.setBounds(0, translationY, getWidth(), this.f.getIntrinsicHeight() + translationY);
            this.f.draw(canvas);
        }
    }

    @Override // o0.k
    public final void e(View view, int i3) {
        if (i3 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // o0.k
    public final void f(View view, int i3, int i4, int[] iArr, int i5) {
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f260d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        t0 t0Var = this.A;
        return t0Var.f2069b | t0Var.f2068a;
    }

    public CharSequence getTitle() {
        k();
        return ((g3) this.f261e).f3087a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.f280y);
        removeCallbacks(this.f281z);
        ViewPropertyAnimator viewPropertyAnimator = this.f278w;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(C);
        this.f257a = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.f277v = new OverScroller(context);
    }

    public final void j(int i3) {
        k();
        if (i3 == 2) {
            this.f261e.getClass();
        } else if (i3 == 5) {
            this.f261e.getClass();
        } else {
            if (i3 != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    public final void k() {
        j1 wrapper;
        if (this.f259c == null) {
            this.f259c = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.f260d = (ActionBarContainer) findViewById(R.id.action_bar_container);
            KeyEvent.Callback callbackFindViewById = findViewById(R.id.action_bar);
            if (callbackFindViewById instanceof j1) {
                wrapper = (j1) callbackFindViewById;
            } else {
                if (!(callbackFindViewById instanceof Toolbar)) {
                    throw new IllegalStateException("Can't make a decor toolbar out of ".concat(callbackFindViewById.getClass().getSimpleName()));
                }
                wrapper = ((Toolbar) callbackFindViewById).getWrapper();
            }
            this.f261e = wrapper;
        }
    }

    public final void l(Menu menu, x xVar) {
        k();
        g3 g3Var = (g3) this.f261e;
        Toolbar toolbar = g3Var.f3087a;
        if (g3Var.f3098m == null) {
            g3Var.f3098m = new l.k(toolbar.getContext());
        }
        l.k kVar = g3Var.f3098m;
        kVar.f3132e = xVar;
        m mVar = (m) menu;
        if (mVar == null && toolbar.f339a == null) {
            return;
        }
        toolbar.f();
        m mVar2 = toolbar.f339a.f282p;
        if (mVar2 == mVar) {
            return;
        }
        if (mVar2 != null) {
            mVar2.r(toolbar.K);
            mVar2.r(toolbar.L);
        }
        if (toolbar.L == null) {
            toolbar.L = new b3(toolbar);
        }
        kVar.f3143q = true;
        if (mVar != null) {
            mVar.b(kVar, toolbar.f347j);
            mVar.b(toolbar.L, toolbar.f347j);
        } else {
            kVar.k(toolbar.f347j, null);
            toolbar.L.k(toolbar.f347j, null);
            kVar.i();
            toolbar.L.i();
        }
        toolbar.f339a.setPopupTheme(toolbar.f348k);
        toolbar.f339a.setPresenter(kVar);
        toolbar.K = kVar;
        toolbar.u();
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        k();
        f1 f1VarG = f1.g(this, windowInsets);
        boolean zG = g(this.f260d, new Rect(f1VarG.b(), f1VarG.d(), f1VarG.c(), f1VarG.a()), false);
        WeakHashMap weakHashMap = h0.f3558a;
        Rect rect = this.f268m;
        z.b(this, f1VarG, rect);
        int i3 = rect.left;
        int i4 = rect.top;
        int i5 = rect.right;
        int i6 = rect.bottom;
        d1 d1Var = f1VarG.f3545a;
        f1 f1VarL = d1Var.l(i3, i4, i5, i6);
        this.f272q = f1VarL;
        boolean z4 = true;
        if (!this.f273r.equals(f1VarL)) {
            this.f273r = this.f272q;
            zG = true;
        }
        Rect rect2 = this.f269n;
        if (rect2.equals(rect)) {
            z4 = zG;
        } else {
            rect2.set(rect);
        }
        if (z4) {
            requestLayout();
        }
        return d1Var.a().f3545a.c().f3545a.b().f();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        WeakHashMap weakHashMap = h0.f3558a;
        o0.x.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i8 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin + paddingLeft;
                int i9 = ((ViewGroup.MarginLayoutParams) eVar).topMargin + paddingTop;
                childAt.layout(i8, i9, measuredWidth + i8, measuredHeight + i9);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:22:0x00aa  */
    /* JADX WARN: Code duplicated, block: B:24:0x00cf  */
    /* JADX WARN: Code duplicated, block: B:25:0x00d5  */
    /* JADX WARN: Code duplicated, block: B:27:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:28:0x00df  */
    @Override // android.view.View
    public final void onMeasure(int i3, int i4) {
        int measuredHeight;
        f1 f1Var;
        int i5;
        w0 t0Var;
        k();
        measureChildWithMargins(this.f260d, i3, 0, i4, 0);
        e eVar = (e) this.f260d.getLayoutParams();
        int iMax = Math.max(0, this.f260d.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin + ((ViewGroup.MarginLayoutParams) eVar).rightMargin);
        int iMax2 = Math.max(0, this.f260d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar).topMargin + ((ViewGroup.MarginLayoutParams) eVar).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.f260d.getMeasuredState());
        WeakHashMap weakHashMap = h0.f3558a;
        boolean z4 = (getWindowSystemUiVisibility() & 256) != 0;
        if (z4) {
            measuredHeight = this.f257a;
            if (this.f263h && this.f260d.getTabContainer() != null) {
                measuredHeight += this.f257a;
            }
        } else {
            measuredHeight = this.f260d.getVisibility() != 8 ? this.f260d.getMeasuredHeight() : 0;
        }
        Rect rect = this.f268m;
        Rect rect2 = this.f270o;
        rect2.set(rect);
        this.f274s = this.f272q;
        if (this.f262g || z4) {
            g0.c cVarB = g0.c.b(this.f274s.b(), this.f274s.d() + measuredHeight, this.f274s.c(), this.f274s.a());
            f1Var = this.f274s;
            i5 = Build.VERSION.SDK_INT;
            if (i5 >= 30) {
                t0Var = new v0(f1Var);
            } else if (i5 >= 29) {
                t0Var = new u0(f1Var);
            } else {
                t0Var = new o0.t0(f1Var);
            }
            t0Var.g(cVarB);
            this.f274s = t0Var.b();
        } else {
            f fVar = this.B;
            f1 f1Var2 = D;
            Rect rect3 = this.f271p;
            z.b(fVar, f1Var2, rect3);
            if (rect3.equals(E)) {
                g0.c cVarB2 = g0.c.b(this.f274s.b(), this.f274s.d() + measuredHeight, this.f274s.c(), this.f274s.a());
                f1Var = this.f274s;
                i5 = Build.VERSION.SDK_INT;
                if (i5 >= 30) {
                    t0Var = new v0(f1Var);
                } else if (i5 >= 29) {
                    t0Var = new u0(f1Var);
                } else {
                    t0Var = new o0.t0(f1Var);
                }
                t0Var.g(cVarB2);
                this.f274s = t0Var.b();
            } else {
                rect2.top += measuredHeight;
                rect2.bottom = rect2.bottom;
                this.f274s = this.f274s.f3545a.l(0, measuredHeight, 0, 0);
            }
        }
        g(this.f259c, rect2, true);
        if (!this.f275t.equals(this.f274s)) {
            f1 f1Var3 = this.f274s;
            this.f275t = f1Var3;
            ContentFrameLayout contentFrameLayout = this.f259c;
            WindowInsets windowInsetsF = f1Var3.f();
            if (windowInsetsF != null) {
                WindowInsets windowInsetsA = o0.x.a(contentFrameLayout, windowInsetsF);
                if (!windowInsetsA.equals(windowInsetsF)) {
                    f1.g(contentFrameLayout, windowInsetsA);
                }
            }
        }
        measureChildWithMargins(this.f259c, i3, 0, i4, 0);
        e eVar2 = (e) this.f259c.getLayoutParams();
        int iMax3 = Math.max(iMax, this.f259c.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar2).leftMargin + ((ViewGroup.MarginLayoutParams) eVar2).rightMargin);
        int iMax4 = Math.max(iMax2, this.f259c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar2).topMargin + ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f259c.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + iMax3, getSuggestedMinimumWidth()), i3, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + iMax4, getSuggestedMinimumHeight()), i4, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f4, boolean z4) {
        if (!this.f264i || !z4) {
            return false;
        }
        this.f277v.fling(0, 0, 0, (int) f4, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f277v.getFinalY() > this.f260d.getHeight()) {
            h();
            this.f281z.run();
        } else {
            h();
            this.f280y.run();
        }
        this.f265j = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f4) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i3, int i4, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i3, int i4, int i5, int i6) {
        int i7 = this.f266k + i4;
        this.f266k = i7;
        setActionBarHideOffset(i7);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i3) {
        p0 p0Var;
        j jVar;
        this.A.f2068a = i3;
        this.f266k = getActionBarHideOffset();
        h();
        d dVar = this.f276u;
        if (dVar == null || (jVar = (p0Var = (p0) dVar).G) == null) {
            return;
        }
        jVar.a();
        p0Var.G = null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i3) {
        if ((i3 & 2) == 0 || this.f260d.getVisibility() != 0) {
            return false;
        }
        return this.f264i;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.f264i || this.f265j) {
            return;
        }
        if (this.f266k <= this.f260d.getHeight()) {
            h();
            postDelayed(this.f280y, 600L);
        } else {
            h();
            postDelayed(this.f281z, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i3) {
        super.onWindowSystemUiVisibilityChanged(i3);
        k();
        int i4 = this.f267l ^ i3;
        this.f267l = i3;
        boolean z4 = (i3 & 4) == 0;
        boolean z5 = (i3 & 256) != 0;
        d dVar = this.f276u;
        if (dVar != null) {
            p0 p0Var = (p0) dVar;
            p0Var.C = !z5;
            if (z4 || !z5) {
                if (p0Var.D) {
                    p0Var.D = false;
                    p0Var.q0(true);
                }
            } else if (!p0Var.D) {
                p0Var.D = true;
                p0Var.q0(true);
            }
        }
        if ((i4 & 256) == 0 || this.f276u == null) {
            return;
        }
        WeakHashMap weakHashMap = h0.f3558a;
        o0.x.c(this);
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i3) {
        super.onWindowVisibilityChanged(i3);
        this.f258b = i3;
        d dVar = this.f276u;
        if (dVar != null) {
            ((p0) dVar).B = i3;
        }
    }

    public void setActionBarHideOffset(int i3) {
        h();
        this.f260d.setTranslationY(-Math.max(0, Math.min(i3, this.f260d.getHeight())));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.f276u = dVar;
        if (getWindowToken() != null) {
            ((p0) this.f276u).B = this.f258b;
            int i3 = this.f267l;
            if (i3 != 0) {
                onWindowSystemUiVisibilityChanged(i3);
                WeakHashMap weakHashMap = h0.f3558a;
                o0.x.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z4) {
        this.f263h = z4;
    }

    public void setHideOnContentScrollEnabled(boolean z4) {
        if (z4 != this.f264i) {
            this.f264i = z4;
            if (z4) {
                return;
            }
            h();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i3) {
        k();
        g3 g3Var = (g3) this.f261e;
        g3Var.f3090d = i3 != 0 ? a.G(g3Var.f3087a.getContext(), i3) : null;
        g3Var.c();
    }

    public void setLogo(int i3) {
        k();
        g3 g3Var = (g3) this.f261e;
        g3Var.f3091e = i3 != 0 ? a.G(g3Var.f3087a.getContext(), i3) : null;
        g3Var.c();
    }

    public void setOverlayMode(boolean z4) {
        this.f262g = z4;
    }

    public void setShowingForActionMode(boolean z4) {
    }

    public void setUiOptions(int i3) {
    }

    @Override // l.i1
    public void setWindowCallback(Window.Callback callback) {
        k();
        ((g3) this.f261e).f3096k = callback;
    }

    @Override // l.i1
    public void setWindowTitle(CharSequence charSequence) {
        k();
        g3 g3Var = (g3) this.f261e;
        if (g3Var.f3092g) {
            return;
        }
        Toolbar toolbar = g3Var.f3087a;
        g3Var.f3093h = charSequence;
        if ((g3Var.f3088b & 8) != 0) {
            toolbar.setTitle(charSequence);
            if (g3Var.f3092g) {
                h0.q(toolbar.getRootView(), charSequence);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new e(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        k();
        g3 g3Var = (g3) this.f261e;
        g3Var.f3090d = drawable;
        g3Var.c();
    }
}
