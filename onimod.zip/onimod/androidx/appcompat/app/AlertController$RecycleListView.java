package androidx.appcompat.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ListView;
import d.a;

/* JADX INFO: loaded from: classes.dex */
public class AlertController$RecycleListView extends ListView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f199a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f200b;

    public AlertController$RecycleListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f1612t);
        this.f200b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, -1);
        this.f199a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, -1);
    }
}
