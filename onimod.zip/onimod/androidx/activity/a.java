package androidx.activity;

import android.window.BackEvent;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f120a = new a();

    public final BackEvent a(float f, float f4, float f5, int i3) {
        return new BackEvent(f, f4, f5, i3);
    }

    public final float b(BackEvent backEvent) {
        kotlin.jvm.internal.d.f(backEvent, "backEvent");
        return backEvent.getProgress();
    }

    public final int c(BackEvent backEvent) {
        kotlin.jvm.internal.d.f(backEvent, "backEvent");
        return backEvent.getSwipeEdge();
    }

    public final float d(BackEvent backEvent) {
        kotlin.jvm.internal.d.f(backEvent, "backEvent");
        return backEvent.getTouchX();
    }

    public final float e(BackEvent backEvent) {
        kotlin.jvm.internal.d.f(backEvent, "backEvent");
        return backEvent.getTouchY();
    }
}
