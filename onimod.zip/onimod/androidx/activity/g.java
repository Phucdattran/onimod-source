package androidx.activity;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.fragment.app.z;

/* JADX INFO: loaded from: classes.dex */
public final class g extends androidx.activity.result.h {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ z f130h;

    public g(z zVar) {
        this.f130h = zVar;
    }

    @Override // androidx.activity.result.h
    public final void b(int i3, a3.a aVar, Cloneable cloneable) {
        Bundle bundleExtra;
        int i4;
        z zVar = this.f130h;
        b.a aVarJ = aVar.J(zVar, cloneable);
        if (aVarJ != null) {
            new Handler(Looper.getMainLooper()).post(new a2.c(this, i3, aVarJ, 1));
            return;
        }
        Intent intentX = aVar.x(zVar, cloneable);
        if (intentX.getExtras() != null && intentX.getExtras().getClassLoader() == null) {
            intentX.setExtrasClassLoader(zVar.getClassLoader());
        }
        if (intentX.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
            bundleExtra = intentX.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
            intentX.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        } else {
            bundleExtra = null;
        }
        Bundle bundle = bundleExtra;
        if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intentX.getAction())) {
            String[] stringArrayExtra = intentX.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
            if (stringArrayExtra == null) {
                stringArrayExtra = new String[0];
            }
            c0.g.i(zVar, stringArrayExtra, i3);
            return;
        }
        if (!"androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(intentX.getAction())) {
            zVar.startActivityForResult(intentX, i3, bundle);
            return;
        }
        androidx.activity.result.i iVar = (androidx.activity.result.i) intentX.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
            i4 = i3;
            try {
                zVar.startIntentSenderForResult(iVar.f187a, i4, iVar.f188b, iVar.f189c, iVar.f190d, 0, bundle);
            } catch (IntentSender.SendIntentException e4) {
                e = e4;
                new Handler(Looper.getMainLooper()).post(new a2.c(this, i4, e, 2));
            }
        } catch (IntentSender.SendIntentException e5) {
            e = e5;
            i4 = i3;
        }
    }
}
