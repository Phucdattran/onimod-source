package androidx.activity;

import android.os.Bundle;
import androidx.fragment.app.y;
import androidx.fragment.app.z;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class f implements a.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f128a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ z f129b;

    public /* synthetic */ f(z zVar, int i3) {
        this.f128a = i3;
        this.f129b = zVar;
    }

    @Override // a.b
    public final void a() {
        switch (this.f128a) {
            case 0:
                z zVar = this.f129b;
                Bundle bundleC = ((f1.d) zVar.f139e.f157c).c("android:support:activity-result");
                if (bundleC != null) {
                    g gVar = zVar.f144k;
                    HashMap map = gVar.f182b;
                    HashMap map2 = gVar.f181a;
                    Bundle bundle = gVar.f186g;
                    ArrayList<Integer> integerArrayList = bundleC.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
                    ArrayList<String> stringArrayList = bundleC.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
                    if (stringArrayList != null && integerArrayList != null) {
                        gVar.f184d = bundleC.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                        bundle.putAll(bundleC.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
                        for (int i3 = 0; i3 < stringArrayList.size(); i3++) {
                            String str = stringArrayList.get(i3);
                            if (map.containsKey(str)) {
                                Integer num = (Integer) map.remove(str);
                                if (!bundle.containsKey(str)) {
                                    map2.remove(num);
                                }
                            }
                            Integer num2 = integerArrayList.get(i3);
                            num2.intValue();
                            String str2 = stringArrayList.get(i3);
                            map2.put(num2, str2);
                            gVar.f182b.put(str2, num2);
                        }
                        break;
                    }
                }
                break;
            default:
                y yVar = (y) ((e.n) this.f129b).f814s.f3b;
                yVar.f809r.b(yVar, yVar, null);
                break;
        }
    }
}
