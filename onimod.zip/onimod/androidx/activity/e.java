package androidx.activity;

import android.os.Bundle;
import androidx.fragment.app.o0;
import androidx.fragment.app.y;
import androidx.fragment.app.z;
import androidx.lifecycle.Lifecycle$Event;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class e implements f1.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f126a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f127b;

    public /* synthetic */ e(int i3, Object obj) {
        this.f126a = i3;
        this.f127b = obj;
    }

    @Override // f1.c
    public final Bundle a() {
        switch (this.f126a) {
            case 0:
                z zVar = (z) this.f127b;
                Bundle bundle = new Bundle();
                g gVar = zVar.f144k;
                gVar.getClass();
                HashMap map = gVar.f182b;
                bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(map.values()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(map.keySet()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(gVar.f184d));
                bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) gVar.f186g.clone());
                return bundle;
            case 1:
                e.n nVar = (e.n) this.f127b;
                while (z.j(((y) nVar.f814s.f3b).f809r)) {
                }
                nVar.f815t.d(Lifecycle$Event.ON_STOP);
                return new Bundle();
            default:
                return ((o0) this.f127b).T();
        }
    }
}
