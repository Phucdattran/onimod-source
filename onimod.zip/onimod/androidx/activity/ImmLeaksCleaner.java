package androidx.activity;

import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.fragment.app.z;
import androidx.lifecycle.Lifecycle$Event;
import java.lang.reflect.Field;

/* JADX INFO: loaded from: classes.dex */
final class ImmLeaksCleaner implements androidx.lifecycle.o {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static int f111b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Field f112c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static Field f113d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Field f114e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public z f115a;

    @Override // androidx.lifecycle.o
    public final void a(androidx.lifecycle.q qVar, Lifecycle$Event lifecycle$Event) {
        if (lifecycle$Event != Lifecycle$Event.ON_DESTROY) {
            return;
        }
        if (f111b == 0) {
            try {
                f111b = 2;
                Field declaredField = InputMethodManager.class.getDeclaredField("mServedView");
                f113d = declaredField;
                declaredField.setAccessible(true);
                Field declaredField2 = InputMethodManager.class.getDeclaredField("mNextServedView");
                f114e = declaredField2;
                declaredField2.setAccessible(true);
                Field declaredField3 = InputMethodManager.class.getDeclaredField("mH");
                f112c = declaredField3;
                declaredField3.setAccessible(true);
                f111b = 1;
            } catch (NoSuchFieldException unused) {
            }
        }
        if (f111b == 1) {
            InputMethodManager inputMethodManager = (InputMethodManager) this.f115a.getSystemService("input_method");
            try {
                Object obj = f112c.get(inputMethodManager);
                if (obj == null) {
                    return;
                }
                synchronized (obj) {
                    try {
                        try {
                            View view = (View) f113d.get(inputMethodManager);
                            if (view != null) {
                                if (!view.isAttachedToWindow()) {
                                    try {
                                        f114e.set(inputMethodManager, null);
                                        inputMethodManager.isActive();
                                    } catch (IllegalAccessException unused2) {
                                    }
                                }
                            }
                        } catch (ClassCastException unused3) {
                        } catch (IllegalAccessException unused4) {
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            } catch (IllegalAccessException unused5) {
            }
        }
    }
}
