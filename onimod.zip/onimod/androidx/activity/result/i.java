package androidx.activity.result;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class i implements Parcelable {
    public static final Parcelable.Creator<i> CREATOR = new a(1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final IntentSender f187a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Intent f188b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f189c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f190d;

    public i(IntentSender intentSender, Intent intent, int i3, int i4) {
        this.f187a = intentSender;
        this.f188b = intent;
        this.f189c = i3;
        this.f190d = i4;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel dest, int i3) {
        kotlin.jvm.internal.d.f(dest, "dest");
        dest.writeParcelable(this.f187a, i3);
        dest.writeParcelable(this.f188b, i3);
        dest.writeInt(this.f189c);
        dest.writeInt(this.f190d);
    }
}
