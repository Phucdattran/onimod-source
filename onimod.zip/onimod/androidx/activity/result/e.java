package androidx.activity.result;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class e extends d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f173a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f174b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ a3.a f175c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ h f176d;

    public /* synthetic */ e(h hVar, String str, a3.a aVar, int i3) {
        this.f173a = i3;
        this.f176d = hVar;
        this.f174b = str;
        this.f175c = aVar;
    }

    @Override // androidx.activity.result.d
    public final void a(Object obj) throws Exception {
        switch (this.f173a) {
            case 0:
                h hVar = this.f176d;
                HashMap map = hVar.f182b;
                String str = this.f174b;
                Integer num = (Integer) map.get(str);
                a3.a aVar = this.f175c;
                if (num != null) {
                    hVar.f184d.add(str);
                    try {
                        hVar.b(num.intValue(), aVar, (Cloneable) obj);
                        return;
                    } catch (Exception e4) {
                        hVar.f184d.remove(str);
                        throw e4;
                    }
                }
                throw new IllegalStateException("Attempting to launch an unregistered ActivityResultLauncher with contract " + aVar + " and input " + obj + ". You must ensure the ActivityResultLauncher is registered before calling launch().");
            default:
                h hVar2 = this.f176d;
                HashMap map2 = hVar2.f182b;
                String str2 = this.f174b;
                Integer num2 = (Integer) map2.get(str2);
                a3.a aVar2 = this.f175c;
                if (num2 != null) {
                    hVar2.f184d.add(str2);
                    try {
                        hVar2.b(num2.intValue(), aVar2, (Cloneable) obj);
                        return;
                    } catch (Exception e5) {
                        hVar2.f184d.remove(str2);
                        throw e5;
                    }
                }
                throw new IllegalStateException("Attempting to launch an unregistered ActivityResultLauncher with contract " + aVar2 + " and input " + obj + ". You must ensure the ActivityResultLauncher is registered before calling launch().");
        }
    }

    public void b() {
        this.f176d.f(this.f174b);
    }
}
