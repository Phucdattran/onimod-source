package androidx.activity.result;

/* JADX INFO: loaded from: classes.dex */
public abstract class d {
    public abstract void a(Object obj);
}
