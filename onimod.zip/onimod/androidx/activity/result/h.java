package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import androidx.lifecycle.Lifecycle$Event;
import androidx.lifecycle.Lifecycle$State;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import androidx.lifecycle.s;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public abstract class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f181a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f182b = new HashMap();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final HashMap f183c = new HashMap();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList f184d = new ArrayList();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final transient HashMap f185e = new HashMap();
    public final HashMap f = new HashMap();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Bundle f186g = new Bundle();

    public final boolean a(int i3, int i4, Intent intent) {
        String str = (String) this.f181a.get(Integer.valueOf(i3));
        if (str == null) {
            return false;
        }
        f fVar = (f) this.f185e.get(str);
        if (fVar != null) {
            c cVar = fVar.f177a;
            if (this.f184d.contains(str)) {
                cVar.a(fVar.f178b.X(i4, intent));
                this.f184d.remove(str);
                return true;
            }
        }
        this.f.remove(str);
        this.f186g.putParcelable(str, new b(i4, intent));
        return true;
    }

    public abstract void b(int i3, a3.a aVar, Cloneable cloneable);

    public final e c(String str, a3.a aVar, c cVar) {
        e(str);
        this.f185e.put(str, new f(cVar, aVar));
        HashMap map = this.f;
        if (map.containsKey(str)) {
            Object obj = map.get(str);
            map.remove(str);
            cVar.a(obj);
        }
        Bundle bundle = this.f186g;
        b bVar = (b) bundle.getParcelable(str);
        if (bVar != null) {
            bundle.remove(str);
            cVar.a(aVar.X(bVar.f171a, bVar.f172b));
        }
        return new e(this, str, aVar, 1);
    }

    public final e d(final String str, q qVar, final a3.a aVar, final c cVar) {
        s sVarE = qVar.e();
        if (sVarE.f879c.compareTo(Lifecycle$State.f832d) >= 0) {
            throw new IllegalStateException("LifecycleOwner " + qVar + " is attempting to register while current state is " + sVarE.f879c + ". LifecycleOwners must call register before they are STARTED.");
        }
        e(str);
        HashMap map = this.f183c;
        g gVar = (g) map.get(str);
        if (gVar == null) {
            gVar = new g(sVarE);
        }
        o oVar = new o() { // from class: androidx.activity.result.ActivityResultRegistry$1
            @Override // androidx.lifecycle.o
            public final void a(q qVar2, Lifecycle$Event lifecycle$Event) {
                boolean zEquals = Lifecycle$Event.ON_START.equals(lifecycle$Event);
                String str2 = str;
                h hVar = this.f169d;
                if (!zEquals) {
                    if (Lifecycle$Event.ON_STOP.equals(lifecycle$Event)) {
                        hVar.f185e.remove(str2);
                        return;
                    } else {
                        if (Lifecycle$Event.ON_DESTROY.equals(lifecycle$Event)) {
                            hVar.f(str2);
                            return;
                        }
                        return;
                    }
                }
                HashMap map2 = hVar.f185e;
                Bundle bundle = hVar.f186g;
                HashMap map3 = hVar.f;
                c cVar2 = cVar;
                a3.a aVar2 = aVar;
                map2.put(str2, new f(cVar2, aVar2));
                if (map3.containsKey(str2)) {
                    Object obj = map3.get(str2);
                    map3.remove(str2);
                    cVar2.a(obj);
                }
                b bVar = (b) bundle.getParcelable(str2);
                if (bVar != null) {
                    bundle.remove(str2);
                    cVar2.a(aVar2.X(bVar.f171a, bVar.f172b));
                }
            }
        };
        gVar.f179a.a(oVar);
        gVar.f180b.add(oVar);
        map.put(str, gVar);
        return new e(this, str, aVar, 0);
    }

    public final void e(String str) {
        HashMap map = this.f182b;
        if (((Integer) map.get(str)) != null) {
            return;
        }
        k3.d.f2817a.getClass();
        int iNextInt = k3.d.f2818b.a().nextInt(2147418112);
        while (true) {
            int i3 = iNextInt + 65536;
            Integer numValueOf = Integer.valueOf(i3);
            HashMap map2 = this.f181a;
            if (!map2.containsKey(numValueOf)) {
                map2.put(Integer.valueOf(i3), str);
                map.put(str, Integer.valueOf(i3));
                return;
            } else {
                k3.d.f2817a.getClass();
                iNextInt = k3.d.f2818b.a().nextInt(2147418112);
            }
        }
    }

    public final void f(String str) {
        Integer num;
        if (!this.f184d.contains(str) && (num = (Integer) this.f182b.remove(str)) != null) {
            this.f181a.remove(num);
        }
        this.f185e.remove(str);
        HashMap map = this.f;
        if (map.containsKey(str)) {
            Objects.toString(map.get(str));
            map.remove(str);
        }
        Bundle bundle = this.f186g;
        if (bundle.containsKey(str)) {
            Objects.toString(bundle.getParcelable(str));
            bundle.remove(str);
        }
        HashMap map2 = this.f183c;
        g gVar = (g) map2.get(str);
        if (gVar != null) {
            ArrayList arrayList = gVar.f180b;
            int size = arrayList.size();
            int i3 = 0;
            while (i3 < size) {
                Object obj = arrayList.get(i3);
                i3++;
                gVar.f179a.f((o) obj);
            }
            arrayList.clear();
            map2.remove(str);
        }
    }
}
