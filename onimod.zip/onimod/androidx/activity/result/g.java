package androidx.activity.result;

import androidx.lifecycle.s;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final s f179a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f180b = new ArrayList();

    public g(s sVar) {
        this.f179a = sVar;
    }
}
