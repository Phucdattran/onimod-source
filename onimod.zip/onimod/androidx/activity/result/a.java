package androidx.activity.result;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.fragment.app.l0;
import androidx.fragment.app.p0;
import androidx.fragment.app.s0;
import androidx.versionedparcelable.ParcelImpl;
import com.google.android.material.datepicker.p;
import e1.i0;
import e1.u1;
import e1.v1;
import java.util.ArrayList;
import l.n0;
import top.niunaijun.blackbox.core.system.JarConfig;
import top.niunaijun.blackbox.entity.location.BCell;

/* JADX INFO: loaded from: classes.dex */
public final class a implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f170a;

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel inParcel) {
        switch (this.f170a) {
            case 0:
                return new b(inParcel);
            case 1:
                kotlin.jvm.internal.d.f(inParcel, "inParcel");
                Parcelable parcelable = inParcel.readParcelable(IntentSender.class.getClassLoader());
                kotlin.jvm.internal.d.c(parcelable);
                return new i((IntentSender) parcelable, (Intent) inParcel.readParcelable(Intent.class.getClassLoader()), inParcel.readInt(), inParcel.readInt());
            case 2:
                return new androidx.fragment.app.b(inParcel);
            case 3:
                return new androidx.fragment.app.c(inParcel);
            case 4:
                l0 l0Var = new l0();
                l0Var.f670a = inParcel.readString();
                l0Var.f671b = inParcel.readInt();
                return l0Var;
            case 5:
                p0 p0Var = new p0();
                p0Var.f715e = null;
                p0Var.f = new ArrayList();
                p0Var.f716g = new ArrayList();
                p0Var.f711a = inParcel.createStringArrayList();
                p0Var.f712b = inParcel.createStringArrayList();
                p0Var.f713c = (androidx.fragment.app.b[]) inParcel.createTypedArray(androidx.fragment.app.b.CREATOR);
                p0Var.f714d = inParcel.readInt();
                p0Var.f715e = inParcel.readString();
                p0Var.f = inParcel.createStringArrayList();
                p0Var.f716g = inParcel.createTypedArrayList(androidx.fragment.app.c.CREATOR);
                p0Var.f717h = inParcel.createTypedArrayList(l0.CREATOR);
                return p0Var;
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                return new s0(inParcel);
            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                return new com.google.android.material.datepicker.b((p) inParcel.readParcelable(p.class.getClassLoader()), (p) inParcel.readParcelable(p.class.getClassLoader()), (com.google.android.material.datepicker.d) inParcel.readParcelable(com.google.android.material.datepicker.d.class.getClassLoader()), (p) inParcel.readParcelable(p.class.getClassLoader()), inParcel.readInt());
            case 8:
                return new com.google.android.material.datepicker.d(inParcel.readLong());
            case 9:
                return p.a(inParcel.readInt(), inParcel.readInt());
            case JarConfig.MAX_CACHE_SIZE /* 10 */:
                i0 i0Var = new i0();
                i0Var.f1916a = inParcel.readInt();
                i0Var.f1917b = inParcel.readInt();
                i0Var.f1918c = inParcel.readInt() == 1;
                return i0Var;
            case 11:
                u1 u1Var = new u1();
                u1Var.f2080a = inParcel.readInt();
                u1Var.f2081b = inParcel.readInt();
                u1Var.f2083d = inParcel.readInt() == 1;
                int i3 = inParcel.readInt();
                if (i3 > 0) {
                    int[] iArr = new int[i3];
                    u1Var.f2082c = iArr;
                    inParcel.readIntArray(iArr);
                }
                return u1Var;
            case 12:
                v1 v1Var = new v1();
                v1Var.f2089a = inParcel.readInt();
                v1Var.f2090b = inParcel.readInt();
                int i4 = inParcel.readInt();
                v1Var.f2091c = i4;
                if (i4 > 0) {
                    int[] iArr2 = new int[i4];
                    v1Var.f2092d = iArr2;
                    inParcel.readIntArray(iArr2);
                }
                int i5 = inParcel.readInt();
                v1Var.f2093e = i5;
                if (i5 > 0) {
                    int[] iArr3 = new int[i5];
                    v1Var.f = iArr3;
                    inParcel.readIntArray(iArr3);
                }
                v1Var.f2095h = inParcel.readInt() == 1;
                v1Var.f2096i = inParcel.readInt() == 1;
                v1Var.f2097j = inParcel.readInt() == 1;
                v1Var.f2094g = inParcel.readArrayList(u1.class.getClassLoader());
                return v1Var;
            case 13:
                e2.a aVar = new e2.a(inParcel);
                aVar.f2159a = ((Integer) inParcel.readValue(e2.a.class.getClassLoader())).intValue();
                return aVar;
            case 14:
                return new ParcelImpl(inParcel);
            case 15:
                n0 n0Var = new n0(inParcel);
                n0Var.f3174a = inParcel.readByte() != 0;
                return n0Var;
            default:
                r0.g gVar = new r0.g(inParcel);
                gVar.f3788a = inParcel.readInt();
                return gVar;
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i3) {
        switch (this.f170a) {
            case 0:
                return new b[i3];
            case 1:
                return new i[i3];
            case 2:
                return new androidx.fragment.app.b[i3];
            case 3:
                return new androidx.fragment.app.c[i3];
            case 4:
                return new l0[i3];
            case 5:
                return new p0[i3];
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                return new s0[i3];
            case BCell.NETWORK_TYPE_1xRTT /* 7 */:
                return new com.google.android.material.datepicker.b[i3];
            case 8:
                return new com.google.android.material.datepicker.d[i3];
            case 9:
                return new p[i3];
            case JarConfig.MAX_CACHE_SIZE /* 10 */:
                return new i0[i3];
            case 11:
                return new u1[i3];
            case 12:
                return new v1[i3];
            case 13:
                return new e2.a[i3];
            case 14:
                return new ParcelImpl[i3];
            case 15:
                return new n0[i3];
            default:
                return new r0.g[i3];
        }
    }
}
