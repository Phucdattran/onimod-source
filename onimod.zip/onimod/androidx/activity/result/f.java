package androidx.activity.result;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f177a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a3.a f178b;

    public f(c cVar, a3.a aVar) {
        this.f177a = cVar;
        this.f178b = aVar;
    }
}
