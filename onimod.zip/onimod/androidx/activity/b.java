package androidx.activity;

import android.window.BackEvent;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f121a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f122b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f123c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f124d;

    public b(BackEvent backEvent) {
        a aVar = a.f120a;
        float fD = aVar.d(backEvent);
        float fE = aVar.e(backEvent);
        float fB = aVar.b(backEvent);
        int iC = aVar.c(backEvent);
        this.f121a = fD;
        this.f122b = fE;
        this.f123c = fB;
        this.f124d = iC;
    }

    public final String toString() {
        return "BackEventCompat{touchX=" + this.f121a + ", touchY=" + this.f122b + ", progress=" + this.f123c + ", swipeEdge=" + this.f124d + '}';
    }
}
