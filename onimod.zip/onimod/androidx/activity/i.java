package androidx.activity;

import androidx.lifecycle.l0;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public l0 f131a;
}
