package androidx.activity;

import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

/* JADX INFO: loaded from: classes.dex */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final p f160a = new p();

    public final OnBackInvokedCallback a(j3.a onBackInvoked) {
        kotlin.jvm.internal.d.f(onBackInvoked, "onBackInvoked");
        return new o(0, onBackInvoked);
    }

    public final void b(Object dispatcher, int i3, Object callback) {
        kotlin.jvm.internal.d.f(dispatcher, "dispatcher");
        kotlin.jvm.internal.d.f(callback, "callback");
        ((OnBackInvokedDispatcher) dispatcher).registerOnBackInvokedCallback(i3, (OnBackInvokedCallback) callback);
    }

    public final void c(Object dispatcher, Object callback) {
        kotlin.jvm.internal.d.f(dispatcher, "dispatcher");
        kotlin.jvm.internal.d.f(callback, "callback");
        ((OnBackInvokedDispatcher) dispatcher).unregisterOnBackInvokedCallback((OnBackInvokedCallback) callback);
    }
}
