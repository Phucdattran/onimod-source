package androidx.activity;

import android.window.OnBackInvokedCallback;
import e.f0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class o implements OnBackInvokedCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f158a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f159b;

    public /* synthetic */ o(int i3, Object obj) {
        this.f158a = i3;
        this.f159b = obj;
    }

    @Override // android.window.OnBackInvokedCallback
    public final void onBackInvoked() {
        switch (this.f158a) {
            case 0:
                ((j3.a) this.f159b).b();
                break;
            case 1:
                ((f0) this.f159b).C();
                break;
            default:
                ((Runnable) this.f159b).run();
                break;
        }
    }
}
