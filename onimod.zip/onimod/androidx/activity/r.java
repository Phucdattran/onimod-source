package androidx.activity;

import android.window.OnBackInvokedCallback;

/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final r f165a = new r();

    public final OnBackInvokedCallback a(j3.l onBackStarted, j3.l onBackProgressed, j3.a onBackInvoked, j3.a onBackCancelled) {
        kotlin.jvm.internal.d.f(onBackStarted, "onBackStarted");
        kotlin.jvm.internal.d.f(onBackProgressed, "onBackProgressed");
        kotlin.jvm.internal.d.f(onBackInvoked, "onBackInvoked");
        kotlin.jvm.internal.d.f(onBackCancelled, "onBackCancelled");
        return new q(onBackStarted, onBackProgressed, onBackInvoked, onBackCancelled);
    }
}
