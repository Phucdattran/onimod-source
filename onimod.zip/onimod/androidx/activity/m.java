package androidx.activity;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.Lifecycle$Event;
import androidx.lifecycle.f0;

/* JADX INFO: loaded from: classes.dex */
public class m extends Dialog implements androidx.lifecycle.q, u, f1.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public androidx.lifecycle.s f152a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final n f153b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final t f154c;

    public m(Context context, int i3) {
        super(context, i3);
        this.f153b = new n(this);
        this.f154c = new t(new a4.b(4, this));
    }

    public static void a(m mVar) {
        super.onBackPressed();
    }

    @Override // android.app.Dialog
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        kotlin.jvm.internal.d.f(view, "view");
        b();
        super.addContentView(view, layoutParams);
    }

    public final void b() {
        Window window = getWindow();
        kotlin.jvm.internal.d.c(window);
        View decorView = window.getDecorView();
        kotlin.jvm.internal.d.e(decorView, "window!!.decorView");
        f0.e(decorView, this);
        Window window2 = getWindow();
        kotlin.jvm.internal.d.c(window2);
        View decorView2 = window2.getDecorView();
        kotlin.jvm.internal.d.e(decorView2, "window!!.decorView");
        a3.a.c0(decorView2, this);
        Window window3 = getWindow();
        kotlin.jvm.internal.d.c(window3);
        View decorView3 = window3.getDecorView();
        kotlin.jvm.internal.d.e(decorView3, "window!!.decorView");
        a3.a.d0(decorView3, this);
    }

    @Override // f1.e
    public final f1.d c() {
        return (f1.d) this.f153b.f157c;
    }

    @Override // androidx.lifecycle.q
    public final androidx.lifecycle.s e() {
        androidx.lifecycle.s sVar = this.f152a;
        if (sVar != null) {
            return sVar;
        }
        androidx.lifecycle.s sVar2 = new androidx.lifecycle.s(this);
        this.f152a = sVar2;
        return sVar2;
    }

    @Override // android.app.Dialog
    public final void onBackPressed() {
        this.f154c.b();
    }

    @Override // android.app.Dialog
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcher = getOnBackInvokedDispatcher();
            kotlin.jvm.internal.d.e(onBackInvokedDispatcher, "onBackInvokedDispatcher");
            t tVar = this.f154c;
            tVar.getClass();
            tVar.f197e = onBackInvokedDispatcher;
            tVar.c(tVar.f198g);
        }
        this.f153b.b(bundle);
        androidx.lifecycle.s sVar = this.f152a;
        if (sVar == null) {
            sVar = new androidx.lifecycle.s(this);
            this.f152a = sVar;
        }
        sVar.d(Lifecycle$Event.ON_CREATE);
    }

    @Override // android.app.Dialog
    public final Bundle onSaveInstanceState() {
        Bundle bundleOnSaveInstanceState = super.onSaveInstanceState();
        kotlin.jvm.internal.d.e(bundleOnSaveInstanceState, "super.onSaveInstanceState()");
        this.f153b.c(bundleOnSaveInstanceState);
        return bundleOnSaveInstanceState;
    }

    @Override // android.app.Dialog
    public final void onStart() {
        super.onStart();
        androidx.lifecycle.s sVar = this.f152a;
        if (sVar == null) {
            sVar = new androidx.lifecycle.s(this);
            this.f152a = sVar;
        }
        sVar.d(Lifecycle$Event.ON_RESUME);
    }

    @Override // android.app.Dialog
    public void onStop() {
        androidx.lifecycle.s sVar = this.f152a;
        if (sVar == null) {
            sVar = new androidx.lifecycle.s(this);
            this.f152a = sVar;
        }
        sVar.d(Lifecycle$Event.ON_DESTROY);
        this.f152a = null;
        super.onStop();
    }

    @Override // android.app.Dialog
    public void setContentView(int i3) {
        b();
        super.setContentView(i3);
    }

    @Override // android.app.Dialog
    public void setContentView(View view) {
        kotlin.jvm.internal.d.f(view, "view");
        b();
        super.setContentView(view);
    }

    @Override // android.app.Dialog
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        kotlin.jvm.internal.d.f(view, "view");
        b();
        super.setContentView(view, layoutParams);
    }
}
