package androidx.activity;

import android.window.BackEvent;
import android.window.OnBackAnimationCallback;

/* JADX INFO: loaded from: classes.dex */
public final class q implements OnBackAnimationCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ j3.l f161a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ j3.l f162b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ j3.a f163c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ j3.a f164d;

    public q(j3.l lVar, j3.l lVar2, j3.a aVar, j3.a aVar2) {
        this.f161a = lVar;
        this.f162b = lVar2;
        this.f163c = aVar;
        this.f164d = aVar2;
    }

    @Override // android.window.OnBackAnimationCallback
    public final void onBackCancelled() {
        this.f164d.b();
    }

    @Override // android.window.OnBackInvokedCallback
    public final void onBackInvoked() {
        this.f163c.b();
    }

    @Override // android.window.OnBackAnimationCallback
    public final void onBackProgressed(BackEvent backEvent) {
        kotlin.jvm.internal.d.f(backEvent, "backEvent");
        this.f162b.h(new b(backEvent));
    }

    @Override // android.window.OnBackAnimationCallback
    public final void onBackStarted(BackEvent backEvent) {
        kotlin.jvm.internal.d.f(backEvent, "backEvent");
        this.f161a.h(new b(backEvent));
    }
}
