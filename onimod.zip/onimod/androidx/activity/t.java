package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.fragment.app.g0;
import androidx.fragment.app.o0;
import androidx.lifecycle.Lifecycle$State;
import java.util.Iterator;
import java.util.ListIterator;

/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Runnable f193a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final kotlin.collections.h f194b = new kotlin.collections.h();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public g0 f195c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final OnBackInvokedCallback f196d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public OnBackInvokedDispatcher f197e;
    public boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f198g;

    public t(Runnable runnable) {
        OnBackInvokedCallback onBackInvokedCallbackA;
        this.f193a = runnable;
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 33) {
            if (i3 >= 34) {
                onBackInvokedCallbackA = r.f165a.a(new j3.l() { // from class: androidx.activity.OnBackPressedDispatcher$1
                    {
                        super(1);
                    }

                    @Override // j3.l
                    public final Object h(Object obj) {
                        Object objPrevious;
                        b backEvent = (b) obj;
                        kotlin.jvm.internal.d.f(backEvent, "backEvent");
                        t tVar = this.this$0;
                        kotlin.collections.h hVar = tVar.f194b;
                        ListIterator listIterator = hVar.listIterator(hVar.size());
                        while (listIterator.hasPrevious()) {
                            objPrevious = listIterator.previous();
                            if (((g0) objPrevious).f652a) {
                                tVar.f195c = (g0) objPrevious;
                                return z2.c.f4964c;
                            }
                        }
                        objPrevious = null;
                        tVar.f195c = (g0) objPrevious;
                        return z2.c.f4964c;
                    }
                }, new j3.l() { // from class: androidx.activity.OnBackPressedDispatcher$2
                    {
                        super(1);
                    }

                    @Override // j3.l
                    public final Object h(Object obj) {
                        Object objPrevious;
                        b backEvent = (b) obj;
                        kotlin.jvm.internal.d.f(backEvent, "backEvent");
                        kotlin.collections.h hVar = this.this$0.f194b;
                        ListIterator listIterator = hVar.listIterator(hVar.size());
                        while (listIterator.hasPrevious()) {
                            objPrevious = listIterator.previous();
                            if (((g0) objPrevious).f652a) {
                                return z2.c.f4964c;
                            }
                        }
                        objPrevious = null;
                        return z2.c.f4964c;
                    }
                }, new j3.a() { // from class: androidx.activity.OnBackPressedDispatcher$3
                    {
                        super(0);
                    }

                    @Override // j3.a
                    public final Object b() {
                        this.this$0.b();
                        return z2.c.f4964c;
                    }
                }, new j3.a() { // from class: androidx.activity.OnBackPressedDispatcher$4
                    {
                        super(0);
                    }

                    @Override // j3.a
                    public final Object b() {
                        Object objPrevious;
                        t tVar = this.this$0;
                        kotlin.collections.h hVar = tVar.f194b;
                        ListIterator listIterator = hVar.listIterator(hVar.size());
                        while (listIterator.hasPrevious()) {
                            objPrevious = listIterator.previous();
                            if (((g0) objPrevious).f652a) {
                                tVar.f195c = null;
                                return z2.c.f4964c;
                            }
                        }
                        objPrevious = null;
                        tVar.f195c = null;
                        return z2.c.f4964c;
                    }
                });
            } else {
                onBackInvokedCallbackA = p.f160a.a(new j3.a() { // from class: androidx.activity.OnBackPressedDispatcher$5
                    {
                        super(0);
                    }

                    @Override // j3.a
                    public final Object b() {
                        this.this$0.b();
                        return z2.c.f4964c;
                    }
                });
            }
            this.f196d = onBackInvokedCallbackA;
        }
    }

    public final void a(androidx.lifecycle.q qVar, g0 onBackPressedCallback) {
        kotlin.jvm.internal.d.f(onBackPressedCallback, "onBackPressedCallback");
        androidx.lifecycle.s sVarE = qVar.e();
        if (sVarE.f879c == Lifecycle$State.f829a) {
            return;
        }
        onBackPressedCallback.f653b.add(new OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(this, sVarE, onBackPressedCallback));
        d();
        onBackPressedCallback.f654c = new OnBackPressedDispatcher$addCallback$1(0, t.class, this, "updateEnabledCallbacks", "updateEnabledCallbacks()V");
    }

    public final void b() {
        Object objPrevious;
        kotlin.collections.h hVar = this.f194b;
        hVar.getClass();
        ListIterator listIterator = hVar.listIterator(hVar.f2841c);
        do {
            if (!listIterator.hasPrevious()) {
                objPrevious = null;
                break;
            }
            objPrevious = listIterator.previous();
        } while (!((g0) objPrevious).f652a);
        g0 g0Var = (g0) objPrevious;
        this.f195c = null;
        if (g0Var == null) {
            this.f193a.run();
            return;
        }
        o0 o0Var = g0Var.f655d;
        o0Var.x(true);
        if (o0Var.f691h.f652a) {
            o0Var.N();
        } else {
            o0Var.f690g.b();
        }
    }

    public final void c(boolean z4) {
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.f197e;
        OnBackInvokedCallback onBackInvokedCallback = this.f196d;
        if (onBackInvokedDispatcher == null || onBackInvokedCallback == null) {
            return;
        }
        p pVar = p.f160a;
        if (z4 && !this.f) {
            pVar.b(onBackInvokedDispatcher, 0, onBackInvokedCallback);
            this.f = true;
        } else {
            if (z4 || !this.f) {
                return;
            }
            pVar.c(onBackInvokedDispatcher, onBackInvokedCallback);
            this.f = false;
        }
    }

    public final void d() {
        boolean z4 = this.f198g;
        boolean z5 = false;
        kotlin.collections.h hVar = this.f194b;
        if (hVar == null || !hVar.isEmpty()) {
            Iterator it = hVar.iterator();
            while (it.hasNext()) {
                if (((g0) it.next()).f652a) {
                    z5 = true;
                    break;
                }
            }
        }
        this.f198g = z5;
        if (z5 == z4 || Build.VERSION.SDK_INT < 33) {
            return;
        }
        c(z5);
    }
}
