package androidx.activity;

import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewTreeObserver;
import androidx.fragment.app.z;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final class j implements Executor, ViewTreeObserver.OnDrawListener, Runnable {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Runnable f133b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ z f135d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f132a = SystemClock.uptimeMillis() + 10000;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f134c = false;

    public j(z zVar) {
        this.f135d = zVar;
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.f133b = runnable;
        View decorView = this.f135d.getWindow().getDecorView();
        if (!this.f134c) {
            decorView.postOnAnimation(new a4.b(3, this));
        } else if (Looper.myLooper() == Looper.getMainLooper()) {
            decorView.invalidate();
        } else {
            decorView.postInvalidate();
        }
    }

    @Override // android.view.ViewTreeObserver.OnDrawListener
    public final void onDraw() {
        boolean z4;
        Runnable runnable = this.f133b;
        if (runnable == null) {
            if (SystemClock.uptimeMillis() > this.f132a) {
                this.f134c = false;
                this.f135d.getWindow().getDecorView().post(this);
                return;
            }
            return;
        }
        runnable.run();
        this.f133b = null;
        n nVar = this.f135d.f142i;
        synchronized (nVar.f156b) {
            z4 = nVar.f155a;
        }
        if (z4) {
            this.f134c = false;
            this.f135d.getWindow().getDecorView().post(this);
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f135d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
}
