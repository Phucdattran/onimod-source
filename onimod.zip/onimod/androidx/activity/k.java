package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.fragment.app.h0;
import androidx.fragment.app.z;
import androidx.lifecycle.Lifecycle$Event;
import androidx.lifecycle.c0;
import androidx.lifecycle.e0;
import androidx.lifecycle.f0;
import androidx.lifecycle.j0;
import androidx.lifecycle.l0;
import androidx.lifecycle.m0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public abstract class k extends c0.i implements m0, androidx.lifecycle.i, f1.e, u {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a.a f136b = new a.a();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final androidx.emoji2.text.u f137c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final androidx.lifecycle.s f138d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final n f139e;
    public l0 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public t f140g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final j f141h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final n f142i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final AtomicInteger f143j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final g f144k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final CopyOnWriteArrayList f145l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final CopyOnWriteArrayList f146m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final CopyOnWriteArrayList f147n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final CopyOnWriteArrayList f148o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final CopyOnWriteArrayList f149p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f150q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f151r;

    /* JADX WARN: Type inference failed for: r5v0, types: [androidx.activity.d] */
    public k() {
        final z zVar = (z) this;
        this.f137c = new androidx.emoji2.text.u(new a4.b(2, zVar));
        androidx.lifecycle.s sVar = new androidx.lifecycle.s(this);
        this.f138d = sVar;
        n nVar = new n(this);
        this.f139e = nVar;
        this.f140g = null;
        j jVar = new j(zVar);
        this.f141h = jVar;
        this.f142i = new n(jVar, new j3.a() { // from class: androidx.activity.d
            @Override // j3.a
            public final Object b() {
                zVar.reportFullyDrawn();
                return null;
            }
        });
        this.f143j = new AtomicInteger();
        this.f144k = new g(zVar);
        this.f145l = new CopyOnWriteArrayList();
        this.f146m = new CopyOnWriteArrayList();
        this.f147n = new CopyOnWriteArrayList();
        this.f148o = new CopyOnWriteArrayList();
        this.f149p = new CopyOnWriteArrayList();
        this.f150q = false;
        this.f151r = false;
        int i3 = Build.VERSION.SDK_INT;
        sVar.a(new androidx.lifecycle.o() { // from class: androidx.activity.ComponentActivity$2
            @Override // androidx.lifecycle.o
            public final void a(androidx.lifecycle.q qVar, Lifecycle$Event lifecycle$Event) {
                if (lifecycle$Event == Lifecycle$Event.ON_STOP) {
                    Window window = zVar.getWindow();
                    View viewPeekDecorView = window != null ? window.peekDecorView() : null;
                    if (viewPeekDecorView != null) {
                        viewPeekDecorView.cancelPendingInputEvents();
                    }
                }
            }
        });
        sVar.a(new androidx.lifecycle.o() { // from class: androidx.activity.ComponentActivity$3
            @Override // androidx.lifecycle.o
            public final void a(androidx.lifecycle.q qVar, Lifecycle$Event lifecycle$Event) {
                if (lifecycle$Event == Lifecycle$Event.ON_DESTROY) {
                    zVar.f136b.f1b = null;
                    if (!zVar.isChangingConfigurations()) {
                        zVar.b().a();
                    }
                    j jVar2 = zVar.f141h;
                    z zVar2 = jVar2.f135d;
                    zVar2.getWindow().getDecorView().removeCallbacks(jVar2);
                    zVar2.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(jVar2);
                }
            }
        });
        sVar.a(new androidx.lifecycle.o() { // from class: androidx.activity.ComponentActivity$4
            @Override // androidx.lifecycle.o
            public final void a(androidx.lifecycle.q qVar, Lifecycle$Event lifecycle$Event) {
                z zVar2 = zVar;
                if (zVar2.f == null) {
                    i iVar = (i) zVar2.getLastNonConfigurationInstance();
                    if (iVar != null) {
                        zVar2.f = iVar.f131a;
                    }
                    if (zVar2.f == null) {
                        zVar2.f = new l0();
                    }
                }
                zVar2.f138d.f(this);
            }
        });
        nVar.a();
        f0.b(this);
        if (i3 <= 23) {
            ImmLeaksCleaner immLeaksCleaner = new ImmLeaksCleaner();
            immLeaksCleaner.f115a = zVar;
            sVar.a(immLeaksCleaner);
        }
        ((f1.d) nVar.f157c).e("android:support:activity-result", new e(0, zVar));
        h(new f(zVar, 0));
    }

    @Override // androidx.lifecycle.i
    public final a1.c a() {
        a1.c cVar = new a1.c();
        Application application = getApplication();
        LinkedHashMap linkedHashMap = cVar.f30a;
        if (application != null) {
            linkedHashMap.put(j0.f870a, getApplication());
        }
        linkedHashMap.put(f0.f859a, this);
        linkedHashMap.put(f0.f860b, this);
        if (getIntent() != null && getIntent().getExtras() != null) {
            linkedHashMap.put(f0.f861c, getIntent().getExtras());
        }
        return cVar;
    }

    @Override // androidx.lifecycle.m0
    public final l0 b() {
        if (getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        }
        if (this.f == null) {
            i iVar = (i) getLastNonConfigurationInstance();
            if (iVar != null) {
                this.f = iVar.f131a;
            }
            if (this.f == null) {
                this.f = new l0();
            }
        }
        return this.f;
    }

    @Override // f1.e
    public final f1.d c() {
        return (f1.d) this.f139e.f157c;
    }

    @Override // androidx.lifecycle.q
    public final androidx.lifecycle.s e() {
        return this.f138d;
    }

    public final void g(n0.a aVar) {
        this.f145l.add(aVar);
    }

    public final void h(a.b bVar) {
        a.a aVar = this.f136b;
        aVar.getClass();
        if (aVar.f1b != null) {
            bVar.a();
        }
        aVar.f0a.add(bVar);
    }

    public final t i() {
        if (this.f140g == null) {
            this.f140g = new t(new a2.i(2, this));
            this.f138d.a(new androidx.lifecycle.o() { // from class: androidx.activity.ComponentActivity$6
                @Override // androidx.lifecycle.o
                public final void a(androidx.lifecycle.q qVar, Lifecycle$Event lifecycle$Event) {
                    if (lifecycle$Event != Lifecycle$Event.ON_CREATE || Build.VERSION.SDK_INT < 33) {
                        return;
                    }
                    t tVar = this.f110a.f140g;
                    OnBackInvokedDispatcher invoker = h.a((k) qVar);
                    tVar.getClass();
                    kotlin.jvm.internal.d.f(invoker, "invoker");
                    tVar.f197e = invoker;
                    tVar.c(tVar.f198g);
                }
            });
        }
        return this.f140g;
    }

    @Override // android.app.Activity
    public void onActivityResult(int i3, int i4, Intent intent) {
        if (this.f144k.a(i3, i4, intent)) {
            return;
        }
        super.onActivityResult(i3, i4, intent);
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        i().b();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        Iterator it = this.f145l.iterator();
        while (it.hasNext()) {
            ((n0.a) it.next()).accept(configuration);
        }
    }

    @Override // c0.i, android.app.Activity
    public void onCreate(Bundle bundle) {
        this.f139e.b(bundle);
        a.a aVar = this.f136b;
        aVar.getClass();
        aVar.f1b = this;
        Iterator it = aVar.f0a.iterator();
        while (it.hasNext()) {
            ((a.b) it.next()).a();
        }
        super.onCreate(bundle);
        int i3 = e0.f856b;
        c0.b(this);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean onCreatePanelMenu(int i3, Menu menu) {
        if (i3 != 0) {
            return true;
        }
        super.onCreatePanelMenu(i3, menu);
        getMenuInflater();
        Iterator it = ((CopyOnWriteArrayList) this.f137c.f563c).iterator();
        while (it.hasNext()) {
            ((h0) it.next()).f658a.j();
        }
        return true;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i3, MenuItem menuItem) {
        if (super.onMenuItemSelected(i3, menuItem)) {
            return true;
        }
        if (i3 == 0) {
            Iterator it = ((CopyOnWriteArrayList) this.f137c.f563c).iterator();
            while (it.hasNext()) {
                if (((h0) it.next()).f658a.o()) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z4) {
        if (this.f150q) {
            return;
        }
        Iterator it = this.f148o.iterator();
        while (it.hasNext()) {
            ((n0.a) it.next()).accept(new c0.j(z4));
        }
    }

    @Override // android.app.Activity
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Iterator it = this.f147n.iterator();
        while (it.hasNext()) {
            ((n0.a) it.next()).accept(intent);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i3, Menu menu) {
        Iterator it = ((CopyOnWriteArrayList) this.f137c.f563c).iterator();
        while (it.hasNext()) {
            ((h0) it.next()).f658a.p();
        }
        super.onPanelClosed(i3, menu);
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z4) {
        if (this.f151r) {
            return;
        }
        Iterator it = this.f149p.iterator();
        while (it.hasNext()) {
            ((n0.a) it.next()).accept(new c0.o(z4));
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean onPreparePanel(int i3, View view, Menu menu) {
        if (i3 != 0) {
            return true;
        }
        super.onPreparePanel(i3, view, menu);
        Iterator it = ((CopyOnWriteArrayList) this.f137c.f563c).iterator();
        while (it.hasNext()) {
            ((h0) it.next()).f658a.s();
        }
        return true;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i3, String[] strArr, int[] iArr) {
        if (this.f144k.a(i3, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr)) || Build.VERSION.SDK_INT < 23) {
            return;
        }
        super.onRequestPermissionsResult(i3, strArr, iArr);
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        i iVar;
        l0 l0Var = this.f;
        if (l0Var == null && (iVar = (i) getLastNonConfigurationInstance()) != null) {
            l0Var = iVar.f131a;
        }
        if (l0Var == null) {
            return null;
        }
        i iVar2 = new i();
        iVar2.f131a = l0Var;
        return iVar2;
    }

    @Override // c0.i, android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        androidx.lifecycle.s sVar = this.f138d;
        if (sVar != null) {
            sVar.g();
        }
        super.onSaveInstanceState(bundle);
        this.f139e.c(bundle);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i3) {
        super.onTrimMemory(i3);
        Iterator it = this.f146m.iterator();
        while (it.hasNext()) {
            ((n0.a) it.next()).accept(Integer.valueOf(i3));
        }
    }

    @Override // android.app.Activity
    public final void reportFullyDrawn() {
        try {
            if (a3.a.O()) {
                a3.a.d("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            n nVar = this.f142i;
            synchronized (nVar.f156b) {
                try {
                    nVar.f155a = true;
                    ArrayList arrayList = (ArrayList) nVar.f157c;
                    int size = arrayList.size();
                    int i3 = 0;
                    while (i3 < size) {
                        Object obj = arrayList.get(i3);
                        i3++;
                        ((j3.a) obj).b();
                    }
                    ((ArrayList) nVar.f157c).clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
            Trace.endSection();
        } catch (Throwable th2) {
            Trace.endSection();
            throw th2;
        }
    }

    @Override // android.app.Activity
    public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view) {
        f0.e(getWindow().getDecorView(), this);
        View decorView = getWindow().getDecorView();
        kotlin.jvm.internal.d.f(decorView, "<this>");
        decorView.setTag(R.id.view_tree_view_model_store_owner, this);
        a3.a.d0(getWindow().getDecorView(), this);
        a3.a.c0(getWindow().getDecorView(), this);
        View decorView2 = getWindow().getDecorView();
        kotlin.jvm.internal.d.f(decorView2, "<this>");
        decorView2.setTag(R.id.report_drawn, this);
        View decorView3 = getWindow().getDecorView();
        j jVar = this.f141h;
        if (!jVar.f134c) {
            jVar.f134c = true;
            decorView3.getViewTreeObserver().addOnDrawListener(jVar);
        }
        super.setContentView(view);
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z4, Configuration newConfig) {
        this.f150q = true;
        try {
            super.onMultiWindowModeChanged(z4, newConfig);
            this.f150q = false;
            for (n0.a aVar : this.f148o) {
                kotlin.jvm.internal.d.f(newConfig, "newConfig");
                aVar.accept(new c0.j(z4));
            }
        } catch (Throwable th) {
            this.f150q = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z4, Configuration newConfig) {
        this.f151r = true;
        try {
            super.onPictureInPictureModeChanged(z4, newConfig);
            this.f151r = false;
            for (n0.a aVar : this.f149p) {
                kotlin.jvm.internal.d.f(newConfig, "newConfig");
                aVar.accept(new c0.o(z4));
            }
        } catch (Throwable th) {
            this.f151r = false;
            throw th;
        }
    }
}
