package androidx.activity;

import androidx.fragment.app.g0;

/* JADX INFO: loaded from: classes.dex */
public final class s implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g0 f191a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ t f192b;

    public s(t tVar, g0 onBackPressedCallback) {
        kotlin.jvm.internal.d.f(onBackPressedCallback, "onBackPressedCallback");
        this.f192b = tVar;
        this.f191a = onBackPressedCallback;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [j3.a, kotlin.jvm.internal.FunctionReferenceImpl] */
    @Override // androidx.activity.c
    public final void cancel() {
        t tVar = this.f192b;
        kotlin.collections.h hVar = tVar.f194b;
        g0 g0Var = this.f191a;
        hVar.remove(g0Var);
        if (kotlin.jvm.internal.d.a(tVar.f195c, g0Var)) {
            g0Var.getClass();
            tVar.f195c = null;
        }
        g0Var.f653b.remove(this);
        ?? r1 = g0Var.f654c;
        if (r1 != 0) {
            r1.b();
        }
        g0Var.f654c = null;
    }
}
