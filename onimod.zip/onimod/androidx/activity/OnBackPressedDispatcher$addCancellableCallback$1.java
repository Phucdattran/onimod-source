package androidx.activity;

import kotlin.jvm.internal.FunctionReferenceImpl;

/* JADX INFO: loaded from: classes.dex */
final /* synthetic */ class OnBackPressedDispatcher$addCancellableCallback$1 extends FunctionReferenceImpl implements j3.a {
    @Override // j3.a
    public final Object b() {
        ((t) this.receiver).d();
        return z2.c.f4964c;
    }
}
