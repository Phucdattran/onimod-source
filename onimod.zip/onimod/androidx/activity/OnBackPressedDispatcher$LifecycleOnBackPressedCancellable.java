package androidx.activity;

import androidx.fragment.app.g0;
import androidx.lifecycle.Lifecycle$Event;

/* JADX INFO: loaded from: classes.dex */
final class OnBackPressedDispatcher$LifecycleOnBackPressedCancellable implements androidx.lifecycle.o, c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final androidx.lifecycle.s f116a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g0 f117b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public s f118c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ t f119d;

    public OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(t tVar, androidx.lifecycle.s sVar, g0 onBackPressedCallback) {
        kotlin.jvm.internal.d.f(onBackPressedCallback, "onBackPressedCallback");
        this.f119d = tVar;
        this.f116a = sVar;
        this.f117b = onBackPressedCallback;
        sVar.a(this);
    }

    @Override // androidx.lifecycle.o
    public final void a(androidx.lifecycle.q qVar, Lifecycle$Event lifecycle$Event) {
        if (lifecycle$Event != Lifecycle$Event.ON_START) {
            if (lifecycle$Event != Lifecycle$Event.ON_STOP) {
                if (lifecycle$Event == Lifecycle$Event.ON_DESTROY) {
                    cancel();
                    return;
                }
                return;
            } else {
                s sVar = this.f118c;
                if (sVar != null) {
                    sVar.cancel();
                    return;
                }
                return;
            }
        }
        t tVar = this.f119d;
        tVar.getClass();
        g0 onBackPressedCallback = this.f117b;
        kotlin.jvm.internal.d.f(onBackPressedCallback, "onBackPressedCallback");
        tVar.f194b.addLast(onBackPressedCallback);
        s sVar2 = new s(tVar, onBackPressedCallback);
        onBackPressedCallback.f653b.add(sVar2);
        tVar.d();
        onBackPressedCallback.f654c = new OnBackPressedDispatcher$addCancellableCallback$1(0, t.class, tVar, "updateEnabledCallbacks", "updateEnabledCallbacks()V");
        this.f118c = sVar2;
    }

    @Override // androidx.activity.c
    public final void cancel() {
        this.f116a.f(this);
        this.f117b.f653b.remove(this);
        s sVar = this.f118c;
        if (sVar != null) {
            sVar.cancel();
        }
        this.f118c = null;
    }
}
