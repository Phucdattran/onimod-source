package androidx.activity;

import android.os.Bundle;
import androidx.lifecycle.Lifecycle$Event;
import androidx.lifecycle.Lifecycle$State;
import androidx.lifecycle.q;
import androidx.savedstate.Recreator;
import java.util.ArrayList;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f155a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f156b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f157c;

    public n(f1.e eVar) {
        this.f156b = eVar;
        this.f157c = new f1.d();
    }

    public void a() {
        f1.e eVar = (f1.e) this.f156b;
        androidx.lifecycle.s sVarE = eVar.e();
        if (sVarE.f879c != Lifecycle$State.f830b) {
            throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
        }
        sVarE.a(new Recreator(eVar));
        final f1.d dVar = (f1.d) this.f157c;
        dVar.getClass();
        if (dVar.f2227a) {
            throw new IllegalStateException("SavedStateRegistry was already attached.");
        }
        sVarE.a(new androidx.lifecycle.o() { // from class: f1.a
            @Override // androidx.lifecycle.o
            public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
                d this$0 = dVar;
                kotlin.jvm.internal.d.f(this$0, "this$0");
                if (lifecycle$Event == Lifecycle$Event.ON_START) {
                    this$0.f2229c = true;
                } else if (lifecycle$Event == Lifecycle$Event.ON_STOP) {
                    this$0.f2229c = false;
                }
            }
        });
        dVar.f2227a = true;
        this.f155a = true;
    }

    public void b(Bundle bundle) {
        if (!this.f155a) {
            a();
        }
        androidx.lifecycle.s sVarE = ((f1.e) this.f156b).e();
        if (sVarE.f879c.compareTo(Lifecycle$State.f832d) >= 0) {
            throw new IllegalStateException(("performRestore cannot be called when owner is " + sVarE.f879c).toString());
        }
        f1.d dVar = (f1.d) this.f157c;
        if (!dVar.f2227a) {
            throw new IllegalStateException("You must call performAttach() before calling performRestore(Bundle).");
        }
        if (dVar.f2228b) {
            throw new IllegalStateException("SavedStateRegistry was already restored.");
        }
        dVar.f2231e = bundle != null ? bundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key") : null;
        dVar.f2228b = true;
    }

    public void c(Bundle bundle) {
        f1.d dVar = (f1.d) this.f157c;
        dVar.getClass();
        Bundle bundle2 = new Bundle();
        Bundle bundle3 = (Bundle) dVar.f2231e;
        if (bundle3 != null) {
            bundle2.putAll(bundle3);
        }
        n.f fVar = (n.f) dVar.f2230d;
        fVar.getClass();
        n.d dVar2 = new n.d(fVar);
        fVar.f3401c.put(dVar2, Boolean.FALSE);
        while (dVar2.hasNext()) {
            Map.Entry entry = (Map.Entry) dVar2.next();
            bundle2.putBundle((String) entry.getKey(), ((f1.c) entry.getValue()).a());
        }
        if (bundle2.isEmpty()) {
            return;
        }
        bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle2);
    }

    public n(j jVar, d dVar) {
        this.f156b = new Object();
        this.f157c = new ArrayList();
    }
}
