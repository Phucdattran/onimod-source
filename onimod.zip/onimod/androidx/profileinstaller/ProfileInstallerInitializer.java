package androidx.profileinstaller;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import s2.e;

/* JADX INFO: loaded from: classes.dex */
public class ProfileInstallerInitializer implements g1.b {
    @Override // g1.b
    public final List a() {
        return Collections.EMPTY_LIST;
    }

    @Override // g1.b
    public final Object b(Context context) {
        if (Build.VERSION.SDK_INT < 24) {
            return new e(10);
        }
        final Context applicationContext = context.getApplicationContext();
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback(this) { // from class: c1.g
            @Override // android.view.Choreographer.FrameCallback
            public final void doFrame(long j4) {
                (Build.VERSION.SDK_INT >= 28 ? Handler.createAsync(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new h(applicationContext, 0), new Random().nextInt(Math.max(1000, 1)) + 5000);
            }
        });
        return new e(10);
    }
}
