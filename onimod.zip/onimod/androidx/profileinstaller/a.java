package androidx.profileinstaller;

import c1.c;
import c1.f;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final byte[] f904a = {112, 114, 111, 0};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final byte[] f905b = {112, 114, 109, 0};

    public static byte[] a(c[] cVarArr, byte[] bArr) throws IOException {
        int i3 = 0;
        int length = 0;
        for (c cVar : cVarArr) {
            length += ((((cVar.f1119g * 2) + 7) & (-8)) / 8) + (cVar.f1118e * 2) + b(cVar.f1114a, cVar.f1115b, bArr).getBytes(StandardCharsets.UTF_8).length + 16 + cVar.f;
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(length);
        if (Arrays.equals(bArr, f.f1125d)) {
            int length2 = cVarArr.length;
            while (i3 < length2) {
                c cVar2 = cVarArr[i3];
                k(byteArrayOutputStream, cVar2, b(cVar2.f1114a, cVar2.f1115b, bArr));
                j(byteArrayOutputStream, cVar2);
                i3++;
            }
        } else {
            for (c cVar3 : cVarArr) {
                k(byteArrayOutputStream, cVar3, b(cVar3.f1114a, cVar3.f1115b, bArr));
            }
            int length3 = cVarArr.length;
            while (i3 < length3) {
                j(byteArrayOutputStream, cVarArr[i3]);
                i3++;
            }
        }
        if (byteArrayOutputStream.size() == length) {
            return byteArrayOutputStream.toByteArray();
        }
        throw new IllegalStateException("The bytes saved do not match expectation. actual=" + byteArrayOutputStream.size() + " expected=" + length);
    }

    public static String b(String str, String str2, byte[] bArr) {
        byte[] bArr2 = f.f1126e;
        byte[] bArr3 = f.f;
        Object obj = (Arrays.equals(bArr, bArr3) || Arrays.equals(bArr, bArr2)) ? ":" : "!";
        if (str.length() <= 0) {
            if ("!".equals(obj)) {
                return str2.replace(":", "!");
            }
            if (":".equals(obj)) {
                return str2.replace("!", ":");
            }
        } else {
            if (str2.equals("classes.dex")) {
                return str;
            }
            if (str2.contains("!") || str2.contains(":")) {
                if ("!".equals(obj)) {
                    return str2.replace(":", "!");
                }
                if (":".equals(obj)) {
                    return str2.replace("!", ":");
                }
            } else if (!str2.endsWith(".apk")) {
                StringBuilder sb = new StringBuilder();
                sb.append(str);
                sb.append((Arrays.equals(bArr, bArr3) || Arrays.equals(bArr, bArr2)) ? ":" : "!");
                sb.append(str2);
                return sb.toString();
            }
        }
        return str2;
    }

    public static int[] c(ByteArrayInputStream byteArrayInputStream, int i3) {
        int[] iArr = new int[i3];
        int iF = 0;
        for (int i4 = 0; i4 < i3; i4++) {
            iF += (int) f.f(byteArrayInputStream, 2);
            iArr[i4] = iF;
        }
        return iArr;
    }

    public static c[] d(FileInputStream fileInputStream, byte[] bArr, byte[] bArr2, c[] cVarArr) throws IOException {
        byte[] bArr3 = f.f1127g;
        if (!Arrays.equals(bArr, bArr3)) {
            if (!Arrays.equals(bArr, f.f1128h)) {
                throw new IllegalStateException("Unsupported meta version");
            }
            int iF = (int) f.f(fileInputStream, 2);
            byte[] bArrE = f.e(fileInputStream, (int) f.f(fileInputStream, 4), (int) f.f(fileInputStream, 4));
            if (fileInputStream.read() > 0) {
                throw new IllegalStateException("Content found after the end of file");
            }
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArrE);
            try {
                c[] cVarArrF = f(byteArrayInputStream, bArr2, iF, cVarArr);
                byteArrayInputStream.close();
                return cVarArrF;
            } catch (Throwable th) {
                try {
                    byteArrayInputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
        if (Arrays.equals(f.f1123b, bArr2)) {
            throw new IllegalStateException("Requires new Baseline Profile Metadata. Please rebuild the APK with Android Gradle Plugin 7.2 Canary 7 or higher");
        }
        if (!Arrays.equals(bArr, bArr3)) {
            throw new IllegalStateException("Unsupported meta version");
        }
        int iF2 = (int) f.f(fileInputStream, 1);
        byte[] bArrE2 = f.e(fileInputStream, (int) f.f(fileInputStream, 4), (int) f.f(fileInputStream, 4));
        if (fileInputStream.read() > 0) {
            throw new IllegalStateException("Content found after the end of file");
        }
        ByteArrayInputStream byteArrayInputStream2 = new ByteArrayInputStream(bArrE2);
        try {
            c[] cVarArrE = e(byteArrayInputStream2, iF2, cVarArr);
            byteArrayInputStream2.close();
            return cVarArrE;
        } catch (Throwable th3) {
            try {
                byteArrayInputStream2.close();
            } catch (Throwable th4) {
                th3.addSuppressed(th4);
            }
            throw th3;
        }
    }

    public static c[] e(ByteArrayInputStream byteArrayInputStream, int i3, c[] cVarArr) {
        if (byteArrayInputStream.available() == 0) {
            return new c[0];
        }
        if (i3 != cVarArr.length) {
            throw new IllegalStateException("Mismatched number of dex files found in metadata");
        }
        String[] strArr = new String[i3];
        int[] iArr = new int[i3];
        for (int i4 = 0; i4 < i3; i4++) {
            int iF = (int) f.f(byteArrayInputStream, 2);
            iArr[i4] = (int) f.f(byteArrayInputStream, 2);
            strArr[i4] = new String(f.d(byteArrayInputStream, iF), StandardCharsets.UTF_8);
        }
        for (int i5 = 0; i5 < i3; i5++) {
            c cVar = cVarArr[i5];
            if (!cVar.f1115b.equals(strArr[i5])) {
                throw new IllegalStateException("Order of dexfiles in metadata did not match baseline");
            }
            int i6 = iArr[i5];
            cVar.f1118e = i6;
            cVar.f1120h = c(byteArrayInputStream, i6);
        }
        return cVarArr;
    }

    public static c[] f(ByteArrayInputStream byteArrayInputStream, byte[] bArr, int i3, c[] cVarArr) {
        if (byteArrayInputStream.available() == 0) {
            return new c[0];
        }
        if (i3 != cVarArr.length) {
            throw new IllegalStateException("Mismatched number of dex files found in metadata");
        }
        for (int i4 = 0; i4 < i3; i4++) {
            f.f(byteArrayInputStream, 2);
            String str = new String(f.d(byteArrayInputStream, (int) f.f(byteArrayInputStream, 2)), StandardCharsets.UTF_8);
            long jF = f.f(byteArrayInputStream, 4);
            int iF = (int) f.f(byteArrayInputStream, 2);
            c cVar = null;
            if (cVarArr.length > 0) {
                int iIndexOf = str.indexOf("!");
                if (iIndexOf < 0) {
                    iIndexOf = str.indexOf(":");
                }
                String strSubstring = iIndexOf > 0 ? str.substring(iIndexOf + 1) : str;
                for (int i5 = 0; i5 < cVarArr.length; i5++) {
                    if (cVarArr[i5].f1115b.equals(strSubstring)) {
                        cVar = cVarArr[i5];
                        break;
                    }
                }
            }
            if (cVar == null) {
                throw new IllegalStateException("Missing profile key: ".concat(str));
            }
            cVar.f1117d = jF;
            int[] iArrC = c(byteArrayInputStream, iF);
            if (Arrays.equals(bArr, f.f)) {
                cVar.f1118e = iF;
                cVar.f1120h = iArrC;
            }
        }
        return cVarArr;
    }

    public static c[] g(FileInputStream fileInputStream, byte[] bArr, String str) throws IOException {
        if (!Arrays.equals(bArr, f.f1124c)) {
            throw new IllegalStateException("Unsupported version");
        }
        int iF = (int) f.f(fileInputStream, 1);
        byte[] bArrE = f.e(fileInputStream, (int) f.f(fileInputStream, 4), (int) f.f(fileInputStream, 4));
        if (fileInputStream.read() > 0) {
            throw new IllegalStateException("Content found after the end of file");
        }
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArrE);
        try {
            c[] cVarArrH = h(byteArrayInputStream, str, iF);
            byteArrayInputStream.close();
            return cVarArrH;
        } catch (Throwable th) {
            try {
                byteArrayInputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public static c[] h(ByteArrayInputStream byteArrayInputStream, String str, int i3) throws IOException {
        if (byteArrayInputStream.available() == 0) {
            return new c[0];
        }
        c[] cVarArr = new c[i3];
        for (int i4 = 0; i4 < i3; i4++) {
            int iF = (int) f.f(byteArrayInputStream, 2);
            int iF2 = (int) f.f(byteArrayInputStream, 2);
            cVarArr[i4] = new c(str, new String(f.d(byteArrayInputStream, iF), StandardCharsets.UTF_8), f.f(byteArrayInputStream, 4), iF2, (int) f.f(byteArrayInputStream, 4), (int) f.f(byteArrayInputStream, 4), new int[iF2], new TreeMap());
        }
        int i5 = 0;
        while (i5 < i3) {
            c cVar = cVarArr[i5];
            int iAvailable = byteArrayInputStream.available();
            int i6 = cVar.f;
            int i7 = cVar.f1119g;
            TreeMap treeMap = cVar.f1121i;
            int i8 = iAvailable - i6;
            int iF3 = 0;
            while (byteArrayInputStream.available() > i8) {
                iF3 += (int) f.f(byteArrayInputStream, 2);
                treeMap.put(Integer.valueOf(iF3), 1);
                int iF4 = (int) f.f(byteArrayInputStream, 2);
                while (iF4 > 0) {
                    f.f(byteArrayInputStream, 2);
                    int iF5 = (int) f.f(byteArrayInputStream, 1);
                    if (iF5 != 6 && iF5 != 7) {
                        while (iF5 > 0) {
                            f.f(byteArrayInputStream, 1);
                            int i9 = i5;
                            for (int iF6 = (int) f.f(byteArrayInputStream, 1); iF6 > 0; iF6--) {
                                f.f(byteArrayInputStream, 2);
                            }
                            iF5--;
                            i5 = i9;
                        }
                    }
                    iF4--;
                    i5 = i5;
                }
            }
            int i10 = i5;
            if (byteArrayInputStream.available() != i8) {
                throw new IllegalStateException("Read too much data during profile line parse");
            }
            cVar.f1120h = c(byteArrayInputStream, cVar.f1118e);
            BitSet bitSetValueOf = BitSet.valueOf(f.d(byteArrayInputStream, (((i7 * 2) + 7) & (-8)) / 8));
            for (int i11 = 0; i11 < i7; i11++) {
                int i12 = bitSetValueOf.get(i11) ? 2 : 0;
                if (bitSetValueOf.get(i11 + i7)) {
                    i12 |= 4;
                }
                if (i12 != 0) {
                    Integer num = (Integer) treeMap.get(Integer.valueOf(i11));
                    if (num == null) {
                        num = 0;
                    }
                    treeMap.put(Integer.valueOf(i11), Integer.valueOf(i12 | num.intValue()));
                }
            }
            i5 = i10 + 1;
        }
        return cVarArr;
    }

    public static boolean i(ByteArrayOutputStream byteArrayOutputStream, byte[] bArr, c[] cVarArr) throws IOException {
        int length;
        byte[] bArr2 = f.f;
        byte[] bArr3 = f.f1126e;
        byte[] bArr4 = f.f1123b;
        if (!Arrays.equals(bArr, bArr4)) {
            byte[] bArr5 = f.f1124c;
            if (Arrays.equals(bArr, bArr5)) {
                byte[] bArrA = a(cVarArr, bArr5);
                f.h(byteArrayOutputStream, cVarArr.length, 1);
                f.h(byteArrayOutputStream, bArrA.length, 4);
                byte[] bArrA2 = f.a(bArrA);
                f.h(byteArrayOutputStream, bArrA2.length, 4);
                byteArrayOutputStream.write(bArrA2);
                return true;
            }
            if (Arrays.equals(bArr, bArr3)) {
                f.h(byteArrayOutputStream, cVarArr.length, 1);
                for (c cVar : cVarArr) {
                    int size = cVar.f1121i.size() * 4;
                    String strB = b(cVar.f1114a, cVar.f1115b, bArr3);
                    Charset charset = StandardCharsets.UTF_8;
                    f.i(byteArrayOutputStream, strB.getBytes(charset).length);
                    f.i(byteArrayOutputStream, cVar.f1120h.length);
                    f.h(byteArrayOutputStream, size, 4);
                    f.h(byteArrayOutputStream, cVar.f1116c, 4);
                    byteArrayOutputStream.write(strB.getBytes(charset));
                    Iterator it = cVar.f1121i.keySet().iterator();
                    while (it.hasNext()) {
                        f.i(byteArrayOutputStream, ((Integer) it.next()).intValue());
                        f.i(byteArrayOutputStream, 0);
                    }
                    for (int i3 : cVar.f1120h) {
                        f.i(byteArrayOutputStream, i3);
                    }
                }
                return true;
            }
            byte[] bArr6 = f.f1125d;
            if (Arrays.equals(bArr, bArr6)) {
                byte[] bArrA3 = a(cVarArr, bArr6);
                f.h(byteArrayOutputStream, cVarArr.length, 1);
                f.h(byteArrayOutputStream, bArrA3.length, 4);
                byte[] bArrA4 = f.a(bArrA3);
                f.h(byteArrayOutputStream, bArrA4.length, 4);
                byteArrayOutputStream.write(bArrA4);
                return true;
            }
            if (!Arrays.equals(bArr, bArr2)) {
                return false;
            }
            f.i(byteArrayOutputStream, cVarArr.length);
            for (c cVar2 : cVarArr) {
                String str = cVar2.f1114a;
                TreeMap treeMap = cVar2.f1121i;
                String strB2 = b(str, cVar2.f1115b, bArr2);
                Charset charset2 = StandardCharsets.UTF_8;
                f.i(byteArrayOutputStream, strB2.getBytes(charset2).length);
                f.i(byteArrayOutputStream, treeMap.size());
                f.i(byteArrayOutputStream, cVar2.f1120h.length);
                f.h(byteArrayOutputStream, cVar2.f1116c, 4);
                byteArrayOutputStream.write(strB2.getBytes(charset2));
                Iterator it2 = treeMap.keySet().iterator();
                while (it2.hasNext()) {
                    f.i(byteArrayOutputStream, ((Integer) it2.next()).intValue());
                }
                for (int i4 : cVar2.f1120h) {
                    f.i(byteArrayOutputStream, i4);
                }
            }
            return true;
        }
        ArrayList arrayList = new ArrayList(3);
        ArrayList arrayList2 = new ArrayList(3);
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        try {
            f.i(byteArrayOutputStream2, cVarArr.length);
            int i5 = 2;
            for (c cVar3 : cVarArr) {
                f.h(byteArrayOutputStream2, cVar3.f1116c, 4);
                f.h(byteArrayOutputStream2, cVar3.f1117d, 4);
                f.h(byteArrayOutputStream2, cVar3.f1119g, 4);
                String strB3 = b(cVar3.f1114a, cVar3.f1115b, bArr4);
                Charset charset3 = StandardCharsets.UTF_8;
                int length2 = strB3.getBytes(charset3).length;
                f.i(byteArrayOutputStream2, length2);
                i5 = i5 + 14 + length2;
                byteArrayOutputStream2.write(strB3.getBytes(charset3));
            }
            byte[] byteArray = byteArrayOutputStream2.toByteArray();
            if (i5 != byteArray.length) {
                throw new IllegalStateException("Expected size " + i5 + ", does not match actual size " + byteArray.length);
            }
            b bVar = new b(FileSectionType.DEX_FILES, byteArray, false);
            byteArrayOutputStream2.close();
            arrayList.add(bVar);
            ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
            int i6 = 0;
            for (int i7 = 0; i7 < cVarArr.length; i7++) {
                try {
                    c cVar4 = cVarArr[i7];
                    f.i(byteArrayOutputStream3, i7);
                    f.i(byteArrayOutputStream3, cVar4.f1118e);
                    i6 = i6 + 4 + (cVar4.f1118e * 2);
                    int[] iArr = cVar4.f1120h;
                    int length3 = iArr.length;
                    int i8 = 0;
                    int i9 = 0;
                    while (i8 < length3) {
                        int i10 = iArr[i8];
                        f.i(byteArrayOutputStream3, i10 - i9);
                        i8++;
                        i9 = i10;
                    }
                } catch (Throwable th) {
                    try {
                        byteArrayOutputStream3.close();
                        throw th;
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                        throw th;
                    }
                }
            }
            byte[] byteArray2 = byteArrayOutputStream3.toByteArray();
            if (i6 != byteArray2.length) {
                throw new IllegalStateException("Expected size " + i6 + ", does not match actual size " + byteArray2.length);
            }
            b bVar2 = new b(FileSectionType.CLASSES, byteArray2, true);
            byteArrayOutputStream3.close();
            arrayList.add(bVar2);
            ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
            int i11 = 0;
            for (int i12 = 0; i12 < cVarArr.length; i12++) {
                try {
                    c cVar5 = cVarArr[i12];
                    Iterator it3 = cVar5.f1121i.entrySet().iterator();
                    int iIntValue = 0;
                    while (it3.hasNext()) {
                        iIntValue |= ((Integer) ((Map.Entry) it3.next()).getValue()).intValue();
                    }
                    ByteArrayOutputStream byteArrayOutputStream5 = new ByteArrayOutputStream();
                    try {
                        l(byteArrayOutputStream5, iIntValue, cVar5);
                        byte[] byteArray3 = byteArrayOutputStream5.toByteArray();
                        byteArrayOutputStream5.close();
                        ByteArrayOutputStream byteArrayOutputStream6 = new ByteArrayOutputStream();
                        try {
                            m(byteArrayOutputStream6, cVar5);
                            byte[] byteArray4 = byteArrayOutputStream6.toByteArray();
                            byteArrayOutputStream6.close();
                            f.i(byteArrayOutputStream4, i12);
                            int length4 = byteArray3.length + 2 + byteArray4.length;
                            int i13 = i11 + 6;
                            f.h(byteArrayOutputStream4, length4, 4);
                            f.i(byteArrayOutputStream4, iIntValue);
                            byteArrayOutputStream4.write(byteArray3);
                            byteArrayOutputStream4.write(byteArray4);
                            i11 = i13 + length4;
                        } catch (Throwable th3) {
                            try {
                                byteArrayOutputStream6.close();
                                throw th3;
                            } catch (Throwable th4) {
                                th3.addSuppressed(th4);
                                throw th3;
                            }
                        }
                    } catch (Throwable th5) {
                        try {
                            byteArrayOutputStream5.close();
                            throw th5;
                        } catch (Throwable th6) {
                            th5.addSuppressed(th6);
                            throw th5;
                        }
                    }
                } catch (Throwable th7) {
                    try {
                        byteArrayOutputStream4.close();
                        throw th7;
                    } catch (Throwable th8) {
                        th7.addSuppressed(th8);
                        throw th7;
                    }
                }
            }
            byte[] byteArray5 = byteArrayOutputStream4.toByteArray();
            if (i11 != byteArray5.length) {
                throw new IllegalStateException("Expected size " + i11 + ", does not match actual size " + byteArray5.length);
            }
            b bVar3 = new b(FileSectionType.METHODS, byteArray5, true);
            byteArrayOutputStream4.close();
            arrayList.add(bVar3);
            long j4 = 4;
            long size2 = j4 + j4 + 4 + ((long) (arrayList.size() * 16));
            f.h(byteArrayOutputStream, arrayList.size(), 4);
            for (int i14 = 0; i14 < arrayList.size(); i14++) {
                b bVar4 = (b) arrayList.get(i14);
                FileSectionType fileSectionType = bVar4.f906a;
                byte[] bArr7 = bVar4.f907b;
                f.h(byteArrayOutputStream, fileSectionType.a(), 4);
                f.h(byteArrayOutputStream, size2, 4);
                if (bVar4.f908c) {
                    long length5 = bArr7.length;
                    byte[] bArrA5 = f.a(bArr7);
                    arrayList2.add(bArrA5);
                    f.h(byteArrayOutputStream, bArrA5.length, 4);
                    f.h(byteArrayOutputStream, length5, 4);
                    length = bArrA5.length;
                } else {
                    arrayList2.add(bArr7);
                    f.h(byteArrayOutputStream, bArr7.length, 4);
                    f.h(byteArrayOutputStream, 0L, 4);
                    length = bArr7.length;
                }
                size2 += (long) length;
            }
            for (int i15 = 0; i15 < arrayList2.size(); i15++) {
                byteArrayOutputStream.write((byte[]) arrayList2.get(i15));
            }
            return true;
        } catch (Throwable th9) {
            try {
                byteArrayOutputStream2.close();
                throw th9;
            } catch (Throwable th10) {
                th9.addSuppressed(th10);
                throw th9;
            }
        }
    }

    public static void j(ByteArrayOutputStream byteArrayOutputStream, c cVar) throws IOException {
        m(byteArrayOutputStream, cVar);
        int i3 = cVar.f1119g;
        int[] iArr = cVar.f1120h;
        int length = iArr.length;
        int i4 = 0;
        int i5 = 0;
        while (i4 < length) {
            int i6 = iArr[i4];
            f.i(byteArrayOutputStream, i6 - i5);
            i4++;
            i5 = i6;
        }
        byte[] bArr = new byte[(((i3 * 2) + 7) & (-8)) / 8];
        for (Map.Entry entry : cVar.f1121i.entrySet()) {
            int iIntValue = ((Integer) entry.getKey()).intValue();
            int iIntValue2 = ((Integer) entry.getValue()).intValue();
            if ((iIntValue2 & 2) != 0) {
                int i7 = iIntValue / 8;
                bArr[i7] = (byte) (bArr[i7] | (1 << (iIntValue % 8)));
            }
            if ((iIntValue2 & 4) != 0) {
                int i8 = iIntValue + i3;
                int i9 = i8 / 8;
                bArr[i9] = (byte) ((1 << (i8 % 8)) | bArr[i9]);
            }
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void k(ByteArrayOutputStream byteArrayOutputStream, c cVar, String str) throws IOException {
        Charset charset = StandardCharsets.UTF_8;
        f.i(byteArrayOutputStream, str.getBytes(charset).length);
        f.i(byteArrayOutputStream, cVar.f1118e);
        f.h(byteArrayOutputStream, cVar.f, 4);
        f.h(byteArrayOutputStream, cVar.f1116c, 4);
        f.h(byteArrayOutputStream, cVar.f1119g, 4);
        byteArrayOutputStream.write(str.getBytes(charset));
    }

    public static void l(ByteArrayOutputStream byteArrayOutputStream, int i3, c cVar) throws IOException {
        int i4 = cVar.f1119g;
        byte[] bArr = new byte[(((Integer.bitCount(i3 & (-2)) * i4) + 7) & (-8)) / 8];
        for (Map.Entry entry : cVar.f1121i.entrySet()) {
            int iIntValue = ((Integer) entry.getKey()).intValue();
            int iIntValue2 = ((Integer) entry.getValue()).intValue();
            int i5 = 0;
            for (int i6 = 1; i6 <= 4; i6 <<= 1) {
                if (i6 != 1 && (i6 & i3) != 0) {
                    if ((i6 & iIntValue2) == i6) {
                        int i7 = (i5 * i4) + iIntValue;
                        int i8 = i7 / 8;
                        bArr[i8] = (byte) ((1 << (i7 % 8)) | bArr[i8]);
                    }
                    i5++;
                }
            }
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void m(ByteArrayOutputStream byteArrayOutputStream, c cVar) {
        int i3 = 0;
        for (Map.Entry entry : cVar.f1121i.entrySet()) {
            int iIntValue = ((Integer) entry.getKey()).intValue();
            if ((((Integer) entry.getValue()).intValue() & 1) != 0) {
                f.i(byteArrayOutputStream, iIntValue - i3);
                f.i(byteArrayOutputStream, 0);
                i3 = iIntValue;
            }
        }
    }
}
