package androidx.profileinstaller;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final FileSectionType f906a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final byte[] f907b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f908c;

    public b(FileSectionType fileSectionType, byte[] bArr, boolean z4) {
        this.f906a = fileSectionType;
        this.f907b = bArr;
        this.f908c = z4;
    }
}
