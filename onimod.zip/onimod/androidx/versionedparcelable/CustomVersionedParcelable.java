package androidx.versionedparcelable;

import k1.c;

/* JADX INFO: loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements c {
}
