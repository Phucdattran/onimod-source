package androidx.emoji2.text;

import android.util.SparseArray;

/* JADX INFO: loaded from: classes.dex */
public final class x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final SparseArray f573a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public a0 f574b;

    public x(int i3) {
        this.f573a = new SparseArray(i3);
    }

    public final void a(a0 a0Var, int i3, int i4) {
        int iA = a0Var.a(i3);
        SparseArray sparseArray = this.f573a;
        x xVar = sparseArray == null ? null : (x) sparseArray.get(iA);
        if (xVar == null) {
            xVar = new x(1);
            sparseArray.put(a0Var.a(i3), xVar);
        }
        if (i4 > i3) {
            xVar.a(a0Var, i3 + 1, i4);
        } else {
            xVar.f574b = a0Var;
        }
    }
}
