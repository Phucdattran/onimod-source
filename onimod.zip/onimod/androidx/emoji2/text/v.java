package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public final class v implements l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f565a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l0.e f566b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final s2.e f567c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f568d = new Object();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Handler f569e;
    public ThreadPoolExecutor f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ThreadPoolExecutor f570g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public a3.a f571h;

    public v(Context context, l0.e eVar) {
        i1.m.h(context, "Context cannot be null");
        this.f565a = context.getApplicationContext();
        this.f566b = eVar;
        this.f567c = w.f572d;
    }

    public final void a() {
        synchronized (this.f568d) {
            try {
                this.f571h = null;
                Handler handler = this.f569e;
                if (handler != null) {
                    handler.removeCallbacks(null);
                }
                this.f569e = null;
                ThreadPoolExecutor threadPoolExecutor = this.f570g;
                if (threadPoolExecutor != null) {
                    threadPoolExecutor.shutdown();
                }
                this.f = null;
                this.f570g = null;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b() {
        synchronized (this.f568d) {
            try {
                if (this.f571h == null) {
                    return;
                }
                if (this.f == null) {
                    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new a("emojiCompat"));
                    threadPoolExecutor.allowCoreThreadTimeOut(true);
                    this.f570g = threadPoolExecutor;
                    this.f = threadPoolExecutor;
                }
                this.f.execute(new a4.b(5, this));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // androidx.emoji2.text.l
    public final void c(a3.a aVar) {
        synchronized (this.f568d) {
            this.f571h = aVar;
        }
        b();
    }

    public final l0.j d() {
        try {
            s2.e eVar = this.f567c;
            Context context = this.f565a;
            l0.e eVar2 = this.f566b;
            eVar.getClass();
            Object[] objArr = {eVar2};
            ArrayList arrayList = new ArrayList(1);
            Object obj = objArr[0];
            Objects.requireNonNull(obj);
            arrayList.add(obj);
            a2.g gVarA = l0.d.a(context, Collections.unmodifiableList(arrayList));
            int i3 = gVarA.f43a;
            if (i3 != 0) {
                throw new RuntimeException("fetchFonts failed (" + i3 + ")");
            }
            l0.j[] jVarArr = (l0.j[]) ((List) gVarA.f44b).get(0);
            if (jVarArr == null || jVarArr.length == 0) {
                throw new RuntimeException("fetchFonts failed (empty result)");
            }
            return jVarArr[0];
        } catch (PackageManager.NameNotFoundException e4) {
            throw new RuntimeException("provider not found", e4);
        }
    }
}
