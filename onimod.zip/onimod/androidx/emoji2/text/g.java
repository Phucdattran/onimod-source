package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m f529a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public volatile u f530b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile a0.k f531c;

    public g(m mVar) {
        this.f529a = mVar;
    }
}
