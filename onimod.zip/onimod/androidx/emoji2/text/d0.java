package androidx.emoji2.text;

import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import java.util.stream.IntStream;

/* JADX INFO: loaded from: classes.dex */
public final class d0 implements Spannable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f524a = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Spannable f525b;

    public d0(Spannable spannable) {
        this.f525b = spannable;
    }

    public final void a() {
        Spannable spannable = this.f525b;
        if (!this.f524a) {
            if ((Build.VERSION.SDK_INT < 28 ? new s2.e(4) : new c0(4)).k(spannable)) {
                this.f525b = new SpannableString(spannable);
            }
        }
        this.f524a = true;
    }

    @Override // java.lang.CharSequence
    public final char charAt(int i3) {
        return this.f525b.charAt(i3);
    }

    @Override // java.lang.CharSequence
    public final IntStream chars() {
        return this.f525b.chars();
    }

    @Override // java.lang.CharSequence
    public final IntStream codePoints() {
        return this.f525b.codePoints();
    }

    @Override // android.text.Spanned
    public final int getSpanEnd(Object obj) {
        return this.f525b.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public final int getSpanFlags(Object obj) {
        return this.f525b.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public final int getSpanStart(Object obj) {
        return this.f525b.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    public final Object[] getSpans(int i3, int i4, Class cls) {
        return this.f525b.getSpans(i3, i4, cls);
    }

    @Override // java.lang.CharSequence
    public final int length() {
        return this.f525b.length();
    }

    @Override // android.text.Spanned
    public final int nextSpanTransition(int i3, int i4, Class cls) {
        return this.f525b.nextSpanTransition(i3, i4, cls);
    }

    @Override // android.text.Spannable
    public final void removeSpan(Object obj) {
        a();
        this.f525b.removeSpan(obj);
    }

    @Override // android.text.Spannable
    public final void setSpan(Object obj, int i3, int i4, int i5) {
        a();
        this.f525b.setSpan(obj, i3, i4, i5);
    }

    @Override // java.lang.CharSequence
    public final CharSequence subSequence(int i3, int i4) {
        return this.f525b.subSequence(i3, i4);
    }

    @Override // java.lang.CharSequence
    public final String toString() {
        return this.f525b.toString();
    }
}
