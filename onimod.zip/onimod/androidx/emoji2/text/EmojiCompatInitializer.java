package androidx.emoji2.text;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class EmojiCompatInitializer implements g1.b {
    @Override // g1.b
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // g1.b
    public final Object b(Context context) {
        w wVar = new w(new a0.b(context));
        wVar.f532a = 1;
        if (m.f539k == null) {
            synchronized (m.f538j) {
                try {
                    if (m.f539k == null) {
                        m.f539k = new m(wVar);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        c(context);
        return Boolean.TRUE;
    }

    public final void c(Context context) {
        Object objB;
        g1.a aVarC = g1.a.c(context);
        aVarC.getClass();
        synchronized (g1.a.f2346e) {
            try {
                objB = aVarC.f2347a.get(ProcessLifecycleInitializer.class);
                if (objB == null) {
                    objB = aVarC.b(ProcessLifecycleInitializer.class, new HashSet());
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        final androidx.lifecycle.s sVarE = ((androidx.lifecycle.q) objB).e();
        sVarE.a(new androidx.lifecycle.e(this) { // from class: androidx.emoji2.text.EmojiCompatInitializer.1
            @Override // androidx.lifecycle.e
            public final void b() {
                (Build.VERSION.SDK_INT >= 28 ? c.a(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new o(), 500L);
                sVarE.f(this);
            }
        });
    }
}
