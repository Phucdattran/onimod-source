package androidx.emoji2.text;

import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f555a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final x f556b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public x f557c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public x f558d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f559e;
    public int f;

    public t(x xVar) {
        this.f556b = xVar;
        this.f557c = xVar;
    }

    public final void a() {
        this.f555a = 1;
        this.f557c = this.f556b;
        this.f = 0;
    }

    public final boolean b() {
        v0.a aVarB = this.f557c.f574b.b();
        int iA = aVarB.a(6);
        return !(iA == 0 || ((ByteBuffer) aVarB.f3615d).get(iA + aVarB.f3612a) == 0) || this.f559e == 65039;
    }
}
