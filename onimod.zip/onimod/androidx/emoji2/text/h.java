package androidx.emoji2.text;

import android.graphics.Rect;
import android.view.View;
import e1.k0;
import e1.y0;

/* JADX INFO: loaded from: classes.dex */
public abstract class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f532a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f533b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f534c;

    public h(y0 y0Var) {
        this.f532a = Integer.MIN_VALUE;
        this.f534c = new Rect();
        this.f533b = y0Var;
    }

    public static h a(y0 y0Var, int i3) {
        if (i3 == 0) {
            return new k0(y0Var, 0);
        }
        if (i3 == 1) {
            return new k0(y0Var, 1);
        }
        throw new IllegalArgumentException("invalid orientation");
    }

    public abstract int b(View view);

    public abstract int c(View view);

    public abstract int d(View view);

    public abstract int e(View view);

    public abstract int f();

    public abstract int g();

    public abstract int h();

    public abstract int i();

    public abstract int j();

    public abstract int k();

    public abstract int l();

    public abstract int m(View view);

    public abstract int n(View view);

    public abstract void o(int i3);

    public h(l lVar) {
        this.f532a = 0;
        this.f534c = new e();
        this.f533b = lVar;
    }
}
