package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public final class c0 extends s2.e {
    @Override // s2.e
    public final boolean k(CharSequence charSequence) {
        return b.x(charSequence);
    }
}
