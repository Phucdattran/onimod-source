package androidx.emoji2.text;

import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/* JADX INFO: loaded from: classes.dex */
public final class m {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final Object f538j = new Object();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static volatile m f539k;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ReentrantReadWriteLock f540a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final q.f f541b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile int f542c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Handler f543d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final g f544e;
    public final l f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final s2.e f545g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f546h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final e f547i;

    public m(w wVar) {
        ReentrantReadWriteLock reentrantReadWriteLock = new ReentrantReadWriteLock();
        this.f540a = reentrantReadWriteLock;
        this.f542c = 3;
        l lVar = (l) wVar.f533b;
        this.f = lVar;
        int i3 = wVar.f532a;
        this.f546h = i3;
        this.f547i = (e) wVar.f534c;
        this.f543d = new Handler(Looper.getMainLooper());
        this.f541b = new q.f(0);
        this.f545g = new s2.e(2);
        g gVar = new g(this);
        this.f544e = gVar;
        reentrantReadWriteLock.writeLock().lock();
        if (i3 == 0) {
            try {
                this.f542c = 0;
            } catch (Throwable th) {
                this.f540a.writeLock().unlock();
                throw th;
            }
        }
        reentrantReadWriteLock.writeLock().unlock();
        if (b() == 0) {
            try {
                lVar.c(new f(gVar));
            } catch (Throwable th2) {
                d(th2);
            }
        }
    }

    public static m a() {
        m mVar;
        synchronized (f538j) {
            try {
                mVar = f539k;
                if (!(mVar != null)) {
                    throw new IllegalStateException("EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return mVar;
    }

    public final int b() {
        this.f540a.readLock().lock();
        try {
            return this.f542c;
        } finally {
            this.f540a.readLock().unlock();
        }
    }

    public final void c() {
        if (!(this.f546h == 1)) {
            throw new IllegalStateException("Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
        }
        if (b() == 1) {
            return;
        }
        this.f540a.writeLock().lock();
        try {
            if (this.f542c == 0) {
                this.f540a.writeLock().unlock();
                return;
            }
            this.f542c = 0;
            this.f540a.writeLock().unlock();
            g gVar = this.f544e;
            m mVar = gVar.f529a;
            try {
                mVar.f.c(new f(gVar));
            } catch (Throwable th) {
                mVar.d(th);
            }
        } catch (Throwable th2) {
            this.f540a.writeLock().unlock();
            throw th2;
        }
    }

    public final void d(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.f540a.writeLock().lock();
        try {
            this.f542c = 2;
            arrayList.addAll(this.f541b);
            this.f541b.clear();
            this.f540a.writeLock().unlock();
            this.f543d.post(new k(arrayList, this.f542c, th));
        } catch (Throwable th2) {
            this.f540a.writeLock().unlock();
            throw th2;
        }
    }

    /* JADX WARN: Code duplicated, block: B:103:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:105:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:52:0x009f A[Catch: all -> 0x0082, TryCatch #0 {all -> 0x0082, blocks: (B:32:0x005a, B:35:0x005f, B:37:0x0063, B:39:0x0070, B:46:0x008f, B:48:0x0099, B:50:0x009c, B:52:0x009f, B:54:0x00af, B:55:0x00b2), top: B:94:0x005a }] */
    /* JADX WARN: Code duplicated, block: B:54:0x00af A[Catch: all -> 0x0082, TryCatch #0 {all -> 0x0082, blocks: (B:32:0x005a, B:35:0x005f, B:37:0x0063, B:39:0x0070, B:46:0x008f, B:48:0x0099, B:50:0x009c, B:52:0x009f, B:54:0x00af, B:55:0x00b2), top: B:94:0x005a }] */
    /* JADX WARN: Code duplicated, block: B:61:0x00c7  */
    /* JADX WARN: Code duplicated, block: B:85:0x0104  */
    public final CharSequence e(CharSequence charSequence, int i3, int i4) throws Throwable {
        Throwable th;
        CharSequence charSequence2;
        int i5;
        int i6;
        b0[] b0VarArr;
        int spanStart;
        if (!(b() == 1)) {
            throw new IllegalStateException("Not initialized yet");
        }
        if (i3 < 0) {
            throw new IllegalArgumentException("start cannot be negative");
        }
        if (i4 < 0) {
            throw new IllegalArgumentException("end cannot be negative");
        }
        i1.m.f("start should be <= than end", i3 <= i4);
        d0 d0Var = null;
        if (charSequence == null) {
            return null;
        }
        i1.m.f("start should be < than charSequence length", i3 <= charSequence.length());
        i1.m.f("end should be < than charSequence length", i4 <= charSequence.length());
        if (charSequence.length() == 0 || i3 == i4) {
            return charSequence;
        }
        u uVar = this.f544e.f530b;
        uVar.getClass();
        boolean z4 = charSequence instanceof z;
        if (z4) {
            ((z) charSequence).a();
        }
        if (z4) {
            d0Var = new d0((Spannable) charSequence);
            if (d0Var != null) {
                for (b0 b0Var : b0VarArr) {
                    spanStart = d0Var.f525b.getSpanStart(b0Var);
                    int spanEnd = d0Var.f525b.getSpanEnd(b0Var);
                    if (spanStart != i4) {
                        d0Var.removeSpan(b0Var);
                    }
                    i3 = Math.min(spanStart, i3);
                    i4 = Math.max(spanEnd, i4);
                }
            }
            i5 = i3;
            i6 = i4;
            if (i5 != i6) {
                charSequence2 = charSequence;
                if (!z4) {
                    return charSequence2;
                }
            } else {
                charSequence2 = charSequence;
                if (!z4) {
                    return charSequence2;
                }
            }
            ((z) charSequence2).b();
            return charSequence2;
        }
        try {
            if (charSequence instanceof Spannable) {
                try {
                    d0Var = new d0((Spannable) charSequence);
                } catch (Throwable th2) {
                    th = th2;
                    charSequence2 = charSequence;
                    th = th;
                    if (!z4) {
                        throw th;
                    }
                    ((z) charSequence2).b();
                    throw th;
                }
            } else if ((charSequence instanceof Spanned) && ((Spanned) charSequence).nextSpanTransition(i3 - 1, i4 + 1, b0.class) <= i4) {
                d0Var = new d0();
                d0Var.f524a = false;
                d0Var.f525b = new SpannableString(charSequence);
            }
            if (d0Var != null && (b0VarArr = (b0[]) d0Var.f525b.getSpans(i3, i4, b0.class)) != null && b0VarArr.length > 0) {
                while (i < r5) {
                    spanStart = d0Var.f525b.getSpanStart(b0Var);
                    int spanEnd2 = d0Var.f525b.getSpanEnd(b0Var);
                    if (spanStart != i4) {
                        d0Var.removeSpan(b0Var);
                    }
                    i3 = Math.min(spanStart, i3);
                    i4 = Math.max(spanEnd2, i4);
                }
            }
            i5 = i3;
            i6 = i4;
            if (i5 != i6 || i5 >= charSequence.length()) {
                charSequence2 = charSequence;
                if (!z4) {
                    return charSequence2;
                }
            } else {
                try {
                    charSequence2 = charSequence;
                    try {
                        d0 d0Var2 = (d0) uVar.y(charSequence2, i5, i6, Integer.MAX_VALUE, false, new q(d0Var, 0, (s2.e) uVar.f562b));
                        if (d0Var2 != null) {
                            Spannable spannable = d0Var2.f525b;
                            if (z4) {
                                ((z) charSequence2).b();
                            }
                            return spannable;
                        }
                        if (!z4) {
                            return charSequence2;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        th = th;
                        if (!z4) {
                            throw th;
                        }
                        ((z) charSequence2).b();
                        throw th;
                    }
                } catch (Throwable th4) {
                    charSequence2 = charSequence;
                    th = th4;
                }
            }
            ((z) charSequence2).b();
            return charSequence2;
        } catch (Throwable th5) {
            th = th5;
            charSequence2 = charSequence;
        }
        if (!z4) {
            throw th;
        }
        ((z) charSequence2).b();
        throw th;
    }

    public final void f(j jVar) {
        i1.m.h(jVar, "initCallback cannot be null");
        this.f540a.writeLock().lock();
        try {
            if (this.f542c == 1 || this.f542c == 2) {
                this.f543d.post(new k(Arrays.asList(jVar), this.f542c, (Throwable) null));
            } else {
                this.f541b.add(jVar);
            }
        } finally {
            this.f540a.writeLock().unlock();
        }
    }
}
