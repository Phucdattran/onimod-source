package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public abstract class j {
    public abstract void b();

    public void a() {
    }
}
