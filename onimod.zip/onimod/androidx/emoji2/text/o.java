package androidx.emoji2.text;

import android.os.Trace;

/* JADX INFO: loaded from: classes.dex */
public final class o implements Runnable {
    @Override // java.lang.Runnable
    public final void run() {
        try {
            int i3 = k0.j.f2785a;
            Trace.beginSection("EmojiCompat.EmojiCompatInitializer.run");
            if (m.f539k != null) {
                m.a().c();
            }
        } finally {
            int i4 = k0.j.f2785a;
            Trace.endSection();
        }
    }
}
