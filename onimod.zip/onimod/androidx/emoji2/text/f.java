package androidx.emoji2.text;

import android.os.Build;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class f extends a3.a {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ g f528o;

    public f(g gVar) {
        this.f528o = gVar;
    }

    @Override // a3.a
    public final void T(Throwable th) {
        this.f528o.f529a.d(th);
    }

    @Override // a3.a
    public final void W(a0.k kVar) {
        g gVar = this.f528o;
        gVar.f531c = kVar;
        a0.k kVar2 = gVar.f531c;
        m mVar = gVar.f529a;
        gVar.f530b = new u(kVar2, mVar.f545g, mVar.f547i, Build.VERSION.SDK_INT >= 34 ? p.a() : a3.a.H());
        m mVar2 = gVar.f529a;
        mVar2.getClass();
        ArrayList arrayList = new ArrayList();
        mVar2.f540a.writeLock().lock();
        try {
            mVar2.f542c = 1;
            arrayList.addAll(mVar2.f541b);
            mVar2.f541b.clear();
            mVar2.f540a.writeLock().unlock();
            mVar2.f543d.post(new k(arrayList, mVar2.f542c, (Throwable) null));
        } catch (Throwable th) {
            mVar2.f540a.writeLock().unlock();
            throw th;
        }
    }
}
