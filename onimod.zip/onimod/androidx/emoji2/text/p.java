package androidx.emoji2.text;

import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public abstract class p {
    public static Set<int[]> a() {
        return a3.a.H();
    }
}
