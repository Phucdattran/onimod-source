package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public final class w extends h {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final s2.e f572d = new s2.e(3);
}
