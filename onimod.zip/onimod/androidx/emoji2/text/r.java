package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public interface r {
    boolean b(CharSequence charSequence, int i3, int i4, a0 a0Var);

    Object getResult();
}
