package androidx.emoji2.text;

import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
public final class a0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final ThreadLocal f515d = new ThreadLocal();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f516a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a0.k f517b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile int f518c = 0;

    public a0(a0.k kVar, int i3) {
        this.f517b = kVar;
        this.f516a = i3;
    }

    public final int a(int i3) {
        v0.a aVarB = b();
        int iA = aVarB.a(16);
        if (iA == 0) {
            return 0;
        }
        ByteBuffer byteBuffer = (ByteBuffer) aVarB.f3615d;
        int i4 = iA + aVarB.f3612a;
        return byteBuffer.getInt((i3 * 4) + byteBuffer.getInt(i4) + i4 + 4);
    }

    public final v0.a b() {
        ThreadLocal threadLocal = f515d;
        v0.a aVar = (v0.a) threadLocal.get();
        if (aVar == null) {
            aVar = new v0.a();
            threadLocal.set(aVar);
        }
        v0.b bVar = (v0.b) this.f517b.f23a;
        int iA = bVar.a(6);
        if (iA != 0) {
            int i3 = iA + bVar.f3612a;
            int i4 = (this.f516a * 4) + ((ByteBuffer) bVar.f3615d).getInt(i3) + i3 + 4;
            int i5 = ((ByteBuffer) bVar.f3615d).getInt(i4) + i4;
            ByteBuffer byteBuffer = (ByteBuffer) bVar.f3615d;
            aVar.f3615d = byteBuffer;
            if (byteBuffer != null) {
                aVar.f3612a = i5;
                int i6 = i5 - byteBuffer.getInt(i5);
                aVar.f3613b = i6;
                aVar.f3614c = ((ByteBuffer) aVar.f3615d).getShort(i6);
                return aVar;
            }
            aVar.f3612a = 0;
            aVar.f3613b = 0;
            aVar.f3614c = 0;
        }
        return aVar;
    }

    public final String toString() {
        int i3;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(", id:");
        v0.a aVarB = b();
        int iA = aVarB.a(4);
        sb.append(Integer.toHexString(iA != 0 ? ((ByteBuffer) aVarB.f3615d).getInt(iA + aVarB.f3612a) : 0));
        sb.append(", codepoints:");
        v0.a aVarB2 = b();
        int iA2 = aVarB2.a(16);
        if (iA2 != 0) {
            int i4 = iA2 + aVarB2.f3612a;
            i3 = ((ByteBuffer) aVarB2.f3615d).getInt(((ByteBuffer) aVarB2.f3615d).getInt(i4) + i4);
        } else {
            i3 = 0;
        }
        for (int i5 = 0; i5 < i3; i5++) {
            sb.append(Integer.toHexString(a(i5)));
            sb.append(" ");
        }
        return sb.toString();
    }
}
