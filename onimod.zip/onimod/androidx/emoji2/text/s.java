package androidx.emoji2.text;

import android.text.TextUtils;

/* JADX INFO: loaded from: classes.dex */
public final class s implements r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f553a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f554b;

    public /* synthetic */ s(String str, int i3) {
        this.f553a = i3;
        this.f554b = str;
    }

    @Override // androidx.emoji2.text.r
    public boolean b(CharSequence charSequence, int i3, int i4, a0 a0Var) {
        if (!TextUtils.equals(charSequence.subSequence(i3, i4), this.f554b)) {
            return true;
        }
        a0Var.f518c = (a0Var.f518c & 3) | 4;
        return false;
    }

    @Override // androidx.emoji2.text.r
    public Object getResult() {
        return this;
    }

    public String toString() {
        switch (this.f553a) {
            case 1:
                return "<" + this.f554b + '>';
            default:
                return super.toString();
        }
    }
}
