package androidx.emoji2.text;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.text.style.ReplacementSpan;
import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
public final class b0 extends ReplacementSpan {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a0 f520b;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public TextPaint f523e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Paint.FontMetricsInt f519a = new Paint.FontMetricsInt();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public short f521c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f522d = 1.0f;

    public b0(a0 a0Var) {
        i1.m.h(a0Var, "rasterizer cannot be null");
        this.f520b = a0Var;
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0042  */
    /* JADX WARN: Code duplicated, block: B:21:0x0046  */
    @Override // android.text.style.ReplacementSpan
    public final void draw(Canvas canvas, CharSequence charSequence, int i3, int i4, float f, int i5, int i6, int i7, Paint paint) {
        TextPaint textPaint = null;
        if (charSequence instanceof Spanned) {
            CharacterStyle[] characterStyleArr = (CharacterStyle[]) ((Spanned) charSequence).getSpans(i3, i4, CharacterStyle.class);
            if (characterStyleArr.length != 0) {
                if (characterStyleArr.length != 1 || characterStyleArr[0] != this) {
                    TextPaint textPaint2 = this.f523e;
                    if (textPaint2 == null) {
                        textPaint2 = new TextPaint();
                        this.f523e = textPaint2;
                    }
                    textPaint = textPaint2;
                    textPaint.set(paint);
                    for (CharacterStyle characterStyle : characterStyleArr) {
                        characterStyle.updateDrawState(textPaint);
                    }
                } else if (paint instanceof TextPaint) {
                    textPaint = (TextPaint) paint;
                }
            } else if (paint instanceof TextPaint) {
                textPaint = (TextPaint) paint;
            }
        } else if (paint instanceof TextPaint) {
            textPaint = (TextPaint) paint;
        }
        TextPaint textPaint3 = textPaint;
        if (textPaint3 != null && textPaint3.bgColor != 0) {
            int color = textPaint3.getColor();
            Paint.Style style = textPaint3.getStyle();
            textPaint3.setColor(textPaint3.bgColor);
            textPaint3.setStyle(Paint.Style.FILL);
            canvas.drawRect(f, i5, f + this.f521c, i7, textPaint3);
            textPaint3.setStyle(style);
            textPaint3.setColor(color);
        }
        m.a().getClass();
        float f4 = i6;
        Paint paint2 = textPaint3;
        if (textPaint3 == null) {
            paint2 = paint;
        }
        a0 a0Var = this.f520b;
        a0.k kVar = a0Var.f517b;
        Typeface typeface = (Typeface) kVar.f26d;
        Typeface typeface2 = paint2.getTypeface();
        paint2.setTypeface(typeface);
        canvas.drawText((char[]) kVar.f24b, a0Var.f516a * 2, 2, f, f4, paint2);
        paint2.setTypeface(typeface2);
    }

    @Override // android.text.style.ReplacementSpan
    public final int getSize(Paint paint, CharSequence charSequence, int i3, int i4, Paint.FontMetricsInt fontMetricsInt) {
        Paint.FontMetricsInt fontMetricsInt2 = this.f519a;
        paint.getFontMetricsInt(fontMetricsInt2);
        float fAbs = Math.abs(fontMetricsInt2.descent - fontMetricsInt2.ascent) * 1.0f;
        a0 a0Var = this.f520b;
        v0.a aVarB = a0Var.b();
        int iA = aVarB.a(14);
        this.f522d = fAbs / (iA != 0 ? ((ByteBuffer) aVarB.f3615d).getShort(iA + aVarB.f3612a) : (short) 0);
        v0.a aVarB2 = a0Var.b();
        int iA2 = aVarB2.a(14);
        if (iA2 != 0) {
            ((ByteBuffer) aVarB2.f3615d).getShort(iA2 + aVarB2.f3612a);
        }
        v0.a aVarB3 = a0Var.b();
        int iA3 = aVarB3.a(12);
        short s3 = (short) ((iA3 != 0 ? ((ByteBuffer) aVarB3.f3615d).getShort(iA3 + aVarB3.f3612a) : (short) 0) * this.f522d);
        this.f521c = s3;
        if (fontMetricsInt != null) {
            fontMetricsInt.ascent = fontMetricsInt2.ascent;
            fontMetricsInt.descent = fontMetricsInt2.descent;
            fontMetricsInt.top = fontMetricsInt2.top;
            fontMetricsInt.bottom = fontMetricsInt2.bottom;
        }
        return s3;
    }
}
