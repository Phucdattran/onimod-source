package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public interface l {
    void c(a3.a aVar);
}
