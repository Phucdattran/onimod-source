package androidx.emoji2.text;

import android.content.Context;
import android.content.res.XmlResourceParser;
import android.graphics.Rect;
import android.text.Spannable;
import android.text.SpannableString;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.ActionMode;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import androidx.lifecycle.l0;
import androidx.lifecycle.m0;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import e.f0;
import e1.o1;
import e1.t0;
import e1.u1;
import e1.w0;
import e1.x1;
import e1.y1;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.WeakHashMap;
import o0.d1;
import o0.f1;
import o0.h0;
import o0.j0;
import org.xmlpull.v1.XmlPullParserException;
import top.niunaijun.blackboxa.util.OniLaunch$Step;
import top.niunaijun.blackboxa.view.apps.AppsFragment;
import top.niunaijun.blackboxa.view.main.ShortcutActivity;

/* JADX INFO: loaded from: classes.dex */
public final class q implements r, r0.f, o0.m, top.niunaijun.blackboxa.util.w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f550a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f551b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f552c;

    public /* synthetic */ q(int i3, Object obj) {
        this.f550a = i3;
        this.f552c = obj;
    }

    public static q l(androidx.lifecycle.q qVar) {
        return new q(qVar, ((m0) qVar).b());
    }

    public static int m(int i3, int i4) {
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 0; i7 < i3; i7++) {
            i5++;
            if (i5 == i4) {
                i6++;
                i5 = 0;
            } else if (i5 > i4) {
                i6++;
                i5 = 1;
            }
        }
        return i5 + 1 > i4 ? i6 + 1 : i6;
    }

    @Override // top.niunaijun.blackboxa.util.w
    public void a(final OniLaunch$Step oniLaunch$Step) {
        switch (this.f550a) {
            case 15:
                androidx.fragment.app.z zVarG = ((AppsFragment) this.f551b).g();
                if (zVarG != null) {
                    final top.niunaijun.blackboxa.view.base.c cVar = (top.niunaijun.blackboxa.view.base.c) this.f552c;
                    final int i3 = 0;
                    zVarG.runOnUiThread(new Runnable() { // from class: top.niunaijun.blackboxa.view.apps.k
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i3) {
                                case 0:
                                    top.niunaijun.blackboxa.view.base.c overlay = cVar;
                                    kotlin.jvm.internal.d.f(overlay, "$overlay");
                                    OniLaunch$Step step = oniLaunch$Step;
                                    kotlin.jvm.internal.d.f(step, "$step");
                                    overlay.e(step);
                                    break;
                                default:
                                    top.niunaijun.blackboxa.view.base.c overlay2 = cVar;
                                    kotlin.jvm.internal.d.f(overlay2, "$overlay");
                                    OniLaunch$Step step2 = oniLaunch$Step;
                                    kotlin.jvm.internal.d.f(step2, "$step");
                                    overlay2.e(step2);
                                    break;
                            }
                        }
                    });
                }
                break;
            default:
                ShortcutActivity shortcutActivity = (ShortcutActivity) this.f551b;
                final top.niunaijun.blackboxa.view.base.c cVar2 = (top.niunaijun.blackboxa.view.base.c) this.f552c;
                final int i4 = 1;
                shortcutActivity.runOnUiThread(new Runnable() { // from class: top.niunaijun.blackboxa.view.apps.k
                    @Override // java.lang.Runnable
                    public final void run() {
                        switch (i4) {
                            case 0:
                                top.niunaijun.blackboxa.view.base.c overlay = cVar2;
                                kotlin.jvm.internal.d.f(overlay, "$overlay");
                                OniLaunch$Step step = oniLaunch$Step;
                                kotlin.jvm.internal.d.f(step, "$step");
                                overlay.e(step);
                                break;
                            default:
                                top.niunaijun.blackboxa.view.base.c overlay2 = cVar2;
                                kotlin.jvm.internal.d.f(overlay2, "$overlay");
                                OniLaunch$Step step2 = oniLaunch$Step;
                                kotlin.jvm.internal.d.f(step2, "$step");
                                overlay2.e(step2);
                                break;
                        }
                    }
                });
                break;
        }
    }

    @Override // androidx.emoji2.text.r
    public boolean b(CharSequence charSequence, int i3, int i4, a0 a0Var) {
        if ((a0Var.f518c & 4) > 0) {
            return true;
        }
        if (((d0) this.f551b) == null) {
            this.f551b = new d0(charSequence instanceof Spannable ? (Spannable) charSequence : new SpannableString(charSequence));
        }
        ((s2.e) this.f552c).getClass();
        ((d0) this.f551b).setSpan(new b0(a0Var), i3, i4, 33);
        return true;
    }

    @Override // top.niunaijun.blackboxa.util.w
    public void c(final int i3, final long j4, final long j5) {
        switch (this.f550a) {
            case 15:
                androidx.fragment.app.z zVarG = ((AppsFragment) this.f551b).g();
                if (zVarG != null) {
                    final top.niunaijun.blackboxa.view.base.c cVar = (top.niunaijun.blackboxa.view.base.c) this.f552c;
                    final int i4 = 0;
                    zVarG.runOnUiThread(new Runnable() { // from class: top.niunaijun.blackboxa.view.apps.j
                        @Override // java.lang.Runnable
                        public final void run() {
                            switch (i4) {
                                case 0:
                                    top.niunaijun.blackboxa.view.base.c overlay = cVar;
                                    kotlin.jvm.internal.d.f(overlay, "$overlay");
                                    overlay.c(i3, j4, j5);
                                    break;
                                default:
                                    top.niunaijun.blackboxa.view.base.c overlay2 = cVar;
                                    kotlin.jvm.internal.d.f(overlay2, "$overlay");
                                    overlay2.c(i3, j4, j5);
                                    break;
                            }
                        }
                    });
                }
                break;
            default:
                ShortcutActivity shortcutActivity = (ShortcutActivity) this.f551b;
                final top.niunaijun.blackboxa.view.base.c cVar2 = (top.niunaijun.blackboxa.view.base.c) this.f552c;
                final int i5 = 1;
                shortcutActivity.runOnUiThread(new Runnable() { // from class: top.niunaijun.blackboxa.view.apps.j
                    @Override // java.lang.Runnable
                    public final void run() {
                        switch (i5) {
                            case 0:
                                top.niunaijun.blackboxa.view.base.c overlay = cVar2;
                                kotlin.jvm.internal.d.f(overlay, "$overlay");
                                overlay.c(i3, j4, j5);
                                break;
                            default:
                                top.niunaijun.blackboxa.view.base.c overlay2 = cVar2;
                                kotlin.jvm.internal.d.f(overlay2, "$overlay");
                                overlay2.c(i3, j4, j5);
                                break;
                        }
                    }
                });
                break;
        }
    }

    /* JADX WARN: Code duplicated, block: B:33:0x0089  */
    @Override // o0.m
    public f1 d(View view, f1 f1Var) {
        boolean z4;
        a2.e eVar = (a2.e) this.f551b;
        k2.j jVar = (k2.j) this.f552c;
        int i3 = jVar.f2813a;
        int i4 = jVar.f2814b;
        int i5 = jVar.f2815c;
        d1 d1Var = f1Var.f3545a;
        g0.c cVarF = d1Var.f(7);
        g0.c cVarF2 = d1Var.f(32);
        BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) eVar.f40b;
        int i6 = cVarF.f2321b;
        int i7 = cVarF.f2322c;
        int i8 = cVarF.f2320a;
        bottomSheetBehavior.f1275w = i6;
        boolean zE = k2.h.e(view);
        int paddingBottom = view.getPaddingBottom();
        int paddingLeft = view.getPaddingLeft();
        int paddingRight = view.getPaddingRight();
        boolean z5 = bottomSheetBehavior.f1267o;
        if (z5) {
            int iA = f1Var.a();
            bottomSheetBehavior.f1274v = iA;
            paddingBottom = iA + i5;
        }
        if (bottomSheetBehavior.f1268p) {
            paddingLeft = (zE ? i4 : i3) + i8;
        }
        if (bottomSheetBehavior.f1269q) {
            if (!zE) {
                i3 = i4;
            }
            paddingRight = i3 + i7;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        boolean z6 = true;
        if (!bottomSheetBehavior.f1271s || marginLayoutParams.leftMargin == i8) {
            z4 = false;
        } else {
            marginLayoutParams.leftMargin = i8;
            z4 = true;
        }
        if (bottomSheetBehavior.f1272t && marginLayoutParams.rightMargin != i7) {
            marginLayoutParams.rightMargin = i7;
            z4 = true;
        }
        if (bottomSheetBehavior.f1273u) {
            int i9 = marginLayoutParams.topMargin;
            int i10 = cVarF.f2321b;
            if (i9 != i10) {
                marginLayoutParams.topMargin = i10;
            } else {
                z6 = z4;
            }
        } else {
            z6 = z4;
        }
        if (z6) {
            view.setLayoutParams(marginLayoutParams);
        }
        view.setPadding(paddingLeft, view.getPaddingTop(), paddingRight, paddingBottom);
        boolean z7 = eVar.f39a;
        if (z7) {
            bottomSheetBehavior.f1265m = cVarF2.f2323d;
        }
        if (!z5 && !z7) {
            return f1Var;
        }
        bottomSheetBehavior.I();
        return f1Var;
    }

    public void e(o1 o1Var, t0 t0Var) {
        q.i iVar = (q.i) this.f551b;
        y1 y1VarA = (y1) iVar.get(o1Var);
        if (y1VarA == null) {
            y1VarA = y1.a();
            iVar.put(o1Var, y1VarA);
        }
        y1VarA.f2139c = t0Var;
        y1VarA.f2137a |= 8;
    }

    public boolean f(int i3, int i4) {
        top.niunaijun.blackboxa.view.list.a aVar = (top.niunaijun.blackboxa.view.list.a) ((List) this.f551b).get(i3);
        top.niunaijun.blackboxa.view.list.a aVar2 = (top.niunaijun.blackboxa.view.list.a) ((List) this.f552c).get(i4);
        return kotlin.jvm.internal.d.a(aVar.f4235a, aVar2.f4235a) && aVar.f4238d == aVar2.f4238d && aVar.f4239e == aVar2.f4239e && aVar.f == aVar2.f && aVar.f4240g == aVar2.f4240g && aVar.f4237c == aVar2.f4237c;
    }

    public boolean g(int i3, int i4) {
        return kotlin.jvm.internal.d.a(((top.niunaijun.blackboxa.view.list.a) ((List) this.f551b).get(i3)).f4236b, ((top.niunaijun.blackboxa.view.list.a) ((List) this.f552c).get(i4)).f4236b);
    }

    @Override // androidx.emoji2.text.r
    public Object getResult() {
        return (d0) this.f551b;
    }

    public void h() {
        int[] iArr = (int[]) this.f551b;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
        this.f552c = null;
    }

    public void i(String str, PrintWriter printWriter) {
        q.j jVar = ((b1.a) this.f552c).f1037d;
        if (jVar.f3745c > 0) {
            printWriter.print(str);
            printWriter.println("Loaders:");
            if (jVar.f3745c <= 0) {
                return;
            }
            if (jVar.f3744b[0] != null) {
                throw new ClassCastException();
            }
            printWriter.print(str);
            printWriter.print("  #");
            printWriter.print(jVar.f3743a[0]);
            printWriter.print(": ");
            throw null;
        }
    }

    public void j(int i3) {
        int[] iArr = (int[]) this.f551b;
        if (iArr == null) {
            int[] iArr2 = new int[Math.max(i3, 10) + 1];
            this.f551b = iArr2;
            Arrays.fill(iArr2, -1);
        } else if (i3 >= iArr.length) {
            int length = iArr.length;
            while (length <= i3) {
                length *= 2;
            }
            int[] iArr3 = new int[length];
            this.f551b = iArr3;
            System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
            int[] iArr4 = (int[]) this.f551b;
            Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
        }
    }

    public View k(int i3, int i4, int i5, int i6) {
        View viewU;
        x1 x1Var = (x1) this.f552c;
        w0 w0Var = (w0) this.f551b;
        int iD = w0Var.d();
        int iC = w0Var.c();
        int i7 = i4 > i3 ? 1 : -1;
        View view = null;
        while (i3 != i4) {
            switch (w0Var.f2103a) {
                case 0:
                    viewU = w0Var.f2104b.u(i3);
                    break;
                default:
                    viewU = w0Var.f2104b.u(i3);
                    break;
            }
            int iB = w0Var.b(viewU);
            int iA = w0Var.a(viewU);
            x1Var.f2117b = iD;
            x1Var.f2118c = iC;
            x1Var.f2119d = iB;
            x1Var.f2120e = iA;
            if (i5 != 0) {
                x1Var.f2116a = i5;
                if (x1Var.a()) {
                    return viewU;
                }
            }
            if (i6 != 0) {
                x1Var.f2116a = i6;
                if (x1Var.a()) {
                    view = viewU;
                }
            }
            i3 += i7;
        }
        return view;
    }

    public void n() {
        ((SparseIntArray) this.f551b).clear();
    }

    public boolean o(View view) {
        x1 x1Var = (x1) this.f552c;
        w0 w0Var = (w0) this.f551b;
        int iD = w0Var.d();
        int iC = w0Var.c();
        int iB = w0Var.b(view);
        int iA = w0Var.a(view);
        x1Var.f2117b = iD;
        x1Var.f2118c = iC;
        x1Var.f2119d = iB;
        x1Var.f2120e = iA;
        x1Var.f2116a = 24579;
        return x1Var.a();
    }

    public void p(int i3, int i4) {
        int[] iArr = (int[]) this.f551b;
        if (iArr == null || i3 >= iArr.length) {
            return;
        }
        int i5 = i3 + i4;
        j(i5);
        int[] iArr2 = (int[]) this.f551b;
        System.arraycopy(iArr2, i3, iArr2, i5, (iArr2.length - i3) - i4);
        Arrays.fill((int[]) this.f551b, i3, i5, -1);
        ArrayList arrayList = (ArrayList) this.f552c;
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            u1 u1Var = (u1) ((ArrayList) this.f552c).get(size);
            int i6 = u1Var.f2080a;
            if (i6 >= i3) {
                u1Var.f2080a = i6 + i4;
            }
        }
    }

    public void q(int i3, int i4) {
        int[] iArr = (int[]) this.f551b;
        if (iArr == null || i3 >= iArr.length) {
            return;
        }
        int i5 = i3 + i4;
        j(i5);
        int[] iArr2 = (int[]) this.f551b;
        System.arraycopy(iArr2, i5, iArr2, i3, (iArr2.length - i3) - i4);
        int[] iArr3 = (int[]) this.f551b;
        Arrays.fill(iArr3, iArr3.length - i4, iArr3.length, -1);
        ArrayList arrayList = (ArrayList) this.f552c;
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            u1 u1Var = (u1) ((ArrayList) this.f552c).get(size);
            int i6 = u1Var.f2080a;
            if (i6 >= i3) {
                if (i6 < i5) {
                    ((ArrayList) this.f552c).remove(size);
                } else {
                    u1Var.f2080a = i6 - i4;
                }
            }
        }
    }

    public void r(j.a aVar) {
        a0.k kVar = (a0.k) this.f551b;
        ((ActionMode.Callback) kVar.f23a).onDestroyActionMode(kVar.e(aVar));
        f0 f0Var = (f0) this.f552c;
        if (f0Var.f1698w != null) {
            f0Var.f1687l.getDecorView().removeCallbacks(f0Var.f1699x);
        }
        if (f0Var.f1697v != null) {
            j0 j0Var = f0Var.f1700y;
            if (j0Var != null) {
                j0Var.b();
            }
            j0 j0VarA = h0.a(f0Var.f1697v);
            j0VarA.a(0.0f);
            f0Var.f1700y = j0VarA;
            j0VarA.d(new e.w(2, this));
        }
        f0Var.f1696u = null;
        ViewGroup viewGroup = f0Var.A;
        WeakHashMap weakHashMap = h0.f3558a;
        o0.x.c(viewGroup);
        f0Var.H();
    }

    public boolean s(j.a aVar, Menu menu) {
        ViewGroup viewGroup = ((f0) this.f552c).A;
        WeakHashMap weakHashMap = h0.f3558a;
        o0.x.c(viewGroup);
        a0.k kVar = (a0.k) this.f551b;
        ActionMode.Callback callback = (ActionMode.Callback) kVar.f23a;
        j.e eVarE = kVar.e(aVar);
        q.i iVar = (q.i) kVar.f24b;
        Menu b0Var = (Menu) iVar.get(menu);
        if (b0Var == null) {
            b0Var = new k.b0((Context) kVar.f26d, (k.m) menu);
            iVar.put(menu, b0Var);
        }
        return callback.onPrepareActionMode(eVarE, b0Var);
    }

    public void t(l0.h hVar) {
        l0.m mVar = (l0.m) this.f552c;
        a0.b bVar = (a0.b) this.f551b;
        int i3 = hVar.f3341b;
        if (i3 != 0) {
            mVar.execute(new k(bVar, i3, 2));
        } else {
            mVar.execute(new c0.d(bVar, 5, hVar.f3340a));
        }
    }

    public String toString() {
        int iLastIndexOf;
        switch (this.f550a) {
            case 2:
                StringBuilder sb = new StringBuilder(128);
                sb.append("LoaderManager{");
                sb.append(Integer.toHexString(System.identityHashCode(this)));
                sb.append(" in ");
                androidx.lifecycle.q qVar = (androidx.lifecycle.q) this.f551b;
                if (qVar == null) {
                    sb.append("null");
                } else {
                    String simpleName = qVar.getClass().getSimpleName();
                    if (simpleName.length() <= 0 && (iLastIndexOf = (simpleName = qVar.getClass().getName()).lastIndexOf(46)) > 0) {
                        simpleName = simpleName.substring(iLastIndexOf + 1);
                    }
                    sb.append(simpleName);
                    sb.append('{');
                    sb.append(Integer.toHexString(System.identityHashCode(qVar)));
                }
                sb.append("}}");
                return sb.toString();
            case 12:
                return "Bounds{lower=" + ((g0.c) this.f551b) + " upper=" + ((g0.c) this.f552c) + "}";
            case 14:
                String str = "[ ";
                if (((t.e) this.f551b) != null) {
                    for (int i3 = 0; i3 < 9; i3++) {
                        str = str + ((t.e) this.f551b).f3977h[i3] + " ";
                    }
                }
                return str + "] " + ((t.e) this.f551b);
            default:
                return super.toString();
        }
    }

    /* JADX WARN: Code duplicated, block: B:106:0x00fe A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:57:0x00f7 A[Catch: IOException | XmlPullParserException -> 0x01fd, IOException | XmlPullParserException -> 0x01fd, TryCatch #0 {IOException | XmlPullParserException -> 0x01fd, blocks: (B:18:0x0056, B:91:0x01f7, B:91:0x01f7, B:26:0x0068, B:27:0x0076, B:29:0x007b, B:32:0x0085, B:40:0x009f, B:35:0x008e, B:38:0x0097, B:41:0x00ad, B:45:0x00bc, B:45:0x00bc, B:47:0x00c4, B:47:0x00c4, B:48:0x00ce, B:48:0x00ce, B:57:0x00f7, B:57:0x00f7, B:58:0x00fe, B:58:0x00fe, B:59:0x0116, B:59:0x0116, B:51:0x00d7, B:51:0x00d7, B:53:0x00df, B:53:0x00df, B:54:0x00ed, B:54:0x00ed, B:60:0x0117, B:60:0x0117, B:62:0x011f, B:62:0x011f, B:63:0x012d, B:63:0x012d, B:66:0x0137, B:66:0x0137, B:67:0x0142, B:67:0x0142, B:68:0x015a, B:68:0x015a, B:69:0x015b, B:69:0x015b, B:72:0x0165, B:72:0x0165, B:73:0x0170, B:73:0x0170, B:74:0x0188, B:74:0x0188, B:75:0x0189, B:75:0x0189, B:77:0x0191, B:77:0x0191, B:78:0x019a, B:78:0x019a, B:81:0x01a4, B:81:0x01a4, B:82:0x01ae, B:82:0x01ae, B:83:0x01c6, B:83:0x01c6, B:84:0x01c7, B:84:0x01c7, B:87:0x01d1, B:87:0x01d1, B:88:0x01db, B:88:0x01db, B:89:0x01f3, B:89:0x01f3, B:90:0x01f4, B:90:0x01f4), top: B:98:0x0056 }] */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public void u(Context context, XmlResourceParser xmlResourceParser) {
        y.n nVar = new y.n();
        int attributeCount = xmlResourceParser.getAttributeCount();
        for (int i3 = 0; i3 < attributeCount; i3++) {
            String attributeName = xmlResourceParser.getAttributeName(i3);
            String attributeValue = xmlResourceParser.getAttributeValue(i3);
            if (attributeName != null && attributeValue != null && "id".equals(attributeName)) {
                int identifier = attributeValue.contains("/") ? context.getResources().getIdentifier(attributeValue.substring(attributeValue.indexOf(47) + 1), "id", context.getPackageName()) : -1;
                if (identifier == -1 && attributeValue.length() > 1) {
                    identifier = Integer.parseInt(attributeValue.substring(1));
                }
                try {
                    int eventType = xmlResourceParser.getEventType();
                    y.i iVarD = null;
                    while (eventType != 1) {
                        if (eventType == 0) {
                            xmlResourceParser.getName();
                        } else if (eventType == 2) {
                            String name = xmlResourceParser.getName();
                            switch (name.hashCode()) {
                                case -2025855158:
                                    if (name.equals("Layout")) {
                                        if (iVarD == null) {
                                            throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                                        }
                                        iVarD.f4819d.a(context, Xml.asAttributeSet(xmlResourceParser));
                                    } else {
                                        continue;
                                    }
                                    break;
                                case -1984451626:
                                    if (name.equals("Motion")) {
                                        if (iVarD == null) {
                                            throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                                        }
                                        iVarD.f4818c.a(context, Xml.asAttributeSet(xmlResourceParser));
                                    } else {
                                        continue;
                                    }
                                    break;
                                case -1962203927:
                                    if (name.equals("ConstraintOverride")) {
                                        iVarD = y.n.d(context, Xml.asAttributeSet(xmlResourceParser), true);
                                    }
                                    break;
                                case -1269513683:
                                    if (name.equals("PropertySet")) {
                                        if (iVarD == null) {
                                            throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                                        }
                                        iVarD.f4817b.a(context, Xml.asAttributeSet(xmlResourceParser));
                                    } else {
                                        continue;
                                    }
                                    break;
                                case -1238332596:
                                    if (name.equals("Transform")) {
                                        if (iVarD == null) {
                                            throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                                        }
                                        iVarD.f4820e.a(context, Xml.asAttributeSet(xmlResourceParser));
                                    } else {
                                        continue;
                                    }
                                    break;
                                case -71750448:
                                    if (name.equals("Guideline")) {
                                        iVarD = y.n.d(context, Xml.asAttributeSet(xmlResourceParser), false);
                                        iVarD.f4819d.f4822a = true;
                                    }
                                    break;
                                case 366511058:
                                    if (name.equals("CustomMethod")) {
                                        if (iVarD != null) {
                                            throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                                        }
                                        y.b.a(context, xmlResourceParser, iVarD.f);
                                    } else {
                                        continue;
                                    }
                                    break;
                                case 1331510167:
                                    if (name.equals("Barrier")) {
                                        iVarD = y.n.d(context, Xml.asAttributeSet(xmlResourceParser), false);
                                        iVarD.f4819d.f4836h0 = 1;
                                    }
                                    break;
                                case 1791837707:
                                    if (name.equals("CustomAttribute")) {
                                        if (iVarD != null) {
                                            throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                                        }
                                        y.b.a(context, xmlResourceParser, iVarD.f);
                                    } else {
                                        continue;
                                    }
                                    break;
                                case 1803088381:
                                    if (name.equals("Constraint")) {
                                        iVarD = y.n.d(context, Xml.asAttributeSet(xmlResourceParser), false);
                                    }
                                    break;
                            }
                        } else if (eventType == 3) {
                            String lowerCase = xmlResourceParser.getName().toLowerCase(Locale.ROOT);
                            switch (lowerCase.hashCode()) {
                                case -2075718416:
                                    if (lowerCase.equals("guideline")) {
                                        nVar.f4891c.put(Integer.valueOf(iVarD.f4816a), iVarD);
                                        iVarD = null;
                                    }
                                    break;
                                case -190376483:
                                    if (lowerCase.equals("constraint")) {
                                        nVar.f4891c.put(Integer.valueOf(iVarD.f4816a), iVarD);
                                        iVarD = null;
                                    }
                                    break;
                                case 426575017:
                                    if (lowerCase.equals("constraintoverride")) {
                                        nVar.f4891c.put(Integer.valueOf(iVarD.f4816a), iVarD);
                                        iVarD = null;
                                    }
                                    break;
                                case 2146106725:
                                    if (lowerCase.equals("constraintset")) {
                                        ((SparseArray) this.f552c).put(identifier, nVar);
                                        return;
                                    }
                                    break;
                                    break;
                                default:
                                    break;
                            }
                        }
                        eventType = xmlResourceParser.next();
                    }
                } catch (IOException | XmlPullParserException unused) {
                }
                ((SparseArray) this.f552c).put(identifier, nVar);
                return;
            }
        }
    }

    public t0 v(o1 o1Var, int i3) {
        y1 y1Var;
        t0 t0Var;
        q.i iVar = (q.i) this.f551b;
        int iD = iVar.d(o1Var);
        if (iD >= 0 && (y1Var = (y1) iVar.i(iD)) != null) {
            int i4 = y1Var.f2137a;
            if ((i4 & i3) != 0) {
                int i5 = i4 & (~i3);
                y1Var.f2137a = i5;
                if (i3 == 4) {
                    t0Var = y1Var.f2138b;
                } else {
                    if (i3 != 8) {
                        throw new IllegalArgumentException("Must provide flag PRE or POST");
                    }
                    t0Var = y1Var.f2139c;
                }
                if ((i5 & 12) == 0) {
                    iVar.g(iD);
                    y1Var.f2137a = 0;
                    y1Var.f2138b = null;
                    y1Var.f2139c = null;
                    y1.f2136d.c(y1Var);
                }
                return t0Var;
            }
        }
        return null;
    }

    public void w(o1 o1Var) {
        y1 y1Var = (y1) ((q.i) this.f551b).get(o1Var);
        if (y1Var == null) {
            return;
        }
        y1Var.f2137a &= -2;
    }

    public void x(o1 o1Var) {
        q.g gVar = (q.g) this.f552c;
        for (int iJ = gVar.j() - 1; iJ >= 0; iJ--) {
            if (o1Var == gVar.k(iJ)) {
                Object[] objArr = gVar.f3736c;
                Object obj = objArr[iJ];
                Object obj2 = q.h.f3738a;
                if (obj == obj2) {
                    break;
                }
                objArr[iJ] = obj2;
                gVar.f3734a = true;
                break;
            }
        }
        y1 y1Var = (y1) ((q.i) this.f551b).remove(o1Var);
        if (y1Var != null) {
            y1Var.f2137a = 0;
            y1Var.f2138b = null;
            y1Var.f2139c = null;
            y1.f2136d.c(y1Var);
        }
    }

    public void y(int i3, int i4, int i5, int i6) {
        p.a aVar = (p.a) this.f552c;
        aVar.f3663d.set(i3, i4, i5, i6);
        Rect rect = aVar.f3662c;
        super/*android.widget.FrameLayout*/.setPadding(i3 + rect.left, i4 + rect.top, i5 + rect.right, i6 + rect.bottom);
    }

    public /* synthetic */ q(int i3, boolean z4) {
        this.f550a = i3;
    }

    public /* synthetic */ q(Object obj, int i3, Object obj2) {
        this.f550a = i3;
        this.f551b = obj;
        this.f552c = obj2;
    }

    public q(androidx.lifecycle.q qVar, l0 l0Var) {
        this.f550a = 2;
        this.f551b = qVar;
        this.f552c = (b1.a) new u(l0Var, b1.a.f1036e).k(b1.a.class);
    }

    public q(w0 w0Var) {
        this.f550a = 7;
        this.f551b = w0Var;
        x1 x1Var = new x1();
        x1Var.f2116a = 0;
        this.f552c = x1Var;
    }

    public q(ArrayList arrayList, ArrayList arrayList2) {
        this.f550a = 9;
        int size = arrayList.size();
        this.f551b = new int[size];
        this.f552c = new float[size];
        for (int i3 = 0; i3 < size; i3++) {
            ((int[]) this.f551b)[i3] = ((Integer) arrayList.get(i3)).intValue();
            ((float[]) this.f552c)[i3] = ((Float) arrayList2.get(i3)).floatValue();
        }
    }

    public q(int i3, int i4) {
        this.f550a = 9;
        this.f551b = new int[]{i3, i4};
        this.f552c = new float[]{0.0f, 1.0f};
    }

    public q(int i3, int i4, int i5) {
        this.f550a = 9;
        this.f551b = new int[]{i3, i4, i5};
        this.f552c = new float[]{0.0f, 0.5f, 1.0f};
    }

    public q(EditText editText) {
        this.f550a = 18;
        this.f551b = editText;
        w0.i iVar = new w0.i(editText);
        this.f552c = iVar;
        editText.addTextChangedListener(iVar);
        if (w0.a.f4691b == null) {
            synchronized (w0.a.f4690a) {
                try {
                    if (w0.a.f4691b == null) {
                        w0.a aVar = new w0.a();
                        try {
                            w0.a.f4692c = Class.forName("android.text.DynamicLayout$ChangeWatcher", false, w0.a.class.getClassLoader());
                        } catch (Throwable unused) {
                        }
                        w0.a.f4691b = aVar;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        editText.setEditableFactory(w0.a.f4691b);
    }

    public q(androidx.viewpager2.adapter.e eVar, androidx.fragment.app.w wVar, FrameLayout frameLayout) {
        this.f550a = 1;
        this.f551b = wVar;
        this.f552c = frameLayout;
    }

    public q(int i3) {
        this.f550a = i3;
        switch (i3) {
            case 8:
                this.f551b = new q.i(0);
                this.f552c = new q.g();
                break;
            default:
                this.f551b = new SparseIntArray();
                this.f552c = new SparseIntArray();
                break;
        }
    }

    public q(f0 f0Var, a0.k kVar) {
        this.f550a = 4;
        this.f552c = f0Var;
        this.f551b = kVar;
    }
}
