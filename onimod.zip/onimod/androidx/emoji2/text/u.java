package androidx.emoji2.text;

import android.content.ClipDescription;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.text.Editable;
import android.text.Selection;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.core.widgets.ConstraintWidget$DimensionBehaviour;
import androidx.lifecycle.f0;
import androidx.lifecycle.i0;
import androidx.lifecycle.j0;
import androidx.lifecycle.k0;
import androidx.lifecycle.l0;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import e.m0;
import e1.a1;
import e1.n0;
import e1.o0;
import e1.o1;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import l.r0;
import o0.h0;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public final class u implements q0.g {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static u f560e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f561a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f562b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f563c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f564d;

    public /* synthetic */ u() {
        this.f561a = 10;
    }

    public static u h(View view) {
        int i3 = R.id.badge;
        TextView textView = (TextView) i1.m.p(view, R.id.badge);
        if (textView != null) {
            i3 = R.id.icon;
            ImageView imageView = (ImageView) i1.m.p(view, R.id.icon);
            if (imageView != null) {
                i3 = R.id.iconCard;
                if (((MaterialCardView) i1.m.p(view, R.id.iconCard)) != null) {
                    i3 = R.id.name;
                    TextView textView2 = (TextView) i1.m.p(view, R.id.name);
                    if (textView2 != null) {
                        return new u(13, textView, imageView, textView2);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i3)));
    }

    public static boolean i(Editable editable, KeyEvent keyEvent, boolean z4) {
        b0[] b0VarArr;
        if (KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState())) {
            int selectionStart = Selection.getSelectionStart(editable);
            int selectionEnd = Selection.getSelectionEnd(editable);
            if (selectionStart != -1 && selectionEnd != -1 && selectionStart == selectionEnd && (b0VarArr = (b0[]) editable.getSpans(selectionStart, selectionEnd, b0.class)) != null && b0VarArr.length > 0) {
                for (b0 b0Var : b0VarArr) {
                    int spanStart = editable.getSpanStart(b0Var);
                    int spanEnd = editable.getSpanEnd(b0Var);
                    if ((z4 && spanStart == selectionStart) || ((!z4 && spanEnd == selectionStart) || (selectionStart > spanStart && selectionStart < spanEnd))) {
                        editable.delete(spanStart, spanEnd);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static u x(Context context, AttributeSet attributeSet, int[] iArr, int i3) {
        return new u(context, context.obtainStyledAttributes(attributeSet, iArr, i3, 0));
    }

    public void A(v.e eVar, int i3, int i4, int i5) {
        eVar.getClass();
        int i6 = eVar.f4436c0;
        int i7 = eVar.f4438d0;
        eVar.f4436c0 = 0;
        eVar.f4438d0 = 0;
        eVar.O(i4);
        eVar.L(i5);
        if (i6 < 0) {
            eVar.f4436c0 = 0;
        } else {
            eVar.f4436c0 = i6;
        }
        if (i7 < 0) {
            eVar.f4438d0 = 0;
        } else {
            eVar.f4438d0 = i7;
        }
        v.e eVar2 = (v.e) this.f564d;
        eVar2.f4474t0 = i3;
        eVar2.U();
    }

    public FileOutputStream B() throws IOException {
        File file = (File) this.f563c;
        File file2 = (File) this.f564d;
        if (file2.exists()) {
            File file3 = (File) this.f562b;
            if (file3.isDirectory() && !file3.delete()) {
                file3.toString();
            }
            if (!file2.renameTo(file3)) {
                file2.toString();
                file3.toString();
            }
        }
        try {
            return new FileOutputStream(file);
        } catch (FileNotFoundException unused) {
            if (!file.getParentFile().mkdirs()) {
                throw new IOException("Failed to create directory for " + file);
            }
            try {
                return new FileOutputStream(file);
            } catch (FileNotFoundException e4) {
                throw new IOException("Failed to create new file " + file, e4);
            }
        }
    }

    public void C(View view) {
        if (((ArrayList) this.f564d).remove(view)) {
            n0 n0Var = (n0) this.f562b;
            o1 o1VarJ = RecyclerView.J(view);
            if (o1VarJ != null) {
                RecyclerView recyclerView = n0Var.f1988a;
                int i3 = o1VarJ.f2017p;
                if (recyclerView.M()) {
                    o1VarJ.f2018q = i3;
                    recyclerView.f958t0.add(o1VarJ);
                } else {
                    View view2 = o1VarJ.f2003a;
                    WeakHashMap weakHashMap = h0.f3558a;
                    view2.setImportantForAccessibility(i3);
                }
                o1VarJ.f2017p = 0;
            }
        }
    }

    public void D(v.e eVar) {
        ArrayList arrayList = (ArrayList) this.f562b;
        arrayList.clear();
        int size = eVar.f4471q0.size();
        for (int i3 = 0; i3 < size; i3++) {
            v.d dVar = (v.d) eVar.f4471q0.get(i3);
            ConstraintWidget$DimensionBehaviour[] constraintWidget$DimensionBehaviourArr = dVar.T;
            ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour = constraintWidget$DimensionBehaviourArr[0];
            ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour2 = ConstraintWidget$DimensionBehaviour.f383c;
            if (constraintWidget$DimensionBehaviour == constraintWidget$DimensionBehaviour2 || constraintWidget$DimensionBehaviourArr[1] == constraintWidget$DimensionBehaviour2) {
                arrayList.add(dVar);
            }
        }
        eVar.f4473s0.f4676b = true;
    }

    @Override // q0.g
    public Uri a() {
        return (Uri) this.f562b;
    }

    @Override // q0.g
    public Uri c() {
        return (Uri) this.f564d;
    }

    @Override // q0.g
    public ClipDescription d() {
        return (ClipDescription) this.f563c;
    }

    @Override // q0.g
    public Object e() {
        return null;
    }

    public void f(View view, int i3, boolean z4) {
        RecyclerView recyclerView = ((n0) this.f562b).f1988a;
        int childCount = i3 < 0 ? recyclerView.getChildCount() : r(i3);
        ((e1.d) this.f563c).e(childCount, z4);
        if (z4) {
            v(view);
        }
        recyclerView.addView(view, childCount);
        o1 o1VarJ = RecyclerView.J(view);
        o0 o0Var = recyclerView.f941l;
        if (o0Var != null && o1VarJ != null) {
            o0Var.j(o1VarJ);
        }
        ArrayList arrayList = recyclerView.B;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((a1) recyclerView.B.get(size)).c(view);
            }
        }
    }

    public void g(View view, int i3, ViewGroup.LayoutParams layoutParams, boolean z4) {
        RecyclerView recyclerView = ((n0) this.f562b).f1988a;
        int childCount = i3 < 0 ? recyclerView.getChildCount() : r(i3);
        ((e1.d) this.f563c).e(childCount, z4);
        if (z4) {
            v(view);
        }
        o1 o1VarJ = RecyclerView.J(view);
        if (o1VarJ != null) {
            if (!o1VarJ.k() && !o1VarJ.p()) {
                throw new IllegalArgumentException("Called attach on a child which is not detached: " + o1VarJ + recyclerView.z());
            }
            o1VarJ.f2011j &= -257;
        }
        recyclerView.attachViewToParent(view, childCount, layoutParams);
    }

    public void j(int i3) {
        o1 o1VarJ;
        int iR = r(i3);
        ((e1.d) this.f563c).f(iR);
        RecyclerView recyclerView = ((n0) this.f562b).f1988a;
        View childAt = recyclerView.getChildAt(iR);
        if (childAt != null && (o1VarJ = RecyclerView.J(childAt)) != null) {
            if (o1VarJ.k() && !o1VarJ.p()) {
                throw new IllegalArgumentException("called detach on an already detached child " + o1VarJ + recyclerView.z());
            }
            o1VarJ.a(256);
        }
        recyclerView.detachViewFromParent(iR);
    }

    public i0 k(Class cls) {
        i0 viewModel;
        String canonicalName = cls.getCanonicalName();
        if (canonicalName == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        String key = "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(canonicalName);
        k0 k0Var = (k0) this.f563c;
        kotlin.jvm.internal.d.f(key, "key");
        l0 l0Var = (l0) this.f562b;
        l0Var.getClass();
        LinkedHashMap linkedHashMap = l0Var.f873a;
        i0 i0Var = (i0) linkedHashMap.get(key);
        if (cls.isInstance(i0Var)) {
            kotlin.jvm.internal.d.d(i0Var, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
            return i0Var;
        }
        a1.c cVar = new a1.c((a1.b) this.f564d);
        cVar.f30a.put(j0.f871b, key);
        try {
            viewModel = k0Var.c(cls, cVar);
        } catch (AbstractMethodError unused) {
            viewModel = k0Var.a(cls);
        }
        kotlin.jvm.internal.d.f(viewModel, "viewModel");
        i0 i0Var2 = (i0) linkedHashMap.put(key, viewModel);
        if (i0Var2 != null) {
            i0Var2.c();
        }
        return viewModel;
    }

    public View l(int i3) {
        return ((n0) this.f562b).f1988a.getChildAt(r(i3));
    }

    public int m() {
        return ((n0) this.f562b).f1988a.getChildCount() - ((ArrayList) this.f564d).size();
    }

    public ColorStateList n(int i3) {
        int resourceId;
        ColorStateList colorStateListC;
        TypedArray typedArray = (TypedArray) this.f563c;
        return (!typedArray.hasValue(i3) || (resourceId = typedArray.getResourceId(i3, 0)) == 0 || (colorStateListC = c0.g.c((Context) this.f562b, resourceId)) == null) ? typedArray.getColorStateList(i3) : colorStateListC;
    }

    public Drawable o(int i3) {
        int resourceId;
        TypedArray typedArray = (TypedArray) this.f563c;
        return (!typedArray.hasValue(i3) || (resourceId = typedArray.getResourceId(i3, 0)) == 0) ? typedArray.getDrawable(i3) : a3.a.G((Context) this.f562b, resourceId);
    }

    public Drawable p(int i3) {
        int resourceId;
        Drawable drawableG;
        if (!((TypedArray) this.f563c).hasValue(i3) || (resourceId = ((TypedArray) this.f563c).getResourceId(i3, 0)) == 0) {
            return null;
        }
        l.s sVarA = l.s.a();
        Context context = (Context) this.f562b;
        synchronized (sVarA) {
            drawableG = sVarA.f3232a.g(context, resourceId, true);
        }
        return drawableG;
    }

    public Typeface q(int i3, int i4, r0 r0Var) {
        int resourceId = ((TypedArray) this.f563c).getResourceId(i3, 0);
        if (resourceId == 0) {
            return null;
        }
        if (((TypedValue) this.f564d) == null) {
            this.f564d = new TypedValue();
        }
        Context context = (Context) this.f562b;
        TypedValue typedValue = (TypedValue) this.f564d;
        ThreadLocal threadLocal = f0.m.f2213a;
        if (context.isRestricted()) {
            return null;
        }
        return f0.m.c(context, resourceId, typedValue, i4, r0Var, true, false);
    }

    public int r(int i3) {
        e1.d dVar = (e1.d) this.f563c;
        if (i3 < 0) {
            return -1;
        }
        int childCount = ((n0) this.f562b).f1988a.getChildCount();
        int i4 = i3;
        while (i4 < childCount) {
            int iB = i3 - (i4 - dVar.b(i4));
            if (iB == 0) {
                while (dVar.d(i4)) {
                    i4++;
                }
                return i4;
            }
            i4 += iB;
        }
        return -1;
    }

    public View s(int i3) {
        return ((n0) this.f562b).f1988a.getChildAt(i3);
    }

    public int t() {
        return ((n0) this.f562b).f1988a.getChildCount();
    }

    public String toString() {
        switch (this.f561a) {
            case 4:
                return ((e1.d) this.f563c).toString() + ", hidden list:" + ((ArrayList) this.f564d).size();
            default:
                return super.toString();
        }
    }

    /* JADX WARN: Code duplicated, block: B:11:0x0033  */
    /* JADX WARN: Code duplicated, block: B:42:0x00c4  */
    public boolean u(CharSequence charSequence, int i3, int i4, a0 a0Var) {
        boolean zH;
        if ((a0Var.f518c & 3) == 0) {
            i iVar = (i) this.f564d;
            v0.a aVarB = a0Var.b();
            int iA = aVarB.a(8);
            short s3 = iA != 0 ? ((ByteBuffer) aVarB.f3615d).getShort(iA + aVarB.f3612a) : (short) 0;
            e eVar = (e) iVar;
            eVar.getClass();
            int i5 = Build.VERSION.SDK_INT;
            if (i5 >= 23 || s3 <= i5) {
                ThreadLocal threadLocal = e.f526b;
                if (threadLocal.get() == null) {
                    threadLocal.set(new StringBuilder());
                }
                StringBuilder sb = (StringBuilder) threadLocal.get();
                sb.setLength(0);
                while (i3 < i4) {
                    sb.append(charSequence.charAt(i3));
                    i3++;
                }
                TextPaint textPaint = eVar.f527a;
                String string = sb.toString();
                ThreadLocal threadLocal2 = g0.d.f2324a;
                if (Build.VERSION.SDK_INT >= 23) {
                    zH = d0.a.h(textPaint, string);
                } else {
                    int length = string.length();
                    if (length == 1 && Character.isWhitespace(string.charAt(0))) {
                        zH = true;
                    } else {
                        float fMeasureText = textPaint.measureText("\udfffd");
                        float fMeasureText2 = textPaint.measureText("m");
                        float fMeasureText3 = textPaint.measureText(string);
                        float fMeasureText4 = 0.0f;
                        if (fMeasureText3 != 0.0f) {
                            if (string.codePointCount(0, string.length()) > 1) {
                                if (fMeasureText3 <= fMeasureText2 * 2.0f) {
                                    int i6 = 0;
                                    while (i6 < length) {
                                        int iCharCount = Character.charCount(string.codePointAt(i6)) + i6;
                                        fMeasureText4 += textPaint.measureText(string, i6, iCharCount);
                                        i6 = iCharCount;
                                    }
                                    if (fMeasureText3 >= fMeasureText4) {
                                    }
                                }
                                zH = false;
                            }
                            if (fMeasureText3 != fMeasureText) {
                                zH = true;
                            } else {
                                ThreadLocal threadLocal3 = g0.d.f2324a;
                                n0.b bVar = (n0.b) threadLocal3.get();
                                if (bVar == null) {
                                    bVar = new n0.b(new Rect(), new Rect());
                                    threadLocal3.set(bVar);
                                } else {
                                    bVar.f3403a.setEmpty();
                                    bVar.f3404b.setEmpty();
                                }
                                Rect rect = bVar.f3404b;
                                Rect rect2 = bVar.f3403a;
                                textPaint.getTextBounds("\udfffd", 0, 2, rect2);
                                textPaint.getTextBounds(string, 0, length, rect);
                                zH = !rect2.equals(rect);
                            }
                        } else {
                            zH = false;
                        }
                    }
                }
            } else {
                zH = false;
            }
            int i7 = a0Var.f518c & 4;
            a0Var.f518c = zH ? i7 | 2 : i7 | 1;
        }
        return (a0Var.f518c & 3) == 2;
    }

    public void v(View view) {
        ((ArrayList) this.f564d).add(view);
        n0 n0Var = (n0) this.f562b;
        o1 o1VarJ = RecyclerView.J(view);
        if (o1VarJ != null) {
            View view2 = o1VarJ.f2003a;
            RecyclerView recyclerView = n0Var.f1988a;
            int i3 = o1VarJ.f2018q;
            if (i3 != -1) {
                o1VarJ.f2017p = i3;
            } else {
                WeakHashMap weakHashMap = h0.f3558a;
                o1VarJ.f2017p = view2.getImportantForAccessibility();
            }
            if (recyclerView.M()) {
                o1VarJ.f2018q = 4;
                recyclerView.f958t0.add(o1VarJ);
            } else {
                WeakHashMap weakHashMap2 = h0.f3558a;
                view2.setImportantForAccessibility(4);
            }
        }
    }

    public boolean w(int i3, v.d dVar, y.f fVar) {
        w.b bVar = (w.b) this.f563c;
        ConstraintWidget$DimensionBehaviour[] constraintWidget$DimensionBehaviourArr = dVar.T;
        int[] iArr = dVar.f4464t;
        bVar.f4664a = constraintWidget$DimensionBehaviourArr[0];
        bVar.f4665b = constraintWidget$DimensionBehaviourArr[1];
        bVar.f4666c = dVar.q();
        bVar.f4667d = dVar.k();
        bVar.f4671i = false;
        bVar.f4672j = i3;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour = bVar.f4664a;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour2 = ConstraintWidget$DimensionBehaviour.f383c;
        boolean z4 = constraintWidget$DimensionBehaviour == constraintWidget$DimensionBehaviour2;
        boolean z5 = bVar.f4665b == constraintWidget$DimensionBehaviour2;
        boolean z6 = z4 && dVar.X > 0.0f;
        boolean z7 = z5 && dVar.X > 0.0f;
        ConstraintWidget$DimensionBehaviour constraintWidget$DimensionBehaviour3 = ConstraintWidget$DimensionBehaviour.f381a;
        if (z6 && iArr[0] == 4) {
            bVar.f4664a = constraintWidget$DimensionBehaviour3;
        }
        if (z7 && iArr[1] == 4) {
            bVar.f4665b = constraintWidget$DimensionBehaviour3;
        }
        fVar.b(dVar, bVar);
        dVar.O(bVar.f4668e);
        dVar.L(bVar.f);
        dVar.E = bVar.f4670h;
        dVar.I(bVar.f4669g);
        bVar.f4672j = 0;
        return bVar.f4671i;
    }

    public Object y(CharSequence charSequence, int i3, int i4, int i5, boolean z4, r rVar) {
        char c3;
        t tVar = new t((x) ((a0.k) this.f563c).f25c);
        int i6 = i3;
        int iCodePointAt = Character.codePointAt(charSequence, i3);
        int i7 = 0;
        boolean zB = true;
        int iCharCount = i6;
        while (iCharCount < i4 && i7 < i5 && zB) {
            SparseArray sparseArray = tVar.f557c.f573a;
            x xVar = sparseArray == null ? null : (x) sparseArray.get(iCodePointAt);
            if (tVar.f555a == 2) {
                if (xVar != null) {
                    tVar.f557c = xVar;
                    tVar.f++;
                } else {
                    if (iCodePointAt == 65038) {
                        tVar.a();
                    } else if (iCodePointAt != 65039) {
                        x xVar2 = tVar.f557c;
                        if (xVar2.f574b != null) {
                            if (tVar.f != 1) {
                                tVar.f558d = xVar2;
                                tVar.a();
                            } else if (tVar.b()) {
                                tVar.f558d = tVar.f557c;
                                tVar.a();
                            } else {
                                tVar.a();
                            }
                            c3 = 3;
                        } else {
                            tVar.a();
                        }
                    }
                    c3 = 1;
                }
                c3 = 2;
            } else if (xVar == null) {
                tVar.a();
                c3 = 1;
            } else {
                tVar.f555a = 2;
                tVar.f557c = xVar;
                tVar.f = 1;
                c3 = 2;
            }
            tVar.f559e = iCodePointAt;
            if (c3 == 1) {
                iCharCount = Character.charCount(Character.codePointAt(charSequence, i6)) + i6;
                if (iCharCount < i4) {
                    iCodePointAt = Character.codePointAt(charSequence, iCharCount);
                }
            } else if (c3 == 2) {
                int iCharCount2 = Character.charCount(iCodePointAt) + iCharCount;
                if (iCharCount2 < i4) {
                    iCodePointAt = Character.codePointAt(charSequence, iCharCount2);
                }
                iCharCount = iCharCount2;
            } else if (c3 == 3) {
                if (z4 || !u(charSequence, i6, iCharCount, tVar.f558d.f574b)) {
                    zB = rVar.b(charSequence, i6, iCharCount, tVar.f558d.f574b);
                    i7++;
                }
            }
            i6 = iCharCount;
        }
        if (tVar.f555a == 2 && tVar.f557c.f574b != null && ((tVar.f > 1 || tVar.b()) && i7 < i5 && zB && (z4 || !u(charSequence, i6, iCharCount, tVar.f557c.f574b)))) {
            rVar.b(charSequence, i6, iCharCount, tVar.f557c.f574b);
        }
        return rVar.getResult();
    }

    public void z() {
        ((TypedArray) this.f563c).recycle();
    }

    public /* synthetic */ u(int i3, Object obj, Object obj2, Object obj3) {
        this.f561a = i3;
        this.f562b = obj;
        this.f563c = obj2;
        this.f564d = obj3;
    }

    public u(l0 store, k0 k0Var, a1.b defaultCreationExtras) {
        this.f561a = 1;
        kotlin.jvm.internal.d.f(store, "store");
        kotlin.jvm.internal.d.f(defaultCreationExtras, "defaultCreationExtras");
        this.f562b = store;
        this.f563c = k0Var;
        this.f564d = defaultCreationExtras;
    }

    public u(n0 n0Var) {
        this.f561a = 4;
        this.f562b = n0Var;
        this.f563c = new e1.d();
        this.f564d = new ArrayList();
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public u(l0 store, k0 k0Var) {
        this(store, k0Var, a1.a.f29b);
        this.f561a = 1;
        kotlin.jvm.internal.d.f(store, "store");
    }

    public u(File file) {
        this.f561a = 7;
        this.f562b = file;
        this.f563c = new File(file.getPath() + ".new");
        this.f564d = new File(file.getPath() + ".bak");
    }

    public u(Runnable runnable) {
        this.f561a = 8;
        this.f563c = new CopyOnWriteArrayList();
        this.f564d = new HashMap();
        this.f562b = runnable;
    }

    public u(Context context, TypedArray typedArray) {
        this.f561a = 6;
        this.f562b = context;
        this.f563c = typedArray;
    }

    public u(Context context, LocationManager locationManager) {
        this.f561a = 3;
        this.f564d = new m0();
        this.f562b = context;
        this.f563c = locationManager;
    }

    public u(v.e eVar) {
        this.f561a = 12;
        this.f562b = new ArrayList();
        this.f563c = new w.b();
        this.f564d = eVar;
    }

    public u(Context context, View view) {
        this.f561a = 5;
        k.m mVar = new k.m(context);
        this.f562b = mVar;
        mVar.f2706e = new a0.b(18, this);
        k.w wVar = new k.w(context, mVar, view, false, R.attr.popupMenuStyle, 0);
        this.f563c = wVar;
        wVar.f = 0;
        wVar.f2773j = new k.v(1, this);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public u(androidx.fragment.app.w wVar, f0 f0Var) {
        this(wVar.b(), f0Var, wVar.a());
        this.f561a = 1;
    }

    @Override // q0.g
    public void b() {
    }

    public u(a0.k kVar, s2.e eVar, e eVar2, Set set) {
        this.f561a = 0;
        this.f562b = eVar;
        this.f563c = kVar;
        this.f564d = eVar2;
        if (set.isEmpty()) {
            return;
        }
        Iterator it = set.iterator();
        while (it.hasNext()) {
            int[] iArr = (int[]) it.next();
            String str = new String(iArr, 0, iArr.length);
            y(str, 0, str.length(), 1, true, new s(str, 0));
        }
    }

    public u(a0.b bVar) {
        this.f561a = 11;
        this.f561a = 11;
        this.f562b = bVar;
        this.f563c = Choreographer.getInstance();
        this.f564d = new u0.a(this);
    }
}
