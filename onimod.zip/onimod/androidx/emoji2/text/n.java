package androidx.emoji2.text;

import java.util.concurrent.ThreadPoolExecutor;

/* JADX INFO: loaded from: classes.dex */
public final class n extends a3.a {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ a3.a f548o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ ThreadPoolExecutor f549p;

    public n(a3.a aVar, ThreadPoolExecutor threadPoolExecutor) {
        this.f548o = aVar;
        this.f549p = threadPoolExecutor;
    }

    @Override // a3.a
    public final void T(Throwable th) {
        ThreadPoolExecutor threadPoolExecutor = this.f549p;
        try {
            this.f548o.T(th);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }

    @Override // a3.a
    public final void W(a0.k kVar) {
        ThreadPoolExecutor threadPoolExecutor = this.f549p;
        try {
            this.f548o.W(kVar);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }
}
