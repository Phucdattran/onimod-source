package androidx.emoji2.text;

import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.datepicker.MaterialCalendar;
import e1.y0;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class k implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f535a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f536b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f537c;

    public /* synthetic */ k(Object obj, int i3, int i4) {
        this.f535a = i4;
        this.f537c = obj;
        this.f536b = i3;
    }

    @Override // java.lang.Runnable
    public final void run() {
        y0 y0Var;
        y0 y0Var2;
        switch (this.f535a) {
            case 0:
                ArrayList arrayList = (ArrayList) this.f537c;
                int size = arrayList.size();
                int i3 = 0;
                if (this.f536b == 1) {
                    while (i3 < size) {
                        ((j) arrayList.get(i3)).b();
                        i3++;
                    }
                } else {
                    while (i3 < size) {
                        ((j) arrayList.get(i3)).a();
                        i3++;
                    }
                }
                break;
            case 1:
                RecyclerView recyclerView = ((MaterialCalendar) this.f537c).f1336c0;
                if (!recyclerView.f963w && (y0Var = recyclerView.f943m) != null) {
                    y0Var.E0(recyclerView, this.f536b);
                }
                break;
            case 2:
                f0.b bVar = (f0.b) ((a0.b) this.f537c).f3b;
                if (bVar != null) {
                    bVar.h(this.f536b);
                }
                break;
            default:
                RecyclerView recyclerView2 = (RecyclerView) this.f537c;
                if (!recyclerView2.f963w && (y0Var2 = recyclerView2.f943m) != null) {
                    y0Var2.E0(recyclerView2, this.f536b);
                }
                break;
        }
    }

    public k(int i3, n1.m mVar) {
        this.f535a = 3;
        this.f536b = i3;
        this.f537c = mVar;
    }

    public k(List list, int i3, Throwable th) {
        this.f535a = 0;
        i1.m.h(list, "initCallbacks cannot be null");
        this.f537c = new ArrayList(list);
        this.f536b = i3;
    }
}
