package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.emoji2.text.h;
import e1.f0;
import e1.g0;
import e1.g1;
import e1.h0;
import e1.i0;
import e1.j0;
import e1.k1;
import e1.l1;
import e1.o1;
import e1.q;
import e1.u;
import e1.x0;
import e1.y0;
import e1.z0;
import g0.e;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class LinearLayoutManager extends y0 implements k1 {
    public final f0 A;
    public final g0 B;
    public int C;
    public final int[] D;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f909p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public h0 f910q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public h f911r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f912s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final boolean f913t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f914u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f915v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final boolean f916w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f917x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f918y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public i0 f919z;

    public LinearLayoutManager(int i3) {
        this.f909p = 1;
        this.f913t = false;
        this.f914u = false;
        this.f915v = false;
        this.f916w = true;
        this.f917x = -1;
        this.f918y = Integer.MIN_VALUE;
        this.f919z = null;
        this.A = new f0();
        this.B = new g0();
        this.C = 2;
        this.D = new int[2];
        i1(i3);
        c(null);
        if (this.f913t) {
            this.f913t = false;
            s0();
        }
    }

    @Override // e1.y0
    public final boolean C0() {
        if (this.f2133m != 1073741824 && this.f2132l != 1073741824) {
            int iV = v();
            for (int i3 = 0; i3 < iV; i3++) {
                ViewGroup.LayoutParams layoutParams = u(i3).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // e1.y0
    public void E0(RecyclerView recyclerView, int i3) {
        j0 j0Var = new j0(recyclerView.getContext());
        j0Var.f1925a = i3;
        F0(j0Var);
    }

    @Override // e1.y0
    public boolean G0() {
        return this.f919z == null && this.f912s == this.f915v;
    }

    public void H0(l1 l1Var, int[] iArr) {
        int i3;
        int iL = l1Var.f1965a != -1 ? this.f911r.l() : 0;
        if (this.f910q.f == -1) {
            i3 = 0;
        } else {
            i3 = iL;
            iL = 0;
        }
        iArr[0] = iL;
        iArr[1] = i3;
    }

    public void I0(l1 l1Var, h0 h0Var, u uVar) {
        int i3 = h0Var.f1903d;
        if (i3 < 0 || i3 >= l1Var.b()) {
            return;
        }
        uVar.a(i3, Math.max(0, h0Var.f1905g));
    }

    public final int J0(l1 l1Var) {
        if (v() == 0) {
            return 0;
        }
        N0();
        h hVar = this.f911r;
        boolean z4 = !this.f916w;
        return q.a(l1Var, hVar, Q0(z4), P0(z4), this, this.f916w);
    }

    public final int K0(l1 l1Var) {
        if (v() == 0) {
            return 0;
        }
        N0();
        h hVar = this.f911r;
        boolean z4 = !this.f916w;
        return q.b(l1Var, hVar, Q0(z4), P0(z4), this, this.f916w, this.f914u);
    }

    public final int L0(l1 l1Var) {
        if (v() == 0) {
            return 0;
        }
        N0();
        h hVar = this.f911r;
        boolean z4 = !this.f916w;
        return q.c(l1Var, hVar, Q0(z4), P0(z4), this, this.f916w);
    }

    public final int M0(int i3) {
        if (i3 == 1) {
            return (this.f909p != 1 && a1()) ? 1 : -1;
        }
        if (i3 == 2) {
            return (this.f909p != 1 && a1()) ? -1 : 1;
        }
        if (i3 == 17) {
            return this.f909p == 0 ? -1 : Integer.MIN_VALUE;
        }
        if (i3 == 33) {
            return this.f909p == 1 ? -1 : Integer.MIN_VALUE;
        }
        if (i3 != 66) {
            return (i3 == 130 && this.f909p == 1) ? 1 : Integer.MIN_VALUE;
        }
        return this.f909p == 0 ? 1 : Integer.MIN_VALUE;
    }

    public final void N0() {
        if (this.f910q == null) {
            h0 h0Var = new h0();
            h0Var.f1900a = true;
            h0Var.f1906h = 0;
            h0Var.f1907i = 0;
            h0Var.f1909k = null;
            this.f910q = h0Var;
        }
    }

    public final int O0(g1 g1Var, h0 h0Var, l1 l1Var, boolean z4) {
        int i3;
        int i4 = h0Var.f1902c;
        int i5 = h0Var.f1905g;
        if (i5 != Integer.MIN_VALUE) {
            if (i4 < 0) {
                h0Var.f1905g = i5 + i4;
            }
            d1(g1Var, h0Var);
        }
        int i6 = h0Var.f1902c + h0Var.f1906h;
        while (true) {
            if ((!h0Var.f1910l && i6 <= 0) || (i3 = h0Var.f1903d) < 0 || i3 >= l1Var.b()) {
                break;
            }
            g0 g0Var = this.B;
            g0Var.f1884a = 0;
            g0Var.f1885b = false;
            g0Var.f1886c = false;
            g0Var.f1887d = false;
            b1(g1Var, l1Var, h0Var, g0Var);
            if (!g0Var.f1885b) {
                int i7 = h0Var.f1901b;
                int i8 = g0Var.f1884a;
                h0Var.f1901b = (h0Var.f * i8) + i7;
                if (!g0Var.f1886c || h0Var.f1909k != null || !l1Var.f1970g) {
                    h0Var.f1902c -= i8;
                    i6 -= i8;
                }
                int i9 = h0Var.f1905g;
                if (i9 != Integer.MIN_VALUE) {
                    int i10 = i9 + i8;
                    h0Var.f1905g = i10;
                    int i11 = h0Var.f1902c;
                    if (i11 < 0) {
                        h0Var.f1905g = i10 + i11;
                    }
                    d1(g1Var, h0Var);
                }
                if (z4 && g0Var.f1887d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i4 - h0Var.f1902c;
    }

    @Override // e1.y0
    public final boolean P() {
        return true;
    }

    public final View P0(boolean z4) {
        return this.f914u ? U0(0, v(), z4, true) : U0(v() - 1, -1, z4, true);
    }

    public final View Q0(boolean z4) {
        return this.f914u ? U0(v() - 1, -1, z4, true) : U0(0, v(), z4, true);
    }

    public final int R0() {
        View viewU0 = U0(0, v(), false, true);
        if (viewU0 == null) {
            return -1;
        }
        return y0.L(viewU0);
    }

    public final int S0() {
        View viewU0 = U0(v() - 1, -1, false, true);
        if (viewU0 == null) {
            return -1;
        }
        return y0.L(viewU0);
    }

    public final View T0(int i3, int i4) {
        int i5;
        int i6;
        N0();
        if (i4 <= i3 && i4 >= i3) {
            return u(i3);
        }
        if (this.f911r.e(u(i3)) < this.f911r.k()) {
            i5 = 16644;
            i6 = 16388;
        } else {
            i5 = 4161;
            i6 = 4097;
        }
        return this.f909p == 0 ? this.f2124c.k(i3, i4, i5, i6) : this.f2125d.k(i3, i4, i5, i6);
    }

    public final View U0(int i3, int i4, boolean z4, boolean z5) {
        N0();
        int i5 = z4 ? 24579 : 320;
        int i6 = z5 ? 320 : 0;
        return this.f909p == 0 ? this.f2124c.k(i3, i4, i5, i6) : this.f2125d.k(i3, i4, i5, i6);
    }

    /* JADX WARN: Code duplicated, block: B:33:0x0075  */
    /* JADX WARN: Code duplicated, block: B:35:0x0079  */
    public View V0(g1 g1Var, l1 l1Var, boolean z4, boolean z5) {
        int i3;
        int iV;
        int i4;
        N0();
        int iV2 = v();
        if (z5) {
            iV = v() - 1;
            i3 = -1;
            i4 = -1;
        } else {
            i3 = iV2;
            iV = 0;
            i4 = 1;
        }
        int iB = l1Var.b();
        int iK = this.f911r.k();
        int iG = this.f911r.g();
        View view = null;
        View view2 = null;
        View view3 = null;
        while (iV != i3) {
            View viewU = u(iV);
            int iL = y0.L(viewU);
            int iE = this.f911r.e(viewU);
            int iB2 = this.f911r.b(viewU);
            if (iL >= 0 && iL < iB) {
                if (!((z0) viewU.getLayoutParams()).f2155a.i()) {
                    boolean z6 = iB2 <= iK && iE < iK;
                    boolean z7 = iE >= iG && iB2 > iG;
                    if (!z6 && !z7) {
                        return viewU;
                    }
                    if (z4) {
                        if (z7) {
                            view2 = viewU;
                        } else if (view == null) {
                            view = viewU;
                        }
                    } else if (z6) {
                        view2 = viewU;
                    } else if (view == null) {
                        view = viewU;
                    }
                } else if (view3 == null) {
                    view3 = viewU;
                }
            }
            iV += i4;
        }
        if (view != null) {
            return view;
        }
        return view2 != null ? view2 : view3;
    }

    public final int W0(int i3, g1 g1Var, l1 l1Var, boolean z4) {
        int iG;
        int iG2 = this.f911r.g() - i3;
        if (iG2 <= 0) {
            return 0;
        }
        int i4 = -g1(-iG2, g1Var, l1Var);
        int i5 = i3 + i4;
        if (!z4 || (iG = this.f911r.g() - i5) <= 0) {
            return i4;
        }
        this.f911r.o(iG);
        return iG + i4;
    }

    @Override // e1.y0
    public View X(View view, int i3, g1 g1Var, l1 l1Var) {
        int iM0;
        View viewT0;
        f1();
        if (v() != 0 && (iM0 = M0(i3)) != Integer.MIN_VALUE) {
            N0();
            k1(iM0, (int) (this.f911r.l() * 0.33333334f), false, l1Var);
            h0 h0Var = this.f910q;
            h0Var.f1905g = Integer.MIN_VALUE;
            h0Var.f1900a = false;
            O0(g1Var, h0Var, l1Var, true);
            if (iM0 == -1) {
                viewT0 = this.f914u ? T0(v() - 1, -1) : T0(0, v());
            } else {
                viewT0 = this.f914u ? T0(0, v()) : T0(v() - 1, -1);
            }
            View viewZ0 = iM0 == -1 ? Z0() : Y0();
            if (!viewZ0.hasFocusable()) {
                return viewT0;
            }
            if (viewT0 != null) {
                return viewZ0;
            }
        }
        return null;
    }

    public final int X0(int i3, g1 g1Var, l1 l1Var, boolean z4) {
        int iK;
        int iK2 = i3 - this.f911r.k();
        if (iK2 <= 0) {
            return 0;
        }
        int i4 = -g1(iK2, g1Var, l1Var);
        int i5 = i3 + i4;
        if (!z4 || (iK = i5 - this.f911r.k()) <= 0) {
            return i4;
        }
        this.f911r.o(-iK);
        return i4 - iK;
    }

    @Override // e1.y0
    public final void Y(AccessibilityEvent accessibilityEvent) {
        super.Y(accessibilityEvent);
        if (v() > 0) {
            accessibilityEvent.setFromIndex(R0());
            accessibilityEvent.setToIndex(S0());
        }
    }

    public final View Y0() {
        return u(this.f914u ? 0 : v() - 1);
    }

    public final View Z0() {
        return u(this.f914u ? v() - 1 : 0);
    }

    @Override // e1.k1
    public final PointF a(int i3) {
        if (v() == 0) {
            return null;
        }
        int i4 = (i3 < y0.L(u(0))) != this.f914u ? -1 : 1;
        return this.f909p == 0 ? new PointF(i4, 0.0f) : new PointF(0.0f, i4);
    }

    public final boolean a1() {
        return G() == 1;
    }

    public void b1(g1 g1Var, l1 l1Var, h0 h0Var, g0 g0Var) {
        int I;
        int i3;
        int i4;
        int iD;
        View viewB = h0Var.b(g1Var);
        if (viewB == null) {
            g0Var.f1885b = true;
            return;
        }
        z0 z0Var = (z0) viewB.getLayoutParams();
        if (h0Var.f1909k == null) {
            if (this.f914u == (h0Var.f == -1)) {
                b(viewB, -1, false);
            } else {
                b(viewB, 0, false);
            }
        } else {
            if (this.f914u == (h0Var.f == -1)) {
                b(viewB, -1, true);
            } else {
                b(viewB, 0, true);
            }
        }
        z0 z0Var2 = (z0) viewB.getLayoutParams();
        Rect rectK = this.f2123b.K(viewB);
        int i5 = rectK.left + rectK.right;
        int i6 = rectK.top + rectK.bottom;
        int iW = y0.w(d(), this.f2134n, this.f2132l, J() + I() + ((ViewGroup.MarginLayoutParams) z0Var2).leftMargin + ((ViewGroup.MarginLayoutParams) z0Var2).rightMargin + i5, ((ViewGroup.MarginLayoutParams) z0Var2).width);
        int iW2 = y0.w(e(), this.f2135o, this.f2133m, H() + K() + ((ViewGroup.MarginLayoutParams) z0Var2).topMargin + ((ViewGroup.MarginLayoutParams) z0Var2).bottomMargin + i6, ((ViewGroup.MarginLayoutParams) z0Var2).height);
        if (B0(viewB, iW, iW2, z0Var2)) {
            viewB.measure(iW, iW2);
        }
        g0Var.f1884a = this.f911r.c(viewB);
        if (this.f909p == 1) {
            if (a1()) {
                iD = this.f2134n - J();
                I = iD - this.f911r.d(viewB);
            } else {
                I = I();
                iD = this.f911r.d(viewB) + I;
            }
            if (h0Var.f == -1) {
                i3 = h0Var.f1901b;
                i4 = i3 - g0Var.f1884a;
            } else {
                i4 = h0Var.f1901b;
                i3 = g0Var.f1884a + i4;
            }
        } else {
            int iK = K();
            int iD2 = this.f911r.d(viewB) + iK;
            if (h0Var.f == -1) {
                int i7 = h0Var.f1901b;
                int i8 = i7 - g0Var.f1884a;
                iD = i7;
                i3 = iD2;
                I = i8;
                i4 = iK;
            } else {
                int i9 = h0Var.f1901b;
                int i10 = g0Var.f1884a + i9;
                I = i9;
                i3 = iD2;
                i4 = iK;
                iD = i10;
            }
        }
        y0.R(viewB, I, i4, iD, i3);
        if (z0Var.f2155a.i() || z0Var.f2155a.l()) {
            g0Var.f1886c = true;
        }
        g0Var.f1887d = viewB.hasFocusable();
    }

    @Override // e1.y0
    public final void c(String str) {
        if (this.f919z == null) {
            super.c(str);
        }
    }

    @Override // e1.y0
    public final boolean d() {
        return this.f909p == 0;
    }

    public final void d1(g1 g1Var, h0 h0Var) {
        if (!h0Var.f1900a || h0Var.f1910l) {
            return;
        }
        int i3 = h0Var.f1905g;
        int i4 = h0Var.f1907i;
        if (h0Var.f == -1) {
            int iV = v();
            if (i3 < 0) {
                return;
            }
            int iF = (this.f911r.f() - i3) + i4;
            if (this.f914u) {
                for (int i5 = 0; i5 < iV; i5++) {
                    View viewU = u(i5);
                    if (this.f911r.e(viewU) < iF || this.f911r.n(viewU) < iF) {
                        e1(g1Var, 0, i5);
                        return;
                    }
                }
                return;
            }
            int i6 = iV - 1;
            for (int i7 = i6; i7 >= 0; i7--) {
                View viewU2 = u(i7);
                if (this.f911r.e(viewU2) < iF || this.f911r.n(viewU2) < iF) {
                    e1(g1Var, i6, i7);
                    return;
                }
            }
            return;
        }
        if (i3 < 0) {
            return;
        }
        int i8 = i3 - i4;
        int iV2 = v();
        if (!this.f914u) {
            for (int i9 = 0; i9 < iV2; i9++) {
                View viewU3 = u(i9);
                if (this.f911r.b(viewU3) > i8 || this.f911r.m(viewU3) > i8) {
                    e1(g1Var, 0, i9);
                    return;
                }
            }
            return;
        }
        int i10 = iV2 - 1;
        for (int i11 = i10; i11 >= 0; i11--) {
            View viewU4 = u(i11);
            if (this.f911r.b(viewU4) > i8 || this.f911r.m(viewU4) > i8) {
                e1(g1Var, i10, i11);
                return;
            }
        }
    }

    @Override // e1.y0
    public final boolean e() {
        return this.f909p == 1;
    }

    public final void e1(g1 g1Var, int i3, int i4) {
        if (i3 == i4) {
            return;
        }
        if (i4 <= i3) {
            while (i3 > i4) {
                View viewU = u(i3);
                q0(i3);
                g1Var.g(viewU);
                i3--;
            }
            return;
        }
        for (int i5 = i4 - 1; i5 >= i3; i5--) {
            View viewU2 = u(i5);
            q0(i5);
            g1Var.g(viewU2);
        }
    }

    public final void f1() {
        if (this.f909p == 1 || !a1()) {
            this.f914u = this.f913t;
        } else {
            this.f914u = !this.f913t;
        }
    }

    public final int g1(int i3, g1 g1Var, l1 l1Var) {
        if (v() != 0 && i3 != 0) {
            N0();
            this.f910q.f1900a = true;
            int i4 = i3 > 0 ? 1 : -1;
            int iAbs = Math.abs(i3);
            k1(i4, iAbs, true, l1Var);
            h0 h0Var = this.f910q;
            int iO0 = O0(g1Var, h0Var, l1Var, false) + h0Var.f1905g;
            if (iO0 >= 0) {
                if (iAbs > iO0) {
                    i3 = i4 * iO0;
                }
                this.f911r.o(-i3);
                this.f910q.f1908j = i3;
                return i3;
            }
        }
        return 0;
    }

    @Override // e1.y0
    public final void h(int i3, int i4, l1 l1Var, u uVar) {
        if (this.f909p != 0) {
            i3 = i4;
        }
        if (v() == 0 || i3 == 0) {
            return;
        }
        N0();
        k1(i3 > 0 ? 1 : -1, Math.abs(i3), true, l1Var);
        I0(l1Var, this.f910q, uVar);
    }

    /* JADX WARN: Code duplicated, block: B:102:0x01ab  */
    /* JADX WARN: Code duplicated, block: B:104:0x01ae  */
    /* JADX WARN: Code duplicated, block: B:111:0x01d8  */
    /* JADX WARN: Code duplicated, block: B:114:0x01df  */
    /* JADX WARN: Code duplicated, block: B:118:0x01f2  */
    /* JADX WARN: Code duplicated, block: B:122:0x0212 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:124:0x0216  */
    /* JADX WARN: Code duplicated, block: B:126:0x0219 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:128:0x021d  */
    /* JADX WARN: Code duplicated, block: B:130:0x0220 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:131:0x0222  */
    /* JADX WARN: Code duplicated, block: B:133:0x0226  */
    /* JADX WARN: Code duplicated, block: B:135:0x022a  */
    /* JADX WARN: Code duplicated, block: B:137:0x0231  */
    /* JADX WARN: Code duplicated, block: B:138:0x0237  */
    /* JADX WARN: Code duplicated, block: B:95:0x0194  */
    @Override // e1.y0
    public void h0(g1 g1Var, l1 l1Var) {
        View focusedChild;
        int iB;
        RecyclerView recyclerView;
        View focusedChild2;
        boolean z4;
        boolean z5;
        View viewV0;
        int iE;
        int iB2;
        int iK;
        int iG;
        boolean z6;
        boolean z7;
        z0 z0Var;
        int i3;
        int iE2;
        int i4;
        int i5;
        List list;
        int i6;
        int i7;
        int iW0;
        int i8;
        View viewQ;
        int iE3;
        int iG2;
        int i9;
        int i10 = -1;
        if (!(this.f919z == null && this.f917x == -1) && l1Var.b() == 0) {
            n0(g1Var);
            return;
        }
        i0 i0Var = this.f919z;
        if (i0Var != null && (i9 = i0Var.f1916a) >= 0) {
            this.f917x = i9;
        }
        N0();
        this.f910q.f1900a = false;
        f1();
        RecyclerView recyclerView2 = this.f2123b;
        if (recyclerView2 == null || (focusedChild = recyclerView2.getFocusedChild()) == null || ((ArrayList) this.f2122a.f564d).contains(focusedChild)) {
            focusedChild = null;
        }
        f0 f0Var = this.A;
        if (!f0Var.f1876e || this.f917x != -1 || this.f919z != null) {
            f0Var.d();
            f0Var.f1875d = this.f914u ^ this.f915v;
            if (l1Var.f1970g || (i3 = this.f917x) == -1) {
                if (v() != 0) {
                    recyclerView = this.f2123b;
                    if (recyclerView != null || (focusedChild2 = recyclerView.getFocusedChild()) == null || ((ArrayList) this.f2122a.f564d).contains(focusedChild2)) {
                        focusedChild2 = null;
                    }
                    if (focusedChild2 != null) {
                        z0Var = (z0) focusedChild2.getLayoutParams();
                        if (!z0Var.f2155a.i() || z0Var.f2155a.c() < 0 || z0Var.f2155a.c() >= l1Var.b()) {
                            z4 = this.f912s;
                            z5 = this.f915v;
                            if (z4 == z5 || (viewV0 = V0(g1Var, l1Var, f0Var.f1875d, z5)) == null) {
                                f0Var.a();
                                if (this.f915v) {
                                    iB = l1Var.b() - 1;
                                } else {
                                    iB = 0;
                                }
                                f0Var.f1873b = iB;
                            } else {
                                f0Var.b(viewV0, y0.L(viewV0));
                                if (!l1Var.f1970g && G0()) {
                                    iE = this.f911r.e(viewV0);
                                    iB2 = this.f911r.b(viewV0);
                                    iK = this.f911r.k();
                                    iG = this.f911r.g();
                                    if (iB2 <= iK || iE >= iK) {
                                        z6 = false;
                                    } else {
                                        z6 = true;
                                    }
                                    if (iE >= iG || iB2 <= iG) {
                                        z7 = false;
                                    } else {
                                        z7 = true;
                                    }
                                    if (z6 || z7) {
                                        if (f0Var.f1875d) {
                                            iK = iG;
                                        }
                                        f0Var.f1874c = iK;
                                    }
                                }
                            }
                        } else {
                            f0Var.c(focusedChild2, y0.L(focusedChild2));
                        }
                    } else {
                        z4 = this.f912s;
                        z5 = this.f915v;
                        if (z4 == z5) {
                            f0Var.a();
                            if (this.f915v) {
                                iB = l1Var.b() - 1;
                            } else {
                                iB = 0;
                            }
                            f0Var.f1873b = iB;
                        } else {
                            f0Var.b(viewV0, y0.L(viewV0));
                            if (!l1Var.f1970g) {
                                iE = this.f911r.e(viewV0);
                                iB2 = this.f911r.b(viewV0);
                                iK = this.f911r.k();
                                iG = this.f911r.g();
                                if (iB2 <= iK) {
                                    z6 = false;
                                } else {
                                    z6 = false;
                                }
                                if (iE >= iG) {
                                    z7 = false;
                                } else {
                                    z7 = false;
                                }
                                if (z6) {
                                    if (f0Var.f1875d) {
                                        iK = iG;
                                    }
                                    f0Var.f1874c = iK;
                                } else {
                                    if (f0Var.f1875d) {
                                        iK = iG;
                                    }
                                    f0Var.f1874c = iK;
                                }
                            }
                        }
                    }
                } else {
                    f0Var.a();
                    if (this.f915v) {
                        iB = l1Var.b() - 1;
                    } else {
                        iB = 0;
                    }
                    f0Var.f1873b = iB;
                }
            } else if (i3 < 0 || i3 >= l1Var.b()) {
                this.f917x = -1;
                this.f918y = Integer.MIN_VALUE;
                if (v() != 0) {
                    recyclerView = this.f2123b;
                    if (recyclerView != null) {
                        focusedChild2 = null;
                    } else {
                        focusedChild2 = null;
                    }
                    if (focusedChild2 != null) {
                        z0Var = (z0) focusedChild2.getLayoutParams();
                        if (z0Var.f2155a.i()) {
                            z4 = this.f912s;
                            z5 = this.f915v;
                            if (z4 == z5) {
                                f0Var.a();
                                if (this.f915v) {
                                    iB = l1Var.b() - 1;
                                } else {
                                    iB = 0;
                                }
                                f0Var.f1873b = iB;
                            } else {
                                f0Var.b(viewV0, y0.L(viewV0));
                                if (!l1Var.f1970g) {
                                    iE = this.f911r.e(viewV0);
                                    iB2 = this.f911r.b(viewV0);
                                    iK = this.f911r.k();
                                    iG = this.f911r.g();
                                    if (iB2 <= iK) {
                                        z6 = false;
                                    } else {
                                        z6 = false;
                                    }
                                    if (iE >= iG) {
                                        z7 = false;
                                    } else {
                                        z7 = false;
                                    }
                                    if (z6) {
                                        if (f0Var.f1875d) {
                                            iK = iG;
                                        }
                                        f0Var.f1874c = iK;
                                    } else {
                                        if (f0Var.f1875d) {
                                            iK = iG;
                                        }
                                        f0Var.f1874c = iK;
                                    }
                                }
                            }
                        } else {
                            z4 = this.f912s;
                            z5 = this.f915v;
                            if (z4 == z5) {
                                f0Var.a();
                                if (this.f915v) {
                                    iB = l1Var.b() - 1;
                                } else {
                                    iB = 0;
                                }
                                f0Var.f1873b = iB;
                            } else {
                                f0Var.b(viewV0, y0.L(viewV0));
                                if (!l1Var.f1970g) {
                                    iE = this.f911r.e(viewV0);
                                    iB2 = this.f911r.b(viewV0);
                                    iK = this.f911r.k();
                                    iG = this.f911r.g();
                                    if (iB2 <= iK) {
                                        z6 = false;
                                    } else {
                                        z6 = false;
                                    }
                                    if (iE >= iG) {
                                        z7 = false;
                                    } else {
                                        z7 = false;
                                    }
                                    if (z6) {
                                        if (f0Var.f1875d) {
                                            iK = iG;
                                        }
                                        f0Var.f1874c = iK;
                                    } else {
                                        if (f0Var.f1875d) {
                                            iK = iG;
                                        }
                                        f0Var.f1874c = iK;
                                    }
                                }
                            }
                        }
                    } else {
                        z4 = this.f912s;
                        z5 = this.f915v;
                        if (z4 == z5) {
                            f0Var.a();
                            if (this.f915v) {
                                iB = l1Var.b() - 1;
                            } else {
                                iB = 0;
                            }
                            f0Var.f1873b = iB;
                        } else {
                            f0Var.b(viewV0, y0.L(viewV0));
                            if (!l1Var.f1970g) {
                                iE = this.f911r.e(viewV0);
                                iB2 = this.f911r.b(viewV0);
                                iK = this.f911r.k();
                                iG = this.f911r.g();
                                if (iB2 <= iK) {
                                    z6 = false;
                                } else {
                                    z6 = false;
                                }
                                if (iE >= iG) {
                                    z7 = false;
                                } else {
                                    z7 = false;
                                }
                                if (z6) {
                                    if (f0Var.f1875d) {
                                        iK = iG;
                                    }
                                    f0Var.f1874c = iK;
                                } else {
                                    if (f0Var.f1875d) {
                                        iK = iG;
                                    }
                                    f0Var.f1874c = iK;
                                }
                            }
                        }
                    }
                } else {
                    f0Var.a();
                    if (this.f915v) {
                        iB = l1Var.b() - 1;
                    } else {
                        iB = 0;
                    }
                    f0Var.f1873b = iB;
                }
            } else {
                int i11 = this.f917x;
                f0Var.f1873b = i11;
                i0 i0Var2 = this.f919z;
                if (i0Var2 != null && i0Var2.f1916a >= 0) {
                    boolean z8 = i0Var2.f1918c;
                    f0Var.f1875d = z8;
                    if (z8) {
                        f0Var.f1874c = this.f911r.g() - this.f919z.f1917b;
                    } else {
                        f0Var.f1874c = this.f911r.k() + this.f919z.f1917b;
                    }
                } else if (this.f918y == Integer.MIN_VALUE) {
                    View viewQ2 = q(i11);
                    if (viewQ2 == null) {
                        if (v() > 0) {
                            f0Var.f1875d = (this.f917x < y0.L(u(0))) == this.f914u;
                        }
                        f0Var.a();
                    } else if (this.f911r.c(viewQ2) > this.f911r.l()) {
                        f0Var.a();
                    } else if (this.f911r.e(viewQ2) - this.f911r.k() < 0) {
                        f0Var.f1874c = this.f911r.k();
                        f0Var.f1875d = false;
                    } else if (this.f911r.g() - this.f911r.b(viewQ2) < 0) {
                        f0Var.f1874c = this.f911r.g();
                        f0Var.f1875d = true;
                    } else {
                        if (f0Var.f1875d) {
                            int iB3 = this.f911r.b(viewQ2);
                            h hVar = this.f911r;
                            iE2 = (Integer.MIN_VALUE == hVar.f532a ? 0 : hVar.l() - hVar.f532a) + iB3;
                        } else {
                            iE2 = this.f911r.e(viewQ2);
                        }
                        f0Var.f1874c = iE2;
                    }
                } else {
                    boolean z9 = this.f914u;
                    f0Var.f1875d = z9;
                    if (z9) {
                        f0Var.f1874c = this.f911r.g() - this.f918y;
                    } else {
                        f0Var.f1874c = this.f911r.k() + this.f918y;
                    }
                }
            }
            f0Var.f1876e = true;
        } else if (focusedChild != null && (this.f911r.e(focusedChild) >= this.f911r.g() || this.f911r.b(focusedChild) <= this.f911r.k())) {
            f0Var.c(focusedChild, y0.L(focusedChild));
        }
        h0 h0Var = this.f910q;
        h0Var.f = h0Var.f1908j >= 0 ? 1 : -1;
        int[] iArr = this.D;
        iArr[0] = 0;
        iArr[1] = 0;
        H0(l1Var, iArr);
        int iK2 = this.f911r.k() + Math.max(0, iArr[0]);
        int iH = this.f911r.h() + Math.max(0, iArr[1]);
        if (l1Var.f1970g && (i8 = this.f917x) != -1 && this.f918y != Integer.MIN_VALUE && (viewQ = q(i8)) != null) {
            if (this.f914u) {
                iG2 = this.f911r.g() - this.f911r.b(viewQ);
                iE3 = this.f918y;
            } else {
                iE3 = this.f911r.e(viewQ) - this.f911r.k();
                iG2 = this.f918y;
            }
            int i12 = iG2 - iE3;
            if (i12 > 0) {
                iK2 += i12;
            } else {
                iH -= i12;
            }
        }
        if (!f0Var.f1875d ? !this.f914u : this.f914u) {
            i10 = 1;
        }
        c1(g1Var, l1Var, f0Var, i10);
        p(g1Var);
        this.f910q.f1910l = this.f911r.i() == 0 && this.f911r.f() == 0;
        this.f910q.getClass();
        this.f910q.f1907i = 0;
        if (f0Var.f1875d) {
            m1(f0Var.f1873b, f0Var.f1874c);
            h0 h0Var2 = this.f910q;
            h0Var2.f1906h = iK2;
            O0(g1Var, h0Var2, l1Var, false);
            h0 h0Var3 = this.f910q;
            i5 = h0Var3.f1901b;
            int i13 = h0Var3.f1903d;
            int i14 = h0Var3.f1902c;
            if (i14 > 0) {
                iH += i14;
            }
            l1(f0Var.f1873b, f0Var.f1874c);
            h0 h0Var4 = this.f910q;
            h0Var4.f1906h = iH;
            h0Var4.f1903d += h0Var4.f1904e;
            O0(g1Var, h0Var4, l1Var, false);
            h0 h0Var5 = this.f910q;
            i4 = h0Var5.f1901b;
            int i15 = h0Var5.f1902c;
            if (i15 > 0) {
                m1(i13, i5);
                h0 h0Var6 = this.f910q;
                h0Var6.f1906h = i15;
                O0(g1Var, h0Var6, l1Var, false);
                i5 = this.f910q.f1901b;
            }
        } else {
            l1(f0Var.f1873b, f0Var.f1874c);
            h0 h0Var7 = this.f910q;
            h0Var7.f1906h = iH;
            O0(g1Var, h0Var7, l1Var, false);
            h0 h0Var8 = this.f910q;
            i4 = h0Var8.f1901b;
            int i16 = h0Var8.f1903d;
            int i17 = h0Var8.f1902c;
            if (i17 > 0) {
                iK2 += i17;
            }
            m1(f0Var.f1873b, f0Var.f1874c);
            h0 h0Var9 = this.f910q;
            h0Var9.f1906h = iK2;
            h0Var9.f1903d += h0Var9.f1904e;
            O0(g1Var, h0Var9, l1Var, false);
            h0 h0Var10 = this.f910q;
            int i18 = h0Var10.f1901b;
            int i19 = h0Var10.f1902c;
            if (i19 > 0) {
                l1(i16, i4);
                h0 h0Var11 = this.f910q;
                h0Var11.f1906h = i19;
                O0(g1Var, h0Var11, l1Var, false);
                i4 = this.f910q.f1901b;
            }
            i5 = i18;
        }
        if (v() > 0) {
            if (this.f914u ^ this.f915v) {
                int iW1 = W0(i4, g1Var, l1Var, true);
                i6 = i5 + iW1;
                i7 = i4 + iW1;
                iW0 = X0(i6, g1Var, l1Var, false);
            } else {
                int iX0 = X0(i5, g1Var, l1Var, true);
                i6 = i5 + iX0;
                i7 = i4 + iX0;
                iW0 = W0(i7, g1Var, l1Var, false);
            }
            i5 = i6 + iW0;
            i4 = i7 + iW0;
        }
        if (l1Var.f1974k && v() != 0 && !l1Var.f1970g && G0()) {
            List list2 = g1Var.f1891d;
            int size = list2.size();
            int iL = y0.L(u(0));
            int iC = 0;
            int iC2 = 0;
            for (int i20 = 0; i20 < size; i20++) {
                o1 o1Var = (o1) list2.get(i20);
                boolean zI = o1Var.i();
                View view = o1Var.f2003a;
                if (!zI) {
                    if ((o1Var.c() < iL) != this.f914u) {
                        iC += this.f911r.c(view);
                    } else {
                        iC2 += this.f911r.c(view);
                    }
                }
            }
            this.f910q.f1909k = list2;
            if (iC > 0) {
                m1(y0.L(Z0()), i5);
                h0 h0Var12 = this.f910q;
                h0Var12.f1906h = iC;
                h0Var12.f1902c = 0;
                h0Var12.a(null);
                O0(g1Var, this.f910q, l1Var, false);
            }
            if (iC2 > 0) {
                l1(y0.L(Y0()), i4);
                h0 h0Var13 = this.f910q;
                h0Var13.f1906h = iC2;
                h0Var13.f1902c = 0;
                list = null;
                h0Var13.a(null);
                O0(g1Var, this.f910q, l1Var, false);
            } else {
                list = null;
            }
            this.f910q.f1909k = list;
        }
        if (l1Var.f1970g) {
            f0Var.d();
        } else {
            h hVar2 = this.f911r;
            hVar2.f532a = hVar2.l();
        }
        this.f912s = this.f915v;
    }

    public final void h1(int i3, int i4) {
        this.f917x = i3;
        this.f918y = i4;
        i0 i0Var = this.f919z;
        if (i0Var != null) {
            i0Var.f1916a = -1;
        }
        s0();
    }

    @Override // e1.y0
    public final void i(int i3, u uVar) {
        boolean z4;
        int i4;
        i0 i0Var = this.f919z;
        if (i0Var == null || (i4 = i0Var.f1916a) < 0) {
            f1();
            z4 = this.f914u;
            i4 = this.f917x;
            if (i4 == -1) {
                i4 = z4 ? i3 - 1 : 0;
            }
        } else {
            z4 = i0Var.f1918c;
        }
        int i5 = z4 ? -1 : 1;
        for (int i6 = 0; i6 < this.C && i4 >= 0 && i4 < i3; i6++) {
            uVar.a(i4, 0);
            i4 += i5;
        }
    }

    @Override // e1.y0
    public void i0(l1 l1Var) {
        this.f919z = null;
        this.f917x = -1;
        this.f918y = Integer.MIN_VALUE;
        this.A.d();
    }

    public final void i1(int i3) {
        if (i3 != 0 && i3 != 1) {
            throw new IllegalArgumentException(e.b(i3, "invalid orientation:"));
        }
        c(null);
        if (i3 != this.f909p || this.f911r == null) {
            h hVarA = h.a(this, i3);
            this.f911r = hVarA;
            this.A.f1872a = hVarA;
            this.f909p = i3;
            s0();
        }
    }

    @Override // e1.y0
    public final int j(l1 l1Var) {
        return J0(l1Var);
    }

    @Override // e1.y0
    public final void j0(Parcelable parcelable) {
        if (parcelable instanceof i0) {
            i0 i0Var = (i0) parcelable;
            this.f919z = i0Var;
            if (this.f917x != -1) {
                i0Var.f1916a = -1;
            }
            s0();
        }
    }

    public void j1(boolean z4) {
        c(null);
        if (this.f915v == z4) {
            return;
        }
        this.f915v = z4;
        s0();
    }

    @Override // e1.y0
    public int k(l1 l1Var) {
        return K0(l1Var);
    }

    @Override // e1.y0
    public final Parcelable k0() {
        i0 i0Var = this.f919z;
        if (i0Var != null) {
            i0 i0Var2 = new i0();
            i0Var2.f1916a = i0Var.f1916a;
            i0Var2.f1917b = i0Var.f1917b;
            i0Var2.f1918c = i0Var.f1918c;
            return i0Var2;
        }
        i0 i0Var3 = new i0();
        if (v() <= 0) {
            i0Var3.f1916a = -1;
            return i0Var3;
        }
        N0();
        boolean z4 = this.f912s ^ this.f914u;
        i0Var3.f1918c = z4;
        if (z4) {
            View viewY0 = Y0();
            i0Var3.f1917b = this.f911r.g() - this.f911r.b(viewY0);
            i0Var3.f1916a = y0.L(viewY0);
            return i0Var3;
        }
        View viewZ0 = Z0();
        i0Var3.f1916a = y0.L(viewZ0);
        i0Var3.f1917b = this.f911r.e(viewZ0) - this.f911r.k();
        return i0Var3;
    }

    public final void k1(int i3, int i4, boolean z4, l1 l1Var) {
        int iK;
        this.f910q.f1910l = this.f911r.i() == 0 && this.f911r.f() == 0;
        this.f910q.f = i3;
        int[] iArr = this.D;
        iArr[0] = 0;
        iArr[1] = 0;
        H0(l1Var, iArr);
        int iMax = Math.max(0, iArr[0]);
        int iMax2 = Math.max(0, iArr[1]);
        boolean z5 = i3 == 1;
        h0 h0Var = this.f910q;
        int i5 = z5 ? iMax2 : iMax;
        h0Var.f1906h = i5;
        if (!z5) {
            iMax = iMax2;
        }
        h0Var.f1907i = iMax;
        if (z5) {
            h0Var.f1906h = this.f911r.h() + i5;
            View viewY0 = Y0();
            h0 h0Var2 = this.f910q;
            h0Var2.f1904e = this.f914u ? -1 : 1;
            int iL = y0.L(viewY0);
            h0 h0Var3 = this.f910q;
            h0Var2.f1903d = iL + h0Var3.f1904e;
            h0Var3.f1901b = this.f911r.b(viewY0);
            iK = this.f911r.b(viewY0) - this.f911r.g();
        } else {
            View viewZ0 = Z0();
            h0 h0Var4 = this.f910q;
            h0Var4.f1906h = this.f911r.k() + h0Var4.f1906h;
            h0 h0Var5 = this.f910q;
            h0Var5.f1904e = this.f914u ? 1 : -1;
            int iL2 = y0.L(viewZ0);
            h0 h0Var6 = this.f910q;
            h0Var5.f1903d = iL2 + h0Var6.f1904e;
            h0Var6.f1901b = this.f911r.e(viewZ0);
            iK = (-this.f911r.e(viewZ0)) + this.f911r.k();
        }
        h0 h0Var7 = this.f910q;
        h0Var7.f1902c = i4;
        if (z4) {
            h0Var7.f1902c = i4 - iK;
        }
        h0Var7.f1905g = iK;
    }

    @Override // e1.y0
    public int l(l1 l1Var) {
        return L0(l1Var);
    }

    public final void l1(int i3, int i4) {
        this.f910q.f1902c = this.f911r.g() - i4;
        h0 h0Var = this.f910q;
        h0Var.f1904e = this.f914u ? -1 : 1;
        h0Var.f1903d = i3;
        h0Var.f = 1;
        h0Var.f1901b = i4;
        h0Var.f1905g = Integer.MIN_VALUE;
    }

    @Override // e1.y0
    public final int m(l1 l1Var) {
        return J0(l1Var);
    }

    public final void m1(int i3, int i4) {
        this.f910q.f1902c = i4 - this.f911r.k();
        h0 h0Var = this.f910q;
        h0Var.f1903d = i3;
        h0Var.f1904e = this.f914u ? 1 : -1;
        h0Var.f = -1;
        h0Var.f1901b = i4;
        h0Var.f1905g = Integer.MIN_VALUE;
    }

    @Override // e1.y0
    public int n(l1 l1Var) {
        return K0(l1Var);
    }

    @Override // e1.y0
    public int o(l1 l1Var) {
        return L0(l1Var);
    }

    @Override // e1.y0
    public final View q(int i3) {
        int iV = v();
        if (iV == 0) {
            return null;
        }
        int iL = i3 - y0.L(u(0));
        if (iL >= 0 && iL < iV) {
            View viewU = u(iL);
            if (y0.L(viewU) == i3) {
                return viewU;
            }
        }
        return super.q(i3);
    }

    @Override // e1.y0
    public z0 r() {
        return new z0(-2, -2);
    }

    @Override // e1.y0
    public int t0(int i3, g1 g1Var, l1 l1Var) {
        if (this.f909p == 1) {
            return 0;
        }
        return g1(i3, g1Var, l1Var);
    }

    @Override // e1.y0
    public final void u0(int i3) {
        this.f917x = i3;
        this.f918y = Integer.MIN_VALUE;
        i0 i0Var = this.f919z;
        if (i0Var != null) {
            i0Var.f1916a = -1;
        }
        s0();
    }

    @Override // e1.y0
    public int v0(int i3, g1 g1Var, l1 l1Var) {
        if (this.f909p == 0) {
            return 0;
        }
        return g1(i3, g1Var, l1Var);
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i3, int i4) {
        this.f909p = 1;
        this.f913t = false;
        this.f914u = false;
        this.f915v = false;
        this.f916w = true;
        this.f917x = -1;
        this.f918y = Integer.MIN_VALUE;
        this.f919z = null;
        this.A = new f0();
        this.B = new g0();
        this.C = 2;
        this.D = new int[2];
        x0 x0VarM = y0.M(context, attributeSet, i3, i4);
        i1(x0VarM.f2112a);
        boolean z4 = x0VarM.f2114c;
        c(null);
        if (z4 != this.f913t) {
            this.f913t = z4;
            s0();
        }
        j1(x0VarM.f2115d);
    }

    @Override // e1.y0
    public final void W(RecyclerView recyclerView) {
    }

    public void c1(g1 g1Var, l1 l1Var, f0 f0Var, int i3) {
    }
}
