package androidx.recyclerview.widget;

import a2.i;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.emoji2.text.h;
import androidx.emoji2.text.q;
import e1.e0;
import e1.g1;
import e1.j0;
import e1.k1;
import e1.l1;
import e1.s1;
import e1.t1;
import e1.u;
import e1.u1;
import e1.v1;
import e1.w1;
import e1.x0;
import e1.y0;
import e1.z0;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.WeakHashMap;
import o0.h0;

/* JADX INFO: loaded from: classes.dex */
public class StaggeredGridLayoutManager extends y0 implements k1 {
    public final q B;
    public final int C;
    public boolean D;
    public boolean E;
    public v1 F;
    public final Rect G;
    public final s1 H;
    public final boolean I;
    public int[] J;
    public final i K;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f972p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final w1[] f973q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final h f974r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final h f975s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f976t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f977u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final e0 f978v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f979w;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final BitSet f981y;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f980x = false;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f982z = -1;
    public int A = Integer.MIN_VALUE;

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i3, int i4) {
        this.f972p = -1;
        this.f979w = false;
        q qVar = new q(6, false);
        this.B = qVar;
        this.C = 2;
        this.G = new Rect();
        this.H = new s1(this);
        this.I = true;
        this.K = new i(10, this);
        x0 x0VarM = y0.M(context, attributeSet, i3, i4);
        int i5 = x0VarM.f2112a;
        if (i5 != 0 && i5 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        c(null);
        if (i5 != this.f976t) {
            this.f976t = i5;
            h hVar = this.f974r;
            this.f974r = this.f975s;
            this.f975s = hVar;
            s0();
        }
        int i6 = x0VarM.f2113b;
        c(null);
        if (i6 != this.f972p) {
            qVar.h();
            s0();
            this.f972p = i6;
            this.f981y = new BitSet(this.f972p);
            this.f973q = new w1[this.f972p];
            for (int i7 = 0; i7 < this.f972p; i7++) {
                this.f973q[i7] = new w1(this, i7);
            }
            s0();
        }
        boolean z4 = x0VarM.f2114c;
        c(null);
        v1 v1Var = this.F;
        if (v1Var != null && v1Var.f2095h != z4) {
            v1Var.f2095h = z4;
        }
        this.f979w = z4;
        s0();
        e0 e0Var = new e0();
        e0Var.f1855a = true;
        e0Var.f = 0;
        e0Var.f1860g = 0;
        this.f978v = e0Var;
        this.f974r = h.a(this, this.f976t);
        this.f975s = h.a(this, 1 - this.f976t);
    }

    public static int h1(int i3, int i4, int i5) {
        int mode;
        return (!(i4 == 0 && i5 == 0) && ((mode = View.MeasureSpec.getMode(i3)) == Integer.MIN_VALUE || mode == 1073741824)) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i3) - i4) - i5), mode) : i3;
    }

    @Override // e1.y0
    public final void E0(RecyclerView recyclerView, int i3) {
        j0 j0Var = new j0(recyclerView.getContext());
        j0Var.f1925a = i3;
        F0(j0Var);
    }

    @Override // e1.y0
    public final boolean G0() {
        return this.F == null;
    }

    public final boolean H0() {
        int iO0;
        if (v() != 0 && this.C != 0 && this.f2127g) {
            if (this.f980x) {
                iO0 = P0();
                O0();
            } else {
                iO0 = O0();
                P0();
            }
            if (iO0 == 0 && T0() != null) {
                this.B.h();
                this.f = true;
                s0();
                return true;
            }
        }
        return false;
    }

    public final int I0(l1 l1Var) {
        if (v() == 0) {
            return 0;
        }
        boolean z4 = !this.I;
        return e1.q.b(l1Var, this.f974r, L0(z4), K0(z4), this, this.I, this.f980x);
    }

    /* JADX WARN: Type inference failed for: r8v2 */
    /* JADX WARN: Type inference failed for: r8v24 */
    /* JADX WARN: Type inference failed for: r8v3, types: [boolean, int] */
    public final int J0(g1 g1Var, e0 e0Var, l1 l1Var) {
        w1 w1Var;
        ?? r8;
        int i3;
        int iC;
        int iK;
        int iC2;
        int i4;
        int i5;
        int i6;
        int i7 = 1;
        this.f981y.set(0, this.f972p, true);
        e0 e0Var2 = this.f978v;
        int i8 = e0Var2.f1862i ? e0Var.f1859e == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE : e0Var.f1859e == 1 ? e0Var.f1860g + e0Var.f1856b : e0Var.f - e0Var.f1856b;
        int i9 = e0Var.f1859e;
        for (int i10 = 0; i10 < this.f972p; i10++) {
            if (!((ArrayList) this.f973q[i10].f).isEmpty()) {
                g1(this.f973q[i10], i9, i8);
            }
        }
        int iG = this.f980x ? this.f974r.g() : this.f974r.k();
        boolean z4 = false;
        while (true) {
            int i11 = e0Var.f1857c;
            if (i11 < 0 || i11 >= l1Var.b() || (!e0Var2.f1862i && this.f981y.isEmpty())) {
                break;
            }
            View view = g1Var.j(e0Var.f1857c, Long.MAX_VALUE).f2003a;
            e0Var.f1857c += e0Var.f1858d;
            t1 t1Var = (t1) view.getLayoutParams();
            int iC3 = t1Var.f2155a.c();
            q qVar = this.B;
            int[] iArr = (int[]) qVar.f551b;
            int i12 = (iArr == null || iC3 >= iArr.length) ? -1 : iArr[iC3];
            if (i12 == -1) {
                if (X0(e0Var.f1859e)) {
                    i5 = this.f972p - i7;
                    i4 = -1;
                    i6 = -1;
                } else {
                    i4 = this.f972p;
                    i5 = 0;
                    i6 = 1;
                }
                w1 w1Var2 = null;
                if (e0Var.f1859e == i7) {
                    int iK2 = this.f974r.k();
                    int i13 = Integer.MAX_VALUE;
                    while (i5 != i4) {
                        w1 w1Var3 = this.f973q[i5];
                        int iG2 = w1Var3.g(iK2);
                        if (iG2 < i13) {
                            i13 = iG2;
                            w1Var2 = w1Var3;
                        }
                        i5 += i6;
                    }
                } else {
                    int iG3 = this.f974r.g();
                    int i14 = Integer.MIN_VALUE;
                    while (i5 != i4) {
                        w1 w1Var4 = this.f973q[i5];
                        int i15 = w1Var4.i(iG3);
                        if (i15 > i14) {
                            w1Var2 = w1Var4;
                            i14 = i15;
                        }
                        i5 += i6;
                    }
                }
                w1Var = w1Var2;
                qVar.j(iC3);
                ((int[]) qVar.f551b)[iC3] = w1Var.f2109e;
            } else {
                w1Var = this.f973q[i12];
            }
            t1Var.f2070e = w1Var;
            if (e0Var.f1859e == 1) {
                r8 = 0;
                b(view, -1, false);
            } else {
                r8 = 0;
                b(view, 0, false);
            }
            if (this.f976t == 1) {
                V0(view, y0.w(r8, this.f977u, this.f2132l, r8, ((ViewGroup.MarginLayoutParams) t1Var).width), y0.w(true, this.f2135o, this.f2133m, H() + K(), ((ViewGroup.MarginLayoutParams) t1Var).height));
            } else {
                V0(view, y0.w(true, this.f2134n, this.f2132l, J() + I(), ((ViewGroup.MarginLayoutParams) t1Var).width), y0.w(false, this.f977u, this.f2133m, 0, ((ViewGroup.MarginLayoutParams) t1Var).height));
            }
            if (e0Var.f1859e == 1) {
                iC = w1Var.g(iG);
                i3 = this.f974r.c(view) + iC;
            } else {
                i3 = w1Var.i(iG);
                iC = i3 - this.f974r.c(view);
            }
            if (e0Var.f1859e == 1) {
                w1 w1Var5 = t1Var.f2070e;
                w1Var5.getClass();
                t1 t1Var2 = (t1) view.getLayoutParams();
                t1Var2.f2070e = w1Var5;
                ArrayList arrayList = (ArrayList) w1Var5.f;
                arrayList.add(view);
                w1Var5.f2107c = Integer.MIN_VALUE;
                if (arrayList.size() == 1) {
                    w1Var5.f2106b = Integer.MIN_VALUE;
                }
                if (t1Var2.f2155a.i() || t1Var2.f2155a.l()) {
                    w1Var5.f2108d = ((StaggeredGridLayoutManager) w1Var5.f2110g).f974r.c(view) + w1Var5.f2108d;
                }
            } else {
                w1 w1Var6 = t1Var.f2070e;
                w1Var6.getClass();
                t1 t1Var3 = (t1) view.getLayoutParams();
                t1Var3.f2070e = w1Var6;
                ArrayList arrayList2 = (ArrayList) w1Var6.f;
                arrayList2.add(0, view);
                w1Var6.f2106b = Integer.MIN_VALUE;
                if (arrayList2.size() == 1) {
                    w1Var6.f2107c = Integer.MIN_VALUE;
                }
                if (t1Var3.f2155a.i() || t1Var3.f2155a.l()) {
                    w1Var6.f2108d = ((StaggeredGridLayoutManager) w1Var6.f2110g).f974r.c(view) + w1Var6.f2108d;
                }
            }
            if (U0() && this.f976t == 1) {
                iC2 = this.f975s.g() - (((this.f972p - 1) - w1Var.f2109e) * this.f977u);
                iK = iC2 - this.f975s.c(view);
            } else {
                iK = this.f975s.k() + (w1Var.f2109e * this.f977u);
                iC2 = this.f975s.c(view) + iK;
            }
            if (this.f976t == 1) {
                y0.R(view, iK, iC, iC2, i3);
            } else {
                y0.R(view, iC, iK, i3, iC2);
            }
            g1(w1Var, e0Var2.f1859e, i8);
            Z0(g1Var, e0Var2);
            if (e0Var2.f1861h && view.hasFocusable()) {
                this.f981y.set(w1Var.f2109e, false);
            }
            i7 = 1;
            z4 = true;
        }
        if (!z4) {
            Z0(g1Var, e0Var2);
        }
        int iK3 = e0Var2.f1859e == -1 ? this.f974r.k() - R0(this.f974r.k()) : Q0(this.f974r.g()) - this.f974r.g();
        if (iK3 > 0) {
            return Math.min(e0Var.f1856b, iK3);
        }
        return 0;
    }

    public final View K0(boolean z4) {
        int iK = this.f974r.k();
        int iG = this.f974r.g();
        View view = null;
        for (int iV = v() - 1; iV >= 0; iV--) {
            View viewU = u(iV);
            int iE = this.f974r.e(viewU);
            int iB = this.f974r.b(viewU);
            if (iB > iK && iE < iG) {
                if (iB <= iG || !z4) {
                    return viewU;
                }
                if (view == null) {
                    view = viewU;
                }
            }
        }
        return view;
    }

    public final View L0(boolean z4) {
        int iK = this.f974r.k();
        int iG = this.f974r.g();
        int iV = v();
        View view = null;
        for (int i3 = 0; i3 < iV; i3++) {
            View viewU = u(i3);
            int iE = this.f974r.e(viewU);
            if (this.f974r.b(viewU) > iK && iE < iG) {
                if (iE >= iK || !z4) {
                    return viewU;
                }
                if (view == null) {
                    view = viewU;
                }
            }
        }
        return view;
    }

    public final void M0(g1 g1Var, l1 l1Var, boolean z4) {
        int iG;
        int iQ0 = Q0(Integer.MIN_VALUE);
        if (iQ0 != Integer.MIN_VALUE && (iG = this.f974r.g() - iQ0) > 0) {
            int i3 = iG - (-d1(-iG, g1Var, l1Var));
            if (!z4 || i3 <= 0) {
                return;
            }
            this.f974r.o(i3);
        }
    }

    public final void N0(g1 g1Var, l1 l1Var, boolean z4) {
        int iK;
        int iR0 = R0(Integer.MAX_VALUE);
        if (iR0 != Integer.MAX_VALUE && (iK = iR0 - this.f974r.k()) > 0) {
            int iD1 = iK - d1(iK, g1Var, l1Var);
            if (!z4 || iD1 <= 0) {
                return;
            }
            this.f974r.o(-iD1);
        }
    }

    public final int O0() {
        if (v() == 0) {
            return 0;
        }
        return y0.L(u(0));
    }

    @Override // e1.y0
    public final boolean P() {
        return this.C != 0;
    }

    public final int P0() {
        int iV = v();
        if (iV == 0) {
            return 0;
        }
        return y0.L(u(iV - 1));
    }

    public final int Q0(int i3) {
        int iG = this.f973q[0].g(i3);
        for (int i4 = 1; i4 < this.f972p; i4++) {
            int iG2 = this.f973q[i4].g(i3);
            if (iG2 > iG) {
                iG = iG2;
            }
        }
        return iG;
    }

    public final int R0(int i3) {
        int i4 = this.f973q[0].i(i3);
        for (int i5 = 1; i5 < this.f972p; i5++) {
            int i6 = this.f973q[i5].i(i3);
            if (i6 < i4) {
                i4 = i6;
            }
        }
        return i4;
    }

    @Override // e1.y0
    public final void S(int i3) {
        super.S(i3);
        for (int i4 = 0; i4 < this.f972p; i4++) {
            w1 w1Var = this.f973q[i4];
            int i5 = w1Var.f2106b;
            if (i5 != Integer.MIN_VALUE) {
                w1Var.f2106b = i5 + i3;
            }
            int i6 = w1Var.f2107c;
            if (i6 != Integer.MIN_VALUE) {
                w1Var.f2107c = i6 + i3;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0034  */
    /* JADX WARN: Code duplicated, block: B:22:0x0036 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:24:0x0039  */
    /* JADX WARN: Code duplicated, block: B:26:0x0041  */
    /* JADX WARN: Code duplicated, block: B:29:0x0050 A[LOOP:0: B:25:0x003f->B:29:0x0050, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:30:0x0053 A[EDGE_INSN: B:30:0x0053->B:31:0x0054 BREAK  A[LOOP:0: B:25:0x003f->B:29:0x0050]] */
    /* JADX WARN: Code duplicated, block: B:32:0x0056  */
    /* JADX WARN: Code duplicated, block: B:35:0x0068  */
    /* JADX WARN: Code duplicated, block: B:38:0x0077 A[LOOP:1: B:34:0x0066->B:38:0x0077, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:41:0x007d  */
    /* JADX WARN: Code duplicated, block: B:43:0x0092  */
    /* JADX WARN: Code duplicated, block: B:44:0x00a0  */
    /* JADX WARN: Code duplicated, block: B:47:0x00b5  */
    /* JADX WARN: Code duplicated, block: B:49:0x00b8 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:51:0x00bb  */
    /* JADX WARN: Code duplicated, block: B:52:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:53:0x00c6  */
    /* JADX WARN: Code duplicated, block: B:56:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:58:0x00d0  */
    /* JADX WARN: Code duplicated, block: B:59:0x00d5  */
    /* JADX WARN: Code duplicated, block: B:61:0x00db  */
    /* JADX WARN: Code duplicated, block: B:63:0x0053 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:64:0x0054 A[EDGE_INSN: B:64:0x0054->B:31:0x0054 BREAK  A[LOOP:0: B:25:0x003f->B:29:0x0050], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:65:0x007a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:66:0x007b A[EDGE_INSN: B:66:0x007b->B:40:0x007b BREAK  A[LOOP:1: B:34:0x0066->B:38:0x0077], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:67:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:68:? A[RETURN, SYNTHETIC] */
    public final void S0(int i3, int i4, int i5) {
        int i6;
        int i7;
        q qVar;
        int[] iArr;
        int iP0;
        ArrayList arrayList;
        u1 u1Var;
        int size;
        int i8;
        int i9;
        int size2;
        int iP1 = this.f980x ? P0() : O0();
        if (i5 == 8) {
            if (i3 < i4) {
                i6 = i4 + 1;
            } else {
                i6 = i3 + 1;
                i7 = i4;
            }
            qVar = this.B;
            iArr = (int[]) qVar.f551b;
            if (iArr != null && i7 < iArr.length) {
                arrayList = (ArrayList) qVar.f552c;
                if (arrayList != null) {
                    if (arrayList == null) {
                        size2 = arrayList.size() - 1;
                        while (true) {
                            if (size2 >= 0) {
                                u1Var = null;
                                break;
                            }
                            u1Var = (u1) ((ArrayList) qVar.f552c).get(size2);
                            if (u1Var.f2080a == i7) {
                                break;
                            } else {
                                size2--;
                            }
                        }
                    } else {
                        u1Var = null;
                        break;
                    }
                    if (u1Var != null) {
                        ((ArrayList) qVar.f552c).remove(u1Var);
                    }
                    size = ((ArrayList) qVar.f552c).size();
                    i8 = 0;
                    while (true) {
                        if (i8 < size) {
                            i8 = -1;
                            break;
                        } else if (((u1) ((ArrayList) qVar.f552c).get(i8)).f2080a >= i7) {
                            break;
                        } else {
                            i8++;
                        }
                    }
                    if (i8 != -1) {
                        u1 u1Var2 = (u1) ((ArrayList) qVar.f552c).get(i8);
                        ((ArrayList) qVar.f552c).remove(i8);
                        i9 = u1Var2.f2080a;
                    } else {
                        i9 = -1;
                    }
                } else {
                    i9 = -1;
                }
                if (i9 == -1) {
                    int[] iArr2 = (int[]) qVar.f551b;
                    Arrays.fill(iArr2, i7, iArr2.length, -1);
                    int length = ((int[]) qVar.f551b).length;
                } else {
                    Arrays.fill((int[]) qVar.f551b, i7, Math.min(i9 + 1, ((int[]) qVar.f551b).length), -1);
                }
            }
            if (i5 != 1) {
                qVar.p(i3, i4);
            } else if (i5 != 2) {
                qVar.q(i3, i4);
            } else if (i5 == 8) {
                qVar.q(i3, 1);
                qVar.p(i4, 1);
            }
            if (i6 <= iP1) {
                return;
            }
            if (this.f980x) {
                iP0 = O0();
            } else {
                iP0 = P0();
            }
            if (i7 <= iP0) {
                s0();
            }
        }
        i6 = i3 + i4;
        i7 = i3;
        qVar = this.B;
        iArr = (int[]) qVar.f551b;
        if (iArr != null) {
            arrayList = (ArrayList) qVar.f552c;
            if (arrayList != null) {
                if (arrayList == null) {
                    size2 = arrayList.size() - 1;
                    while (true) {
                        if (size2 >= 0) {
                            u1Var = null;
                            break;
                        }
                        u1Var = (u1) ((ArrayList) qVar.f552c).get(size2);
                        if (u1Var.f2080a == i7) {
                            break;
                            break;
                        }
                        size2--;
                    }
                } else {
                    u1Var = null;
                    break;
                }
                if (u1Var != null) {
                    ((ArrayList) qVar.f552c).remove(u1Var);
                }
                size = ((ArrayList) qVar.f552c).size();
                i8 = 0;
                while (true) {
                    if (i8 < size) {
                        i8 = -1;
                        break;
                    } else {
                        if (((u1) ((ArrayList) qVar.f552c).get(i8)).f2080a >= i7) {
                            break;
                            break;
                        }
                        i8++;
                    }
                }
                if (i8 != -1) {
                    u1 u1Var3 = (u1) ((ArrayList) qVar.f552c).get(i8);
                    ((ArrayList) qVar.f552c).remove(i8);
                    i9 = u1Var3.f2080a;
                } else {
                    i9 = -1;
                }
            } else {
                i9 = -1;
            }
            if (i9 == -1) {
                int[] iArr3 = (int[]) qVar.f551b;
                Arrays.fill(iArr3, i7, iArr3.length, -1);
                int length2 = ((int[]) qVar.f551b).length;
            } else {
                Arrays.fill((int[]) qVar.f551b, i7, Math.min(i9 + 1, ((int[]) qVar.f551b).length), -1);
            }
        }
        if (i5 != 1) {
            qVar.p(i3, i4);
        } else if (i5 != 2) {
            qVar.q(i3, i4);
        } else if (i5 == 8) {
            qVar.q(i3, 1);
            qVar.p(i4, 1);
        }
        if (i6 <= iP1) {
            return;
        }
        if (this.f980x) {
            iP0 = O0();
        } else {
            iP0 = P0();
        }
        if (i7 <= iP0) {
            s0();
        }
    }

    @Override // e1.y0
    public final void T(int i3) {
        super.T(i3);
        for (int i4 = 0; i4 < this.f972p; i4++) {
            w1 w1Var = this.f973q[i4];
            int i5 = w1Var.f2106b;
            if (i5 != Integer.MIN_VALUE) {
                w1Var.f2106b = i5 + i3;
            }
            int i6 = w1Var.f2107c;
            if (i6 != Integer.MIN_VALUE) {
                w1Var.f2107c = i6 + i3;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:51:0x00f9  */
    /* JADX WARN: Code duplicated, block: B:52:0x00fb  */
    /* JADX WARN: Code duplicated, block: B:54:0x00fe  */
    /* JADX WARN: Code duplicated, block: B:55:0x0100  */
    /* JADX WARN: Code duplicated, block: B:68:0x0103 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:74:0x002c A[SYNTHETIC] */
    public final View T0() {
        boolean z4;
        boolean z5;
        int iV = v();
        int i3 = iV - 1;
        BitSet bitSet = new BitSet(this.f972p);
        bitSet.set(0, this.f972p, true);
        byte b4 = (this.f976t == 1 && U0()) ? (byte) 1 : (byte) -1;
        if (this.f980x) {
            iV = -1;
        } else {
            i3 = 0;
        }
        int i4 = i3 < iV ? 1 : -1;
        while (i3 != iV) {
            View viewU = u(i3);
            t1 t1Var = (t1) viewU.getLayoutParams();
            if (bitSet.get(t1Var.f2070e.f2109e)) {
                w1 w1Var = t1Var.f2070e;
                if (this.f980x) {
                    int i5 = w1Var.f2107c;
                    if (i5 == Integer.MIN_VALUE) {
                        w1Var.a();
                        i5 = w1Var.f2107c;
                    }
                    if (i5 < this.f974r.g()) {
                        ArrayList arrayList = (ArrayList) w1Var.f;
                        ((t1) ((View) arrayList.get(arrayList.size() - 1)).getLayoutParams()).getClass();
                        return viewU;
                    }
                } else {
                    int i6 = w1Var.f2106b;
                    ArrayList arrayList2 = (ArrayList) w1Var.f;
                    if (i6 == Integer.MIN_VALUE) {
                        View view = (View) arrayList2.get(0);
                        t1 t1Var2 = (t1) view.getLayoutParams();
                        w1Var.f2106b = ((StaggeredGridLayoutManager) w1Var.f2110g).f974r.e(view);
                        t1Var2.getClass();
                        i6 = w1Var.f2106b;
                    }
                    if (i6 > this.f974r.k()) {
                        ((t1) ((View) arrayList2.get(0)).getLayoutParams()).getClass();
                        return viewU;
                    }
                }
                bitSet.clear(t1Var.f2070e.f2109e);
            }
            i3 += i4;
            if (i3 != iV) {
                View viewU2 = u(i3);
                if (this.f980x) {
                    int iB = this.f974r.b(viewU);
                    int iB2 = this.f974r.b(viewU2);
                    if (iB >= iB2) {
                        if (iB == iB2) {
                            if (t1Var.f2070e.f2109e - ((t1) viewU2.getLayoutParams()).f2070e.f2109e < 0) {
                                z4 = true;
                            } else {
                                z4 = false;
                            }
                            if (b4 < 0) {
                                z5 = true;
                            } else {
                                z5 = false;
                            }
                            if (z4 != z5) {
                            }
                        } else {
                            continue;
                        }
                    }
                    return viewU;
                }
                int iE = this.f974r.e(viewU);
                int iE2 = this.f974r.e(viewU2);
                if (iE <= iE2) {
                    if (iE == iE2) {
                        if (t1Var.f2070e.f2109e - ((t1) viewU2.getLayoutParams()).f2070e.f2109e < 0) {
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        if (b4 < 0) {
                            z5 = true;
                        } else {
                            z5 = false;
                        }
                        if (z4 != z5) {
                        }
                    } else {
                        continue;
                    }
                }
                return viewU;
            }
        }
        return null;
    }

    @Override // e1.y0
    public final void U() {
        this.B.h();
        for (int i3 = 0; i3 < this.f972p; i3++) {
            this.f973q[i3].b();
        }
    }

    public final boolean U0() {
        return G() == 1;
    }

    public final void V0(View view, int i3, int i4) {
        RecyclerView recyclerView = this.f2123b;
        Rect rect = this.G;
        if (recyclerView == null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect.set(recyclerView.K(view));
        }
        t1 t1Var = (t1) view.getLayoutParams();
        int iH1 = h1(i3, ((ViewGroup.MarginLayoutParams) t1Var).leftMargin + rect.left, ((ViewGroup.MarginLayoutParams) t1Var).rightMargin + rect.right);
        int iH2 = h1(i4, ((ViewGroup.MarginLayoutParams) t1Var).topMargin + rect.top, ((ViewGroup.MarginLayoutParams) t1Var).bottomMargin + rect.bottom);
        if (B0(view, iH1, iH2, t1Var)) {
            view.measure(iH1, iH2);
        }
    }

    @Override // e1.y0
    public final void W(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f2123b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(this.K);
        }
        for (int i3 = 0; i3 < this.f972p; i3++) {
            this.f973q[i3].b();
        }
        recyclerView.requestLayout();
    }

    /* JADX WARN: Code duplicated, block: B:108:0x01a8  */
    /* JADX WARN: Code duplicated, block: B:109:0x01aa  */
    /* JADX WARN: Code duplicated, block: B:123:0x01e1  */
    /* JADX WARN: Code duplicated, block: B:125:0x01ec  */
    /* JADX WARN: Code duplicated, block: B:131:0x01fe  */
    /* JADX WARN: Code duplicated, block: B:133:0x0209  */
    /* JADX WARN: Code duplicated, block: B:254:0x041e  */
    /* JADX WARN: Code duplicated, block: B:265:0x01fc A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:269:0x01fc A[SYNTHETIC] */
    public final void W0(g1 g1Var, l1 l1Var, boolean z4) {
        boolean z5;
        v1 v1Var;
        int iV;
        int i3;
        int iL;
        int iL2;
        int iV2;
        int i4;
        boolean z6;
        v1 v1Var2 = this.F;
        s1 s1Var = this.H;
        if (!(v1Var2 == null && this.f982z == -1) && l1Var.b() == 0) {
            n0(g1Var);
            s1Var.a();
            return;
        }
        boolean z7 = s1Var.f2041e;
        StaggeredGridLayoutManager staggeredGridLayoutManager = s1Var.f2042g;
        boolean z8 = (z7 && this.f982z == -1 && this.F == null) ? false : true;
        q qVar = this.B;
        if (z8) {
            s1Var.a();
            v1 v1Var3 = this.F;
            if (v1Var3 != null) {
                int i5 = v1Var3.f2091c;
                if (i5 > 0) {
                    if (i5 == this.f972p) {
                        for (int i6 = 0; i6 < this.f972p; i6++) {
                            this.f973q[i6].b();
                            v1 v1Var4 = this.F;
                            int iG = v1Var4.f2092d[i6];
                            if (iG != Integer.MIN_VALUE) {
                                iG += v1Var4.f2096i ? this.f974r.g() : this.f974r.k();
                            }
                            w1 w1Var = this.f973q[i6];
                            w1Var.f2106b = iG;
                            w1Var.f2107c = iG;
                        }
                    } else {
                        v1Var3.f2092d = null;
                        v1Var3.f2091c = 0;
                        v1Var3.f2093e = 0;
                        v1Var3.f = null;
                        v1Var3.f2094g = null;
                        v1Var3.f2089a = v1Var3.f2090b;
                    }
                }
                v1 v1Var5 = this.F;
                this.E = v1Var5.f2097j;
                boolean z9 = v1Var5.f2095h;
                c(null);
                v1 v1Var6 = this.F;
                if (v1Var6 != null && v1Var6.f2095h != z9) {
                    v1Var6.f2095h = z9;
                }
                this.f979w = z9;
                s0();
                c1();
                v1 v1Var7 = this.F;
                int i7 = v1Var7.f2089a;
                if (i7 != -1) {
                    this.f982z = i7;
                    s1Var.f2039c = v1Var7.f2096i;
                } else {
                    s1Var.f2039c = this.f980x;
                }
                if (v1Var7.f2093e > 1) {
                    qVar.f551b = v1Var7.f;
                    qVar.f552c = v1Var7.f2094g;
                }
            } else {
                c1();
                s1Var.f2039c = this.f980x;
            }
            if (l1Var.f1970g || (i4 = this.f982z) == -1) {
                if (this.D) {
                    int iB = l1Var.b();
                    iV2 = v() - 1;
                    while (true) {
                        if (iV2 < 0) {
                            iL2 = 0;
                            break;
                        }
                        iL2 = y0.L(u(iV2));
                        if (iL2 < 0 && iL2 < iB) {
                            break;
                        } else {
                            iV2--;
                        }
                    }
                } else {
                    int iB2 = l1Var.b();
                    iV = v();
                    i3 = 0;
                    while (true) {
                        if (i3 >= iV) {
                            iL2 = 0;
                            break;
                        }
                        iL = y0.L(u(i3));
                        if (iL < 0 && iL < iB2) {
                            iL2 = iL;
                            break;
                        }
                        i3++;
                    }
                }
                s1Var.f2037a = iL2;
                s1Var.f2038b = Integer.MIN_VALUE;
            } else if (i4 < 0 || i4 >= l1Var.b()) {
                this.f982z = -1;
                this.A = Integer.MIN_VALUE;
                if (this.D) {
                    int iB3 = l1Var.b();
                    iV2 = v() - 1;
                    while (true) {
                        if (iV2 < 0) {
                            iL2 = 0;
                            break;
                        } else {
                            iL2 = y0.L(u(iV2));
                            if (iL2 < 0) {
                            }
                            iV2--;
                        }
                    }
                } else {
                    int iB4 = l1Var.b();
                    iV = v();
                    i3 = 0;
                    while (true) {
                        if (i3 >= iV) {
                            iL2 = 0;
                            break;
                        } else {
                            iL = y0.L(u(i3));
                            if (iL < 0) {
                            }
                            i3++;
                        }
                    }
                }
                s1Var.f2037a = iL2;
                s1Var.f2038b = Integer.MIN_VALUE;
            } else {
                v1 v1Var8 = this.F;
                if (v1Var8 == null || v1Var8.f2089a == -1 || v1Var8.f2091c < 1) {
                    View viewQ = q(this.f982z);
                    if (viewQ != null) {
                        s1Var.f2037a = this.f980x ? P0() : O0();
                        if (this.A != Integer.MIN_VALUE) {
                            if (s1Var.f2039c) {
                                s1Var.f2038b = (this.f974r.g() - this.A) - this.f974r.b(viewQ);
                            } else {
                                s1Var.f2038b = (this.f974r.k() + this.A) - this.f974r.e(viewQ);
                            }
                        } else if (this.f974r.c(viewQ) > this.f974r.l()) {
                            s1Var.f2038b = s1Var.f2039c ? this.f974r.g() : this.f974r.k();
                        } else {
                            int iE = this.f974r.e(viewQ) - this.f974r.k();
                            if (iE < 0) {
                                s1Var.f2038b = -iE;
                            } else {
                                int iG2 = this.f974r.g() - this.f974r.b(viewQ);
                                if (iG2 < 0) {
                                    s1Var.f2038b = iG2;
                                } else {
                                    s1Var.f2038b = Integer.MIN_VALUE;
                                }
                            }
                        }
                    } else {
                        int i8 = this.f982z;
                        s1Var.f2037a = i8;
                        int i9 = this.A;
                        if (i9 == Integer.MIN_VALUE) {
                            if (v() != 0) {
                                if ((i8 < O0()) != this.f980x) {
                                    z6 = false;
                                } else {
                                    z6 = true;
                                }
                            } else if (this.f980x) {
                                z6 = true;
                            } else {
                                z6 = false;
                            }
                            s1Var.f2039c = z6;
                            s1Var.f2038b = z6 ? staggeredGridLayoutManager.f974r.g() : staggeredGridLayoutManager.f974r.k();
                        } else if (s1Var.f2039c) {
                            s1Var.f2038b = staggeredGridLayoutManager.f974r.g() - i9;
                        } else {
                            s1Var.f2038b = staggeredGridLayoutManager.f974r.k() + i9;
                        }
                        s1Var.f2040d = true;
                    }
                } else {
                    s1Var.f2038b = Integer.MIN_VALUE;
                    s1Var.f2037a = this.f982z;
                }
            }
            s1Var.f2041e = true;
        }
        if (this.F == null && this.f982z == -1 && (s1Var.f2039c != this.D || U0() != this.E)) {
            qVar.h();
            s1Var.f2040d = true;
        }
        if (v() > 0 && ((v1Var = this.F) == null || v1Var.f2091c < 1)) {
            if (s1Var.f2040d) {
                for (int i10 = 0; i10 < this.f972p; i10++) {
                    this.f973q[i10].b();
                    int i11 = s1Var.f2038b;
                    if (i11 != Integer.MIN_VALUE) {
                        w1 w1Var2 = this.f973q[i10];
                        w1Var2.f2106b = i11;
                        w1Var2.f2107c = i11;
                    }
                }
            } else if (z8 || s1Var.f == null) {
                for (int i12 = 0; i12 < this.f972p; i12++) {
                    w1 w1Var3 = this.f973q[i12];
                    boolean z10 = this.f980x;
                    int i13 = s1Var.f2038b;
                    StaggeredGridLayoutManager staggeredGridLayoutManager2 = (StaggeredGridLayoutManager) w1Var3.f2110g;
                    int iG3 = z10 ? w1Var3.g(Integer.MIN_VALUE) : w1Var3.i(Integer.MIN_VALUE);
                    w1Var3.b();
                    if (iG3 != Integer.MIN_VALUE && ((!z10 || iG3 >= staggeredGridLayoutManager2.f974r.g()) && (z10 || iG3 <= staggeredGridLayoutManager2.f974r.k()))) {
                        if (i13 != Integer.MIN_VALUE) {
                            iG3 += i13;
                        }
                        w1Var3.f2107c = iG3;
                        w1Var3.f2106b = iG3;
                    }
                }
                w1[] w1VarArr = this.f973q;
                int length = w1VarArr.length;
                int[] iArr = s1Var.f;
                if (iArr == null || iArr.length < length) {
                    s1Var.f = new int[staggeredGridLayoutManager.f973q.length];
                }
                for (int i14 = 0; i14 < length; i14++) {
                    s1Var.f[i14] = w1VarArr[i14].i(Integer.MIN_VALUE);
                }
            } else {
                for (int i15 = 0; i15 < this.f972p; i15++) {
                    w1 w1Var4 = this.f973q[i15];
                    w1Var4.b();
                    int i16 = s1Var.f[i15];
                    w1Var4.f2106b = i16;
                    w1Var4.f2107c = i16;
                }
            }
        }
        p(g1Var);
        e0 e0Var = this.f978v;
        e0Var.f1855a = false;
        int iL3 = this.f975s.l();
        this.f977u = iL3 / this.f972p;
        View.MeasureSpec.makeMeasureSpec(iL3, this.f975s.i());
        f1(s1Var.f2037a, l1Var);
        if (s1Var.f2039c) {
            e1(-1);
            J0(g1Var, e0Var, l1Var);
            e1(1);
            e0Var.f1857c = s1Var.f2037a + e0Var.f1858d;
            J0(g1Var, e0Var, l1Var);
        } else {
            e1(1);
            J0(g1Var, e0Var, l1Var);
            e1(-1);
            e0Var.f1857c = s1Var.f2037a + e0Var.f1858d;
            J0(g1Var, e0Var, l1Var);
        }
        if (this.f975s.i() != 1073741824) {
            int iV3 = v();
            float fMax = 0.0f;
            for (int i17 = 0; i17 < iV3; i17++) {
                View viewU = u(i17);
                float fC = this.f975s.c(viewU);
                if (fC >= fMax) {
                    ((t1) viewU.getLayoutParams()).getClass();
                    fMax = Math.max(fMax, fC);
                }
            }
            int i18 = this.f977u;
            int iRound = Math.round(fMax * this.f972p);
            if (this.f975s.i() == Integer.MIN_VALUE) {
                iRound = Math.min(iRound, this.f975s.l());
            }
            this.f977u = iRound / this.f972p;
            View.MeasureSpec.makeMeasureSpec(iRound, this.f975s.i());
            if (this.f977u != i18) {
                for (int i19 = 0; i19 < iV3; i19++) {
                    View viewU2 = u(i19);
                    t1 t1Var = (t1) viewU2.getLayoutParams();
                    t1Var.getClass();
                    if (U0() && this.f976t == 1) {
                        int i20 = -((this.f972p - 1) - t1Var.f2070e.f2109e);
                        viewU2.offsetLeftAndRight((this.f977u * i20) - (i20 * i18));
                    } else {
                        int i21 = t1Var.f2070e.f2109e;
                        int i22 = this.f977u * i21;
                        int i23 = i21 * i18;
                        if (this.f976t == 1) {
                            viewU2.offsetLeftAndRight(i22 - i23);
                        } else {
                            viewU2.offsetTopAndBottom(i22 - i23);
                        }
                    }
                }
            }
        }
        if (v() > 0) {
            if (this.f980x) {
                M0(g1Var, l1Var, true);
                N0(g1Var, l1Var, false);
            } else {
                N0(g1Var, l1Var, true);
                M0(g1Var, l1Var, false);
            }
        }
        if (z4 && !l1Var.f1970g && this.C != 0 && v() > 0 && T0() != null) {
            RecyclerView recyclerView = this.f2123b;
            if (recyclerView != null) {
                recyclerView.removeCallbacks(this.K);
            }
            z5 = H0();
        }
        if (l1Var.f1970g) {
            s1Var.a();
        }
        this.D = s1Var.f2039c;
        this.E = U0();
        if (z5) {
            s1Var.a();
            W0(g1Var, l1Var, false);
        }
    }

    /* JADX WARN: Code duplicated, block: B:31:0x0049  */
    /* JADX WARN: Code duplicated, block: B:37:0x0054  */
    @Override // e1.y0
    public final View X(View view, int i3, g1 g1Var, l1 l1Var) {
        View viewB;
        int i4;
        if (v() != 0) {
            RecyclerView recyclerView = this.f2123b;
            if (recyclerView == null || (viewB = recyclerView.B(view)) == null || ((ArrayList) this.f2122a.f564d).contains(viewB)) {
                viewB = null;
            }
            if (viewB != null) {
                c1();
                if (i3 != 1) {
                    if (i3 != 2) {
                        if (i3 != 17) {
                            if (i3 != 33) {
                                if (i3 == 66 ? this.f976t == 0 : !(i3 != 130 || this.f976t != 1)) {
                                    i4 = 1;
                                }
                            } else if (this.f976t == 1) {
                                i4 = -1;
                            }
                            i4 = Integer.MIN_VALUE;
                        } else if (this.f976t == 0) {
                            i4 = -1;
                        } else {
                            i4 = Integer.MIN_VALUE;
                        }
                    } else if (this.f976t != 1 && U0()) {
                        i4 = -1;
                    } else {
                        i4 = 1;
                    }
                } else if (this.f976t != 1 && U0()) {
                    i4 = 1;
                } else {
                    i4 = -1;
                }
                if (i4 != Integer.MIN_VALUE) {
                    t1 t1Var = (t1) viewB.getLayoutParams();
                    t1Var.getClass();
                    w1 w1Var = t1Var.f2070e;
                    int iP0 = i4 == 1 ? P0() : O0();
                    f1(iP0, l1Var);
                    e1(i4);
                    e0 e0Var = this.f978v;
                    e0Var.f1857c = e0Var.f1858d + iP0;
                    e0Var.f1856b = (int) (this.f974r.l() * 0.33333334f);
                    e0Var.f1861h = true;
                    e0Var.f1855a = false;
                    J0(g1Var, e0Var, l1Var);
                    this.D = this.f980x;
                    View viewH = w1Var.h(iP0, i4);
                    if (viewH != null && viewH != viewB) {
                        return viewH;
                    }
                    if (X0(i4)) {
                        for (int i5 = this.f972p - 1; i5 >= 0; i5--) {
                            View viewH2 = this.f973q[i5].h(iP0, i4);
                            if (viewH2 != null && viewH2 != viewB) {
                                return viewH2;
                            }
                        }
                    } else {
                        for (int i6 = 0; i6 < this.f972p; i6++) {
                            View viewH3 = this.f973q[i6].h(iP0, i4);
                            if (viewH3 != null && viewH3 != viewB) {
                                return viewH3;
                            }
                        }
                    }
                    boolean z4 = (this.f979w ^ true) == (i4 == -1);
                    View viewQ = q(z4 ? w1Var.c() : w1Var.d());
                    if (viewQ != null && viewQ != viewB) {
                        return viewQ;
                    }
                    if (X0(i4)) {
                        for (int i7 = this.f972p - 1; i7 >= 0; i7--) {
                            if (i7 != w1Var.f2109e) {
                                View viewQ2 = q(z4 ? this.f973q[i7].c() : this.f973q[i7].d());
                                if (viewQ2 != null && viewQ2 != viewB) {
                                    return viewQ2;
                                }
                            }
                        }
                    } else {
                        for (int i8 = 0; i8 < this.f972p; i8++) {
                            View viewQ3 = q(z4 ? this.f973q[i8].c() : this.f973q[i8].d());
                            if (viewQ3 != null && viewQ3 != viewB) {
                                return viewQ3;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    public final boolean X0(int i3) {
        if (this.f976t == 0) {
            return (i3 == -1) != this.f980x;
        }
        return ((i3 == -1) == this.f980x) == U0();
    }

    @Override // e1.y0
    public final void Y(AccessibilityEvent accessibilityEvent) {
        super.Y(accessibilityEvent);
        if (v() > 0) {
            View viewL0 = L0(false);
            View viewK0 = K0(false);
            if (viewL0 == null || viewK0 == null) {
                return;
            }
            int iL = y0.L(viewL0);
            int iL2 = y0.L(viewK0);
            if (iL < iL2) {
                accessibilityEvent.setFromIndex(iL);
                accessibilityEvent.setToIndex(iL2);
            } else {
                accessibilityEvent.setFromIndex(iL2);
                accessibilityEvent.setToIndex(iL);
            }
        }
    }

    public final void Y0(int i3, l1 l1Var) {
        int iO0;
        int i4;
        if (i3 > 0) {
            iO0 = P0();
            i4 = 1;
        } else {
            iO0 = O0();
            i4 = -1;
        }
        e0 e0Var = this.f978v;
        e0Var.f1855a = true;
        f1(iO0, l1Var);
        e1(i4);
        e0Var.f1857c = iO0 + e0Var.f1858d;
        e0Var.f1856b = Math.abs(i3);
    }

    public final void Z0(g1 g1Var, e0 e0Var) {
        int iMin;
        if (!e0Var.f1855a || e0Var.f1862i) {
            return;
        }
        if (e0Var.f1856b == 0) {
            if (e0Var.f1859e == -1) {
                a1(g1Var, e0Var.f1860g);
                return;
            } else {
                b1(g1Var, e0Var.f);
                return;
            }
        }
        int i3 = 1;
        if (e0Var.f1859e == -1) {
            int i4 = e0Var.f;
            int i5 = this.f973q[0].i(i4);
            while (i3 < this.f972p) {
                int i6 = this.f973q[i3].i(i4);
                if (i6 > i5) {
                    i5 = i6;
                }
                i3++;
            }
            int i7 = i4 - i5;
            a1(g1Var, i7 < 0 ? e0Var.f1860g : e0Var.f1860g - Math.min(i7, e0Var.f1856b));
            return;
        }
        int i8 = e0Var.f1860g;
        int iG = this.f973q[0].g(i8);
        while (i3 < this.f972p) {
            int iG2 = this.f973q[i3].g(i8);
            if (iG2 < iG) {
                iG = iG2;
            }
            i3++;
        }
        int i9 = iG - e0Var.f1860g;
        if (i9 < 0) {
            iMin = e0Var.f;
        } else {
            iMin = Math.min(i9, e0Var.f1856b) + e0Var.f;
        }
        b1(g1Var, iMin);
    }

    /* JADX WARN: Code duplicated, block: B:6:0x000c  */
    @Override // e1.k1
    public final PointF a(int i3) {
        int i4 = -1;
        if (v() != 0) {
            if ((i3 < O0()) == this.f980x) {
                i4 = 1;
            }
        } else if (this.f980x) {
            i4 = 1;
        }
        PointF pointF = new PointF();
        if (i4 == 0) {
            return null;
        }
        if (this.f976t == 0) {
            pointF.x = i4;
            pointF.y = 0.0f;
            return pointF;
        }
        pointF.x = 0.0f;
        pointF.y = i4;
        return pointF;
    }

    public final void a1(g1 g1Var, int i3) {
        for (int iV = v() - 1; iV >= 0; iV--) {
            View viewU = u(iV);
            if (this.f974r.e(viewU) < i3 || this.f974r.n(viewU) < i3) {
                return;
            }
            t1 t1Var = (t1) viewU.getLayoutParams();
            t1Var.getClass();
            if (((ArrayList) t1Var.f2070e.f).size() == 1) {
                return;
            }
            w1 w1Var = t1Var.f2070e;
            ArrayList arrayList = (ArrayList) w1Var.f;
            int size = arrayList.size();
            View view = (View) arrayList.remove(size - 1);
            t1 t1Var2 = (t1) view.getLayoutParams();
            t1Var2.f2070e = null;
            if (t1Var2.f2155a.i() || t1Var2.f2155a.l()) {
                w1Var.f2108d -= ((StaggeredGridLayoutManager) w1Var.f2110g).f974r.c(view);
            }
            if (size == 1) {
                w1Var.f2106b = Integer.MIN_VALUE;
            }
            w1Var.f2107c = Integer.MIN_VALUE;
            p0(viewU, g1Var);
        }
    }

    public final void b1(g1 g1Var, int i3) {
        while (v() > 0) {
            View viewU = u(0);
            if (this.f974r.b(viewU) > i3 || this.f974r.m(viewU) > i3) {
                return;
            }
            t1 t1Var = (t1) viewU.getLayoutParams();
            t1Var.getClass();
            if (((ArrayList) t1Var.f2070e.f).size() == 1) {
                return;
            }
            w1 w1Var = t1Var.f2070e;
            ArrayList arrayList = (ArrayList) w1Var.f;
            View view = (View) arrayList.remove(0);
            t1 t1Var2 = (t1) view.getLayoutParams();
            t1Var2.f2070e = null;
            if (arrayList.size() == 0) {
                w1Var.f2107c = Integer.MIN_VALUE;
            }
            if (t1Var2.f2155a.i() || t1Var2.f2155a.l()) {
                w1Var.f2108d -= ((StaggeredGridLayoutManager) w1Var.f2110g).f974r.c(view);
            }
            w1Var.f2106b = Integer.MIN_VALUE;
            p0(viewU, g1Var);
        }
    }

    @Override // e1.y0
    public final void c(String str) {
        if (this.F == null) {
            super.c(str);
        }
    }

    @Override // e1.y0
    public final void c0(int i3, int i4) {
        S0(i3, i4, 1);
    }

    public final void c1() {
        if (this.f976t == 1 || !U0()) {
            this.f980x = this.f979w;
        } else {
            this.f980x = !this.f979w;
        }
    }

    @Override // e1.y0
    public final boolean d() {
        return this.f976t == 0;
    }

    @Override // e1.y0
    public final void d0() {
        this.B.h();
        s0();
    }

    public final int d1(int i3, g1 g1Var, l1 l1Var) {
        if (v() == 0 || i3 == 0) {
            return 0;
        }
        Y0(i3, l1Var);
        e0 e0Var = this.f978v;
        int iJ0 = J0(g1Var, e0Var, l1Var);
        if (e0Var.f1856b >= iJ0) {
            i3 = i3 < 0 ? -iJ0 : iJ0;
        }
        this.f974r.o(-i3);
        this.D = this.f980x;
        e0Var.f1856b = 0;
        Z0(g1Var, e0Var);
        return i3;
    }

    @Override // e1.y0
    public final boolean e() {
        return this.f976t == 1;
    }

    @Override // e1.y0
    public final void e0(int i3, int i4) {
        S0(i3, i4, 8);
    }

    public final void e1(int i3) {
        e0 e0Var = this.f978v;
        e0Var.f1859e = i3;
        e0Var.f1858d = this.f980x != (i3 == -1) ? -1 : 1;
    }

    @Override // e1.y0
    public final boolean f(z0 z0Var) {
        return z0Var instanceof t1;
    }

    @Override // e1.y0
    public final void f0(int i3, int i4) {
        S0(i3, i4, 2);
    }

    /* JADX WARN: Code duplicated, block: B:22:0x004c  */
    public final void f1(int i3, l1 l1Var) {
        int iL;
        int iL2;
        RecyclerView recyclerView;
        int i4;
        e0 e0Var = this.f978v;
        boolean z4 = false;
        e0Var.f1856b = 0;
        e0Var.f1857c = i3;
        j0 j0Var = this.f2126e;
        if (j0Var != null && j0Var.f1929e && (i4 = l1Var.f1965a) != -1) {
            if (this.f980x == (i4 < i3)) {
                iL = this.f974r.l();
            } else {
                iL2 = this.f974r.l();
                iL = 0;
            }
            recyclerView = this.f2123b;
            if (recyclerView == null && recyclerView.f932g) {
                e0Var.f = this.f974r.k() - iL2;
                e0Var.f1860g = this.f974r.g() + iL;
            } else {
                e0Var.f1860g = this.f974r.f() + iL;
                e0Var.f = -iL2;
            }
            e0Var.f1861h = false;
            e0Var.f1855a = true;
            if (this.f974r.i() == 0 && this.f974r.f() == 0) {
                z4 = true;
            }
            e0Var.f1862i = z4;
        }
        iL = 0;
        iL2 = 0;
        recyclerView = this.f2123b;
        if (recyclerView == null) {
            e0Var.f1860g = this.f974r.f() + iL;
            e0Var.f = -iL2;
        } else {
            e0Var.f1860g = this.f974r.f() + iL;
            e0Var.f = -iL2;
        }
        e0Var.f1861h = false;
        e0Var.f1855a = true;
        if (this.f974r.i() == 0) {
            z4 = true;
        }
        e0Var.f1862i = z4;
    }

    @Override // e1.y0
    public final void g0(int i3, int i4) {
        S0(i3, i4, 4);
    }

    public final void g1(w1 w1Var, int i3, int i4) {
        int i5 = w1Var.f2108d;
        int i6 = w1Var.f2109e;
        if (i3 != -1) {
            int i7 = w1Var.f2107c;
            if (i7 == Integer.MIN_VALUE) {
                w1Var.a();
                i7 = w1Var.f2107c;
            }
            if (i7 - i5 >= i4) {
                this.f981y.set(i6, false);
                return;
            }
            return;
        }
        int i8 = w1Var.f2106b;
        if (i8 == Integer.MIN_VALUE) {
            View view = (View) ((ArrayList) w1Var.f).get(0);
            t1 t1Var = (t1) view.getLayoutParams();
            w1Var.f2106b = ((StaggeredGridLayoutManager) w1Var.f2110g).f974r.e(view);
            t1Var.getClass();
            i8 = w1Var.f2106b;
        }
        if (i8 + i5 <= i4) {
            this.f981y.set(i6, false);
        }
    }

    @Override // e1.y0
    public final void h(int i3, int i4, l1 l1Var, u uVar) {
        e0 e0Var;
        int iG;
        int i5;
        if (this.f976t != 0) {
            i3 = i4;
        }
        if (v() == 0 || i3 == 0) {
            return;
        }
        Y0(i3, l1Var);
        int[] iArr = this.J;
        if (iArr == null || iArr.length < this.f972p) {
            this.J = new int[this.f972p];
        }
        int i6 = 0;
        int i7 = 0;
        while (true) {
            int i8 = this.f972p;
            e0Var = this.f978v;
            if (i6 >= i8) {
                break;
            }
            if (e0Var.f1858d == -1) {
                iG = e0Var.f;
                i5 = this.f973q[i6].i(iG);
            } else {
                iG = this.f973q[i6].g(e0Var.f1860g);
                i5 = e0Var.f1860g;
            }
            int i9 = iG - i5;
            if (i9 >= 0) {
                this.J[i7] = i9;
                i7++;
            }
            i6++;
        }
        Arrays.sort(this.J, 0, i7);
        for (int i10 = 0; i10 < i7; i10++) {
            int i11 = e0Var.f1857c;
            if (i11 < 0 || i11 >= l1Var.b()) {
                return;
            }
            uVar.a(e0Var.f1857c, this.J[i10]);
            e0Var.f1857c += e0Var.f1858d;
        }
    }

    @Override // e1.y0
    public final void h0(g1 g1Var, l1 l1Var) {
        W0(g1Var, l1Var, true);
    }

    @Override // e1.y0
    public final void i0(l1 l1Var) {
        this.f982z = -1;
        this.A = Integer.MIN_VALUE;
        this.F = null;
        this.H.a();
    }

    @Override // e1.y0
    public final int j(l1 l1Var) {
        if (v() == 0) {
            return 0;
        }
        boolean z4 = !this.I;
        return e1.q.a(l1Var, this.f974r, L0(z4), K0(z4), this, this.I);
    }

    @Override // e1.y0
    public final void j0(Parcelable parcelable) {
        if (parcelable instanceof v1) {
            v1 v1Var = (v1) parcelable;
            this.F = v1Var;
            if (this.f982z != -1) {
                v1Var.f2089a = -1;
                v1Var.f2090b = -1;
                v1Var.f2092d = null;
                v1Var.f2091c = 0;
                v1Var.f2093e = 0;
                v1Var.f = null;
                v1Var.f2094g = null;
            }
            s0();
        }
    }

    @Override // e1.y0
    public final int k(l1 l1Var) {
        return I0(l1Var);
    }

    @Override // e1.y0
    public final Parcelable k0() {
        int i3;
        int iK;
        int[] iArr;
        v1 v1Var = this.F;
        if (v1Var != null) {
            v1 v1Var2 = new v1();
            v1Var2.f2091c = v1Var.f2091c;
            v1Var2.f2089a = v1Var.f2089a;
            v1Var2.f2090b = v1Var.f2090b;
            v1Var2.f2092d = v1Var.f2092d;
            v1Var2.f2093e = v1Var.f2093e;
            v1Var2.f = v1Var.f;
            v1Var2.f2095h = v1Var.f2095h;
            v1Var2.f2096i = v1Var.f2096i;
            v1Var2.f2097j = v1Var.f2097j;
            v1Var2.f2094g = v1Var.f2094g;
            return v1Var2;
        }
        v1 v1Var3 = new v1();
        v1Var3.f2095h = this.f979w;
        v1Var3.f2096i = this.D;
        v1Var3.f2097j = this.E;
        q qVar = this.B;
        if (qVar == null || (iArr = (int[]) qVar.f551b) == null) {
            v1Var3.f2093e = 0;
        } else {
            v1Var3.f = iArr;
            v1Var3.f2093e = iArr.length;
            v1Var3.f2094g = (ArrayList) qVar.f552c;
        }
        if (v() <= 0) {
            v1Var3.f2089a = -1;
            v1Var3.f2090b = -1;
            v1Var3.f2091c = 0;
            return v1Var3;
        }
        v1Var3.f2089a = this.D ? P0() : O0();
        View viewK0 = this.f980x ? K0(true) : L0(true);
        v1Var3.f2090b = viewK0 != null ? y0.L(viewK0) : -1;
        int i4 = this.f972p;
        v1Var3.f2091c = i4;
        v1Var3.f2092d = new int[i4];
        for (int i5 = 0; i5 < this.f972p; i5++) {
            if (this.D) {
                i3 = this.f973q[i5].g(Integer.MIN_VALUE);
                if (i3 != Integer.MIN_VALUE) {
                    iK = this.f974r.g();
                    i3 -= iK;
                }
            } else {
                i3 = this.f973q[i5].i(Integer.MIN_VALUE);
                if (i3 != Integer.MIN_VALUE) {
                    iK = this.f974r.k();
                    i3 -= iK;
                }
            }
            v1Var3.f2092d[i5] = i3;
        }
        return v1Var3;
    }

    @Override // e1.y0
    public final int l(l1 l1Var) {
        if (v() == 0) {
            return 0;
        }
        boolean z4 = !this.I;
        return e1.q.c(l1Var, this.f974r, L0(z4), K0(z4), this, this.I);
    }

    @Override // e1.y0
    public final void l0(int i3) {
        if (i3 == 0) {
            H0();
        }
    }

    @Override // e1.y0
    public final int m(l1 l1Var) {
        if (v() == 0) {
            return 0;
        }
        boolean z4 = !this.I;
        return e1.q.a(l1Var, this.f974r, L0(z4), K0(z4), this, this.I);
    }

    @Override // e1.y0
    public final int n(l1 l1Var) {
        return I0(l1Var);
    }

    @Override // e1.y0
    public final int o(l1 l1Var) {
        if (v() == 0) {
            return 0;
        }
        boolean z4 = !this.I;
        return e1.q.c(l1Var, this.f974r, L0(z4), K0(z4), this, this.I);
    }

    @Override // e1.y0
    public final z0 r() {
        return this.f976t == 0 ? new t1(-2, -1) : new t1(-1, -2);
    }

    @Override // e1.y0
    public final z0 s(Context context, AttributeSet attributeSet) {
        return new t1(context, attributeSet);
    }

    @Override // e1.y0
    public final z0 t(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new t1((ViewGroup.MarginLayoutParams) layoutParams) : new t1(layoutParams);
    }

    @Override // e1.y0
    public final int t0(int i3, g1 g1Var, l1 l1Var) {
        return d1(i3, g1Var, l1Var);
    }

    @Override // e1.y0
    public final void u0(int i3) {
        v1 v1Var = this.F;
        if (v1Var != null && v1Var.f2089a != i3) {
            v1Var.f2092d = null;
            v1Var.f2091c = 0;
            v1Var.f2089a = -1;
            v1Var.f2090b = -1;
        }
        this.f982z = i3;
        this.A = Integer.MIN_VALUE;
        s0();
    }

    @Override // e1.y0
    public final int v0(int i3, g1 g1Var, l1 l1Var) {
        return d1(i3, g1Var, l1Var);
    }

    @Override // e1.y0
    public final void y0(Rect rect, int i3, int i4) {
        int iG;
        int iG2;
        int iJ = J() + I();
        int iH = H() + K();
        int i5 = this.f976t;
        int i6 = this.f972p;
        if (i5 == 1) {
            int iHeight = rect.height() + iH;
            RecyclerView recyclerView = this.f2123b;
            WeakHashMap weakHashMap = h0.f3558a;
            iG2 = y0.g(i4, iHeight, recyclerView.getMinimumHeight());
            iG = y0.g(i3, (this.f977u * i6) + iJ, this.f2123b.getMinimumWidth());
        } else {
            int iWidth = rect.width() + iJ;
            RecyclerView recyclerView2 = this.f2123b;
            WeakHashMap weakHashMap2 = h0.f3558a;
            iG = y0.g(i3, iWidth, recyclerView2.getMinimumWidth());
            iG2 = y0.g(i4, (this.f977u * i6) + iH, this.f2123b.getMinimumHeight());
        }
        this.f2123b.setMeasuredDimension(iG, iG2);
    }
}
