package androidx.recyclerview.widget;

import android.R;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import androidx.emoji2.text.h;
import androidx.emoji2.text.q;
import androidx.emoji2.text.u;
import androidx.viewpager2.adapter.c;
import com.mod.menu.ModConfig;
import e1.a;
import e1.a0;
import e1.a1;
import e1.b;
import e1.b1;
import e1.c1;
import e1.d;
import e1.d1;
import e1.e1;
import e1.f1;
import e1.g1;
import e1.h1;
import e1.i1;
import e1.j0;
import e1.k;
import e1.k1;
import e1.l0;
import e1.l1;
import e1.m0;
import e1.m1;
import e1.n0;
import e1.n1;
import e1.o0;
import e1.o1;
import e1.q1;
import e1.r0;
import e1.s0;
import e1.t;
import e1.t0;
import e1.u0;
import e1.v0;
import e1.w;
import e1.y0;
import e1.y1;
import e1.z0;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Objects;
import java.util.WeakHashMap;
import o0.b0;
import o0.h0;
import o0.i0;
import o0.j;
import o0.z;
import q.g;
import q.i;
import top.niunaijun.blackbox.core.system.JarConfig;
import top.niunaijun.blackbox.utils.FileUtils;

/* JADX INFO: loaded from: classes.dex */
public class RecyclerView extends ViewGroup {
    public static final boolean A0;
    public static final boolean B0;
    public static final boolean C0;
    public static final Class[] D0;
    public static final a0 E0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public static final int[] f920z0 = {R.attr.nestedScrollingEnabled};
    public final AccessibilityManager A;
    public ArrayList B;
    public boolean C;
    public boolean D;
    public int E;
    public int F;
    public s0 G;
    public EdgeEffect H;
    public EdgeEffect I;
    public EdgeEffect J;
    public EdgeEffect K;
    public u0 L;
    public int M;
    public int N;
    public VelocityTracker O;
    public int P;
    public int Q;
    public int R;
    public int S;
    public int T;
    public b1 U;
    public final int V;
    public final int W;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f921a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public final float f922a0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g1 f923b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public final float f924b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public i1 f925c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public boolean f926c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final b f927d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public final n1 f928d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final u f929e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public w f930e0;
    public final q f;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public final e1.u f931f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f932g;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public final l1 f933g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final m0 f934h;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public d1 f935h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Rect f936i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public ArrayList f937i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Rect f938j;
    public boolean j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final RectF f939k;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public boolean f940k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public o0 f941l;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public final n0 f942l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public y0 f943m;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public boolean f944m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final ArrayList f945n;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public q1 f946n0;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final ArrayList f947o;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public final int[] f948o0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final ArrayList f949p;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public j f950p0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public c1 f951q;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public final int[] f952q0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f953r;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final int[] f954r0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f955s;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final int[] f956s0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f957t;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final ArrayList f958t0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f959u;

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    public final m0 f960u0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f961v;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public boolean f962v0;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f963w;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public int f964w0;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f965x;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public int f966x0;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f967y;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public final n0 f968y0;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f969z;

    static {
        A0 = Build.VERSION.SDK_INT >= 23;
        B0 = true;
        C0 = true;
        Class cls = Integer.TYPE;
        D0 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        E0 = new a0(2);
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, top.niunaijun.blackbox.R.attr.recyclerViewStyle);
    }

    public static RecyclerView E(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            RecyclerView recyclerViewE = E(viewGroup.getChildAt(i3));
            if (recyclerViewE != null) {
                return recyclerViewE;
            }
        }
        return null;
    }

    public static o1 J(View view) {
        if (view == null) {
            return null;
        }
        return ((z0) view.getLayoutParams()).f2155a;
    }

    private j getScrollingChildHelper() {
        if (this.f950p0 == null) {
            this.f950p0 = new j(this);
        }
        return this.f950p0;
    }

    public static void j(o1 o1Var) {
        WeakReference weakReference = o1Var.f2004b;
        if (weakReference != null) {
            View view = (View) weakReference.get();
            while (view != null) {
                if (view == o1Var.f2003a) {
                    return;
                }
                Object parent = view.getParent();
                view = parent instanceof View ? (View) parent : null;
            }
            o1Var.f2004b = null;
        }
    }

    public final void A(l1 l1Var) {
        if (getScrollState() != 2) {
            l1Var.getClass();
            return;
        }
        OverScroller overScroller = this.f928d0.f1991c;
        overScroller.getFinalX();
        overScroller.getCurrX();
        l1Var.getClass();
        overScroller.getFinalY();
        overScroller.getCurrY();
    }

    public final View B(View view) {
        ViewParent parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = parent;
            parent = view.getParent();
        }
        if (parent == this) {
            return view;
        }
        return null;
    }

    public final boolean C(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        ArrayList arrayList = this.f949p;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            c1 c1Var = (c1) arrayList.get(i3);
            if (c1Var.d(motionEvent) && action != 3) {
                this.f951q = c1Var;
                return true;
            }
        }
        return false;
    }

    public final void D(int[] iArr) {
        int iM = this.f929e.m();
        if (iM == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i3 = Integer.MAX_VALUE;
        int i4 = Integer.MIN_VALUE;
        for (int i5 = 0; i5 < iM; i5++) {
            o1 o1VarJ = J(this.f929e.l(i5));
            if (!o1VarJ.p()) {
                int iC = o1VarJ.c();
                if (iC < i3) {
                    i3 = iC;
                }
                if (iC > i4) {
                    i4 = iC;
                }
            }
        }
        iArr[0] = i3;
        iArr[1] = i4;
    }

    public final o1 F(int i3) {
        o1 o1Var = null;
        if (this.C) {
            return null;
        }
        int iT = this.f929e.t();
        for (int i4 = 0; i4 < iT; i4++) {
            o1 o1VarJ = J(this.f929e.s(i4));
            if (o1VarJ != null && !o1VarJ.i() && G(o1VarJ) == i3) {
                if (!((ArrayList) this.f929e.f564d).contains(o1VarJ.f2003a)) {
                    return o1VarJ;
                }
                o1Var = o1VarJ;
            }
        }
        return o1Var;
    }

    public final int G(o1 o1Var) {
        if ((o1Var.f2011j & 524) == 0 && o1Var.f()) {
            int i3 = o1Var.f2005c;
            ArrayList arrayList = (ArrayList) this.f927d.f1813c;
            int size = arrayList.size();
            for (int i4 = 0; i4 < size; i4++) {
                a aVar = (a) arrayList.get(i4);
                int i5 = aVar.f1807a;
                if (i5 != 1) {
                    if (i5 == 2) {
                        int i6 = aVar.f1808b;
                        if (i6 <= i3) {
                            int i7 = aVar.f1809c;
                            if (i6 + i7 <= i3) {
                                i3 -= i7;
                            }
                        } else {
                            continue;
                        }
                    } else if (i5 == 8) {
                        int i8 = aVar.f1808b;
                        if (i8 == i3) {
                            i3 = aVar.f1809c;
                        } else {
                            if (i8 < i3) {
                                i3--;
                            }
                            if (aVar.f1809c <= i3) {
                                i3++;
                            }
                        }
                    }
                } else if (aVar.f1808b <= i3) {
                    i3 += aVar.f1809c;
                }
            }
            return i3;
        }
        return -1;
    }

    public final long H(o1 o1Var) {
        return this.f941l.f2000b ? o1Var.f2007e : o1Var.f2005c;
    }

    public final o1 I(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return J(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    public final Rect K(View view) {
        z0 z0Var = (z0) view.getLayoutParams();
        boolean z4 = z0Var.f2157c;
        Rect rect = z0Var.f2156b;
        if (!z4 || (this.f933g0.f1970g && (z0Var.f2155a.l() || z0Var.f2155a.g()))) {
            return rect;
        }
        rect.set(0, 0, 0, 0);
        ArrayList arrayList = this.f947o;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            Rect rect2 = this.f936i;
            rect2.set(0, 0, 0, 0);
            ((v0) arrayList.get(i3)).f(rect2, view);
            rect.left += rect2.left;
            rect.top += rect2.top;
            rect.right += rect2.right;
            rect.bottom += rect2.bottom;
        }
        z0Var.f2157c = false;
        return rect;
    }

    public final boolean L() {
        return !this.f957t || this.C || this.f927d.j();
    }

    public final boolean M() {
        return this.E > 0;
    }

    public final void N(int i3) {
        if (this.f943m == null) {
            return;
        }
        setScrollState(2);
        this.f943m.u0(i3);
        awakenScrollBars();
    }

    public final void O() {
        int iT = this.f929e.t();
        for (int i3 = 0; i3 < iT; i3++) {
            ((z0) this.f929e.s(i3).getLayoutParams()).f2157c = true;
        }
        ArrayList arrayList = this.f923b.f1890c;
        int size = arrayList.size();
        for (int i4 = 0; i4 < size; i4++) {
            z0 z0Var = (z0) ((o1) arrayList.get(i4)).f2003a.getLayoutParams();
            if (z0Var != null) {
                z0Var.f2157c = true;
            }
        }
    }

    public final void P(int i3, int i4, boolean z4) {
        int i5 = i3 + i4;
        int iT = this.f929e.t();
        for (int i6 = 0; i6 < iT; i6++) {
            o1 o1VarJ = J(this.f929e.s(i6));
            if (o1VarJ != null && !o1VarJ.p()) {
                int i7 = o1VarJ.f2005c;
                l1 l1Var = this.f933g0;
                if (i7 >= i5) {
                    o1VarJ.m(-i4, z4);
                    l1Var.f = true;
                } else if (i7 >= i3) {
                    o1VarJ.a(8);
                    o1VarJ.m(-i4, z4);
                    o1VarJ.f2005c = i3 - 1;
                    l1Var.f = true;
                }
            }
        }
        g1 g1Var = this.f923b;
        ArrayList arrayList = g1Var.f1890c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            o1 o1Var = (o1) arrayList.get(size);
            if (o1Var != null) {
                int i8 = o1Var.f2005c;
                if (i8 >= i5) {
                    o1Var.m(-i4, z4);
                } else if (i8 >= i3) {
                    o1Var.a(8);
                    g1Var.f(size);
                }
            }
        }
        requestLayout();
    }

    public final void Q() {
        this.E++;
    }

    public final void R(boolean z4) {
        int i3;
        AccessibilityManager accessibilityManager;
        int i4 = this.E - 1;
        this.E = i4;
        if (i4 < 1) {
            this.E = 0;
            if (z4) {
                int i5 = this.f967y;
                this.f967y = 0;
                if (i5 != 0 && (accessibilityManager = this.A) != null && accessibilityManager.isEnabled()) {
                    AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain();
                    accessibilityEventObtain.setEventType(FileUtils.FileMode.MODE_ISUID);
                    accessibilityEventObtain.setContentChangeTypes(i5);
                    sendAccessibilityEventUnchecked(accessibilityEventObtain);
                }
                ArrayList arrayList = this.f958t0;
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    o1 o1Var = (o1) arrayList.get(size);
                    if (o1Var.f2003a.getParent() == this && !o1Var.p() && (i3 = o1Var.f2018q) != -1) {
                        View view = o1Var.f2003a;
                        WeakHashMap weakHashMap = h0.f3558a;
                        view.setImportantForAccessibility(i3);
                        o1Var.f2018q = -1;
                    }
                }
                arrayList.clear();
            }
        }
    }

    public final void S(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.N) {
            int i3 = actionIndex == 0 ? 1 : 0;
            this.N = motionEvent.getPointerId(i3);
            int x3 = (int) (motionEvent.getX(i3) + 0.5f);
            this.R = x3;
            this.P = x3;
            int y4 = (int) (motionEvent.getY(i3) + 0.5f);
            this.S = y4;
            this.Q = y4;
        }
    }

    public final void T() {
        if (this.f944m0 || !this.f953r) {
            return;
        }
        WeakHashMap weakHashMap = h0.f3558a;
        postOnAnimation(this.f960u0);
        this.f944m0 = true;
    }

    public final void U() {
        boolean z4;
        boolean z5 = false;
        if (this.C) {
            b bVar = this.f927d;
            bVar.q((ArrayList) bVar.f1813c);
            bVar.q((ArrayList) bVar.f1814d);
            bVar.f1811a = 0;
            if (this.D) {
                this.f943m.d0();
            }
        }
        if (this.L == null || !this.f943m.G0()) {
            this.f927d.d();
        } else {
            this.f927d.p();
        }
        boolean z6 = this.j0 || this.f940k0;
        boolean z7 = this.f957t && this.L != null && ((z4 = this.C) || z6 || this.f943m.f) && (!z4 || this.f941l.f2000b);
        l1 l1Var = this.f933g0;
        l1Var.f1973j = z7;
        if (z7 && z6 && !this.C && this.L != null && this.f943m.G0()) {
            z5 = true;
        }
        l1Var.f1974k = z5;
    }

    public final void V(boolean z4) {
        this.D = z4 | this.D;
        this.C = true;
        int iT = this.f929e.t();
        for (int i3 = 0; i3 < iT; i3++) {
            o1 o1VarJ = J(this.f929e.s(i3));
            if (o1VarJ != null && !o1VarJ.p()) {
                o1VarJ.a(6);
            }
        }
        O();
        g1 g1Var = this.f923b;
        ArrayList arrayList = g1Var.f1890c;
        int size = arrayList.size();
        for (int i4 = 0; i4 < size; i4++) {
            o1 o1Var = (o1) arrayList.get(i4);
            if (o1Var != null) {
                o1Var.a(6);
                o1Var.a(1024);
            }
        }
        o0 o0Var = g1Var.f1894h.f941l;
        if (o0Var == null || !o0Var.f2000b) {
            g1Var.e();
        }
    }

    public final void W(o1 o1Var, t0 t0Var) {
        o1Var.f2011j &= -8193;
        boolean z4 = this.f933g0.f1971h;
        q qVar = this.f;
        if (z4 && o1Var.l() && !o1Var.i() && !o1Var.p()) {
            ((g) qVar.f552c).h(H(o1Var), o1Var);
        }
        i iVar = (i) qVar.f551b;
        y1 y1VarA = (y1) iVar.get(o1Var);
        if (y1VarA == null) {
            y1VarA = y1.a();
            iVar.put(o1Var, y1VarA);
        }
        y1VarA.f2138b = t0Var;
        y1VarA.f2137a |= 4;
    }

    public final void X(v0 v0Var) {
        y0 y0Var = this.f943m;
        if (y0Var != null) {
            y0Var.c("Cannot remove item decoration during a scroll  or layout");
        }
        ArrayList arrayList = this.f947o;
        arrayList.remove(v0Var);
        if (arrayList.isEmpty()) {
            setWillNotDraw(getOverScrollMode() == 2);
        }
        O();
        requestLayout();
    }

    public final void Y(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        int width = view3.getWidth();
        int height = view3.getHeight();
        Rect rect = this.f936i;
        rect.set(0, 0, width, height);
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof z0) {
            z0 z0Var = (z0) layoutParams;
            if (!z0Var.f2157c) {
                Rect rect2 = z0Var.f2156b;
                rect.left -= rect2.left;
                rect.right += rect2.right;
                rect.top -= rect2.top;
                rect.bottom += rect2.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, rect);
            offsetRectIntoDescendantCoords(view, rect);
        }
        this.f943m.r0(this, view, this.f936i, !this.f957t, view2 == null);
    }

    public final void Z() {
        VelocityTracker velocityTracker = this.O;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        boolean zIsFinished = false;
        g0(0);
        EdgeEffect edgeEffect = this.H;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            zIsFinished = this.H.isFinished();
        }
        EdgeEffect edgeEffect2 = this.I;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            zIsFinished |= this.I.isFinished();
        }
        EdgeEffect edgeEffect3 = this.J;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            zIsFinished |= this.J.isFinished();
        }
        EdgeEffect edgeEffect4 = this.K;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            zIsFinished |= this.K.isFinished();
        }
        if (zIsFinished) {
            WeakHashMap weakHashMap = h0.f3558a;
            postInvalidateOnAnimation();
        }
    }

    /* JADX WARN: Code duplicated, block: B:31:0x00c8  */
    /* JADX WARN: Code duplicated, block: B:33:0x00df  */
    /* JADX WARN: Code duplicated, block: B:35:0x00e3  */
    /* JADX WARN: Code duplicated, block: B:36:0x00fa A[DONT_INVERT, PHI: r7
  0x00fa: PHI (r7v10 boolean) = (r7v8 boolean), (r7v11 boolean) binds: [B:34:0x00e1, B:32:0x00dd] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:37:0x00fc  */
    /* JADX WARN: Code duplicated, block: B:41:0x0104  */
    public final boolean a0(int i3, int i4, MotionEvent motionEvent, int i5) {
        int i6;
        int i7;
        int i8;
        int i9;
        boolean z4;
        boolean z5;
        m();
        o0 o0Var = this.f941l;
        int[] iArr = this.f956s0;
        if (o0Var != null) {
            iArr[0] = 0;
            iArr[1] = 0;
            b0(i3, i4, iArr);
            i6 = iArr[0];
            i7 = iArr[1];
            i8 = i3 - i6;
            i9 = i4 - i7;
        } else {
            i6 = 0;
            i7 = 0;
            i8 = 0;
            i9 = 0;
        }
        if (!this.f947o.isEmpty()) {
            invalidate();
        }
        iArr[0] = 0;
        iArr[1] = 0;
        t(i6, i7, i8, i9, this.f952q0, i5, iArr);
        int i10 = iArr[0];
        int i11 = i8 - i10;
        int i12 = iArr[1];
        int i13 = i9 - i12;
        boolean z6 = (i10 == 0 && i12 == 0) ? false : true;
        int i14 = this.R;
        int[] iArr2 = this.f952q0;
        int i15 = iArr2[0];
        this.R = i14 - i15;
        int i16 = this.S;
        int i17 = iArr2[1];
        this.S = i16 - i17;
        int[] iArr3 = this.f954r0;
        iArr3[0] = iArr3[0] + i15;
        iArr3[1] = iArr3[1] + i17;
        if (getOverScrollMode() != 2) {
            if (motionEvent == null || (motionEvent.getSource() & 8194) == 8194) {
                z4 = true;
            } else {
                float x3 = motionEvent.getX();
                float f = i11;
                float y4 = motionEvent.getY();
                float f4 = i13;
                if (f < 0.0f) {
                    w();
                    z4 = true;
                    r0.b.a(this.H, (-f) / getWidth(), 1.0f - (y4 / getHeight()));
                } else {
                    z4 = true;
                    if (f > 0.0f) {
                        x();
                        r0.b.a(this.J, f / getWidth(), y4 / getHeight());
                    } else {
                        z5 = false;
                    }
                    if (f4 < 0.0f) {
                        y();
                        r0.b.a(this.I, (-f4) / getHeight(), x3 / getWidth());
                    } else if (f4 > 0.0f) {
                        v();
                        r0.b.a(this.K, f4 / getHeight(), 1.0f - (x3 / getWidth()));
                    } else if (z5 || f != 0.0f || f4 != 0.0f) {
                        WeakHashMap weakHashMap = h0.f3558a;
                        postInvalidateOnAnimation();
                    }
                    z5 = true;
                    if (z5) {
                        WeakHashMap weakHashMap2 = h0.f3558a;
                        postInvalidateOnAnimation();
                    } else {
                        WeakHashMap weakHashMap3 = h0.f3558a;
                        postInvalidateOnAnimation();
                    }
                }
                z5 = true;
                if (f4 < 0.0f) {
                    y();
                    r0.b.a(this.I, (-f4) / getHeight(), x3 / getWidth());
                } else if (f4 > 0.0f) {
                    v();
                    r0.b.a(this.K, f4 / getHeight(), 1.0f - (x3 / getWidth()));
                } else if (z5) {
                    WeakHashMap weakHashMap4 = h0.f3558a;
                    postInvalidateOnAnimation();
                } else {
                    WeakHashMap weakHashMap5 = h0.f3558a;
                    postInvalidateOnAnimation();
                }
                z5 = true;
                if (z5) {
                    WeakHashMap weakHashMap6 = h0.f3558a;
                    postInvalidateOnAnimation();
                } else {
                    WeakHashMap weakHashMap7 = h0.f3558a;
                    postInvalidateOnAnimation();
                }
            }
            l(i3, i4);
        } else {
            z4 = true;
        }
        if (i6 != 0 || i7 != 0) {
            u(i6, i7);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        if (!z6 && i6 == 0 && i7 == 0) {
            return false;
        }
        return z4;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i3, int i4) {
        y0 y0Var = this.f943m;
        if (y0Var != null) {
            y0Var.getClass();
        }
        super.addFocusables(arrayList, i3, i4);
    }

    public final void b0(int i3, int i4, int[] iArr) {
        o1 o1Var;
        e0();
        Q();
        int i5 = k0.j.f2785a;
        Trace.beginSection("RV Scroll");
        l1 l1Var = this.f933g0;
        A(l1Var);
        g1 g1Var = this.f923b;
        int iT0 = i3 != 0 ? this.f943m.t0(i3, g1Var, l1Var) : 0;
        int iV0 = i4 != 0 ? this.f943m.v0(i4, g1Var, l1Var) : 0;
        Trace.endSection();
        u uVar = this.f929e;
        int iM = uVar.m();
        for (int i6 = 0; i6 < iM; i6++) {
            View viewL = uVar.l(i6);
            o1 o1VarI = I(viewL);
            if (o1VarI != null && (o1Var = o1VarI.f2010i) != null) {
                View view = o1Var.f2003a;
                int left = viewL.getLeft();
                int top2 = viewL.getTop();
                if (left != view.getLeft() || top2 != view.getTop()) {
                    view.layout(left, top2, view.getWidth() + left, view.getHeight() + top2);
                }
            }
        }
        R(true);
        f0(false);
        if (iArr != null) {
            iArr[0] = iT0;
            iArr[1] = iV0;
        }
    }

    public final void c0(int i3) {
        j0 j0Var;
        if (this.f963w) {
            return;
        }
        setScrollState(0);
        n1 n1Var = this.f928d0;
        n1Var.f1994g.removeCallbacks(n1Var);
        n1Var.f1991c.abortAnimation();
        y0 y0Var = this.f943m;
        if (y0Var != null && (j0Var = y0Var.f2126e) != null) {
            j0Var.i();
        }
        y0 y0Var2 = this.f943m;
        if (y0Var2 == null) {
            return;
        }
        y0Var2.u0(i3);
        awakenScrollBars();
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof z0) && this.f943m.f((z0) layoutParams);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        y0 y0Var = this.f943m;
        if (y0Var != null && y0Var.d()) {
            return this.f943m.j(this.f933g0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        y0 y0Var = this.f943m;
        if (y0Var != null && y0Var.d()) {
            return this.f943m.k(this.f933g0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        y0 y0Var = this.f943m;
        if (y0Var != null && y0Var.d()) {
            return this.f943m.l(this.f933g0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        y0 y0Var = this.f943m;
        if (y0Var != null && y0Var.e()) {
            return this.f943m.m(this.f933g0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        y0 y0Var = this.f943m;
        if (y0Var != null && y0Var.e()) {
            return this.f943m.n(this.f933g0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        y0 y0Var = this.f943m;
        if (y0Var != null && y0Var.e()) {
            return this.f943m.o(this.f933g0);
        }
        return 0;
    }

    public final void d0(int i3, int i4, boolean z4) {
        y0 y0Var = this.f943m;
        if (y0Var == null || this.f963w) {
            return;
        }
        if (!y0Var.d()) {
            i3 = 0;
        }
        if (!this.f943m.e()) {
            i4 = 0;
        }
        if (i3 == 0 && i4 == 0) {
            return;
        }
        if (z4) {
            int i5 = i3 != 0 ? 1 : 0;
            if (i4 != 0) {
                i5 |= 2;
            }
            getScrollingChildHelper().g(i5, 1);
        }
        this.f928d0.b(i3, i4, Integer.MIN_VALUE, null);
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f4, boolean z4) {
        return getScrollingChildHelper().a(f, f4, z4);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f4) {
        return getScrollingChildHelper().b(f, f4);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i3, int i4, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i3, i4, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i3, int i4, int i5, int i6, int[] iArr) {
        return getScrollingChildHelper().d(i3, i4, i5, i6, iArr, 0, null);
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        boolean z4;
        super.draw(canvas);
        ArrayList arrayList = this.f947o;
        int size = arrayList.size();
        boolean z5 = false;
        for (int i3 = 0; i3 < size; i3++) {
            ((v0) arrayList.get(i3)).h(canvas, this);
        }
        EdgeEffect edgeEffect = this.H;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z4 = false;
        } else {
            int iSave = canvas.save();
            int paddingBottom = this.f932g ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, 0.0f);
            EdgeEffect edgeEffect2 = this.H;
            z4 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect3 = this.I;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int iSave2 = canvas.save();
            if (this.f932g) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.I;
            z4 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(iSave2);
        }
        EdgeEffect edgeEffect5 = this.J;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int iSave3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.f932g ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(paddingTop, -width);
            EdgeEffect edgeEffect6 = this.J;
            z4 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(iSave3);
        }
        EdgeEffect edgeEffect7 = this.K;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int iSave4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.f932g) {
                canvas.translate(getPaddingRight() + (-getWidth()), getPaddingBottom() + (-getHeight()));
            } else {
                canvas.translate(-getWidth(), -getHeight());
            }
            EdgeEffect edgeEffect8 = this.K;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z5 = true;
            }
            z4 |= z5;
            canvas.restoreToCount(iSave4);
        }
        if ((z4 || this.L == null || arrayList.size() <= 0 || !this.L.f()) ? z4 : true) {
            WeakHashMap weakHashMap = h0.f3558a;
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j4) {
        return super.drawChild(canvas, view, j4);
    }

    public final void e0() {
        int i3 = this.f959u + 1;
        this.f959u = i3;
        if (i3 != 1 || this.f963w) {
            return;
        }
        this.f961v = false;
    }

    public final void f(o1 o1Var) {
        View view = o1Var.f2003a;
        boolean z4 = view.getParent() == this;
        this.f923b.k(I(view));
        if (o1Var.k()) {
            this.f929e.g(view, -1, view.getLayoutParams(), true);
            return;
        }
        if (!z4) {
            this.f929e.f(view, -1, true);
            return;
        }
        u uVar = this.f929e;
        int iIndexOfChild = ((n0) uVar.f562b).f1988a.indexOfChild(view);
        if (iIndexOfChild >= 0) {
            ((d) uVar.f563c).h(iIndexOfChild);
            uVar.v(view);
        } else {
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        }
    }

    public final void f0(boolean z4) {
        if (this.f959u < 1) {
            this.f959u = 1;
        }
        if (!z4 && !this.f963w) {
            this.f961v = false;
        }
        if (this.f959u == 1) {
            if (z4 && this.f961v && !this.f963w && this.f943m != null && this.f941l != null) {
                p();
            }
            if (!this.f963w) {
                this.f961v = false;
            }
        }
        this.f959u--;
    }

    /* JADX WARN: Code duplicated, block: B:136:0x019b A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:137:0x019c  */
    /* JADX WARN: Code duplicated, block: B:24:0x004d  */
    /* JADX WARN: Code duplicated, block: B:72:0x00d9  */
    @Override // android.view.ViewGroup, android.view.ViewParent
    public final View focusSearch(View view, int i3) {
        View viewX;
        int i4;
        byte b4;
        boolean z4;
        this.f943m.getClass();
        boolean z5 = true;
        boolean z6 = (this.f941l == null || this.f943m == null || M() || this.f963w) ? false : true;
        FocusFinder focusFinder = FocusFinder.getInstance();
        l1 l1Var = this.f933g0;
        g1 g1Var = this.f923b;
        if (z6 && (i3 == 2 || i3 == 1)) {
            if (this.f943m.e()) {
                if (focusFinder.findNextFocus(this, view, i3 == 2 ? 130 : 33) == null) {
                    z4 = true;
                } else {
                    z4 = false;
                }
            } else {
                z4 = false;
            }
            if (!z4 && this.f943m.d()) {
                z4 = focusFinder.findNextFocus(this, view, (this.f943m.G() == 1) ^ (i3 == 2) ? 66 : 17) == null;
            }
            if (z4) {
                m();
                if (B(view) != null) {
                    e0();
                    this.f943m.X(view, i3, g1Var, l1Var);
                    f0(false);
                }
                return null;
            }
            viewX = focusFinder.findNextFocus(this, view, i3);
            if (viewX == null) {
            }
            if (viewX != null) {
                z5 = false;
            } else {
                z5 = false;
            }
            if (z5) {
                return viewX;
            }
            return super.focusSearch(view, i3);
        }
        View viewFindNextFocus = focusFinder.findNextFocus(this, view, i3);
        if (viewFindNextFocus == null && z6) {
            m();
            if (B(view) != null) {
                e0();
                viewX = this.f943m.X(view, i3, g1Var, l1Var);
                f0(false);
            }
            return null;
        }
        viewX = viewFindNextFocus;
        if (viewX == null && !viewX.hasFocusable()) {
            if (getFocusedChild() == null) {
                return super.focusSearch(view, i3);
            }
            Y(viewX, null);
            return view;
        }
        if (viewX != null || viewX == this || viewX == view || B(viewX) == null) {
            z5 = false;
        } else if (view != null && B(view) != null) {
            int width = view.getWidth();
            int height = view.getHeight();
            Rect rect = this.f936i;
            rect.set(0, 0, width, height);
            int width2 = viewX.getWidth();
            int height2 = viewX.getHeight();
            Rect rect2 = this.f938j;
            rect2.set(0, 0, width2, height2);
            offsetDescendantRectToMyCoords(view, rect);
            offsetDescendantRectToMyCoords(viewX, rect2);
            int i5 = this.f943m.G() == 1 ? -1 : 1;
            int i6 = rect.left;
            int i7 = rect2.left;
            if ((i6 < i7 || rect.right <= i7) && rect.right < rect2.right) {
                i4 = 1;
            } else {
                int i8 = rect.right;
                int i9 = rect2.right;
                i4 = ((i8 > i9 || i6 >= i9) && i6 > i7) ? -1 : 0;
            }
            int i10 = rect.top;
            int i11 = rect2.top;
            if ((i10 < i11 || rect.bottom <= i11) && rect.bottom < rect2.bottom) {
                b4 = 1;
            } else {
                int i12 = rect.bottom;
                int i13 = rect2.bottom;
                b4 = ((i12 > i13 || i10 >= i13) && i10 > i11) ? (byte) -1 : (byte) 0;
            }
            if (i3 != 1) {
                if (i3 != 2) {
                    if (i3 != 17) {
                        if (i3 != 33) {
                            if (i3 != 66) {
                                if (i3 != 130) {
                                    throw new IllegalArgumentException("Invalid direction: " + i3 + z());
                                }
                                if (b4 <= 0) {
                                    z5 = false;
                                }
                            } else if (i4 <= 0) {
                                z5 = false;
                            }
                        } else if (b4 >= 0) {
                            z5 = false;
                        }
                    } else if (i4 >= 0) {
                        z5 = false;
                    }
                } else if (b4 <= 0 && (b4 != 0 || i4 * i5 <= 0)) {
                    z5 = false;
                }
            } else if (b4 >= 0 && (b4 != 0 || i4 * i5 >= 0)) {
                z5 = false;
            }
        }
        if (z5) {
            return viewX;
        }
        return super.focusSearch(view, i3);
    }

    public final void g(v0 v0Var) {
        y0 y0Var = this.f943m;
        if (y0Var != null) {
            y0Var.c("Cannot add item decoration during a scroll  or layout");
        }
        ArrayList arrayList = this.f947o;
        if (arrayList.isEmpty()) {
            setWillNotDraw(false);
        }
        arrayList.add(v0Var);
        O();
        requestLayout();
    }

    public final void g0(int i3) {
        getScrollingChildHelper().h(i3);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        y0 y0Var = this.f943m;
        if (y0Var != null) {
            return y0Var.r();
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + z());
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        y0 y0Var = this.f943m;
        if (y0Var != null) {
            return y0Var.s(getContext(), attributeSet);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + z());
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public o0 getAdapter() {
        return this.f941l;
    }

    @Override // android.view.View
    public int getBaseline() {
        y0 y0Var = this.f943m;
        if (y0Var == null) {
            return super.getBaseline();
        }
        y0Var.getClass();
        return -1;
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i3, int i4) {
        return super.getChildDrawingOrder(i3, i4);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.f932g;
    }

    public q1 getCompatAccessibilityDelegate() {
        return this.f946n0;
    }

    public s0 getEdgeEffectFactory() {
        return this.G;
    }

    public u0 getItemAnimator() {
        return this.L;
    }

    public int getItemDecorationCount() {
        return this.f947o.size();
    }

    public y0 getLayoutManager() {
        return this.f943m;
    }

    public int getMaxFlingVelocity() {
        return this.W;
    }

    public int getMinFlingVelocity() {
        return this.V;
    }

    public long getNanoTime() {
        if (C0) {
            return System.nanoTime();
        }
        return 0L;
    }

    public b1 getOnFlingListener() {
        return this.U;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.f926c0;
    }

    public f1 getRecycledViewPool() {
        return this.f923b.c();
    }

    public int getScrollState() {
        return this.M;
    }

    public final void h(d1 d1Var) {
        if (this.f937i0 == null) {
            this.f937i0 = new ArrayList();
        }
        this.f937i0.add(d1Var);
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().f(0);
    }

    public final void i(String str) {
        if (M()) {
            if (str != null) {
                throw new IllegalStateException(str);
            }
            throw new IllegalStateException("Cannot call this method while RecyclerView is computing a layout or scrolling" + z());
        }
        if (this.F > 0) {
            new IllegalStateException(ModConfig.PREFIX + z());
        }
    }

    @Override // android.view.View
    public final boolean isAttachedToWindow() {
        return this.f953r;
    }

    @Override // android.view.ViewGroup
    public final boolean isLayoutSuppressed() {
        return this.f963w;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().f3568d;
    }

    public final void k() {
        int iT = this.f929e.t();
        for (int i3 = 0; i3 < iT; i3++) {
            o1 o1VarJ = J(this.f929e.s(i3));
            if (!o1VarJ.p()) {
                o1VarJ.f2006d = -1;
                o1VarJ.f2008g = -1;
            }
        }
        g1 g1Var = this.f923b;
        ArrayList arrayList = g1Var.f1888a;
        ArrayList arrayList2 = g1Var.f1890c;
        int size = arrayList2.size();
        for (int i4 = 0; i4 < size; i4++) {
            o1 o1Var = (o1) arrayList2.get(i4);
            o1Var.f2006d = -1;
            o1Var.f2008g = -1;
        }
        int size2 = arrayList.size();
        for (int i5 = 0; i5 < size2; i5++) {
            o1 o1Var2 = (o1) arrayList.get(i5);
            o1Var2.f2006d = -1;
            o1Var2.f2008g = -1;
        }
        ArrayList arrayList3 = g1Var.f1889b;
        if (arrayList3 != null) {
            int size3 = arrayList3.size();
            for (int i6 = 0; i6 < size3; i6++) {
                o1 o1Var3 = (o1) g1Var.f1889b.get(i6);
                o1Var3.f2006d = -1;
                o1Var3.f2008g = -1;
            }
        }
    }

    public final void l(int i3, int i4) {
        boolean zIsFinished;
        EdgeEffect edgeEffect = this.H;
        if (edgeEffect == null || edgeEffect.isFinished() || i3 <= 0) {
            zIsFinished = false;
        } else {
            this.H.onRelease();
            zIsFinished = this.H.isFinished();
        }
        EdgeEffect edgeEffect2 = this.J;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i3 < 0) {
            this.J.onRelease();
            zIsFinished |= this.J.isFinished();
        }
        EdgeEffect edgeEffect3 = this.I;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i4 > 0) {
            this.I.onRelease();
            zIsFinished |= this.I.isFinished();
        }
        EdgeEffect edgeEffect4 = this.K;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i4 < 0) {
            this.K.onRelease();
            zIsFinished |= this.K.isFinished();
        }
        if (zIsFinished) {
            WeakHashMap weakHashMap = h0.f3558a;
            postInvalidateOnAnimation();
        }
    }

    public final void m() {
        if (!this.f957t || this.C) {
            int i3 = k0.j.f2785a;
            Trace.beginSection("RV FullInvalidate");
            p();
            Trace.endSection();
            return;
        }
        b bVar = this.f927d;
        if (bVar.j()) {
            int i4 = bVar.f1811a;
            if ((i4 & 4) == 0 || (i4 & 11) != 0) {
                if (bVar.j()) {
                    int i5 = k0.j.f2785a;
                    Trace.beginSection("RV FullInvalidate");
                    p();
                    Trace.endSection();
                    return;
                }
                return;
            }
            int i6 = k0.j.f2785a;
            Trace.beginSection("RV PartialInvalidate");
            e0();
            Q();
            bVar.p();
            if (!this.f961v) {
                u uVar = this.f929e;
                int iM = uVar.m();
                for (int i7 = 0; i7 < iM; i7++) {
                    o1 o1VarJ = J(uVar.l(i7));
                    if (o1VarJ != null && !o1VarJ.p() && o1VarJ.l()) {
                        p();
                    }
                }
                bVar.c();
            }
            f0(true);
            R(true);
            Trace.endSection();
        }
    }

    public final void n(int i3, int i4) {
        int paddingRight = getPaddingRight() + getPaddingLeft();
        WeakHashMap weakHashMap = h0.f3558a;
        setMeasuredDimension(y0.g(i3, paddingRight, getMinimumWidth()), y0.g(i4, getPaddingBottom() + getPaddingTop(), getMinimumHeight()));
    }

    public final void o(View view) {
        o1 o1VarJ = J(view);
        o0 o0Var = this.f941l;
        if (o0Var != null && o1VarJ != null) {
            o0Var.k(o1VarJ);
        }
        ArrayList arrayList = this.B;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((a1) this.B.get(size)).b(view);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0061  */
    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        float refreshRate;
        super.onAttachedToWindow();
        this.E = 0;
        this.f953r = true;
        this.f957t = this.f957t && !isLayoutRequested();
        y0 y0Var = this.f943m;
        if (y0Var != null) {
            y0Var.f2127g = true;
            y0Var.V(this);
        }
        this.f944m0 = false;
        if (C0) {
            ThreadLocal threadLocal = w.f2098e;
            w wVar = (w) threadLocal.get();
            this.f930e0 = wVar;
            if (wVar == null) {
                w wVar2 = new w();
                wVar2.f2099a = new ArrayList();
                wVar2.f2102d = new ArrayList();
                this.f930e0 = wVar2;
                WeakHashMap weakHashMap = h0.f3558a;
                Display display = getDisplay();
                if (isInEditMode() || display == null) {
                    refreshRate = 60.0f;
                } else {
                    refreshRate = display.getRefreshRate();
                    if (refreshRate < 30.0f) {
                        refreshRate = 60.0f;
                    }
                }
                w wVar3 = this.f930e0;
                wVar3.f2101c = (long) (1.0E9f / refreshRate);
                threadLocal.set(wVar3);
            }
            this.f930e0.f2099a.add(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        w wVar;
        j0 j0Var;
        super.onDetachedFromWindow();
        u0 u0Var = this.L;
        if (u0Var != null) {
            u0Var.e();
        }
        setScrollState(0);
        n1 n1Var = this.f928d0;
        n1Var.f1994g.removeCallbacks(n1Var);
        n1Var.f1991c.abortAnimation();
        y0 y0Var = this.f943m;
        if (y0Var != null && (j0Var = y0Var.f2126e) != null) {
            j0Var.i();
        }
        this.f953r = false;
        y0 y0Var2 = this.f943m;
        if (y0Var2 != null) {
            y0Var2.f2127g = false;
            y0Var2.W(this);
        }
        this.f958t0.clear();
        removeCallbacks(this.f960u0);
        this.f.getClass();
        while (y1.f2136d.a() != null) {
        }
        if (!C0 || (wVar = this.f930e0) == null) {
            return;
        }
        wVar.f2099a.remove(this);
        this.f930e0 = null;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ArrayList arrayList = this.f947o;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            ((v0) arrayList.get(i3)).g(canvas, this);
        }
    }

    /* JADX WARN: Code duplicated, block: B:28:0x0064  */
    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f;
        float axisValue;
        if (this.f943m != null && !this.f963w && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                f = this.f943m.e() ? -motionEvent.getAxisValue(9) : 0.0f;
                axisValue = this.f943m.d() ? motionEvent.getAxisValue(10) : 0.0f;
            } else if ((motionEvent.getSource() & 4194304) != 0) {
                float axisValue2 = motionEvent.getAxisValue(26);
                if (this.f943m.e()) {
                    f = -axisValue2;
                } else if (this.f943m.d()) {
                    axisValue = axisValue2;
                    f = 0.0f;
                } else {
                    f = 0.0f;
                }
            } else {
                f = 0.0f;
            }
            if (f != 0.0f || axisValue != 0.0f) {
                int i3 = (int) (axisValue * this.f922a0);
                int i4 = (int) (f * this.f924b0);
                y0 y0Var = this.f943m;
                if (y0Var != null && !this.f963w) {
                    int[] iArr = this.f956s0;
                    iArr[0] = 0;
                    iArr[1] = 0;
                    boolean zD = y0Var.d();
                    boolean zE = this.f943m.e();
                    getScrollingChildHelper().g(zE ? (zD ? 1 : 0) | 2 : zD ? 1 : 0, 1);
                    if (s(zD ? i3 : 0, zE ? i4 : 0, 1, this.f956s0, this.f952q0)) {
                        i3 -= iArr[0];
                        i4 -= iArr[1];
                    }
                    a0(zD ? i3 : 0, zE ? i4 : 0, motionEvent, 1);
                    w wVar = this.f930e0;
                    if (wVar != null && (i3 != 0 || i4 != 0)) {
                        wVar.a(this, i3, i4);
                    }
                    g0(1);
                }
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z4;
        if (!this.f963w) {
            this.f951q = null;
            if (C(motionEvent)) {
                Z();
                setScrollState(0);
                return true;
            }
            y0 y0Var = this.f943m;
            if (y0Var != null) {
                boolean zD = y0Var.d();
                boolean zE = this.f943m.e();
                if (this.O == null) {
                    this.O = VelocityTracker.obtain();
                }
                this.O.addMovement(motionEvent);
                int actionMasked = motionEvent.getActionMasked();
                int actionIndex = motionEvent.getActionIndex();
                if (actionMasked == 0) {
                    if (this.f965x) {
                        this.f965x = false;
                    }
                    this.N = motionEvent.getPointerId(0);
                    int x3 = (int) (motionEvent.getX() + 0.5f);
                    this.R = x3;
                    this.P = x3;
                    int y4 = (int) (motionEvent.getY() + 0.5f);
                    this.S = y4;
                    this.Q = y4;
                    if (this.M == 2) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                        setScrollState(1);
                        g0(1);
                    }
                    int[] iArr = this.f954r0;
                    iArr[1] = 0;
                    iArr[0] = 0;
                    int i3 = zD;
                    if (zE) {
                        i3 = (zD ? 1 : 0) | 2;
                    }
                    getScrollingChildHelper().g(i3, 0);
                } else if (actionMasked == 1) {
                    this.O.clear();
                    g0(0);
                } else if (actionMasked == 2) {
                    int iFindPointerIndex = motionEvent.findPointerIndex(this.N);
                    if (iFindPointerIndex >= 0) {
                        int x4 = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
                        int y5 = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
                        if (this.M != 1) {
                            int i4 = x4 - this.P;
                            int i5 = y5 - this.Q;
                            if (!zD || Math.abs(i4) <= this.T) {
                                z4 = false;
                            } else {
                                this.R = x4;
                                z4 = true;
                            }
                            if (zE && Math.abs(i5) > this.T) {
                                this.S = y5;
                                z4 = true;
                            }
                            if (z4) {
                                setScrollState(1);
                            }
                        }
                    }
                } else if (actionMasked == 3) {
                    Z();
                    setScrollState(0);
                } else if (actionMasked == 5) {
                    this.N = motionEvent.getPointerId(actionIndex);
                    int x5 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                    this.R = x5;
                    this.P = x5;
                    int y6 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                    this.S = y6;
                    this.Q = y6;
                } else if (actionMasked == 6) {
                    S(motionEvent);
                }
                if (this.M == 1) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        int i7 = k0.j.f2785a;
        Trace.beginSection("RV OnLayout");
        p();
        Trace.endSection();
        this.f957t = true;
    }

    @Override // android.view.View
    public final void onMeasure(int i3, int i4) {
        y0 y0Var = this.f943m;
        if (y0Var == null) {
            n(i3, i4);
            return;
        }
        boolean zP = y0Var.P();
        boolean z4 = false;
        l1 l1Var = this.f933g0;
        if (zP) {
            int mode = View.MeasureSpec.getMode(i3);
            int mode2 = View.MeasureSpec.getMode(i4);
            this.f943m.f2123b.n(i3, i4);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z4 = true;
            }
            this.f962v0 = z4;
            if (z4 || this.f941l == null) {
                return;
            }
            if (l1Var.f1968d == 1) {
                q();
            }
            this.f943m.x0(i3, i4);
            l1Var.f1972i = true;
            r();
            this.f943m.z0(i3, i4);
            if (this.f943m.C0()) {
                this.f943m.x0(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                l1Var.f1972i = true;
                r();
                this.f943m.z0(i3, i4);
            }
            this.f964w0 = getMeasuredWidth();
            this.f966x0 = getMeasuredHeight();
            return;
        }
        if (this.f955s) {
            this.f943m.f2123b.n(i3, i4);
            return;
        }
        if (this.f969z) {
            e0();
            Q();
            U();
            R(true);
            if (l1Var.f1974k) {
                l1Var.f1970g = true;
            } else {
                this.f927d.d();
                l1Var.f1970g = false;
            }
            this.f969z = false;
            f0(false);
        } else if (l1Var.f1974k) {
            setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
        o0 o0Var = this.f941l;
        if (o0Var != null) {
            l1Var.f1969e = o0Var.a();
        } else {
            l1Var.f1969e = 0;
        }
        e0();
        this.f943m.f2123b.n(i3, i4);
        f0(false);
        l1Var.f1970g = false;
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i3, Rect rect) {
        if (M()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i3, rect);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof i1)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        i1 i1Var = (i1) parcelable;
        this.f925c = i1Var;
        super.onRestoreInstanceState(i1Var.f3827a);
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        i1 i1Var = new i1(super.onSaveInstanceState());
        i1 i1Var2 = this.f925c;
        if (i1Var2 != null) {
            i1Var.f1919c = i1Var2.f1919c;
            return i1Var;
        }
        y0 y0Var = this.f943m;
        if (y0Var != null) {
            i1Var.f1919c = y0Var.k0();
            return i1Var;
        }
        i1Var.f1919c = null;
        return i1Var;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i3, int i4, int i5, int i6) {
        super.onSizeChanged(i3, i4, i5, i6);
        if (i3 == i5 && i4 == i6) {
            return;
        }
        this.K = null;
        this.I = null;
        this.J = null;
        this.H = null;
    }

    /* JADX WARN: Code duplicated, block: B:103:0x01a2  */
    /* JADX WARN: Code duplicated, block: B:151:0x0235  */
    /* JADX WARN: Code duplicated, block: B:191:0x02be  */
    /* JADX WARN: Code duplicated, block: B:213:0x02f9  */
    /* JADX WARN: Code duplicated, block: B:215:0x02ff A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:216:0x0301  */
    /* JADX WARN: Code duplicated, block: B:217:0x0304  */
    /* JADX WARN: Code duplicated, block: B:220:0x0332  */
    /* JADX WARN: Code duplicated, block: B:55:0x00e4 A[PHI: r1
  0x00e4: PHI (r1v66 int) = (r1v51 int), (r1v70 int) binds: [B:49:0x00cd, B:53:0x00e0] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v4, types: [e1.l0, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r11v3, types: [e1.y0] */
    /* JADX WARN: Type inference failed for: r1v17, types: [o0.j] */
    /* JADX WARN: Type inference failed for: r1v22, types: [o0.j] */
    /* JADX WARN: Type inference failed for: r22v0 */
    /* JADX WARN: Type inference failed for: r22v1 */
    /* JADX WARN: Type inference failed for: r22v3 */
    /* JADX WARN: Type inference failed for: r22v5 */
    /* JADX WARN: Type inference failed for: r22v6 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v5, types: [int] */
    /* JADX WARN: Type inference failed for: r9v1, types: [int] */
    /* JADX WARN: Type inference failed for: r9v7 */
    /* JADX WARN: Type inference failed for: r9v8 */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean zC;
        ?? r9;
        ?? r22;
        ?? r6;
        n1 n1Var;
        RecyclerView recyclerView;
        Interpolator interpolator;
        a0 a0Var;
        int minFlingVelocity;
        boolean z4;
        h hVarF;
        int iL;
        PointF pointFA;
        int i3;
        int i4;
        boolean z5;
        if (this.f963w || this.f965x) {
            return false;
        }
        c1 c1Var = this.f951q;
        if (c1Var == null) {
            zC = motionEvent.getAction() == 0 ? false : C(motionEvent);
        } else {
            c1Var.a(motionEvent);
            int action = motionEvent.getAction();
            if (action == 3 || action == 1) {
                this.f951q = null;
            }
            zC = true;
        }
        if (zC) {
            Z();
            setScrollState(0);
            return true;
        }
        y0 y0Var = this.f943m;
        if (y0Var == null) {
            return false;
        }
        boolean zD = y0Var.d();
        boolean zE = this.f943m.e();
        if (this.O == null) {
            this.O = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        int[] iArr = this.f954r0;
        if (actionMasked == 0) {
            iArr[1] = 0;
            iArr[0] = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        motionEventObtain.offsetLocation(iArr[0], iArr[1]);
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                this.O.addMovement(motionEventObtain);
                VelocityTracker velocityTracker = this.O;
                int i5 = this.W;
                velocityTracker.computeCurrentVelocity(1000, i5);
                float f = zD ? -this.O.getXVelocity(this.N) : 0.0f;
                float f4 = zE ? -this.O.getYVelocity(this.N) : 0.0f;
                if (f == 0.0f && f4 == 0.0f) {
                    setScrollState(0);
                } else {
                    int i6 = (int) f;
                    int i7 = (int) f4;
                    y0 y0Var2 = this.f943m;
                    if (y0Var2 == null || this.f963w) {
                        setScrollState(0);
                    } else {
                        boolean zD2 = y0Var2.d();
                        boolean zE2 = this.f943m.e();
                        int i8 = this.V;
                        if (!zD2 || Math.abs(i6) < i8) {
                            i6 = 0;
                        }
                        if (!zE2 || Math.abs(i7) < i8) {
                            i7 = 0;
                        }
                        if (i6 == 0 && i7 == 0) {
                            setScrollState(0);
                        } else {
                            float f5 = i6;
                            float f6 = i7;
                            if (dispatchNestedPreFling(f5, f6)) {
                                setScrollState(0);
                            } else {
                                boolean z6 = zD2 || zE2;
                                dispatchNestedFling(f5, f6, z6);
                                b1 b1Var = this.U;
                                if (b1Var != null) {
                                    ?? r10 = (l0) b1Var;
                                    ?? layoutManager = r10.f1961a.getLayoutManager();
                                    if (layoutManager == 0 || r10.f1961a.getAdapter() == null || ((Math.abs(i7) <= (minFlingVelocity = r10.f1961a.getMinFlingVelocity()) && Math.abs(i6) <= minFlingVelocity) || !((z4 = layoutManager instanceof k1)))) {
                                        r22 = zD2;
                                        if (z6) {
                                            if (zE2) {
                                                r6 = r22 | 2;
                                            } else {
                                                r6 = r22;
                                            }
                                            getScrollingChildHelper().g(r6, 1);
                                            int i9 = -i5;
                                            int iMax = Math.max(i9, Math.min(i6, i5));
                                            int iMax2 = Math.max(i9, Math.min(i7, i5));
                                            n1Var = this.f928d0;
                                            recyclerView = n1Var.f1994g;
                                            recyclerView.setScrollState(2);
                                            n1Var.f1990b = 0;
                                            n1Var.f1989a = 0;
                                            interpolator = n1Var.f1992d;
                                            a0Var = E0;
                                            if (interpolator != a0Var) {
                                                n1Var.f1992d = a0Var;
                                                n1Var.f1991c = new OverScroller(recyclerView.getContext(), a0Var);
                                            }
                                            n1Var.f1991c.fling(0, 0, iMax, iMax2, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
                                            n1Var.a();
                                        } else {
                                            setScrollState(0);
                                        }
                                    } else {
                                        d2.b bVar = !z4 ? null : new d2.b(r10, r10.f1961a.getContext(), 1);
                                        if (bVar == null) {
                                            r22 = zD2;
                                        } else {
                                            int iF = layoutManager.F();
                                            if (iF != 0) {
                                                if (layoutManager.e()) {
                                                    hVarF = r10.g(layoutManager);
                                                } else {
                                                    hVarF = layoutManager.d() ? r10.f(layoutManager) : null;
                                                }
                                                if (hVarF == null) {
                                                    r22 = zD2;
                                                    iL = -1;
                                                    i3 = -1;
                                                } else {
                                                    int iV = layoutManager.v();
                                                    int i10 = Integer.MAX_VALUE;
                                                    int i11 = Integer.MIN_VALUE;
                                                    int i12 = 0;
                                                    View view = null;
                                                    View view2 = null;
                                                    while (i12 < iV) {
                                                        boolean z7 = zD2;
                                                        View viewU = layoutManager.u(i12);
                                                        if (viewU == null) {
                                                            i4 = i12;
                                                        } else {
                                                            i4 = i12;
                                                            int iC = l0.c(viewU, hVarF);
                                                            if (iC <= 0 && iC > i11) {
                                                                view2 = viewU;
                                                                i11 = iC;
                                                            }
                                                            if (iC >= 0 && iC < i10) {
                                                                view = viewU;
                                                                i10 = iC;
                                                            }
                                                        }
                                                        i12 = i4 + 1;
                                                        zD2 = z7;
                                                    }
                                                    r22 = zD2;
                                                    boolean z8 = !layoutManager.d() ? i7 <= 0 : i6 <= 0;
                                                    if (z8 && view != null) {
                                                        iL = y0.L(view);
                                                    } else if (z8 || view2 == null) {
                                                        if (z8) {
                                                            view = view2;
                                                        }
                                                        if (view == null) {
                                                            iL = -1;
                                                        } else {
                                                            iL = ((z4 && (pointFA = ((k1) layoutManager).a(layoutManager.F() + (-1))) != null && ((pointFA.x > 0.0f ? 1 : (pointFA.x == 0.0f ? 0 : -1)) < 0 || (pointFA.y > 0.0f ? 1 : (pointFA.y == 0.0f ? 0 : -1)) < 0)) == z8 ? -1 : 1) + y0.L(view);
                                                            if (iL < 0 || iL >= iF) {
                                                                iL = -1;
                                                            }
                                                        }
                                                    } else {
                                                        iL = y0.L(view2);
                                                    }
                                                    i3 = -1;
                                                }
                                            } else {
                                                r22 = zD2;
                                                iL = -1;
                                                i3 = -1;
                                            }
                                            if (iL != i3) {
                                                bVar.f1925a = iL;
                                                layoutManager.F0(bVar);
                                            }
                                        }
                                        if (z6) {
                                            if (zE2) {
                                                r6 = r22 | 2;
                                            } else {
                                                r6 = r22;
                                            }
                                            getScrollingChildHelper().g(r6, 1);
                                            int i13 = -i5;
                                            int iMax3 = Math.max(i13, Math.min(i6, i5));
                                            int iMax4 = Math.max(i13, Math.min(i7, i5));
                                            n1Var = this.f928d0;
                                            recyclerView = n1Var.f1994g;
                                            recyclerView.setScrollState(2);
                                            n1Var.f1990b = 0;
                                            n1Var.f1989a = 0;
                                            interpolator = n1Var.f1992d;
                                            a0Var = E0;
                                            if (interpolator != a0Var) {
                                                n1Var.f1992d = a0Var;
                                                n1Var.f1991c = new OverScroller(recyclerView.getContext(), a0Var);
                                            }
                                            n1Var.f1991c.fling(0, 0, iMax3, iMax4, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
                                            n1Var.a();
                                        } else {
                                            setScrollState(0);
                                        }
                                    }
                                } else {
                                    r22 = zD2;
                                    if (z6) {
                                        if (zE2) {
                                            r6 = r22 | 2;
                                        } else {
                                            r6 = r22;
                                        }
                                        getScrollingChildHelper().g(r6, 1);
                                        int i14 = -i5;
                                        int iMax5 = Math.max(i14, Math.min(i6, i5));
                                        int iMax6 = Math.max(i14, Math.min(i7, i5));
                                        n1Var = this.f928d0;
                                        recyclerView = n1Var.f1994g;
                                        recyclerView.setScrollState(2);
                                        n1Var.f1990b = 0;
                                        n1Var.f1989a = 0;
                                        interpolator = n1Var.f1992d;
                                        a0Var = E0;
                                        if (interpolator != a0Var) {
                                            n1Var.f1992d = a0Var;
                                            n1Var.f1991c = new OverScroller(recyclerView.getContext(), a0Var);
                                        }
                                        n1Var.f1991c.fling(0, 0, iMax5, iMax6, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
                                        n1Var.a();
                                    } else {
                                        setScrollState(0);
                                    }
                                }
                            }
                        }
                    }
                }
                Z();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.N);
                if (iFindPointerIndex < 0) {
                    return false;
                }
                int x3 = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
                int y4 = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
                int iMax7 = this.R - x3;
                int iMax8 = this.S - y4;
                if (this.M != 1) {
                    if (zD) {
                        iMax7 = iMax7 > 0 ? Math.max(0, iMax7 - this.T) : Math.min(0, iMax7 + this.T);
                        if (iMax7 != 0) {
                            z5 = true;
                        } else {
                            z5 = false;
                        }
                    } else {
                        z5 = false;
                    }
                    if (zE) {
                        iMax8 = iMax8 > 0 ? Math.max(0, iMax8 - this.T) : Math.min(0, iMax8 + this.T);
                        if (iMax8 != 0) {
                            z5 = true;
                        }
                    }
                    if (z5) {
                        setScrollState(1);
                    }
                }
                int i15 = iMax7;
                int i16 = iMax8;
                if (this.M == 1) {
                    int[] iArr2 = this.f956s0;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    boolean zS = s(zD ? i15 : 0, zE ? i16 : 0, 0, iArr2, this.f952q0);
                    int[] iArr3 = this.f952q0;
                    if (zS) {
                        i15 -= iArr2[0];
                        i16 -= iArr2[1];
                        iArr[0] = iArr[0] + iArr3[0];
                        iArr[1] = iArr[1] + iArr3[1];
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    int i17 = i16;
                    this.R = x3 - iArr3[0];
                    this.S = y4 - iArr3[1];
                    if (a0(zD ? i15 : 0, zE ? i17 : 0, motionEvent, 0)) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    w wVar = this.f930e0;
                    if (wVar != null && (i15 != 0 || i17 != 0)) {
                        wVar.a(this, i15, i17);
                    }
                }
            } else if (actionMasked == 3) {
                Z();
                setScrollState(0);
            } else if (actionMasked == 5) {
                this.N = motionEvent.getPointerId(actionIndex);
                int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                this.R = x4;
                this.P = x4;
                int y5 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                this.S = y5;
                this.Q = y5;
            } else if (actionMasked == 6) {
                S(motionEvent);
            }
            motionEventObtain.recycle();
            return true;
        }
        this.N = motionEvent.getPointerId(0);
        int x5 = (int) (motionEvent.getX() + 0.5f);
        this.R = x5;
        this.P = x5;
        int y6 = (int) (motionEvent.getY() + 0.5f);
        this.S = y6;
        this.Q = y6;
        if (zE) {
            r9 = zD;
            r9 = (zD ? 1 : 0) | 2;
        }
        r9 = zD;
        getScrollingChildHelper().g(r9, 0);
        this.O.addMovement(motionEventObtain);
        motionEventObtain.recycle();
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:164:0x0329  */
    /* JADX WARN: Code duplicated, block: B:183:0x036f  */
    /* JADX WARN: Code duplicated, block: B:185:0x0372  */
    /* JADX WARN: Code duplicated, block: B:191:0x0389  */
    /* JADX WARN: Code duplicated, block: B:193:0x0391  */
    /* JADX WARN: Code duplicated, block: B:195:0x0395  */
    /* JADX WARN: Code duplicated, block: B:198:0x039d  */
    /* JADX WARN: Code duplicated, block: B:201:0x03a4  */
    /* JADX WARN: Code duplicated, block: B:204:0x03ae A[LOOP:4: B:197:0x039b->B:204:0x03ae, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:207:0x03bb  */
    /* JADX WARN: Code duplicated, block: B:210:0x03c2  */
    /* JADX WARN: Code duplicated, block: B:213:0x03cb A[LOOP:5: B:206:0x03b9->B:213:0x03cb, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:215:0x03d0  */
    /* JADX WARN: Code duplicated, block: B:244:0x03b1 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:245:0x03b1 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:246:0x03ac A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:247:0x03ce A[EDGE_INSN: B:247:0x03ce->B:214:0x03ce BREAK  A[LOOP:5: B:206:0x03b9->B:213:0x03cb], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:248:0x0387 A[SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v23 */
    /* JADX WARN: Type inference failed for: r2v24, types: [int] */
    /* JADX WARN: Type inference failed for: r2v27 */
    /* JADX WARN: Type inference failed for: r2v33 */
    /* JADX WARN: Type inference failed for: r2v34 */
    /* JADX WARN: Type inference failed for: r2v35 */
    /* JADX WARN: Type inference failed for: r2v36 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void p() {
        long j4;
        o1 o1Var;
        int i3;
        int iB;
        int i4;
        int iMin;
        o1 o1VarF;
        View view;
        o1 o1VarF2;
        View view2;
        int i5;
        View viewFindViewById;
        boolean z4;
        t0 t0Var;
        ?? r4;
        boolean zG;
        if (this.f941l == null || this.f943m == null) {
            return;
        }
        l1 l1Var = this.f933g0;
        boolean z5 = false;
        l1Var.f1972i = false;
        int i6 = 1;
        boolean z6 = this.f962v0 && !(this.f964w0 == getWidth() && this.f966x0 == getHeight());
        this.f964w0 = 0;
        this.f966x0 = 0;
        this.f962v0 = false;
        if (l1Var.f1968d == 1) {
            q();
            this.f943m.w0(this);
            r();
        } else {
            b bVar = this.f927d;
            if ((((ArrayList) bVar.f1814d).isEmpty() || ((ArrayList) bVar.f1813c).isEmpty()) && !z6 && this.f943m.f2134n == getWidth() && this.f943m.f2135o == getHeight()) {
                this.f943m.w0(this);
            } else {
                this.f943m.w0(this);
                r();
            }
        }
        l1Var.a(4);
        e0();
        Q();
        l1Var.f1968d = 1;
        boolean z7 = l1Var.f1973j;
        g1 g1Var = this.f923b;
        q qVar = this.f;
        if (z7) {
            int iM = this.f929e.m() - 1;
            while (iM >= 0) {
                o1 o1VarJ = J(this.f929e.l(iM));
                if (!o1VarJ.p()) {
                    long jH = H(o1VarJ);
                    this.L.getClass();
                    t0 t0Var2 = new t0();
                    t0Var2.a(o1VarJ);
                    g gVar = (g) qVar.f552c;
                    i iVar = (i) qVar.f551b;
                    o1 o1Var2 = (o1) gVar.d(jH);
                    if (o1Var2 == null || o1Var2.p()) {
                        qVar.e(o1VarJ, t0Var2);
                    } else {
                        y1 y1Var = (y1) iVar.get(o1Var2);
                        boolean z8 = (y1Var == null || (y1Var.f2137a & i6) == 0) ? false : true;
                        y1 y1Var2 = (y1) iVar.get(o1VarJ);
                        boolean z9 = (y1Var2 == null || (y1Var2.f2137a & i6) == 0) ? false : true;
                        if (z8 && o1Var2 == o1VarJ) {
                            qVar.e(o1VarJ, t0Var2);
                        } else {
                            t0 t0VarV = qVar.v(o1Var2, 4);
                            qVar.e(o1VarJ, t0Var2);
                            t0 t0VarV2 = qVar.v(o1VarJ, 8);
                            if (t0VarV == null) {
                                int iM2 = this.f929e.m();
                                for (int i7 = 0; i7 < iM2; i7++) {
                                    o1 o1VarJ2 = J(this.f929e.l(i7));
                                    if (o1VarJ2 != o1VarJ && H(o1VarJ2) == jH) {
                                        o0 o0Var = this.f941l;
                                        if (o0Var == null || !o0Var.f2000b) {
                                            throw new IllegalStateException("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:" + o1VarJ2 + " \n View Holder 2:" + o1VarJ + z());
                                        }
                                        throw new IllegalStateException("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:" + o1VarJ2 + " \n View Holder 2:" + o1VarJ + z());
                                    }
                                }
                                Objects.toString(o1Var2);
                                Objects.toString(o1VarJ);
                                z();
                            } else {
                                o1Var2.o(false);
                                if (z8) {
                                    f(o1Var2);
                                }
                                if (o1Var2 != o1VarJ) {
                                    if (z9) {
                                        f(o1VarJ);
                                    }
                                    o1Var2.f2009h = o1VarJ;
                                    f(o1Var2);
                                    g1Var.k(o1Var2);
                                    o1VarJ.o(false);
                                    o1VarJ.f2010i = o1Var2;
                                }
                                if (this.L.a(o1Var2, o1VarJ, t0VarV, t0VarV2)) {
                                    T();
                                }
                            }
                        }
                    }
                }
                iM--;
                i6 = 1;
            }
            i iVar2 = (i) qVar.f551b;
            int i8 = iVar2.f3742c - 1;
            while (i8 >= 0) {
                o1 o1Var3 = (o1) iVar2.f(i8);
                y1 y1Var3 = (y1) iVar2.g(i8);
                int i9 = y1Var3.f2137a;
                int i10 = i9 & 3;
                n0 n0Var = this.f968y0;
                if (i10 == 3) {
                    RecyclerView recyclerView = n0Var.f1988a;
                    recyclerView.f943m.p0(o1Var3.f2003a, recyclerView.f923b);
                    r4 = z5;
                } else if ((i9 & 1) != 0) {
                    t0 t0Var3 = y1Var3.f2138b;
                    if (t0Var3 == null) {
                        RecyclerView recyclerView2 = n0Var.f1988a;
                        recyclerView2.f943m.p0(o1Var3.f2003a, recyclerView2.f923b);
                        r4 = z5;
                    } else {
                        n0Var.g(o1Var3, t0Var3, y1Var3.f2139c);
                        r4 = z5;
                    }
                } else if ((i9 & 14) == 14) {
                    n0Var.f(o1Var3, y1Var3.f2138b, y1Var3.f2139c);
                    r4 = z5;
                } else {
                    if ((i9 & 12) == 12) {
                        t0 t0Var4 = y1Var3.f2138b;
                        t0 t0Var5 = y1Var3.f2139c;
                        n0Var.getClass();
                        o1Var3.o(z5);
                        RecyclerView recyclerView3 = n0Var.f1988a;
                        if (!recyclerView3.C) {
                            k kVar = (k) recyclerView3.L;
                            kVar.getClass();
                            int i11 = t0Var4.f2068a;
                            int i12 = t0Var5.f2068a;
                            if (i11 == i12 && t0Var4.f2069b == t0Var5.f2069b) {
                                kVar.c(o1Var3);
                                zG = false;
                            } else {
                                zG = kVar.g(o1Var3, i11, t0Var4.f2069b, i12, t0Var5.f2069b);
                            }
                            if (zG) {
                                recyclerView3.T();
                            }
                        } else if (recyclerView3.L.a(o1Var3, o1Var3, t0Var4, t0Var5)) {
                            recyclerView3.T();
                        }
                        r4 = 0;
                    } else {
                        if ((i9 & 4) != 0) {
                            t0Var = null;
                            n0Var.g(o1Var3, y1Var3.f2138b, null);
                        } else {
                            t0Var = null;
                            if ((i9 & 8) != 0) {
                                n0Var.f(o1Var3, y1Var3.f2138b, y1Var3.f2139c);
                            }
                        }
                        r4 = 0;
                    }
                    y1Var3.f2137a = r4;
                    y1Var3.f2138b = t0Var;
                    y1Var3.f2139c = t0Var;
                    y1.f2136d.c(y1Var3);
                    i8--;
                    z5 = false;
                }
                t0Var = null;
                y1Var3.f2137a = r4;
                y1Var3.f2138b = t0Var;
                y1Var3.f2139c = t0Var;
                y1.f2136d.c(y1Var3);
                i8--;
                z5 = false;
            }
        }
        View view3 = null;
        this.f943m.o0(g1Var);
        l1Var.f1966b = l1Var.f1969e;
        this.C = false;
        this.D = false;
        l1Var.f1973j = false;
        l1Var.f1974k = false;
        this.f943m.f = false;
        ArrayList arrayList = g1Var.f1889b;
        if (arrayList != null) {
            arrayList.clear();
        }
        y0 y0Var = this.f943m;
        if (y0Var.f2131k) {
            y0Var.f2130j = 0;
            y0Var.f2131k = false;
            g1Var.l();
        }
        this.f943m.i0(l1Var);
        R(true);
        f0(false);
        ((i) qVar.f551b).clear();
        ((g) qVar.f552c).b();
        int[] iArr = this.f948o0;
        int i13 = iArr[0];
        int i14 = iArr[1];
        D(iArr);
        if ((iArr[0] == i13 && iArr[1] == i14) ? false : true) {
            u(0, 0);
        }
        if (this.f926c0 && this.f941l != null && hasFocus() && getDescendantFocusability() != 393216 && (getDescendantFocusability() != 131072 || !isFocused())) {
            if (isFocused()) {
                j4 = l1Var.f1976m;
                if (j4 == -1) {
                    o1Var = null;
                } else {
                    o1Var = null;
                }
                if (o1Var != null) {
                    view = o1Var.f2003a;
                    if (!((ArrayList) this.f929e.f564d).contains(view)) {
                        if (this.f929e.m() > 0) {
                            int i15 = l1Var.f1975l;
                            if (i15 != -1) {
                            }
                            iB = l1Var.b();
                            i4 = i3;
                            while (true) {
                                if (i4 < iB) {
                                    o1VarF2 = F(i4);
                                    if (o1VarF2 != null) {
                                        view2 = o1VarF2.f2003a;
                                        if (view2.hasFocusable()) {
                                            view3 = view2;
                                        } else {
                                            i4++;
                                        }
                                    }
                                }
                                for (iMin = Math.min(iB, i3) - 1; iMin >= 0; iMin--) {
                                    o1VarF = F(iMin);
                                    if (o1VarF == null) {
                                        break;
                                        break;
                                    }
                                    view = o1VarF.f2003a;
                                    if (view.hasFocusable()) {
                                        view3 = view;
                                        break;
                                    }
                                }
                            }
                        }
                    } else if (this.f929e.m() > 0) {
                        int i16 = l1Var.f1975l;
                        if (i16 != -1) {
                        }
                        iB = l1Var.b();
                        i4 = i3;
                        while (true) {
                            if (i4 < iB) {
                                o1VarF2 = F(i4);
                                if (o1VarF2 != null) {
                                    view2 = o1VarF2.f2003a;
                                    if (view2.hasFocusable()) {
                                        view3 = view2;
                                    } else {
                                        i4++;
                                    }
                                }
                            }
                            while (iMin >= 0) {
                                o1VarF = F(iMin);
                                if (o1VarF == null) {
                                    break;
                                    break;
                                }
                                view = o1VarF.f2003a;
                                if (view.hasFocusable()) {
                                    view3 = view;
                                    break;
                                }
                            }
                        }
                    }
                } else if (this.f929e.m() > 0) {
                    int i17 = l1Var.f1975l;
                    if (i17 != -1) {
                    }
                    iB = l1Var.b();
                    i4 = i3;
                    while (true) {
                        if (i4 < iB) {
                            o1VarF2 = F(i4);
                            if (o1VarF2 != null) {
                                view2 = o1VarF2.f2003a;
                                if (view2.hasFocusable()) {
                                    view3 = view2;
                                } else {
                                    i4++;
                                }
                            }
                        }
                        while (iMin >= 0) {
                            o1VarF = F(iMin);
                            if (o1VarF == null) {
                                break;
                                break;
                            }
                            view = o1VarF.f2003a;
                            if (view.hasFocusable()) {
                                view3 = view;
                                break;
                            }
                        }
                    }
                }
                if (view3 != null) {
                    i5 = l1Var.f1977n;
                    if (i5 != -1) {
                        view3 = viewFindViewById;
                    }
                    view3.requestFocus();
                }
            } else if (((ArrayList) this.f929e.f564d).contains(getFocusedChild())) {
                j4 = l1Var.f1976m;
                if (j4 == -1 && (z4 = this.f941l.f2000b) && z4) {
                    int iT = this.f929e.t();
                    o1Var = null;
                    for (int i18 = 0; i18 < iT; i18++) {
                        o1 o1VarJ3 = J(this.f929e.s(i18));
                        if (o1VarJ3 != null && !o1VarJ3.i() && o1VarJ3.f2007e == j4) {
                            if (!((ArrayList) this.f929e.f564d).contains(o1VarJ3.f2003a)) {
                                o1Var = o1VarJ3;
                                break;
                            }
                            o1Var = o1VarJ3;
                        }
                    }
                } else {
                    o1Var = null;
                }
                if (o1Var != null) {
                    view = o1Var.f2003a;
                    if (!((ArrayList) this.f929e.f564d).contains(view) && view.hasFocusable()) {
                        view3 = view;
                        break;
                    }
                    if (this.f929e.m() > 0) {
                        int i19 = l1Var.f1975l;
                        i3 = i19 != -1 ? i19 : 0;
                        iB = l1Var.b();
                        i4 = i3;
                        while (true) {
                            if (i4 < iB) {
                                o1VarF2 = F(i4);
                                if (o1VarF2 != null) {
                                    view2 = o1VarF2.f2003a;
                                    if (view2.hasFocusable()) {
                                        view3 = view2;
                                    } else {
                                        i4++;
                                    }
                                }
                            }
                            while (iMin >= 0) {
                                o1VarF = F(iMin);
                                if (o1VarF == null) {
                                    break;
                                }
                                view = o1VarF.f2003a;
                                if (view.hasFocusable()) {
                                    view3 = view;
                                    break;
                                }
                            }
                        }
                    }
                } else if (this.f929e.m() > 0) {
                    int i110 = l1Var.f1975l;
                    if (i110 != -1) {
                    }
                    iB = l1Var.b();
                    i4 = i3;
                    while (true) {
                        if (i4 < iB) {
                            o1VarF2 = F(i4);
                            if (o1VarF2 != null) {
                                view2 = o1VarF2.f2003a;
                                if (view2.hasFocusable()) {
                                    view3 = view2;
                                } else {
                                    i4++;
                                }
                            }
                        }
                        while (iMin >= 0) {
                            o1VarF = F(iMin);
                            if (o1VarF == null) {
                                break;
                                break;
                            }
                            view = o1VarF.f2003a;
                            if (view.hasFocusable()) {
                                view3 = view;
                                break;
                            }
                        }
                    }
                }
                if (view3 != null) {
                    i5 = l1Var.f1977n;
                    if (i5 != -1 && (viewFindViewById = view3.findViewById(i5)) != null && viewFindViewById.isFocusable()) {
                        view3 = viewFindViewById;
                    }
                    view3.requestFocus();
                }
            }
        }
        l1Var.f1976m = -1L;
        l1Var.f1975l = -1;
        l1Var.f1977n = -1;
    }

    /* JADX WARN: Code duplicated, block: B:24:0x0066  */
    public final void q() {
        int iG;
        y1 y1Var;
        View viewB;
        l1 l1Var = this.f933g0;
        l1Var.a(1);
        A(l1Var);
        l1Var.f1972i = false;
        e0();
        q qVar = this.f;
        i iVar = (i) qVar.f551b;
        i iVar2 = (i) qVar.f551b;
        iVar.clear();
        g gVar = (g) qVar.f552c;
        gVar.b();
        Q();
        U();
        o1 o1VarI = null;
        View focusedChild = (this.f926c0 && hasFocus() && this.f941l != null) ? getFocusedChild() : null;
        if (focusedChild != null && (viewB = B(focusedChild)) != null) {
            o1VarI = I(viewB);
        }
        if (o1VarI == null) {
            l1Var.f1976m = -1L;
            l1Var.f1975l = -1;
            l1Var.f1977n = -1;
        } else {
            l1Var.f1976m = this.f941l.f2000b ? o1VarI.f2007e : -1L;
            if (this.C) {
                iG = -1;
            } else if (o1VarI.i()) {
                iG = o1VarI.f2006d;
            } else {
                RecyclerView recyclerView = o1VarI.f2019r;
                if (recyclerView == null) {
                    iG = -1;
                } else {
                    iG = recyclerView.G(o1VarI);
                }
            }
            l1Var.f1975l = iG;
            View focusedChild2 = o1VarI.f2003a;
            int id = focusedChild2.getId();
            while (!focusedChild2.isFocused() && (focusedChild2 instanceof ViewGroup) && focusedChild2.hasFocus()) {
                focusedChild2 = ((ViewGroup) focusedChild2).getFocusedChild();
                if (focusedChild2.getId() != -1) {
                    id = focusedChild2.getId();
                }
            }
            l1Var.f1977n = id;
        }
        l1Var.f1971h = l1Var.f1973j && this.f940k0;
        this.f940k0 = false;
        this.j0 = false;
        l1Var.f1970g = l1Var.f1974k;
        l1Var.f1969e = this.f941l.a();
        D(this.f948o0);
        if (l1Var.f1973j) {
            int iM = this.f929e.m();
            for (int i3 = 0; i3 < iM; i3++) {
                o1 o1VarJ = J(this.f929e.l(i3));
                if (!o1VarJ.p() && (!o1VarJ.g() || this.f941l.f2000b)) {
                    u0 u0Var = this.L;
                    u0.b(o1VarJ);
                    o1VarJ.d();
                    u0Var.getClass();
                    t0 t0Var = new t0();
                    t0Var.a(o1VarJ);
                    y1 y1VarA = (y1) iVar2.get(o1VarJ);
                    if (y1VarA == null) {
                        y1VarA = y1.a();
                        iVar2.put(o1VarJ, y1VarA);
                    }
                    y1VarA.f2138b = t0Var;
                    y1VarA.f2137a |= 4;
                    if (l1Var.f1971h && o1VarJ.l() && !o1VarJ.i() && !o1VarJ.p() && !o1VarJ.g()) {
                        gVar.h(H(o1VarJ), o1VarJ);
                    }
                }
            }
        }
        if (l1Var.f1974k) {
            int iT = this.f929e.t();
            for (int i4 = 0; i4 < iT; i4++) {
                o1 o1VarJ2 = J(this.f929e.s(i4));
                if (!o1VarJ2.p() && o1VarJ2.f2006d == -1) {
                    o1VarJ2.f2006d = o1VarJ2.f2005c;
                }
            }
            boolean z4 = l1Var.f;
            l1Var.f = false;
            this.f943m.h0(this.f923b, l1Var);
            l1Var.f = z4;
            for (int i5 = 0; i5 < this.f929e.m(); i5++) {
                o1 o1VarJ3 = J(this.f929e.l(i5));
                if (!o1VarJ3.p() && ((y1Var = (y1) iVar2.get(o1VarJ3)) == null || (y1Var.f2137a & 4) == 0)) {
                    u0.b(o1VarJ3);
                    boolean z5 = (o1VarJ3.f2011j & JarConfig.DEFAULT_BUFFER_SIZE) != 0;
                    u0 u0Var2 = this.L;
                    o1VarJ3.d();
                    u0Var2.getClass();
                    t0 t0Var2 = new t0();
                    t0Var2.a(o1VarJ3);
                    if (z5) {
                        W(o1VarJ3, t0Var2);
                    } else {
                        y1 y1VarA2 = (y1) iVar2.get(o1VarJ3);
                        if (y1VarA2 == null) {
                            y1VarA2 = y1.a();
                            iVar2.put(o1VarJ3, y1VarA2);
                        }
                        y1VarA2.f2137a |= 2;
                        y1VarA2.f2138b = t0Var2;
                    }
                }
            }
            k();
        } else {
            k();
        }
        R(true);
        f0(false);
        l1Var.f1968d = 2;
    }

    public final void r() {
        e0();
        Q();
        l1 l1Var = this.f933g0;
        l1Var.a(6);
        this.f927d.d();
        l1Var.f1969e = this.f941l.a();
        l1Var.f1967c = 0;
        if (this.f925c != null) {
            o0 o0Var = this.f941l;
            int iOrdinal = o0Var.f2001c.ordinal();
            if (iOrdinal == 1 ? o0Var.a() > 0 : iOrdinal != 2) {
                Parcelable parcelable = this.f925c.f1919c;
                if (parcelable != null) {
                    this.f943m.j0(parcelable);
                }
                this.f925c = null;
            }
        }
        l1Var.f1970g = false;
        this.f943m.h0(this.f923b, l1Var);
        l1Var.f = false;
        l1Var.f1973j = l1Var.f1973j && this.L != null;
        l1Var.f1968d = 4;
        R(true);
        f0(false);
    }

    @Override // android.view.ViewGroup
    public final void removeDetachedView(View view, boolean z4) {
        o1 o1VarJ = J(view);
        if (o1VarJ != null) {
            if (o1VarJ.k()) {
                o1VarJ.f2011j &= -257;
            } else if (!o1VarJ.p()) {
                throw new IllegalArgumentException("Called removeDetachedView with a view which is not flagged as tmp detached." + o1VarJ + z());
            }
        }
        view.clearAnimation();
        o(view);
        super.removeDetachedView(view, z4);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        j0 j0Var = this.f943m.f2126e;
        if ((j0Var == null || !j0Var.f1929e) && !M() && view2 != null) {
            Y(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z4) {
        return this.f943m.r0(this, view, rect, z4, false);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z4) {
        ArrayList arrayList = this.f949p;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            ((c1) arrayList.get(i3)).e(z4);
        }
        super.requestDisallowInterceptTouchEvent(z4);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.f959u != 0 || this.f963w) {
            this.f961v = true;
        } else {
            super.requestLayout();
        }
    }

    public final boolean s(int i3, int i4, int i5, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i3, i4, i5, iArr, iArr2);
    }

    @Override // android.view.View
    public final void scrollBy(int i3, int i4) {
        y0 y0Var = this.f943m;
        if (y0Var == null || this.f963w) {
            return;
        }
        boolean zD = y0Var.d();
        boolean zE = this.f943m.e();
        if (zD || zE) {
            if (!zD) {
                i3 = 0;
            }
            if (!zE) {
                i4 = 0;
            }
            a0(i3, i4, null, 0);
        }
    }

    @Override // android.view.View
    public final void scrollTo(int i3, int i4) {
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (!M()) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        } else {
            int contentChangeTypes = accessibilityEvent != null ? accessibilityEvent.getContentChangeTypes() : 0;
            this.f967y |= contentChangeTypes != 0 ? contentChangeTypes : 0;
        }
    }

    public void setAccessibilityDelegateCompat(q1 q1Var) {
        this.f946n0 = q1Var;
        h0.p(this, q1Var);
    }

    public void setAdapter(o0 o0Var) {
        setLayoutFrozen(false);
        o0 o0Var2 = this.f941l;
        c cVar = this.f921a;
        if (o0Var2 != null) {
            o0Var2.f1999a.unregisterObserver(cVar);
            this.f941l.h(this);
        }
        u0 u0Var = this.L;
        if (u0Var != null) {
            u0Var.e();
        }
        y0 y0Var = this.f943m;
        g1 g1Var = this.f923b;
        if (y0Var != null) {
            y0Var.n0(g1Var);
            this.f943m.o0(g1Var);
        }
        g1Var.f1888a.clear();
        g1Var.e();
        b bVar = this.f927d;
        bVar.q((ArrayList) bVar.f1813c);
        bVar.q((ArrayList) bVar.f1814d);
        bVar.f1811a = 0;
        o0 o0Var3 = this.f941l;
        this.f941l = o0Var;
        if (o0Var != null) {
            o0Var.f1999a.registerObserver(cVar);
            o0Var.d(this);
        }
        y0 y0Var2 = this.f943m;
        if (y0Var2 != null) {
            y0Var2.U();
        }
        o0 o0Var4 = this.f941l;
        g1Var.f1888a.clear();
        g1Var.e();
        f1 f1VarC = g1Var.c();
        if (o0Var3 != null) {
            f1VarC.f1878b--;
        }
        if (f1VarC.f1878b == 0) {
            SparseArray sparseArray = f1VarC.f1877a;
            for (int i3 = 0; i3 < sparseArray.size(); i3++) {
                ((e1) sparseArray.valueAt(i3)).f1863a.clear();
            }
        }
        if (o0Var4 != null) {
            f1VarC.f1878b++;
        }
        this.f933g0.f = true;
        V(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(r0 r0Var) {
        if (r0Var == null) {
            return;
        }
        setChildrenDrawingOrderEnabled(r0Var != null);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z4) {
        if (z4 != this.f932g) {
            this.K = null;
            this.I = null;
            this.J = null;
            this.H = null;
        }
        this.f932g = z4;
        super.setClipToPadding(z4);
        if (this.f957t) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(s0 s0Var) {
        s0Var.getClass();
        this.G = s0Var;
        this.K = null;
        this.I = null;
        this.J = null;
        this.H = null;
    }

    public void setHasFixedSize(boolean z4) {
        this.f955s = z4;
    }

    public void setItemAnimator(u0 u0Var) {
        u0 u0Var2 = this.L;
        if (u0Var2 != null) {
            u0Var2.e();
            this.L.f2075a = null;
        }
        this.L = u0Var;
        if (u0Var != null) {
            u0Var.f2075a = this.f942l0;
        }
    }

    public void setItemViewCacheSize(int i3) {
        g1 g1Var = this.f923b;
        g1Var.f1892e = i3;
        g1Var.l();
    }

    @Deprecated
    public void setLayoutFrozen(boolean z4) {
        suppressLayout(z4);
    }

    public void setLayoutManager(y0 y0Var) {
        j0 j0Var;
        if (y0Var == this.f943m) {
            return;
        }
        setScrollState(0);
        n1 n1Var = this.f928d0;
        n1Var.f1994g.removeCallbacks(n1Var);
        n1Var.f1991c.abortAnimation();
        y0 y0Var2 = this.f943m;
        if (y0Var2 != null && (j0Var = y0Var2.f2126e) != null) {
            j0Var.i();
        }
        y0 y0Var3 = this.f943m;
        g1 g1Var = this.f923b;
        if (y0Var3 != null) {
            u0 u0Var = this.L;
            if (u0Var != null) {
                u0Var.e();
            }
            this.f943m.n0(g1Var);
            this.f943m.o0(g1Var);
            g1Var.f1888a.clear();
            g1Var.e();
            if (this.f953r) {
                y0 y0Var4 = this.f943m;
                y0Var4.f2127g = false;
                y0Var4.W(this);
            }
            this.f943m.A0(null);
            this.f943m = null;
        } else {
            g1Var.f1888a.clear();
            g1Var.e();
        }
        u uVar = this.f929e;
        RecyclerView recyclerView = ((n0) uVar.f562b).f1988a;
        ((d) uVar.f563c).g();
        ArrayList arrayList = (ArrayList) uVar.f564d;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            o1 o1VarJ = J((View) arrayList.get(size));
            if (o1VarJ != null) {
                int i3 = o1VarJ.f2017p;
                if (recyclerView.M()) {
                    o1VarJ.f2018q = i3;
                    recyclerView.f958t0.add(o1VarJ);
                } else {
                    View view = o1VarJ.f2003a;
                    WeakHashMap weakHashMap = h0.f3558a;
                    view.setImportantForAccessibility(i3);
                }
                o1VarJ.f2017p = 0;
            }
            arrayList.remove(size);
        }
        int childCount = recyclerView.getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt = recyclerView.getChildAt(i4);
            recyclerView.o(childAt);
            childAt.clearAnimation();
        }
        recyclerView.removeAllViews();
        this.f943m = y0Var;
        if (y0Var != null) {
            if (y0Var.f2123b != null) {
                throw new IllegalArgumentException("LayoutManager " + y0Var + " is already attached to a RecyclerView:" + y0Var.f2123b.z());
            }
            y0Var.A0(this);
            if (this.f953r) {
                y0 y0Var5 = this.f943m;
                y0Var5.f2127g = true;
                y0Var5.V(this);
            }
        }
        g1Var.l();
        requestLayout();
    }

    @Override // android.view.ViewGroup
    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition != null) {
            throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
        }
        super.setLayoutTransition(null);
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z4) {
        j scrollingChildHelper = getScrollingChildHelper();
        if (scrollingChildHelper.f3568d) {
            ViewGroup viewGroup = scrollingChildHelper.f3567c;
            WeakHashMap weakHashMap = h0.f3558a;
            z.o(viewGroup);
        }
        scrollingChildHelper.f3568d = z4;
    }

    public void setOnFlingListener(b1 b1Var) {
        this.U = b1Var;
    }

    @Deprecated
    public void setOnScrollListener(d1 d1Var) {
        this.f935h0 = d1Var;
    }

    public void setPreserveFocusAfterLayout(boolean z4) {
        this.f926c0 = z4;
    }

    public void setRecycledViewPool(f1 f1Var) {
        g1 g1Var = this.f923b;
        f1 f1Var2 = g1Var.f1893g;
        if (f1Var2 != null) {
            f1Var2.f1878b--;
        }
        g1Var.f1893g = f1Var;
        if (f1Var == null || g1Var.f1894h.getAdapter() == null) {
            return;
        }
        g1Var.f1893g.f1878b++;
    }

    public void setScrollState(int i3) {
        j0 j0Var;
        if (i3 == this.M) {
            return;
        }
        this.M = i3;
        if (i3 != 2) {
            n1 n1Var = this.f928d0;
            n1Var.f1994g.removeCallbacks(n1Var);
            n1Var.f1991c.abortAnimation();
            y0 y0Var = this.f943m;
            if (y0Var != null && (j0Var = y0Var.f2126e) != null) {
                j0Var.i();
            }
        }
        y0 y0Var2 = this.f943m;
        if (y0Var2 != null) {
            y0Var2.l0(i3);
        }
        d1 d1Var = this.f935h0;
        if (d1Var != null) {
            d1Var.a(this, i3);
        }
        ArrayList arrayList = this.f937i0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((d1) this.f937i0.get(size)).a(this, i3);
            }
        }
    }

    public void setScrollingTouchSlop(int i3) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i3 != 1) {
            this.T = viewConfiguration.getScaledTouchSlop();
        } else {
            this.T = viewConfiguration.getScaledPagingTouchSlop();
        }
    }

    public void setViewCacheExtension(m1 m1Var) {
        this.f923b.getClass();
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i3) {
        return getScrollingChildHelper().g(i3, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        getScrollingChildHelper().h(0);
    }

    @Override // android.view.ViewGroup
    public final void suppressLayout(boolean z4) {
        j0 j0Var;
        if (z4 != this.f963w) {
            i("Do not suppressLayout in layout or scroll");
            if (!z4) {
                this.f963w = false;
                if (this.f961v && this.f943m != null && this.f941l != null) {
                    requestLayout();
                }
                this.f961v = false;
                return;
            }
            long jUptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0));
            this.f963w = true;
            this.f965x = true;
            setScrollState(0);
            n1 n1Var = this.f928d0;
            n1Var.f1994g.removeCallbacks(n1Var);
            n1Var.f1991c.abortAnimation();
            y0 y0Var = this.f943m;
            if (y0Var == null || (j0Var = y0Var.f2126e) == null) {
                return;
            }
            j0Var.i();
        }
    }

    public final void t(int i3, int i4, int i5, int i6, int[] iArr, int i7, int[] iArr2) {
        getScrollingChildHelper().d(i3, i4, i5, i6, iArr, i7, iArr2);
    }

    public final void u(int i3, int i4) {
        this.F++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i3, scrollY - i4);
        d1 d1Var = this.f935h0;
        if (d1Var != null) {
            d1Var.b(this, i3, i4);
        }
        ArrayList arrayList = this.f937i0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((d1) this.f937i0.get(size)).b(this, i3, i4);
            }
        }
        this.F--;
    }

    public final void v() {
        if (this.K != null) {
            return;
        }
        this.G.getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.K = edgeEffect;
        if (this.f932g) {
            edgeEffect.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public final void w() {
        if (this.H != null) {
            return;
        }
        this.G.getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.H = edgeEffect;
        if (this.f932g) {
            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    public final void x() {
        if (this.J != null) {
            return;
        }
        this.G.getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.J = edgeEffect;
        if (this.f932g) {
            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    public final void y() {
        if (this.I != null) {
            return;
        }
        this.G.getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.I = edgeEffect;
        if (this.f932g) {
            edgeEffect.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public final String z() {
        return " " + super.toString() + ", adapter:" + this.f941l + ", layout:" + this.f943m + ", context:" + getContext();
    }

    public RecyclerView(Context context, AttributeSet attributeSet, int i3) {
        float fA;
        int i4;
        char c3;
        char c4;
        char c5;
        Constructor constructor;
        super(context, attributeSet, i3);
        int i5 = 1;
        this.f921a = new c(i5, this);
        this.f923b = new g1(this);
        this.f = new q(8);
        this.f934h = new m0(this, 0);
        this.f936i = new Rect();
        this.f938j = new Rect();
        this.f939k = new RectF();
        this.f945n = new ArrayList();
        this.f947o = new ArrayList();
        this.f949p = new ArrayList();
        this.f959u = 0;
        this.C = false;
        this.D = false;
        this.E = 0;
        this.F = 0;
        this.G = new s0();
        k kVar = new k();
        Object[] objArr = null;
        kVar.f2075a = null;
        kVar.f2076b = new ArrayList();
        kVar.f2077c = 120L;
        kVar.f2078d = 120L;
        kVar.f2079e = 250L;
        kVar.f = 250L;
        kVar.f1945g = true;
        kVar.f1946h = new ArrayList();
        kVar.f1947i = new ArrayList();
        kVar.f1948j = new ArrayList();
        kVar.f1949k = new ArrayList();
        kVar.f1950l = new ArrayList();
        kVar.f1951m = new ArrayList();
        kVar.f1952n = new ArrayList();
        kVar.f1953o = new ArrayList();
        kVar.f1954p = new ArrayList();
        kVar.f1955q = new ArrayList();
        kVar.f1956r = new ArrayList();
        this.L = kVar;
        this.M = 0;
        this.N = -1;
        this.f922a0 = Float.MIN_VALUE;
        this.f924b0 = Float.MIN_VALUE;
        this.f926c0 = true;
        this.f928d0 = new n1(this);
        this.f931f0 = C0 ? new e1.u() : null;
        l1 l1Var = new l1();
        l1Var.f1965a = -1;
        l1Var.f1966b = 0;
        l1Var.f1967c = 0;
        l1Var.f1968d = 1;
        l1Var.f1969e = 0;
        l1Var.f = false;
        l1Var.f1970g = false;
        l1Var.f1971h = false;
        l1Var.f1972i = false;
        l1Var.f1973j = false;
        l1Var.f1974k = false;
        this.f933g0 = l1Var;
        this.j0 = false;
        this.f940k0 = false;
        n0 n0Var = new n0(this);
        this.f942l0 = n0Var;
        this.f944m0 = false;
        this.f948o0 = new int[2];
        this.f952q0 = new int[2];
        this.f954r0 = new int[2];
        this.f956s0 = new int[2];
        this.f958t0 = new ArrayList();
        this.f960u0 = new m0(this, i5);
        this.f964w0 = 0;
        this.f966x0 = 0;
        this.f968y0 = new n0(this);
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.T = viewConfiguration.getScaledTouchSlop();
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 26) {
            Method method = i0.f3564a;
            fA = h0.a.b(viewConfiguration);
        } else {
            fA = i0.a(viewConfiguration, context);
        }
        this.f922a0 = fA;
        this.f924b0 = i6 >= 26 ? h0.a.c(viewConfiguration) : i0.a(viewConfiguration, context);
        this.V = viewConfiguration.getScaledMinimumFlingVelocity();
        this.W = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        this.L.f2075a = n0Var;
        this.f927d = new b(new n0(this));
        this.f929e = new u(new n0(this));
        WeakHashMap weakHashMap = h0.f3558a;
        if ((i6 >= 26 ? b0.a(this) : 0) == 0 && i6 >= 26) {
            b0.b(this, 8);
        }
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        this.A = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new q1(this));
        int[] iArr = d1.a.f1622a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i3, 0);
        h0.o(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, i3);
        String string = typedArrayObtainStyledAttributes.getString(8);
        if (typedArrayObtainStyledAttributes.getInt(2, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.f932g = typedArrayObtainStyledAttributes.getBoolean(1, true);
        if (typedArrayObtainStyledAttributes.getBoolean(3, false)) {
            StateListDrawable stateListDrawable = (StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(6);
            Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(7);
            StateListDrawable stateListDrawable2 = (StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(4);
            Drawable drawable2 = typedArrayObtainStyledAttributes.getDrawable(5);
            if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
                throw new IllegalArgumentException("Trying to set fast scroller without both required drawables." + z());
            }
            Resources resources = getContext().getResources();
            c3 = 3;
            c4 = 2;
            c5 = 1;
            i4 = 4;
            new t(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(top.niunaijun.blackbox.R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(top.niunaijun.blackbox.R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(top.niunaijun.blackbox.R.dimen.fastscroll_margin));
        } else {
            i4 = 4;
            c3 = 3;
            c4 = 2;
            c5 = 1;
        }
        typedArrayObtainStyledAttributes.recycle();
        if (string != null) {
            String strTrim = string.trim();
            if (!strTrim.isEmpty()) {
                if (strTrim.charAt(0) == '.') {
                    strTrim = context.getPackageName() + strTrim;
                } else if (!strTrim.contains(".")) {
                    strTrim = RecyclerView.class.getPackage().getName() + '.' + strTrim;
                }
                String str = strTrim;
                try {
                    Class<? extends U> clsAsSubclass = Class.forName(str, false, isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).asSubclass(y0.class);
                    try {
                        constructor = clsAsSubclass.getConstructor(D0);
                        Object[] objArr2 = new Object[i4];
                        objArr2[0] = context;
                        objArr2[c5] = attributeSet;
                        objArr2[c4] = Integer.valueOf(i3);
                        objArr2[c3] = 0;
                        objArr = objArr2;
                    } catch (NoSuchMethodException e4) {
                        try {
                            constructor = clsAsSubclass.getConstructor(null);
                        } catch (NoSuchMethodException e5) {
                            e5.initCause(e4);
                            throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + str, e5);
                        }
                    }
                    constructor.setAccessible(true);
                    setLayoutManager((y0) constructor.newInstance(objArr));
                } catch (ClassCastException e6) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + str, e6);
                } catch (ClassNotFoundException e7) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + str, e7);
                } catch (IllegalAccessException e8) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + str, e8);
                } catch (InstantiationException e9) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e9);
                } catch (InvocationTargetException e10) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e10);
                }
            }
        }
        int[] iArr2 = f920z0;
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i3, 0);
        h0.o(this, context, iArr2, attributeSet, typedArrayObtainStyledAttributes2, i3);
        boolean z4 = typedArrayObtainStyledAttributes2.getBoolean(0, true);
        typedArrayObtainStyledAttributes2.recycle();
        setNestedScrollingEnabled(z4);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        y0 y0Var = this.f943m;
        if (y0Var != null) {
            return y0Var.t(layoutParams);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + z());
    }

    @Deprecated
    public void setRecyclerListener(h1 h1Var) {
    }
}
