package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.emoji2.text.q;
import e1.f0;
import e1.g0;
import e1.g1;
import e1.h0;
import e1.l1;
import e1.u;
import e1.x;
import e1.y0;
import e1.z0;
import g0.e;
import java.util.Arrays;
import java.util.WeakHashMap;
import p0.f;

/* JADX INFO: loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {
    public boolean E;
    public int F;
    public int[] G;
    public View[] H;
    public final SparseIntArray I;
    public final SparseIntArray J;
    public final q K;
    public final Rect L;

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i3, int i4) {
        super(context, attributeSet, i3, i4);
        this.E = false;
        this.F = -1;
        this.I = new SparseIntArray();
        this.J = new SparseIntArray();
        this.K = new q(5);
        this.L = new Rect();
        u1(y0.M(context, attributeSet, i3, i4).f2113b);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    public final boolean G0() {
        return this.f919z == null && !this.E;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void I0(l1 l1Var, h0 h0Var, u uVar) {
        int i3;
        int i4 = this.F;
        for (int i5 = 0; i5 < this.F && (i3 = h0Var.f1903d) >= 0 && i3 < l1Var.b() && i4 > 0; i5++) {
            uVar.a(h0Var.f1903d, Math.max(0, h0Var.f1905g));
            this.K.getClass();
            i4--;
            h0Var.f1903d += h0Var.f1904e;
        }
    }

    @Override // e1.y0
    public final int N(g1 g1Var, l1 l1Var) {
        if (this.f909p == 0) {
            return this.F;
        }
        if (l1Var.b() < 1) {
            return 0;
        }
        return q1(l1Var.b() - 1, g1Var, l1Var) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final View V0(g1 g1Var, l1 l1Var, boolean z4, boolean z5) {
        int i3;
        int iV;
        int iV2 = v();
        int i4 = 1;
        if (z5) {
            iV = v() - 1;
            i3 = -1;
            i4 = -1;
        } else {
            i3 = iV2;
            iV = 0;
        }
        int iB = l1Var.b();
        N0();
        int iK = this.f911r.k();
        int iG = this.f911r.g();
        View view = null;
        View view2 = null;
        while (iV != i3) {
            View viewU = u(iV);
            int iL = y0.L(viewU);
            if (iL >= 0 && iL < iB && r1(iL, g1Var, l1Var) == 0) {
                if (((z0) viewU.getLayoutParams()).f2155a.i()) {
                    if (view2 == null) {
                        view2 = viewU;
                    }
                } else {
                    if (this.f911r.e(viewU) < iG && this.f911r.b(viewU) >= iK) {
                        return viewU;
                    }
                    if (view == null) {
                        view = viewU;
                    }
                }
            }
            iV += i4;
        }
        return view != null ? view : view2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:62:0x00e2, code lost:
    
        if (r13 == (r2 > r15)) goto L57;
     */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.view.View X(android.view.View r23, int r24, e1.g1 r25, e1.l1 r26) {
        /*
            Method dump skipped, instruction units count: 326
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.X(android.view.View, int, e1.g1, e1.l1):android.view.View");
    }

    @Override // e1.y0
    public final void b0(g1 g1Var, l1 l1Var, View view, f fVar) {
        AccessibilityNodeInfo accessibilityNodeInfo = fVar.f3692a;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof x)) {
            a0(view, fVar);
            return;
        }
        x xVar = (x) layoutParams;
        int iQ1 = q1(xVar.f2155a.c(), g1Var, l1Var);
        if (this.f909p == 0) {
            accessibilityNodeInfo.setCollectionItemInfo(AccessibilityNodeInfo.CollectionItemInfo.obtain(xVar.f2111e, xVar.f, iQ1, 1, false, false));
        } else {
            accessibilityNodeInfo.setCollectionItemInfo(AccessibilityNodeInfo.CollectionItemInfo.obtain(iQ1, 1, xVar.f2111e, xVar.f, false, false));
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r12v22 */
    /* JADX WARN: Type inference failed for: r12v23, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r12v26 */
    /* JADX WARN: Type inference failed for: r12v27 */
    /* JADX WARN: Type inference failed for: r12v34 */
    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void b1(g1 g1Var, l1 l1Var, h0 h0Var, g0 g0Var) {
        int i3;
        int i4;
        int i5;
        int iD;
        int I;
        int iK;
        int iD2;
        int iW;
        int iW2;
        ?? r12;
        int i6;
        View viewB;
        int iJ = this.f911r.j();
        boolean z4 = iJ != 1073741824;
        int i7 = v() > 0 ? this.G[this.F] : 0;
        if (z4) {
            v1();
        }
        boolean z5 = h0Var.f1904e == 1;
        int iR1 = this.F;
        if (!z5) {
            iR1 = r1(h0Var.f1903d, g1Var, l1Var) + s1(h0Var.f1903d, g1Var, l1Var);
        }
        int i8 = 0;
        while (i8 < this.F && (i6 = h0Var.f1903d) >= 0 && i6 < l1Var.b() && iR1 > 0) {
            int i9 = h0Var.f1903d;
            int iS1 = s1(i9, g1Var, l1Var);
            if (iS1 > this.F) {
                throw new IllegalArgumentException("Item at position " + i9 + " requires " + iS1 + " spans but GridLayoutManager has only " + this.F + " spans.");
            }
            iR1 -= iS1;
            if (iR1 < 0 || (viewB = h0Var.b(g1Var)) == null) {
                break;
            }
            this.H[i8] = viewB;
            i8++;
        }
        if (i8 == 0) {
            g0Var.f1885b = true;
            return;
        }
        if (z5) {
            i4 = i8;
            i3 = 0;
            i5 = 1;
        } else {
            i3 = i8 - 1;
            i4 = -1;
            i5 = -1;
        }
        int i10 = 0;
        while (i3 != i4) {
            View view = this.H[i3];
            x xVar = (x) view.getLayoutParams();
            int iS2 = s1(y0.L(view), g1Var, l1Var);
            xVar.f = iS2;
            xVar.f2111e = i10;
            i10 += iS2;
            i3 += i5;
        }
        float f = 0.0f;
        int i11 = 0;
        for (int i12 = 0; i12 < i8; i12++) {
            View view2 = this.H[i12];
            if (h0Var.f1909k != null) {
                r12 = 0;
                r12 = 0;
                if (z5) {
                    b(view2, -1, true);
                } else {
                    b(view2, 0, true);
                }
            } else if (z5) {
                r12 = 0;
                b(view2, -1, false);
            } else {
                r12 = 0;
                b(view2, 0, false);
            }
            RecyclerView recyclerView = this.f2123b;
            Rect rect = this.L;
            if (recyclerView == null) {
                rect.set(r12, r12, r12, r12);
            } else {
                rect.set(recyclerView.K(view2));
            }
            t1(view2, iJ, r12);
            int iC = this.f911r.c(view2);
            if (iC > i11) {
                i11 = iC;
            }
            float fD = (this.f911r.d(view2) * 1.0f) / ((x) view2.getLayoutParams()).f;
            if (fD > f) {
                f = fD;
            }
        }
        if (z4) {
            n1(Math.max(Math.round(f * this.F), i7));
            i11 = 0;
            for (int i13 = 0; i13 < i8; i13++) {
                View view3 = this.H[i13];
                t1(view3, 1073741824, true);
                int iC2 = this.f911r.c(view3);
                if (iC2 > i11) {
                    i11 = iC2;
                }
            }
        }
        for (int i14 = 0; i14 < i8; i14++) {
            View view4 = this.H[i14];
            if (this.f911r.c(view4) != i11) {
                x xVar2 = (x) view4.getLayoutParams();
                Rect rect2 = xVar2.f2156b;
                int i15 = rect2.top + rect2.bottom + ((ViewGroup.MarginLayoutParams) xVar2).topMargin + ((ViewGroup.MarginLayoutParams) xVar2).bottomMargin;
                int i16 = rect2.left + rect2.right + ((ViewGroup.MarginLayoutParams) xVar2).leftMargin + ((ViewGroup.MarginLayoutParams) xVar2).rightMargin;
                int iP1 = p1(xVar2.f2111e, xVar2.f);
                if (this.f909p == 1) {
                    iW2 = y0.w(false, iP1, 1073741824, i16, ((ViewGroup.MarginLayoutParams) xVar2).width);
                    iW = View.MeasureSpec.makeMeasureSpec(i11 - i15, 1073741824);
                } else {
                    int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i11 - i16, 1073741824);
                    iW = y0.w(false, iP1, 1073741824, i15, ((ViewGroup.MarginLayoutParams) xVar2).height);
                    iW2 = iMakeMeasureSpec;
                }
                if (D0(view4, iW2, iW, (z0) view4.getLayoutParams())) {
                    view4.measure(iW2, iW);
                }
            }
        }
        g0Var.f1884a = i11;
        if (this.f909p != 1) {
            if (h0Var.f == -1) {
                int i17 = h0Var.f1901b;
                I = i17 - i11;
                iD = i17;
            } else {
                int i18 = h0Var.f1901b;
                iD = i18 + i11;
                I = i18;
            }
            iK = 0;
            iD2 = 0;
        } else if (h0Var.f == -1) {
            iD2 = h0Var.f1901b;
            iK = iD2 - i11;
            I = 0;
            iD = 0;
        } else {
            int i19 = h0Var.f1901b;
            iK = i19;
            iD = 0;
            iD2 = i19 + i11;
            I = 0;
        }
        for (int i20 = 0; i20 < i8; i20++) {
            View view5 = this.H[i20];
            x xVar3 = (x) view5.getLayoutParams();
            if (this.f909p != 1) {
                iK = K() + this.G[xVar3.f2111e];
                iD2 = this.f911r.d(view5) + iK;
            } else if (a1()) {
                int I2 = I() + this.G[this.F - xVar3.f2111e];
                iD = I2;
                I = I2 - this.f911r.d(view5);
            } else {
                I = I() + this.G[xVar3.f2111e];
                iD = this.f911r.d(view5) + I;
            }
            y0.R(view5, I, iK, iD, iD2);
            if (xVar3.f2155a.i() || xVar3.f2155a.l()) {
                g0Var.f1886c = true;
            }
            g0Var.f1887d = view5.hasFocusable() | g0Var.f1887d;
        }
        Arrays.fill(this.H, (Object) null);
    }

    @Override // e1.y0
    public final void c0(int i3, int i4) {
        q qVar = this.K;
        qVar.n();
        ((SparseIntArray) qVar.f552c).clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void c1(g1 g1Var, l1 l1Var, f0 f0Var, int i3) {
        v1();
        if (l1Var.b() > 0 && !l1Var.f1970g) {
            boolean z4 = i3 == 1;
            int iR1 = r1(f0Var.f1873b, g1Var, l1Var);
            if (z4) {
                while (iR1 > 0) {
                    int i4 = f0Var.f1873b;
                    if (i4 <= 0) {
                        break;
                    }
                    int i5 = i4 - 1;
                    f0Var.f1873b = i5;
                    iR1 = r1(i5, g1Var, l1Var);
                }
            } else {
                int iB = l1Var.b() - 1;
                int i6 = f0Var.f1873b;
                while (i6 < iB) {
                    int i7 = i6 + 1;
                    int iR2 = r1(i7, g1Var, l1Var);
                    if (iR2 <= iR1) {
                        break;
                    }
                    i6 = i7;
                    iR1 = iR2;
                }
                f0Var.f1873b = i6;
            }
        }
        o1();
    }

    @Override // e1.y0
    public final void d0() {
        q qVar = this.K;
        qVar.n();
        ((SparseIntArray) qVar.f552c).clear();
    }

    @Override // e1.y0
    public final void e0(int i3, int i4) {
        q qVar = this.K;
        qVar.n();
        ((SparseIntArray) qVar.f552c).clear();
    }

    @Override // e1.y0
    public final boolean f(z0 z0Var) {
        return z0Var instanceof x;
    }

    @Override // e1.y0
    public final void f0(int i3, int i4) {
        q qVar = this.K;
        qVar.n();
        ((SparseIntArray) qVar.f552c).clear();
    }

    @Override // e1.y0
    public final void g0(int i3, int i4) {
        q qVar = this.K;
        qVar.n();
        ((SparseIntArray) qVar.f552c).clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    public final void h0(g1 g1Var, l1 l1Var) {
        boolean z4 = l1Var.f1970g;
        SparseIntArray sparseIntArray = this.J;
        SparseIntArray sparseIntArray2 = this.I;
        if (z4) {
            int iV = v();
            for (int i3 = 0; i3 < iV; i3++) {
                x xVar = (x) u(i3).getLayoutParams();
                int iC = xVar.f2155a.c();
                sparseIntArray2.put(iC, xVar.f);
                sparseIntArray.put(iC, xVar.f2111e);
            }
        }
        super.h0(g1Var, l1Var);
        sparseIntArray2.clear();
        sparseIntArray.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    public final void i0(l1 l1Var) {
        super.i0(l1Var);
        this.E = false;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void j1(boolean z4) {
        if (z4) {
            throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
        }
        super.j1(false);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    public final int k(l1 l1Var) {
        return K0(l1Var);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    public final int l(l1 l1Var) {
        return L0(l1Var);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    public final int n(l1 l1Var) {
        return K0(l1Var);
    }

    public final void n1(int i3) {
        int i4;
        int[] iArr = this.G;
        int i5 = this.F;
        if (iArr == null || iArr.length != i5 + 1 || iArr[iArr.length - 1] != i3) {
            iArr = new int[i5 + 1];
        }
        int i6 = 0;
        iArr[0] = 0;
        int i7 = i3 / i5;
        int i8 = i3 % i5;
        int i9 = 0;
        for (int i10 = 1; i10 <= i5; i10++) {
            i6 += i8;
            if (i6 <= 0 || i5 - i6 >= i8) {
                i4 = i7;
            } else {
                i4 = i7 + 1;
                i6 -= i5;
            }
            i9 += i4;
            iArr[i10] = i9;
        }
        this.G = iArr;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    public final int o(l1 l1Var) {
        return L0(l1Var);
    }

    public final void o1() {
        View[] viewArr = this.H;
        if (viewArr == null || viewArr.length != this.F) {
            this.H = new View[this.F];
        }
    }

    public final int p1(int i3, int i4) {
        if (this.f909p != 1 || !a1()) {
            int[] iArr = this.G;
            return iArr[i4 + i3] - iArr[i3];
        }
        int[] iArr2 = this.G;
        int i5 = this.F;
        return iArr2[i5 - i3] - iArr2[(i5 - i3) - i4];
    }

    public final int q1(int i3, g1 g1Var, l1 l1Var) {
        boolean z4 = l1Var.f1970g;
        q qVar = this.K;
        if (!z4) {
            int i4 = this.F;
            qVar.getClass();
            return q.m(i3, i4);
        }
        int iB = g1Var.b(i3);
        if (iB == -1) {
            return 0;
        }
        int i5 = this.F;
        qVar.getClass();
        return q.m(iB, i5);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    public final z0 r() {
        return this.f909p == 0 ? new x(-2, -1) : new x(-1, -2);
    }

    public final int r1(int i3, g1 g1Var, l1 l1Var) {
        boolean z4 = l1Var.f1970g;
        q qVar = this.K;
        if (!z4) {
            int i4 = this.F;
            qVar.getClass();
            return i3 % i4;
        }
        int i5 = this.J.get(i3, -1);
        if (i5 != -1) {
            return i5;
        }
        int iB = g1Var.b(i3);
        if (iB == -1) {
            return 0;
        }
        int i6 = this.F;
        qVar.getClass();
        return iB % i6;
    }

    @Override // e1.y0
    public final z0 s(Context context, AttributeSet attributeSet) {
        x xVar = new x(context, attributeSet);
        xVar.f2111e = -1;
        xVar.f = 0;
        return xVar;
    }

    public final int s1(int i3, g1 g1Var, l1 l1Var) {
        boolean z4 = l1Var.f1970g;
        q qVar = this.K;
        if (!z4) {
            qVar.getClass();
            return 1;
        }
        int i4 = this.I.get(i3, -1);
        if (i4 != -1) {
            return i4;
        }
        if (g1Var.b(i3) == -1) {
            return 1;
        }
        qVar.getClass();
        return 1;
    }

    @Override // e1.y0
    public final z0 t(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            x xVar = new x((ViewGroup.MarginLayoutParams) layoutParams);
            xVar.f2111e = -1;
            xVar.f = 0;
            return xVar;
        }
        x xVar2 = new x(layoutParams);
        xVar2.f2111e = -1;
        xVar2.f = 0;
        return xVar2;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    public final int t0(int i3, g1 g1Var, l1 l1Var) {
        v1();
        o1();
        return super.t0(i3, g1Var, l1Var);
    }

    public final void t1(View view, int i3, boolean z4) {
        int iW;
        int iW2;
        x xVar = (x) view.getLayoutParams();
        Rect rect = xVar.f2156b;
        int i4 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) xVar).topMargin + ((ViewGroup.MarginLayoutParams) xVar).bottomMargin;
        int i5 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) xVar).leftMargin + ((ViewGroup.MarginLayoutParams) xVar).rightMargin;
        int iP1 = p1(xVar.f2111e, xVar.f);
        if (this.f909p == 1) {
            iW2 = y0.w(false, iP1, i3, i5, ((ViewGroup.MarginLayoutParams) xVar).width);
            iW = y0.w(true, this.f911r.l(), this.f2133m, i4, ((ViewGroup.MarginLayoutParams) xVar).height);
        } else {
            int iW3 = y0.w(false, iP1, i3, i4, ((ViewGroup.MarginLayoutParams) xVar).height);
            int iW4 = y0.w(true, this.f911r.l(), this.f2132l, i5, ((ViewGroup.MarginLayoutParams) xVar).width);
            iW = iW3;
            iW2 = iW4;
        }
        z0 z0Var = (z0) view.getLayoutParams();
        if (z4 ? D0(view, iW2, iW, z0Var) : B0(view, iW2, iW, z0Var)) {
            view.measure(iW2, iW);
        }
    }

    public final void u1(int i3) {
        if (i3 == this.F) {
            return;
        }
        this.E = true;
        if (i3 < 1) {
            throw new IllegalArgumentException(e.b(i3, "Span count should be at least 1. Provided "));
        }
        this.F = i3;
        this.K.n();
        s0();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, e1.y0
    public final int v0(int i3, g1 g1Var, l1 l1Var) {
        v1();
        o1();
        return super.v0(i3, g1Var, l1Var);
    }

    public final void v1() {
        int iH;
        int iK;
        if (this.f909p == 1) {
            iH = this.f2134n - J();
            iK = I();
        } else {
            iH = this.f2135o - H();
            iK = K();
        }
        n1(iH - iK);
    }

    @Override // e1.y0
    public final int x(g1 g1Var, l1 l1Var) {
        if (this.f909p == 1) {
            return this.F;
        }
        if (l1Var.b() < 1) {
            return 0;
        }
        return q1(l1Var.b() - 1, g1Var, l1Var) + 1;
    }

    @Override // e1.y0
    public final void y0(Rect rect, int i3, int i4) {
        int iG;
        int iG2;
        if (this.G == null) {
            super.y0(rect, i3, i4);
        }
        int iJ = J() + I();
        int iH = H() + K();
        if (this.f909p == 1) {
            int iHeight = rect.height() + iH;
            RecyclerView recyclerView = this.f2123b;
            WeakHashMap weakHashMap = o0.h0.f3558a;
            iG2 = y0.g(i4, iHeight, recyclerView.getMinimumHeight());
            int[] iArr = this.G;
            iG = y0.g(i3, iArr[iArr.length - 1] + iJ, this.f2123b.getMinimumWidth());
        } else {
            int iWidth = rect.width() + iJ;
            RecyclerView recyclerView2 = this.f2123b;
            WeakHashMap weakHashMap2 = o0.h0.f3558a;
            iG = y0.g(i3, iWidth, recyclerView2.getMinimumWidth());
            int[] iArr2 = this.G;
            iG2 = y0.g(i4, iArr2[iArr2.length - 1] + iH, this.f2123b.getMinimumHeight());
        }
        this.f2123b.setMeasuredDimension(iG, iG2);
    }

    public GridLayoutManager(int i3) {
        super(1);
        this.E = false;
        this.F = -1;
        this.I = new SparseIntArray();
        this.J = new SparseIntArray();
        this.K = new q(5);
        this.L = new Rect();
        u1(i3);
    }

    public GridLayoutManager() {
        super(1);
        this.E = false;
        this.F = -1;
        this.I = new SparseIntArray();
        this.J = new SparseIntArray();
        this.K = new q(5);
        this.L = new Rect();
        u1(4);
    }
}
