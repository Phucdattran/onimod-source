package androidx.lifecycle;

import android.view.View;
import java.util.Iterator;
import java.util.Map;
import kotlinx.coroutines.n0;
import top.niunaijun.blackbox.R;

/* JADX INFO: loaded from: classes.dex */
public abstract class f0 implements k0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final j0 f859a = new j0();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final j0 f860b = new j0();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final j0 f861c = new j0();

    public static final void b(f1.e eVar) {
        f1.c cVar;
        String str;
        Lifecycle$State lifecycle$State = eVar.e().f879c;
        if (lifecycle$State != Lifecycle$State.f830b && lifecycle$State != Lifecycle$State.f831c) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        f1.d dVarC = eVar.c();
        dVarC.getClass();
        Iterator it = ((n.f) dVarC.f2230d).iterator();
        do {
            n.b bVar = (n.b) it;
            if (!bVar.hasNext()) {
                cVar = null;
                break;
            }
            Map.Entry components = (Map.Entry) bVar.next();
            kotlin.jvm.internal.d.e(components, "components");
            str = (String) components.getKey();
            cVar = (f1.c) components.getValue();
        } while (!kotlin.jvm.internal.d.a(str, "androidx.lifecycle.internal.SavedStateHandlesProvider"));
        if (cVar == null) {
            g0 g0Var = new g0(eVar.c(), (m0) eVar);
            eVar.c().e("androidx.lifecycle.internal.SavedStateHandlesProvider", g0Var);
            eVar.e().a(new SavedStateHandleAttacher(g0Var));
        }
    }

    public static final kotlinx.coroutines.k d(top.niunaijun.blackboxa.view.base.a aVar) {
        Object obj;
        kotlinx.coroutines.k kVar = (kotlinx.coroutines.k) aVar.b("androidx.lifecycle.ViewModelCoroutineScope.JOB_KEY");
        if (kVar != null) {
            return kVar;
        }
        n0 n0Var = new n0();
        kotlinx.coroutines.scheduling.d dVar = kotlinx.coroutines.r.f2955a;
        Object dVar2 = new d(a3.a.Y(n0Var, kotlinx.coroutines.internal.j.f2928a.f3717e));
        synchronized (aVar.f867a) {
            try {
                obj = aVar.f867a.get("androidx.lifecycle.ViewModelCoroutineScope.JOB_KEY");
                if (obj == null) {
                    aVar.f867a.put("androidx.lifecycle.ViewModelCoroutineScope.JOB_KEY", dVar2);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (obj != null) {
            dVar2 = obj;
        }
        if (aVar.f869c) {
            i0.a(dVar2);
        }
        return (kotlinx.coroutines.k) dVar2;
    }

    public static final void e(View view, q qVar) {
        kotlin.jvm.internal.d.f(view, "<this>");
        view.setTag(R.id.view_tree_lifecycle_owner, qVar);
    }

    @Override // androidx.lifecycle.k0
    public i0 c(Class cls, a1.c cVar) {
        return a(cls);
    }
}
