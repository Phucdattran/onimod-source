package androidx.lifecycle;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class g0 implements f1.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f1.d f862a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f863b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Bundle f864c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final z2.b f865d;

    public g0(f1.d savedStateRegistry, final m0 m0Var) {
        kotlin.jvm.internal.d.f(savedStateRegistry, "savedStateRegistry");
        this.f862a = savedStateRegistry;
        this.f865d = kotlin.a.a(new j3.a() { // from class: androidx.lifecycle.SavedStateHandlesProvider$viewModel$2
            {
                super(0);
            }

            @Override // j3.a
            public final Object b() {
                m0 m0Var2 = m0Var;
                kotlin.jvm.internal.d.f(m0Var2, "<this>");
                ArrayList arrayList = new ArrayList();
                kotlin.jvm.internal.f.f2858a.getClass();
                kotlin.jvm.internal.b bVar = new kotlin.jvm.internal.b(h0.class);
                SavedStateHandleSupport$savedStateHandlesVM$1$1 initializer = new j3.l() { // from class: androidx.lifecycle.SavedStateHandleSupport$savedStateHandlesVM$1$1
                    @Override // j3.l
                    public final Object h(Object obj) {
                        a1.b initializer2 = (a1.b) obj;
                        kotlin.jvm.internal.d.f(initializer2, "$this$initializer");
                        return new h0();
                    }
                };
                kotlin.jvm.internal.d.f(initializer, "initializer");
                Class clsA = bVar.a();
                kotlin.jvm.internal.d.d(clsA, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-java>>");
                arrayList.add(new a1.d(clsA, initializer));
                a1.d[] dVarArr = (a1.d[]) arrayList.toArray(new a1.d[0]);
                a1.d[] initializers = (a1.d[]) Arrays.copyOf(dVarArr, dVarArr.length);
                kotlin.jvm.internal.d.f(initializers, "initializers");
                l0 store = m0Var2.b();
                a1.b defaultCreationExtras = m0Var2 instanceof i ? ((i) m0Var2).a() : a1.a.f29b;
                kotlin.jvm.internal.d.f(store, "store");
                LinkedHashMap linkedHashMap = store.f873a;
                kotlin.jvm.internal.d.f(defaultCreationExtras, "defaultCreationExtras");
                i0 i0Var = (i0) linkedHashMap.get("androidx.lifecycle.internal.SavedStateHandlesVM");
                if (h0.class.isInstance(i0Var)) {
                    kotlin.jvm.internal.d.d(i0Var, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
                } else {
                    a1.c cVar = new a1.c(defaultCreationExtras);
                    cVar.f30a.put(j0.f871b, "androidx.lifecycle.internal.SavedStateHandlesVM");
                    try {
                        i0 i0Var2 = null;
                        for (a1.d dVar : initializers) {
                            if (dVar.f31a.equals(h0.class)) {
                                Object objH = dVar.f32b.h(cVar);
                                i0Var2 = objH instanceof i0 ? (i0) objH : null;
                            }
                        }
                        if (i0Var2 == null) {
                            throw new IllegalArgumentException("No initializer set for given class ".concat(h0.class.getName()));
                        }
                        i0 i0Var3 = (i0) linkedHashMap.put("androidx.lifecycle.internal.SavedStateHandlesVM", i0Var2);
                        if (i0Var3 != null) {
                            i0Var3.c();
                        }
                        i0Var = i0Var2;
                    } catch (AbstractMethodError unused) {
                        throw new UnsupportedOperationException("Factory.create(String) is unsupported.  This Factory requires `CreationExtras` to be passed into `create` method.");
                    }
                }
                return (h0) i0Var;
            }
        });
    }

    @Override // f1.c
    public final Bundle a() {
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f864c;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        Iterator it = ((h0) this.f865d.getValue()).f866d.entrySet().iterator();
        if (!it.hasNext()) {
            this.f863b = false;
            return bundle;
        }
        Map.Entry entry = (Map.Entry) it.next();
        entry.getValue().getClass();
        throw new ClassCastException();
    }
}
