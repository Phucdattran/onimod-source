package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Lifecycle$State f875a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public o f876b;

    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        Lifecycle$State lifecycle$StateA = lifecycle$Event.a();
        Lifecycle$State state1 = this.f875a;
        kotlin.jvm.internal.d.f(state1, "state1");
        if (lifecycle$StateA.compareTo(state1) < 0) {
            state1 = lifecycle$StateA;
        }
        this.f875a = state1;
        this.f876b.a(qVar, lifecycle$Event);
        this.f875a = lifecycle$StateA;
    }
}
