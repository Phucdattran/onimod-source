package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
final class RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1 implements o {
    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        if (lifecycle$Event == Lifecycle$Event.ON_DESTROY) {
            throw null;
        }
    }
}
