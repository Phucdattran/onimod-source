package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public abstract class v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final x f886a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f887b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f888c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ w f889d;

    public v(w wVar, x xVar) {
        this.f889d = wVar;
        this.f886a = xVar;
    }

    public final void c(boolean z4) {
        if (z4 == this.f887b) {
            return;
        }
        this.f887b = z4;
        int i3 = z4 ? 1 : -1;
        w wVar = this.f889d;
        int i4 = wVar.f893c;
        wVar.f893c = i3 + i4;
        if (!wVar.f894d) {
            wVar.f894d = true;
            while (true) {
                try {
                    int i5 = wVar.f893c;
                    if (i4 == i5) {
                        break;
                    } else {
                        i4 = i5;
                    }
                } catch (Throwable th) {
                    wVar.f894d = false;
                    throw th;
                }
            }
            wVar.f894d = false;
        }
        if (this.f887b) {
            wVar.c(this);
        }
    }

    public void d() {
    }

    public boolean e(q qVar) {
        return false;
    }

    public abstract boolean f();
}
