package androidx.lifecycle;

import java.io.Closeable;
import kotlinx.coroutines.JobCancellationException;

/* JADX INFO: loaded from: classes.dex */
public final class d implements Closeable, kotlinx.coroutines.k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b3.g f855a;

    public d(b3.g context) {
        kotlin.jvm.internal.d.f(context, "context");
        this.f855a = context;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        kotlinx.coroutines.c0 c0Var = (kotlinx.coroutines.c0) this.f855a.b(kotlinx.coroutines.i.f2899b);
        if (c0Var != null) {
            kotlinx.coroutines.i0 i0Var = (kotlinx.coroutines.i0) c0Var;
            i0Var.m(new JobCancellationException(i0Var.o(), null, i0Var));
        }
    }

    @Override // kotlinx.coroutines.k
    public final b3.g e() {
        return this.f855a;
    }
}
