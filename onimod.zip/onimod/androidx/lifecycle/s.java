package androidx.lifecycle;

import android.os.Looper;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: classes.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f877a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public n.a f878b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Lifecycle$State f879c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final WeakReference f880d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f881e;
    public boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f882g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final ArrayList f883h;

    public s(q qVar) {
        new AtomicReference();
        this.f877a = true;
        this.f878b = new n.a();
        this.f879c = Lifecycle$State.f830b;
        this.f883h = new ArrayList();
        this.f880d = new WeakReference(qVar);
    }

    public final void a(p pVar) {
        o reflectiveGenericLifecycleObserver;
        Object obj;
        q qVar;
        Lifecycle$Event lifecycle$Event;
        c("addObserver");
        Lifecycle$State lifecycle$State = this.f879c;
        Lifecycle$State lifecycle$State2 = Lifecycle$State.f829a;
        if (lifecycle$State != lifecycle$State2) {
            lifecycle$State2 = Lifecycle$State.f830b;
        }
        r rVar = new r();
        HashMap map = t.f884a;
        boolean z4 = pVar instanceof o;
        boolean z5 = pVar instanceof e;
        if (z4 && z5) {
            reflectiveGenericLifecycleObserver = new DefaultLifecycleObserverAdapter((e) pVar, (o) pVar);
        } else if (z5) {
            reflectiveGenericLifecycleObserver = new DefaultLifecycleObserverAdapter((e) pVar, null);
        } else if (z4) {
            reflectiveGenericLifecycleObserver = (o) pVar;
        } else {
            Class<?> cls = pVar.getClass();
            if (t.b(cls) == 2) {
                Object obj2 = t.f885b.get(cls);
                kotlin.jvm.internal.d.c(obj2);
                List list = (List) obj2;
                if (list.size() == 1) {
                    t.a((Constructor) list.get(0), pVar);
                    throw null;
                }
                int size = list.size();
                h[] hVarArr = new h[size];
                if (size > 0) {
                    t.a((Constructor) list.get(0), pVar);
                    throw null;
                }
                reflectiveGenericLifecycleObserver = new CompositeGeneratedAdaptersObserver(hVarArr);
            } else {
                reflectiveGenericLifecycleObserver = new ReflectiveGenericLifecycleObserver(pVar);
            }
        }
        rVar.f876b = reflectiveGenericLifecycleObserver;
        rVar.f875a = lifecycle$State2;
        n.a aVar = this.f878b;
        n.c cVarA = aVar.a(pVar);
        if (cVarA != null) {
            obj = cVarA.f3393b;
        } else {
            HashMap map2 = aVar.f3388e;
            n.c cVar = new n.c(pVar, rVar);
            aVar.f3402d++;
            n.c cVar2 = aVar.f3400b;
            if (cVar2 == null) {
                aVar.f3399a = cVar;
                aVar.f3400b = cVar;
            } else {
                cVar2.f3394c = cVar;
                cVar.f3395d = cVar2;
                aVar.f3400b = cVar;
            }
            map2.put(pVar, cVar);
            obj = null;
        }
        if (((r) obj) == null && (qVar = (q) this.f880d.get()) != null) {
            boolean z6 = this.f881e != 0 || this.f;
            Lifecycle$State lifecycle$StateB = b(pVar);
            this.f881e++;
            while (rVar.f875a.compareTo(lifecycle$StateB) < 0 && this.f878b.f3388e.containsKey(pVar)) {
                Lifecycle$State lifecycle$State3 = rVar.f875a;
                ArrayList arrayList = this.f883h;
                arrayList.add(lifecycle$State3);
                k kVar = Lifecycle$Event.Companion;
                Lifecycle$State state = rVar.f875a;
                kVar.getClass();
                kotlin.jvm.internal.d.f(state, "state");
                int iOrdinal = state.ordinal();
                if (iOrdinal == 1) {
                    lifecycle$Event = Lifecycle$Event.ON_CREATE;
                } else if (iOrdinal != 2) {
                    lifecycle$Event = iOrdinal != 3 ? null : Lifecycle$Event.ON_RESUME;
                } else {
                    lifecycle$Event = Lifecycle$Event.ON_START;
                }
                if (lifecycle$Event == null) {
                    throw new IllegalStateException("no event up from " + rVar.f875a);
                }
                rVar.a(qVar, lifecycle$Event);
                arrayList.remove(arrayList.size() - 1);
                lifecycle$StateB = b(pVar);
            }
            if (!z6) {
                h();
            }
            this.f881e--;
        }
    }

    public final Lifecycle$State b(p pVar) {
        HashMap map = this.f878b.f3388e;
        n.c cVar = map.containsKey(pVar) ? ((n.c) map.get(pVar)).f3395d : null;
        Lifecycle$State lifecycle$State = cVar != null ? ((r) cVar.f3393b).f875a : null;
        ArrayList arrayList = this.f883h;
        Lifecycle$State lifecycle$State2 = arrayList.isEmpty() ? null : (Lifecycle$State) arrayList.get(arrayList.size() - 1);
        Lifecycle$State state1 = this.f879c;
        kotlin.jvm.internal.d.f(state1, "state1");
        if (lifecycle$State == null || lifecycle$State.compareTo(state1) >= 0) {
            lifecycle$State = state1;
        }
        return (lifecycle$State2 == null || lifecycle$State2.compareTo(lifecycle$State) >= 0) ? lifecycle$State : lifecycle$State2;
    }

    public final void c(String str) {
        if (this.f877a) {
            m.a.R().f.getClass();
            if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
                throw new IllegalStateException(g0.e.d("Method ", str, " must be called on the main thread").toString());
            }
        }
    }

    public final void d(Lifecycle$Event event) {
        kotlin.jvm.internal.d.f(event, "event");
        c("handleLifecycleEvent");
        e(event.a());
    }

    public final void e(Lifecycle$State lifecycle$State) {
        Lifecycle$State lifecycle$State2 = this.f879c;
        if (lifecycle$State2 == lifecycle$State) {
            return;
        }
        Lifecycle$State lifecycle$State3 = Lifecycle$State.f830b;
        Lifecycle$State lifecycle$State4 = Lifecycle$State.f829a;
        if (lifecycle$State2 == lifecycle$State3 && lifecycle$State == lifecycle$State4) {
            throw new IllegalStateException(("no event down from " + this.f879c + " in component " + this.f880d.get()).toString());
        }
        this.f879c = lifecycle$State;
        if (this.f || this.f881e != 0) {
            this.f882g = true;
            return;
        }
        this.f = true;
        h();
        this.f = false;
        if (this.f879c == lifecycle$State4) {
            this.f878b = new n.a();
        }
    }

    public final void f(p observer) {
        kotlin.jvm.internal.d.f(observer, "observer");
        c("removeObserver");
        this.f878b.b(observer);
    }

    public final void g() {
        c("setCurrentState");
        e(Lifecycle$State.f831c);
    }

    public final void h() {
        Lifecycle$Event lifecycle$Event;
        Lifecycle$Event lifecycle$Event2;
        q qVar = (q) this.f880d.get();
        if (qVar == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
        while (true) {
            n.a aVar = this.f878b;
            if (aVar.f3402d != 0) {
                n.c cVar = aVar.f3399a;
                kotlin.jvm.internal.d.c(cVar);
                Lifecycle$State lifecycle$State = ((r) cVar.f3393b).f875a;
                n.c cVar2 = this.f878b.f3400b;
                kotlin.jvm.internal.d.c(cVar2);
                Lifecycle$State lifecycle$State2 = ((r) cVar2.f3393b).f875a;
                if (lifecycle$State == lifecycle$State2 && this.f879c == lifecycle$State2) {
                    break;
                }
                this.f882g = false;
                Lifecycle$State lifecycle$State3 = this.f879c;
                n.c cVar3 = this.f878b.f3399a;
                kotlin.jvm.internal.d.c(cVar3);
                int iCompareTo = lifecycle$State3.compareTo(((r) cVar3.f3393b).f875a);
                ArrayList arrayList = this.f883h;
                if (iCompareTo < 0) {
                    n.a aVar2 = this.f878b;
                    n.b bVar = new n.b(aVar2.f3400b, aVar2.f3399a, 1);
                    aVar2.f3401c.put(bVar, Boolean.FALSE);
                    while (bVar.hasNext() && !this.f882g) {
                        Map.Entry entry = (Map.Entry) bVar.next();
                        kotlin.jvm.internal.d.e(entry, "next()");
                        p pVar = (p) entry.getKey();
                        r rVar = (r) entry.getValue();
                        while (rVar.f875a.compareTo(this.f879c) > 0 && !this.f882g && this.f878b.f3388e.containsKey(pVar)) {
                            k kVar = Lifecycle$Event.Companion;
                            Lifecycle$State state = rVar.f875a;
                            kVar.getClass();
                            kotlin.jvm.internal.d.f(state, "state");
                            int iOrdinal = state.ordinal();
                            if (iOrdinal == 2) {
                                lifecycle$Event2 = Lifecycle$Event.ON_DESTROY;
                            } else if (iOrdinal != 3) {
                                lifecycle$Event2 = iOrdinal != 4 ? null : Lifecycle$Event.ON_PAUSE;
                            } else {
                                lifecycle$Event2 = Lifecycle$Event.ON_STOP;
                            }
                            if (lifecycle$Event2 == null) {
                                throw new IllegalStateException("no event down from " + rVar.f875a);
                            }
                            arrayList.add(lifecycle$Event2.a());
                            rVar.a(qVar, lifecycle$Event2);
                            arrayList.remove(arrayList.size() - 1);
                        }
                    }
                }
                n.c cVar4 = this.f878b.f3400b;
                if (!this.f882g && cVar4 != null && this.f879c.compareTo(((r) cVar4.f3393b).f875a) > 0) {
                    n.a aVar3 = this.f878b;
                    aVar3.getClass();
                    n.d dVar = new n.d(aVar3);
                    aVar3.f3401c.put(dVar, Boolean.FALSE);
                    while (dVar.hasNext() && !this.f882g) {
                        Map.Entry entry2 = (Map.Entry) dVar.next();
                        p pVar2 = (p) entry2.getKey();
                        r rVar2 = (r) entry2.getValue();
                        while (rVar2.f875a.compareTo(this.f879c) < 0 && !this.f882g && this.f878b.f3388e.containsKey(pVar2)) {
                            arrayList.add(rVar2.f875a);
                            k kVar2 = Lifecycle$Event.Companion;
                            Lifecycle$State state2 = rVar2.f875a;
                            kVar2.getClass();
                            kotlin.jvm.internal.d.f(state2, "state");
                            int iOrdinal2 = state2.ordinal();
                            if (iOrdinal2 == 1) {
                                lifecycle$Event = Lifecycle$Event.ON_CREATE;
                            } else if (iOrdinal2 != 2) {
                                lifecycle$Event = iOrdinal2 != 3 ? null : Lifecycle$Event.ON_RESUME;
                            } else {
                                lifecycle$Event = Lifecycle$Event.ON_START;
                            }
                            if (lifecycle$Event == null) {
                                throw new IllegalStateException("no event up from " + rVar2.f875a);
                            }
                            rVar2.a(qVar, lifecycle$Event);
                            arrayList.remove(arrayList.size() - 1);
                        }
                    }
                }
            } else {
                break;
            }
        }
        this.f882g = false;
    }
}
