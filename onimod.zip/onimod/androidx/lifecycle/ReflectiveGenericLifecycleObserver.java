package androidx.lifecycle;

import java.util.HashMap;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
class ReflectiveGenericLifecycleObserver implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p f835a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a f836b;

    public ReflectiveGenericLifecycleObserver(p pVar) {
        this.f835a = pVar;
        c cVar = c.f852c;
        Class<?> cls = pVar.getClass();
        a aVar = (a) cVar.f853a.get(cls);
        this.f836b = aVar == null ? cVar.a(cls, null) : aVar;
    }

    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        HashMap map = this.f836b.f840a;
        List list = (List) map.get(lifecycle$Event);
        p pVar = this.f835a;
        a.a(list, qVar, lifecycle$Event, pVar);
        a.a((List) map.get(Lifecycle$Event.ON_ANY), qVar, lifecycle$Event, pVar);
    }
}
