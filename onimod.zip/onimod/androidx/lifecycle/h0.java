package androidx.lifecycle;

import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class h0 extends i0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LinkedHashMap f866d = new LinkedHashMap();
}
