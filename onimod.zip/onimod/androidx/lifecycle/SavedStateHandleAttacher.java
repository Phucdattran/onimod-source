package androidx.lifecycle;

import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public final class SavedStateHandleAttacher implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g0 f837a;

    public SavedStateHandleAttacher(g0 g0Var) {
        this.f837a = g0Var;
    }

    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        if (lifecycle$Event != Lifecycle$Event.ON_CREATE) {
            throw new IllegalStateException(("Next event must be ON_CREATE, it was " + lifecycle$Event).toString());
        }
        qVar.e().f(this);
        g0 g0Var = this.f837a;
        if (g0Var.f863b) {
            return;
        }
        Bundle bundleC = g0Var.f862a.c("androidx.lifecycle.internal.SavedStateHandlesProvider");
        Bundle bundle = new Bundle();
        Bundle bundle2 = g0Var.f864c;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        if (bundleC != null) {
            bundle.putAll(bundleC);
        }
        g0Var.f864c = bundle;
        g0Var.f863b = true;
    }
}
