package androidx.lifecycle;

import android.os.Looper;
import androidx.fragment.app.w0;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class w {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final Object f890k = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f891a = new Object();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final n.f f892b = new n.f();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f893c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f894d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public volatile Object f895e;
    public volatile Object f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f896g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f897h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f898i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final a2.i f899j;

    public w() {
        Object obj = f890k;
        this.f = obj;
        this.f899j = new a2.i(6, this);
        this.f895e = obj;
        this.f896g = -1;
    }

    public static void a(String str) {
        m.a.R().f.getClass();
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException(g0.e.d("Cannot invoke ", str, " on a background thread"));
        }
    }

    public final void b(v vVar) {
        if (vVar.f887b) {
            if (!vVar.f()) {
                vVar.c(false);
                return;
            }
            int i3 = vVar.f888c;
            int i4 = this.f896g;
            if (i3 >= i4) {
                return;
            }
            vVar.f888c = i4;
            vVar.f886a.a(this.f895e);
        }
    }

    public final void c(v vVar) {
        if (this.f897h) {
            this.f898i = true;
            return;
        }
        this.f897h = true;
        do {
            this.f898i = false;
            if (vVar != null) {
                b(vVar);
                vVar = null;
            } else {
                n.f fVar = this.f892b;
                fVar.getClass();
                n.d dVar = new n.d(fVar);
                fVar.f3401c.put(dVar, Boolean.FALSE);
                while (dVar.hasNext()) {
                    b((v) ((Map.Entry) dVar.next()).getValue());
                    if (this.f898i) {
                        break;
                    }
                }
            }
        } while (this.f898i);
        this.f897h = false;
    }

    public final void d(w0 w0Var, x xVar) {
        Object obj;
        a("observe");
        w0Var.f();
        if (w0Var.f801c.f879c == Lifecycle$State.f829a) {
            return;
        }
        LiveData$LifecycleBoundObserver liveData$LifecycleBoundObserver = new LiveData$LifecycleBoundObserver(this, w0Var, xVar);
        n.f fVar = this.f892b;
        n.c cVarA = fVar.a(xVar);
        if (cVarA != null) {
            obj = cVarA.f3393b;
        } else {
            n.c cVar = new n.c(xVar, liveData$LifecycleBoundObserver);
            fVar.f3402d++;
            n.c cVar2 = fVar.f3400b;
            if (cVar2 == null) {
                fVar.f3399a = cVar;
                fVar.f3400b = cVar;
            } else {
                cVar2.f3394c = cVar;
                cVar.f3395d = cVar2;
                fVar.f3400b = cVar;
            }
            obj = null;
        }
        v vVar = (v) obj;
        if (vVar != null && !vVar.e(w0Var)) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (vVar != null) {
            return;
        }
        w0Var.f();
        w0Var.f801c.a(liveData$LifecycleBoundObserver);
    }

    public final void e(androidx.fragment.app.m mVar) {
        Object obj;
        a("observeForever");
        u uVar = new u(this, mVar);
        n.f fVar = this.f892b;
        n.c cVarA = fVar.a(mVar);
        if (cVarA != null) {
            obj = cVarA.f3393b;
        } else {
            n.c cVar = new n.c(mVar, uVar);
            fVar.f3402d++;
            n.c cVar2 = fVar.f3400b;
            if (cVar2 == null) {
                fVar.f3399a = cVar;
                fVar.f3400b = cVar;
            } else {
                cVar2.f3394c = cVar;
                cVar.f3395d = cVar2;
                fVar.f3400b = cVar;
            }
            obj = null;
        }
        v vVar = (v) obj;
        if (vVar instanceof LiveData$LifecycleBoundObserver) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (vVar != null) {
            return;
        }
        uVar.c(true);
    }

    public final void f(Object obj) {
        boolean z4;
        synchronized (this.f891a) {
            z4 = this.f == f890k;
            this.f = obj;
        }
        if (z4) {
            m.a.R().S(this.f899j);
        }
    }

    public final void g(Object obj) {
        a("setValue");
        this.f896g++;
        this.f895e = obj;
        c(null);
    }
}
