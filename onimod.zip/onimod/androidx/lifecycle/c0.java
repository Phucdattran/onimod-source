package androidx.lifecycle;

import android.app.Activity;
import android.app.FragmentManager;
import android.os.Build;

/* JADX INFO: loaded from: classes.dex */
public abstract class c0 {
    /* JADX WARN: Multi-variable type inference failed */
    public static void a(Activity activity, Lifecycle$Event event) {
        kotlin.jvm.internal.d.f(event, "event");
        if (activity instanceof q) {
            s sVarE = ((q) activity).e();
            if (g0.e.g(sVarE)) {
                sVarE.d(event);
            }
        }
    }

    public static void b(Activity activity) {
        if (Build.VERSION.SDK_INT >= 29) {
            e0.a.Companion.getClass();
            activity.registerActivityLifecycleCallbacks(new e0.a());
        }
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new e0(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }
}
