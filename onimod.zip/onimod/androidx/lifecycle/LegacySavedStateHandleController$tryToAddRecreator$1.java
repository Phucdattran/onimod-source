package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class LegacySavedStateHandleController$tryToAddRecreator$1 implements o {
    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        if (lifecycle$Event == Lifecycle$Event.ON_START) {
            throw null;
        }
    }
}
