package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class a0 extends g {
    final /* synthetic */ b0 this$0;

    public static final class a extends g {
        final /* synthetic */ b0 this$0;

        public a(b0 b0Var) {
            this.this$0 = b0Var;
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            kotlin.jvm.internal.d.f(activity, "activity");
            this.this$0.a();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            kotlin.jvm.internal.d.f(activity, "activity");
            b0 b0Var = this.this$0;
            int i3 = b0Var.f845a + 1;
            b0Var.f845a = i3;
            if (i3 == 1 && b0Var.f848d) {
                b0Var.f.d(Lifecycle$Event.ON_START);
                b0Var.f848d = false;
            }
        }
    }

    public a0(b0 b0Var) {
        this.this$0 = b0Var;
    }

    @Override // androidx.lifecycle.g, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        kotlin.jvm.internal.d.f(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i3 = e0.f856b;
            Fragment fragmentFindFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            kotlin.jvm.internal.d.d(fragmentFindFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((e0) fragmentFindFragmentByTag).f857a = this.this$0.f851h;
        }
    }

    @Override // androidx.lifecycle.g, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        kotlin.jvm.internal.d.f(activity, "activity");
        b0 b0Var = this.this$0;
        int i3 = b0Var.f846b - 1;
        b0Var.f846b = i3;
        if (i3 == 0) {
            Handler handler = b0Var.f849e;
            kotlin.jvm.internal.d.c(handler);
            handler.postDelayed(b0Var.f850g, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        kotlin.jvm.internal.d.f(activity, "activity");
        z.a(activity, new a(this.this$0));
    }

    @Override // androidx.lifecycle.g, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        kotlin.jvm.internal.d.f(activity, "activity");
        b0 b0Var = this.this$0;
        int i3 = b0Var.f845a - 1;
        b0Var.f845a = i3;
        if (i3 == 0 && b0Var.f847c) {
            b0Var.f.d(Lifecycle$Event.ON_STOP);
            b0Var.f848d = true;
        }
    }
}
