package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface k0 {
    i0 a(Class cls);

    i0 c(Class cls, a1.c cVar);
}
