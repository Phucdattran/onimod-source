package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface i {
    a1.c a();
}
