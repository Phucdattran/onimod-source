package androidx.lifecycle;

import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class b0 implements q {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final b0 f844i = new b0();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f845a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f846b;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Handler f849e;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f847c = true;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f848d = true;
    public final s f = new s(this);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final a4.b f850g = new a4.b(6, this);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final a0.b f851h = new a0.b(5, this);

    public final void a() {
        int i3 = this.f846b + 1;
        this.f846b = i3;
        if (i3 == 1) {
            if (this.f847c) {
                this.f.d(Lifecycle$Event.ON_RESUME);
                this.f847c = false;
            } else {
                Handler handler = this.f849e;
                kotlin.jvm.internal.d.c(handler);
                handler.removeCallbacks(this.f850g);
            }
        }
    }

    @Override // androidx.lifecycle.q
    public final s e() {
        return this.f;
    }
}
