package androidx.lifecycle;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class CompositeGeneratedAdaptersObserver implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final h[] f826a;

    public CompositeGeneratedAdaptersObserver(h[] hVarArr) {
        this.f826a = hVarArr;
    }

    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        new HashMap();
        h[] hVarArr = this.f826a;
        if (hVarArr.length > 0) {
            h hVar = hVarArr[0];
            throw null;
        }
        if (hVarArr.length <= 0) {
            return;
        }
        h hVar2 = hVarArr[0];
        throw null;
    }
}
