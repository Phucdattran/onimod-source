package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$observer$1 implements o {
    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        Lifecycle$Event.Companion.getClass();
        kotlin.jvm.internal.d.f(null, "state");
        throw null;
    }
}
