package androidx.lifecycle;

import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f842a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Method f843b;

    public b(int i3, Method method) {
        this.f842a = i3;
        this.f843b = method;
        method.setAccessible(true);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return this.f842a == bVar.f842a && this.f843b.getName().equals(bVar.f843b.getName());
    }

    public final int hashCode() {
        return this.f843b.getName().hashCode() + (this.f842a * 31);
    }
}
