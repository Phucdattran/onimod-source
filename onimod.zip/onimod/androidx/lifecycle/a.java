package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f840a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f841b;

    public a(HashMap map) {
        this.f841b = map;
        for (Map.Entry entry : map.entrySet()) {
            Lifecycle$Event lifecycle$Event = (Lifecycle$Event) entry.getValue();
            List arrayList = (List) this.f840a.get(lifecycle$Event);
            if (arrayList == null) {
                arrayList = new ArrayList();
                this.f840a.put(lifecycle$Event, arrayList);
            }
            arrayList.add((b) entry.getKey());
        }
    }

    public static void a(List list, q qVar, Lifecycle$Event lifecycle$Event, p pVar) {
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                b bVar = (b) list.get(size);
                Method method = bVar.f843b;
                try {
                    int i3 = bVar.f842a;
                    if (i3 == 0) {
                        method.invoke(pVar, null);
                    } else if (i3 == 1) {
                        method.invoke(pVar, qVar);
                    } else if (i3 == 2) {
                        method.invoke(pVar, qVar, lifecycle$Event);
                    }
                } catch (IllegalAccessException e4) {
                    throw new RuntimeException(e4);
                } catch (InvocationTargetException e5) {
                    throw new RuntimeException("Failed to call observer method", e5.getCause());
                }
            }
        }
    }
}
