package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface o extends p {
    void a(q qVar, Lifecycle$Event lifecycle$Event);
}
