package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;

/* JADX INFO: loaded from: classes.dex */
public abstract class z {
    public static final void a(Activity activity, Application.ActivityLifecycleCallbacks callback) {
        kotlin.jvm.internal.d.f(activity, "activity");
        kotlin.jvm.internal.d.f(callback, "callback");
        activity.registerActivityLifecycleCallbacks(callback);
    }
}
