package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class DefaultLifecycleObserverAdapter implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e f827a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final o f828b;

    public DefaultLifecycleObserverAdapter(e eVar, o oVar) {
        this.f827a = eVar;
        this.f828b = oVar;
    }

    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        int i3 = f.f858a[lifecycle$Event.ordinal()];
        if (i3 == 3) {
            this.f827a.b();
        } else if (i3 == 7) {
            throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        o oVar = this.f828b;
        if (oVar != null) {
            oVar.a(qVar, lifecycle$Event);
        }
    }
}
