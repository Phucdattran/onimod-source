package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class j0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final j0 f870a = new j0();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final j0 f871b = new j0();
}
