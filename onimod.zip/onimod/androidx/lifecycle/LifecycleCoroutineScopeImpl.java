package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class LifecycleCoroutineScopeImpl implements o, kotlinx.coroutines.k {
    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        throw null;
    }

    @Override // kotlinx.coroutines.k
    public final b3.g e() {
        return null;
    }
}
