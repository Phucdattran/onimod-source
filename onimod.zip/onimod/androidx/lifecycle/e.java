package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface e extends p {
    void b();
}
