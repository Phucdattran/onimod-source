package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class SavedStateHandleController implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f838a;

    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        if (lifecycle$Event == Lifecycle$Event.ON_DESTROY) {
            this.f838a = false;
            qVar.e().f(this);
        }
    }
}
