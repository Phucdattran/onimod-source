package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class j implements f1.b {
}
