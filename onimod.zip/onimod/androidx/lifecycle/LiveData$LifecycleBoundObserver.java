package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
class LiveData$LifecycleBoundObserver extends v implements o {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final q f834e;
    public final /* synthetic */ w f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public LiveData$LifecycleBoundObserver(w wVar, q qVar, x xVar) {
        super(wVar, xVar);
        this.f = wVar;
        this.f834e = qVar;
    }

    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        q qVar2 = this.f834e;
        Lifecycle$State lifecycle$State = qVar2.e().f879c;
        if (lifecycle$State == Lifecycle$State.f829a) {
            w.a("removeObserver");
            v vVar = (v) this.f.f892b.b(this.f886a);
            if (vVar == null) {
                return;
            }
            vVar.d();
            vVar.c(false);
            return;
        }
        Lifecycle$State lifecycle$State2 = null;
        while (lifecycle$State2 != lifecycle$State) {
            c(f());
            lifecycle$State2 = lifecycle$State;
            lifecycle$State = qVar2.e().f879c;
        }
    }

    @Override // androidx.lifecycle.v
    public final void d() {
        this.f834e.e().f(this);
    }

    @Override // androidx.lifecycle.v
    public final boolean e(q qVar) {
        return this.f834e == qVar;
    }

    @Override // androidx.lifecycle.v
    public final boolean f() {
        return this.f834e.e().f879c.compareTo(Lifecycle$State.f832d) >= 0;
    }
}
