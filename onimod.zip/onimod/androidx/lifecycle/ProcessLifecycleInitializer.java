package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.List;
import kotlin.collections.EmptyList;

/* JADX INFO: loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements g1.b {
    @Override // g1.b
    public final List a() {
        return EmptyList.f2819a;
    }

    @Override // g1.b
    public final Object b(Context context) {
        kotlin.jvm.internal.d.f(context, "context");
        g1.a aVarC = g1.a.c(context);
        kotlin.jvm.internal.d.e(aVarC, "getInstance(context)");
        if (!aVarC.f2348b.contains(ProcessLifecycleInitializer.class)) {
            throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
        }
        if (!n.f874a.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            kotlin.jvm.internal.d.d(applicationContext, "null cannot be cast to non-null type android.app.Application");
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new m());
        }
        b0 b0Var = b0.f844i;
        b0Var.getClass();
        b0Var.f849e = new Handler();
        b0Var.f.d(Lifecycle$Event.ON_CREATE);
        Context applicationContext2 = context.getApplicationContext();
        kotlin.jvm.internal.d.d(applicationContext2, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext2).registerActivityLifecycleCallbacks(new a0(b0Var));
        return b0Var;
    }
}
