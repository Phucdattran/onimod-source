package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class Lifecycle$State {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Lifecycle$State f829a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Lifecycle$State f830b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Lifecycle$State f831c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Lifecycle$State f832d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Lifecycle$State f833e;
    public static final /* synthetic */ Lifecycle$State[] f;

    static {
        Lifecycle$State lifecycle$State = new Lifecycle$State("DESTROYED", 0);
        f829a = lifecycle$State;
        Lifecycle$State lifecycle$State2 = new Lifecycle$State("INITIALIZED", 1);
        f830b = lifecycle$State2;
        Lifecycle$State lifecycle$State3 = new Lifecycle$State("CREATED", 2);
        f831c = lifecycle$State3;
        Lifecycle$State lifecycle$State4 = new Lifecycle$State("STARTED", 3);
        f832d = lifecycle$State4;
        Lifecycle$State lifecycle$State5 = new Lifecycle$State("RESUMED", 4);
        f833e = lifecycle$State5;
        f = new Lifecycle$State[]{lifecycle$State, lifecycle$State2, lifecycle$State3, lifecycle$State4, lifecycle$State5};
    }

    public static Lifecycle$State valueOf(String str) {
        return (Lifecycle$State) Enum.valueOf(Lifecycle$State.class, str);
    }

    public static Lifecycle$State[] values() {
        return (Lifecycle$State[]) f.clone();
    }
}
