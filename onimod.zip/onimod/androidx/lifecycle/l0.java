package androidx.lifecycle;

import java.io.Closeable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

/* JADX INFO: loaded from: classes.dex */
public final class l0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f873a = new LinkedHashMap();

    public final void a() {
        for (i0 i0Var : this.f873a.values()) {
            i0Var.f869c = true;
            HashMap map = i0Var.f867a;
            if (map != null) {
                synchronized (map) {
                    try {
                        Iterator it = i0Var.f867a.values().iterator();
                        while (it.hasNext()) {
                            i0.a(it.next());
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            }
            LinkedHashSet linkedHashSet = i0Var.f868b;
            if (linkedHashSet != null) {
                synchronized (linkedHashSet) {
                    try {
                        Iterator it2 = i0Var.f868b.iterator();
                        while (it2.hasNext()) {
                            i0.a((Closeable) it2.next());
                        }
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
            }
            i0Var.c();
        }
        this.f873a.clear();
    }
}
