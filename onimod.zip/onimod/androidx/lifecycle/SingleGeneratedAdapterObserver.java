package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class SingleGeneratedAdapterObserver implements o {
    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        throw null;
    }
}
