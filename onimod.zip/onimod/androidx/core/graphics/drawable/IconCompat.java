package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.versionedparcelable.CustomVersionedParcelable;
import h0.b;
import java.lang.reflect.InvocationTargetException;
import top.niunaijun.blackbox.entity.location.BCell;

/* JADX INFO: loaded from: classes.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final PorterDuff.Mode f478k = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f480b;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f487j;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f479a = -1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public byte[] f481c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Parcelable f482d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f483e = 0;
    public int f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f484g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f485h = f478k;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public String f486i = null;

    public static Bitmap a(Bitmap bitmap, boolean z4) {
        int iMin = (int) (Math.min(bitmap.getWidth(), bitmap.getHeight()) * 0.6666667f);
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(iMin, iMin, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        Paint paint = new Paint(3);
        float f = iMin;
        float f4 = 0.5f * f;
        float f5 = 0.9166667f * f4;
        if (z4) {
            float f6 = 0.010416667f * f;
            paint.setColor(0);
            paint.setShadowLayer(f6, 0.0f, f * 0.020833334f, 1023410176);
            canvas.drawCircle(f4, f4, f5, paint);
            paint.setShadowLayer(f6, 0.0f, 0.0f, 503316480);
            canvas.drawCircle(f4, f4, f5, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
        Matrix matrix = new Matrix();
        matrix.setTranslate((-(bitmap.getWidth() - iMin)) / 2.0f, (-(bitmap.getHeight() - iMin)) / 2.0f);
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader(bitmapShader);
        canvas.drawCircle(f4, f4, f5, paint);
        canvas.setBitmap(null);
        return bitmapCreateBitmap;
    }

    public final String b() {
        int i3;
        int i4 = this.f479a;
        if (i4 == -1 && (i3 = Build.VERSION.SDK_INT) >= 23) {
            Object obj = this.f480b;
            if (i3 >= 28) {
                return b.d(obj);
            }
            try {
                return (String) obj.getClass().getMethod("getResPackage", null).invoke(obj, null);
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
                return null;
            }
        }
        if (i4 == 2) {
            String str = this.f487j;
            return (str == null || TextUtils.isEmpty(str)) ? ((String) this.f480b).split(":", -1)[0] : this.f487j;
        }
        throw new IllegalStateException("called getResPackage() on " + this);
    }

    public final Uri c() {
        int i3;
        int i4 = this.f479a;
        if (i4 == -1 && (i3 = Build.VERSION.SDK_INT) >= 23) {
            Object obj = this.f480b;
            if (i3 >= 28) {
                return b.k(obj);
            }
            try {
                return (Uri) obj.getClass().getMethod("getUri", null).invoke(obj, null);
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
                return null;
            }
        }
        if (i4 == 4 || i4 == 6) {
            return Uri.parse((String) this.f480b);
        }
        throw new IllegalStateException("called getUri() on " + this);
    }

    public final String toString() {
        String str;
        int iIntValue;
        int i3;
        if (this.f479a == -1) {
            return String.valueOf(this.f480b);
        }
        StringBuilder sb = new StringBuilder("Icon(typ=");
        switch (this.f479a) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case 3:
                str = "DATA";
                break;
            case 4:
                str = "URI";
                break;
            case 5:
                str = "BITMAP_MASKABLE";
                break;
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        sb.append(str);
        switch (this.f479a) {
            case 1:
            case 5:
                sb.append(" size=");
                sb.append(((Bitmap) this.f480b).getWidth());
                sb.append("x");
                sb.append(((Bitmap) this.f480b).getHeight());
                break;
            case 2:
                sb.append(" pkg=");
                sb.append(this.f487j);
                sb.append(" id=");
                int i4 = this.f479a;
                if (i4 == -1 && (i3 = Build.VERSION.SDK_INT) >= 23) {
                    Object obj = this.f480b;
                    if (i3 >= 28) {
                        iIntValue = b.c(obj);
                    } else {
                        try {
                            iIntValue = ((Integer) obj.getClass().getMethod("getResId", null).invoke(obj, null)).intValue();
                        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
                            iIntValue = 0;
                        }
                    }
                } else {
                    if (i4 != 2) {
                        throw new IllegalStateException("called getResId() on " + this);
                    }
                    iIntValue = this.f483e;
                }
                sb.append(String.format("0x%08x", Integer.valueOf(iIntValue)));
                break;
            case 3:
                sb.append(" len=");
                sb.append(this.f483e);
                if (this.f != 0) {
                    sb.append(" off=");
                    sb.append(this.f);
                }
                break;
            case 4:
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                sb.append(" uri=");
                sb.append(this.f480b);
                break;
        }
        if (this.f484g != null) {
            sb.append(" tint=");
            sb.append(this.f484g);
        }
        if (this.f485h != f478k) {
            sb.append(" mode=");
            sb.append(this.f485h);
        }
        sb.append(")");
        return sb.toString();
    }
}
