package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;
import k1.a;
import k1.b;
import top.niunaijun.blackbox.entity.location.BCell;

/* JADX INFO: loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        int i3 = iconCompat.f479a;
        if (aVar.e(1)) {
            i3 = ((b) aVar).f2790e.readInt();
        }
        iconCompat.f479a = i3;
        byte[] bArr = iconCompat.f481c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).f2790e;
            int i4 = parcel.readInt();
            if (i4 < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[i4];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f481c = bArr;
        iconCompat.f482d = aVar.f(iconCompat.f482d, 3);
        int i5 = iconCompat.f483e;
        if (aVar.e(4)) {
            i5 = ((b) aVar).f2790e.readInt();
        }
        iconCompat.f483e = i5;
        int i6 = iconCompat.f;
        if (aVar.e(5)) {
            i6 = ((b) aVar).f2790e.readInt();
        }
        iconCompat.f = i6;
        iconCompat.f484g = (ColorStateList) aVar.f(iconCompat.f484g, 6);
        String string = iconCompat.f486i;
        if (aVar.e(7)) {
            string = ((b) aVar).f2790e.readString();
        }
        iconCompat.f486i = string;
        String string2 = iconCompat.f487j;
        if (aVar.e(8)) {
            string2 = ((b) aVar).f2790e.readString();
        }
        iconCompat.f487j = string2;
        iconCompat.f485h = PorterDuff.Mode.valueOf(iconCompat.f486i);
        switch (iconCompat.f479a) {
            case -1:
                Parcelable parcelable = iconCompat.f482d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.f480b = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f482d;
                if (parcelable2 != null) {
                    iconCompat.f480b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.f481c;
                iconCompat.f480b = bArr3;
                iconCompat.f479a = 3;
                iconCompat.f483e = 0;
                iconCompat.f = bArr3.length;
                return iconCompat;
            case 2:
            case 4:
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                String str = new String(iconCompat.f481c, Charset.forName("UTF-16"));
                iconCompat.f480b = str;
                if (iconCompat.f479a == 2 && iconCompat.f487j == null) {
                    iconCompat.f487j = str.split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.f480b = iconCompat.f481c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f486i = iconCompat.f485h.name();
        switch (iconCompat.f479a) {
            case -1:
                iconCompat.f482d = (Parcelable) iconCompat.f480b;
                break;
            case 1:
            case 5:
                iconCompat.f482d = (Parcelable) iconCompat.f480b;
                break;
            case 2:
                iconCompat.f481c = ((String) iconCompat.f480b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f481c = (byte[]) iconCompat.f480b;
                break;
            case 4:
            case BCell.NETWORK_TYPE_EVDO_A /* 6 */:
                iconCompat.f481c = iconCompat.f480b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i3 = iconCompat.f479a;
        if (-1 != i3) {
            aVar.h(1);
            ((b) aVar).f2790e.writeInt(i3);
        }
        byte[] bArr = iconCompat.f481c;
        if (bArr != null) {
            aVar.h(2);
            Parcel parcel = ((b) aVar).f2790e;
            parcel.writeInt(bArr.length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f482d;
        if (parcelable != null) {
            aVar.h(3);
            ((b) aVar).f2790e.writeParcelable(parcelable, 0);
        }
        int i4 = iconCompat.f483e;
        if (i4 != 0) {
            aVar.h(4);
            ((b) aVar).f2790e.writeInt(i4);
        }
        int i5 = iconCompat.f;
        if (i5 != 0) {
            aVar.h(5);
            ((b) aVar).f2790e.writeInt(i5);
        }
        ColorStateList colorStateList = iconCompat.f484g;
        if (colorStateList != null) {
            aVar.h(6);
            ((b) aVar).f2790e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f486i;
        if (str != null) {
            aVar.h(7);
            ((b) aVar).f2790e.writeString(str);
        }
        String str2 = iconCompat.f487j;
        if (str2 != null) {
            aVar.h(8);
            ((b) aVar).f2790e.writeString(str2);
        }
    }
}
