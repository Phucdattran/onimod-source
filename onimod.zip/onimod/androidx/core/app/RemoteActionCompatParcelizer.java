package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import k1.a;
import k1.b;
import k1.c;

/* JADX INFO: loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        c cVarG = remoteActionCompat.f468a;
        boolean z4 = true;
        if (aVar.e(1)) {
            cVarG = aVar.g();
        }
        remoteActionCompat.f468a = (IconCompat) cVarG;
        CharSequence charSequence = remoteActionCompat.f469b;
        if (aVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f2790e);
        }
        remoteActionCompat.f469b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f470c;
        if (aVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f2790e);
        }
        remoteActionCompat.f470c = charSequence2;
        remoteActionCompat.f471d = (PendingIntent) aVar.f(remoteActionCompat.f471d, 4);
        boolean z5 = remoteActionCompat.f472e;
        if (aVar.e(5)) {
            z5 = ((b) aVar).f2790e.readInt() != 0;
        }
        remoteActionCompat.f472e = z5;
        boolean z6 = remoteActionCompat.f;
        if (!aVar.e(6)) {
            z4 = z6;
        } else if (((b) aVar).f2790e.readInt() == 0) {
            z4 = false;
        }
        remoteActionCompat.f = z4;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) {
        aVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f468a;
        aVar.h(1);
        aVar.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.f469b;
        aVar.h(2);
        Parcel parcel = ((b) aVar).f2790e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f470c;
        aVar.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f471d;
        aVar.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z4 = remoteActionCompat.f472e;
        aVar.h(5);
        parcel.writeInt(z4 ? 1 : 0);
        boolean z5 = remoteActionCompat.f;
        aVar.h(6);
        parcel.writeInt(z5 ? 1 : 0);
    }
}
