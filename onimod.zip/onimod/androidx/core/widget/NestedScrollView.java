package androidx.core.widget;

import a0.b;
import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import com.google.android.material.datepicker.g;
import e1.t0;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import k0.a;
import o0.h0;
import o0.i0;
import o0.j;
import o0.l;
import o0.q;
import o0.r;
import o0.s;
import o0.z;
import r0.c;
import r0.e;
import r0.f;

/* JADX INFO: loaded from: classes.dex */
public class NestedScrollView extends FrameLayout implements l {
    public static final float C = (float) (Math.log(0.78d) / Math.log(0.9d));
    public static final g D = new g(3);
    public static final int[] E = {R.attr.fillViewport};
    public f A;
    public final o0.g B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f488a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f489b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Rect f490c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final OverScroller f491d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final EdgeEffect f492e;
    public final EdgeEffect f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f493g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f494h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f495i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public View f496j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f497k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public VelocityTracker f498l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f499m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f500n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f501o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f502p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f503q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f504r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final int[] f505s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int[] f506t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f507u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f508v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public r0.g f509w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final t0 f510x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final j f511y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public float f512z;

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, top.niunaijun.blackbox.R.attr.nestedScrollViewStyle);
        this.f490c = new Rect();
        this.f494h = true;
        this.f495i = false;
        this.f496j = null;
        this.f497k = false;
        this.f500n = true;
        this.f504r = -1;
        this.f505s = new int[2];
        this.f506t = new int[2];
        this.B = new o0.g(getContext(), new b(26, this));
        int i3 = Build.VERSION.SDK_INT;
        this.f492e = i3 >= 31 ? c.a(context, attributeSet) : new EdgeEffect(context);
        this.f = i3 >= 31 ? c.a(context, attributeSet) : new EdgeEffect(context);
        this.f488a = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.f491d = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f501o = viewConfiguration.getScaledTouchSlop();
        this.f502p = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f503q = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, E, top.niunaijun.blackbox.R.attr.nestedScrollViewStyle, 0);
        setFillViewport(typedArrayObtainStyledAttributes.getBoolean(0, false));
        typedArrayObtainStyledAttributes.recycle();
        this.f510x = new t0();
        this.f511y = new j(this);
        setNestedScrollingEnabled(true);
        h0.p(this, D);
    }

    public static boolean l(View view, NestedScrollView nestedScrollView) {
        if (view == nestedScrollView) {
            return true;
        }
        Object parent = view.getParent();
        return (parent instanceof ViewGroup) && l((View) parent, nestedScrollView);
    }

    @Override // o0.l
    public final void a(View view, int i3, int i4, int i5, int i6, int i7, int[] iArr) {
        n(i6, i7, iArr);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view);
    }

    @Override // o0.k
    public final void b(View view, int i3, int i4, int i5, int i6, int i7) {
        n(i6, i7, null);
    }

    @Override // o0.k
    public final boolean c(View view, View view2, int i3, int i4) {
        return (i3 & 2) != 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARN: Code duplicated, block: B:22:0x008b  */
    /* JADX WARN: Code duplicated, block: B:24:0x009a  */
    /* JADX WARN: Code duplicated, block: B:26:0x00bf  */
    /* JADX WARN: Code duplicated, block: B:30:0x00c9 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:31:0x00cb  */
    /* JADX WARN: Code duplicated, block: B:33:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:34:0x00dc  */
    /* JADX WARN: Code duplicated, block: B:36:0x00e2  */
    /* JADX WARN: Code duplicated, block: B:40:0x00fc  */
    /* JADX WARN: Code duplicated, block: B:42:0x0100  */
    @Override // android.view.View
    public final void computeScroll() {
        int iRound;
        int[] iArr;
        int i3;
        int scrollRange;
        int overScrollMode;
        if (this.f491d.isFinished()) {
            return;
        }
        this.f491d.computeScrollOffset();
        int currY = this.f491d.getCurrY();
        int i4 = currY - this.f508v;
        int height = getHeight();
        EdgeEffect edgeEffect = this.f492e;
        EdgeEffect edgeEffect2 = this.f;
        if (i4 <= 0 || q1.b.s(edgeEffect) == 0.0f) {
            if (i4 < 0 && q1.b.s(edgeEffect2) != 0.0f) {
                float f = height;
                iRound = Math.round(q1.b.O(edgeEffect2, (i4 * 4.0f) / f, 0.5f) * (f / 4.0f));
                if (iRound != i4) {
                    edgeEffect2.finish();
                }
            }
            int i5 = i4;
            this.f508v = currY;
            iArr = this.f506t;
            iArr[1] = 0;
            this.f511y.c(0, i5, 1, iArr, null);
            i3 = i5 - iArr[1];
            scrollRange = getScrollRange();
            if (a.a()) {
                e.a(this, Math.abs(this.f491d.getCurrVelocity()));
            }
            if (i3 != 0) {
                int scrollY = getScrollY();
                p(i3, getScrollX(), scrollY, scrollRange);
                int scrollY2 = getScrollY() - scrollY;
                int i6 = i3 - scrollY2;
                iArr[1] = 0;
                this.f511y.d(0, scrollY2, 0, i6, this.f505s, 1, iArr);
                i3 = i6 - iArr[1];
            }
            if (i3 != 0) {
                overScrollMode = getOverScrollMode();
                if (overScrollMode != 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    if (i3 < 0) {
                        if (edgeEffect.isFinished()) {
                            edgeEffect.onAbsorb((int) this.f491d.getCurrVelocity());
                        }
                    } else if (edgeEffect2.isFinished()) {
                        edgeEffect2.onAbsorb((int) this.f491d.getCurrVelocity());
                    }
                }
                this.f491d.abortAnimation();
                w(1);
            }
            if (this.f491d.isFinished()) {
                w(1);
            } else {
                postInvalidateOnAnimation();
            }
        }
        iRound = Math.round(q1.b.O(edgeEffect, ((-i4) * 4.0f) / height, 0.5f) * ((-height) / 4.0f));
        if (iRound != i4) {
            edgeEffect.finish();
        }
        i4 -= iRound;
        int i7 = i4;
        this.f508v = currY;
        iArr = this.f506t;
        iArr[1] = 0;
        this.f511y.c(0, i7, 1, iArr, null);
        i3 = i7 - iArr[1];
        scrollRange = getScrollRange();
        if (a.a()) {
            e.a(this, Math.abs(this.f491d.getCurrVelocity()));
        }
        if (i3 != 0) {
            int scrollY3 = getScrollY();
            p(i3, getScrollX(), scrollY3, scrollRange);
            int scrollY4 = getScrollY() - scrollY3;
            int i8 = i3 - scrollY4;
            iArr[1] = 0;
            this.f511y.d(0, scrollY4, 0, i8, this.f505s, 1, iArr);
            i3 = i8 - iArr[1];
        }
        if (i3 != 0) {
            overScrollMode = getOverScrollMode();
            if (overScrollMode != 0) {
                if (i3 < 0) {
                    if (edgeEffect.isFinished()) {
                        edgeEffect.onAbsorb((int) this.f491d.getCurrVelocity());
                    }
                } else if (edgeEffect2.isFinished()) {
                    edgeEffect2.onAbsorb((int) this.f491d.getCurrVelocity());
                }
            } else if (i3 < 0) {
                if (edgeEffect.isFinished()) {
                    edgeEffect.onAbsorb((int) this.f491d.getCurrVelocity());
                }
            } else if (edgeEffect2.isFinished()) {
                edgeEffect2.onAbsorb((int) this.f491d.getCurrVelocity());
            }
            this.f491d.abortAnimation();
            w(1);
        }
        if (this.f491d.isFinished()) {
            postInvalidateOnAnimation();
        } else {
            w(1);
        }
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int iMax = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        return scrollY > iMax ? (scrollY - iMax) + bottom : bottom;
    }

    @Override // o0.k
    public final void d(View view, View view2, int i3, int i4) {
        t0 t0Var = this.f510x;
        if (i4 == 1) {
            t0Var.f2069b = i3;
        } else {
            t0Var.f2068a = i3;
        }
        this.f511y.g(2, i4);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || i(keyEvent);
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f4, boolean z4) {
        return this.f511y.a(f, f4, z4);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f4) {
        return this.f511y.b(f, f4);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i3, int i4, int[] iArr, int[] iArr2) {
        return this.f511y.c(i3, i4, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i3, int i4, int i5, int i6, int[] iArr) {
        return this.f511y.d(i3, i4, i5, i6, iArr, 0, null);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int paddingLeft;
        super.draw(canvas);
        int scrollY = getScrollY();
        EdgeEffect edgeEffect = this.f492e;
        int paddingLeft2 = 0;
        if (!edgeEffect.isFinished()) {
            int iSave = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int iMin = Math.min(0, scrollY);
            if (getClipToPadding()) {
                width -= getPaddingRight() + getPaddingLeft();
                paddingLeft = getPaddingLeft();
            } else {
                paddingLeft = 0;
            }
            if (getClipToPadding()) {
                height -= getPaddingBottom() + getPaddingTop();
                iMin += getPaddingTop();
            }
            canvas.translate(paddingLeft, iMin);
            edgeEffect.setSize(width, height);
            if (edgeEffect.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect2 = this.f;
        if (edgeEffect2.isFinished()) {
            return;
        }
        int iSave2 = canvas.save();
        int width2 = getWidth();
        int height2 = getHeight();
        int iMax = Math.max(getScrollRange(), scrollY) + height2;
        if (getClipToPadding()) {
            width2 -= getPaddingRight() + getPaddingLeft();
            paddingLeft2 = getPaddingLeft();
        }
        if (getClipToPadding()) {
            height2 -= getPaddingBottom() + getPaddingTop();
            iMax -= getPaddingBottom();
        }
        canvas.translate(paddingLeft2 - width2, iMax);
        canvas.rotate(180.0f, width2, 0.0f);
        edgeEffect2.setSize(width2, height2);
        if (edgeEffect2.draw(canvas)) {
            postInvalidateOnAnimation();
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // o0.k
    public final void e(View view, int i3) {
        t0 t0Var = this.f510x;
        if (i3 == 1) {
            t0Var.f2069b = 0;
        } else {
            t0Var.f2068a = 0;
        }
        w(i3);
    }

    @Override // o0.k
    public final void f(View view, int i3, int i4, int[] iArr, int i5) {
        this.f511y.c(i3, i4, i5, iArr, null);
    }

    public final boolean g(int i3) {
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
        }
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, i3);
        int maxScrollAmount = getMaxScrollAmount();
        if (viewFindNextFocus == null || !m(viewFindNextFocus, maxScrollAmount, getHeight())) {
            if (i3 == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i3 == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i3 != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            s(maxScrollAmount, 0, 1, true);
        } else {
            Rect rect = this.f490c;
            viewFindNextFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(viewFindNextFocus, rect);
            s(h(rect), 0, 1, true);
            viewFindNextFocus.requestFocus(i3);
        }
        if (viewFindFocus != null && viewFindFocus.isFocused() && !m(viewFindFocus, 0, getHeight())) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    @Override // android.view.View
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (getHeight() * 0.5f);
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        t0 t0Var = this.f510x;
        return t0Var.f2069b | t0Var.f2068a;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    @Override // android.view.View
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public float getVerticalScrollFactorCompat() {
        if (this.f512z == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
            this.f512z = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.f512z;
    }

    public final int h(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i3 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i4 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i3 - verticalFadingEdgeLength : i3;
        int i5 = rect.bottom;
        if (i5 > i4 && rect.top > scrollY) {
            return Math.min(rect.height() > height ? rect.top - scrollY : rect.bottom - i4, (childAt.getBottom() + layoutParams.bottomMargin) - i3);
        }
        if (rect.top >= scrollY || i5 >= i4) {
            return 0;
        }
        return Math.max(rect.height() > height ? 0 - (i4 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.f511y.f(0);
    }

    /* JADX WARN: Code duplicated, block: B:48:0x0099  */
    /* JADX WARN: Code duplicated, block: B:54:0x00ac  */
    public final boolean i(KeyEvent keyEvent) {
        View viewFindFocus;
        View viewFindNextFocus;
        this.f490c.setEmpty();
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                if (keyEvent.getAction() == 0) {
                    int keyCode = keyEvent.getKeyCode();
                    if (keyCode == 19) {
                        return keyEvent.isAltPressed() ? k(33) : g(33);
                    }
                    if (keyCode == 20) {
                        return keyEvent.isAltPressed() ? k(130) : g(130);
                    }
                    if (keyCode == 62) {
                        q(keyEvent.isShiftPressed() ? 33 : 130);
                        return false;
                    }
                    if (keyCode == 92) {
                        return k(33);
                    }
                    if (keyCode == 93) {
                        return k(130);
                    }
                    if (keyCode == 122) {
                        q(33);
                        return false;
                    }
                    if (keyCode == 123) {
                        q(130);
                        return false;
                    }
                }
            } else if (isFocused() && keyEvent.getKeyCode() != 4) {
                viewFindFocus = findFocus();
                if (viewFindFocus == this) {
                    viewFindFocus = null;
                }
                viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
                if (viewFindNextFocus == null && viewFindNextFocus != this && viewFindNextFocus.requestFocus(130)) {
                    return true;
                }
            }
        } else if (isFocused()) {
            viewFindFocus = findFocus();
            if (viewFindFocus == this) {
                viewFindFocus = null;
            }
            viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
            if (viewFindNextFocus == null) {
            }
        }
        return false;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.f511y.f3568d;
    }

    public final void j(int i3) {
        if (getChildCount() > 0) {
            this.f491d.fling(getScrollX(), getScrollY(), 0, i3, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            this.f511y.g(2, 1);
            this.f508v = getScrollY();
            postInvalidateOnAnimation();
            if (a.a()) {
                e.a(this, Math.abs(this.f491d.getCurrVelocity()));
            }
        }
    }

    public final boolean k(int i3) {
        int childCount;
        boolean z4 = i3 == 130;
        int height = getHeight();
        Rect rect = this.f490c;
        rect.top = 0;
        rect.bottom = height;
        if (z4 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            rect.bottom = paddingBottom;
            rect.top = paddingBottom - height;
        }
        return r(i3, rect.top, rect.bottom);
    }

    public final boolean m(View view, int i3, int i4) {
        Rect rect = this.f490c;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        return rect.bottom + i3 >= getScrollY() && rect.top - i3 <= getScrollY() + i4;
    }

    @Override // android.view.ViewGroup
    public final void measureChild(View view, int i3, int i4) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i3, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    @Override // android.view.ViewGroup
    public final void measureChildWithMargins(View view, int i3, int i4, int i5, int i6) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i3, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i4, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void n(int i3, int i4, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i3);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f511y.d(0, scrollY2, 0, i3 - scrollY2, null, i4, iArr);
    }

    public final void o(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f504r) {
            int i3 = actionIndex == 0 ? 1 : 0;
            this.f493g = (int) motionEvent.getY(i3);
            this.f504r = motionEvent.getPointerId(i3);
            VelocityTracker velocityTracker = this.f498l;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f495i = false;
    }

    /* JADX WARN: Code duplicated, block: B:102:0x01cf  */
    /* JADX WARN: Code duplicated, block: B:49:0x00db  */
    /* JADX WARN: Code duplicated, block: B:70:0x0126  */
    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        int i3;
        float axisValue;
        int width;
        char c3;
        int scaledMinimumFlingVelocity;
        int scaledMaximumFlingVelocity;
        boolean z4;
        int i4;
        float yVelocity;
        float f;
        long j4;
        float f4;
        float fSqrt;
        if (motionEvent.getAction() != 8 || this.f497k) {
            return false;
        }
        if ((motionEvent.getSource() & 2) == 2) {
            i3 = 9;
            axisValue = motionEvent.getAxisValue(9);
            width = (int) motionEvent.getX();
        } else if ((motionEvent.getSource() & 4194304) == 4194304) {
            axisValue = motionEvent.getAxisValue(26);
            width = getWidth() / 2;
            i3 = 26;
        } else {
            i3 = 0;
            axisValue = 0.0f;
            width = 0;
        }
        if (axisValue == 0.0f) {
            return false;
        }
        s(-((int) (getVerticalScrollFactorCompat() * axisValue)), width, 1, (motionEvent.getSource() & 8194) == 8194);
        if (i3 != 0) {
            o0.g gVar = this.B;
            NestedScrollView nestedScrollView = (NestedScrollView) gVar.f3547b.f3b;
            int[] iArr = gVar.f3552h;
            int source = motionEvent.getSource();
            int deviceId = motionEvent.getDeviceId();
            if (gVar.f == source && gVar.f3551g == deviceId && gVar.f3550e == i3) {
                z4 = false;
                c3 = 0;
            } else {
                Context context = gVar.f3546a;
                ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
                int deviceId2 = motionEvent.getDeviceId();
                c3 = 0;
                int source2 = motionEvent.getSource();
                int i5 = Build.VERSION.SDK_INT;
                if (i5 >= 34) {
                    Method method = i0.f3564a;
                    scaledMinimumFlingVelocity = q.f(viewConfiguration, deviceId2, i3, source2);
                } else {
                    Method method2 = i0.f3564a;
                    InputDevice device = InputDevice.getDevice(deviceId2);
                    if (device == null || device.getMotionRange(i3, source2) == null) {
                        scaledMinimumFlingVelocity = Integer.MAX_VALUE;
                    } else {
                        Resources resources = context.getResources();
                        int identifier = (source2 == 4194304 && i3 == 26) ? resources.getIdentifier("config_viewMinRotaryEncoderFlingVelocity", "dimen", "android") : -1;
                        Objects.requireNonNull(viewConfiguration);
                        if (identifier == -1) {
                            scaledMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
                        } else if (identifier == 0 || (scaledMinimumFlingVelocity = resources.getDimensionPixelSize(identifier)) < 0) {
                            scaledMinimumFlingVelocity = Integer.MAX_VALUE;
                        }
                    }
                }
                iArr[0] = scaledMinimumFlingVelocity;
                int deviceId3 = motionEvent.getDeviceId();
                int source3 = motionEvent.getSource();
                if (i5 >= 34) {
                    scaledMaximumFlingVelocity = q.e(viewConfiguration, deviceId3, i3, source3);
                } else {
                    InputDevice device2 = InputDevice.getDevice(deviceId3);
                    if (device2 == null || device2.getMotionRange(i3, source3) == null) {
                        scaledMaximumFlingVelocity = Integer.MIN_VALUE;
                    } else {
                        Resources resources2 = context.getResources();
                        int identifier2 = (source3 == 4194304 && i3 == 26) ? resources2.getIdentifier("config_viewMaxRotaryEncoderFlingVelocity", "dimen", "android") : -1;
                        Objects.requireNonNull(viewConfiguration);
                        if (identifier2 == -1) {
                            scaledMaximumFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
                        } else if (identifier2 == 0 || (scaledMaximumFlingVelocity = resources2.getDimensionPixelSize(identifier2)) < 0) {
                            scaledMaximumFlingVelocity = Integer.MIN_VALUE;
                        }
                    }
                }
                iArr[1] = scaledMaximumFlingVelocity;
                gVar.f = source;
                gVar.f3551g = deviceId;
                gVar.f3550e = i3;
                z4 = true;
            }
            if (iArr[c3] == Integer.MAX_VALUE) {
                VelocityTracker velocityTracker = gVar.f3548c;
                if (velocityTracker == null) {
                    return true;
                }
                velocityTracker.recycle();
                gVar.f3548c = null;
                return true;
            }
            if (gVar.f3548c == null) {
                gVar.f3548c = VelocityTracker.obtain();
            }
            VelocityTracker velocityTracker2 = gVar.f3548c;
            Map map = r.f3593a;
            velocityTracker2.addMovement(motionEvent);
            int i6 = 20;
            if (Build.VERSION.SDK_INT < 34 && motionEvent.getSource() == 4194304) {
                Map map2 = r.f3593a;
                if (!map2.containsKey(velocityTracker2)) {
                    map2.put(velocityTracker2, new s());
                }
                s sVar = (s) map2.get(velocityTracker2);
                long[] jArr = sVar.f3596b;
                long eventTime = motionEvent.getEventTime();
                if (sVar.f3598d != 0 && eventTime - jArr[sVar.f3599e] > 40) {
                    sVar.f3598d = 0;
                    sVar.f3597c = 0.0f;
                }
                int i7 = (sVar.f3599e + 1) % 20;
                sVar.f3599e = i7;
                int i8 = sVar.f3598d;
                if (i8 != 20) {
                    sVar.f3598d = i8 + 1;
                }
                sVar.f3595a[i7] = motionEvent.getAxisValue(26);
                jArr[sVar.f3599e] = eventTime;
            }
            velocityTracker2.computeCurrentVelocity(1000, Float.MAX_VALUE);
            s sVar2 = (s) r.f3593a.get(velocityTracker2);
            if (sVar2 != null) {
                float[] fArr = sVar2.f3595a;
                long[] jArr2 = sVar2.f3596b;
                int i9 = sVar2.f3598d;
                if (i9 < 2) {
                    i4 = i3;
                    f4 = Float.MAX_VALUE;
                    fSqrt = 0.0f;
                } else {
                    int i10 = sVar2.f3599e;
                    int i11 = ((i10 + 20) - (i9 - 1)) % 20;
                    long j5 = jArr2[i10];
                    while (true) {
                        j4 = jArr2[i11];
                        if (j5 - j4 <= 100) {
                            break;
                        }
                        sVar2.f3598d--;
                        i11 = (i11 + 1) % 20;
                    }
                    int i12 = sVar2.f3598d;
                    if (i12 < 2) {
                        i4 = i3;
                        f4 = Float.MAX_VALUE;
                        fSqrt = 0.0f;
                    } else if (i12 == 2) {
                        int i13 = (i11 + 1) % 20;
                        long j6 = jArr2[i13];
                        if (j4 == j6) {
                            i4 = i3;
                            f4 = Float.MAX_VALUE;
                            fSqrt = 0.0f;
                        } else {
                            i4 = i3;
                            fSqrt = fArr[i13] / (j6 - j4);
                            f4 = Float.MAX_VALUE;
                        }
                    } else {
                        f4 = Float.MAX_VALUE;
                        float f5 = 0.0f;
                        int i14 = 0;
                        int i15 = 0;
                        while (true) {
                            if (i14 >= sVar2.f3598d - 1) {
                                break;
                            }
                            int i16 = i14 + i11;
                            long j7 = jArr2[i16 % 20];
                            int i17 = (i16 + 1) % i6;
                            if (jArr2[i17] != j7) {
                                i15++;
                                float fSqrt2 = (f5 < 0.0f ? -1.0f : 1.0f) * ((float) Math.sqrt(Math.abs(f5) * 2.0f));
                                float f6 = fArr[i17] / (jArr2[i17] - j7);
                                float fAbs = (Math.abs(f6) * (f6 - fSqrt2)) + f5;
                                if (i15 == 1) {
                                    fAbs *= 0.5f;
                                }
                                f5 = fAbs;
                            }
                            i14++;
                            i3 = i3;
                            i6 = 20;
                        }
                        i4 = i3;
                        fSqrt = ((float) Math.sqrt(Math.abs(f5) * 2.0f)) * (f5 < 0.0f ? -1.0f : 1.0f);
                    }
                }
                float f7 = fSqrt * 1000;
                sVar2.f3597c = f7;
                if (f7 < (-Math.abs(f4))) {
                    sVar2.f3597c = -Math.abs(f4);
                } else if (sVar2.f3597c > Math.abs(f4)) {
                    sVar2.f3597c = Math.abs(f4);
                }
            } else {
                i4 = i3;
            }
            if (Build.VERSION.SDK_INT >= 34) {
                yVelocity = q.b(velocityTracker2, i4);
            } else {
                int i18 = i4;
                if (i18 == 0) {
                    yVelocity = velocityTracker2.getXVelocity();
                } else if (i18 == 1) {
                    yVelocity = velocityTracker2.getYVelocity();
                } else {
                    s sVar3 = (s) r.f3593a.get(velocityTracker2);
                    yVelocity = (sVar3 == null || i18 != 26) ? 0.0f : sVar3.f3597c;
                }
            }
            float f8 = yVelocity * (-nestedScrollView.getVerticalScrollFactorCompat());
            float fSignum = Math.signum(f8);
            if (z4 || (fSignum != Math.signum(gVar.f3549d) && fSignum != 0.0f)) {
                nestedScrollView.f491d.abortAnimation();
            }
            if (Math.abs(f8) >= iArr[0]) {
                int i19 = iArr[1];
                float fMax = Math.max(-i19, Math.min(f8, i19));
                if (fMax == 0.0f) {
                    f = 0.0f;
                } else {
                    nestedScrollView.f491d.abortAnimation();
                    nestedScrollView.j((int) fMax);
                    f = fMax;
                }
                gVar.f3549d = f;
                return true;
            }
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:34:0x006b  */
    /* JADX WARN: Code duplicated, block: B:36:0x0073  */
    /* JADX WARN: Code duplicated, block: B:39:0x008f  */
    /* JADX WARN: Code duplicated, block: B:62:0x0101  */
    /* JADX WARN: Code duplicated, block: B:70:0x0117  */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        VelocityTracker velocityTracker;
        VelocityTracker velocityTracker2;
        int iFindPointerIndex;
        int action = motionEvent.getAction();
        boolean z4 = true;
        if (action == 2 && this.f497k) {
            return true;
        }
        int i3 = action & 255;
        if (i3 == 0) {
            int y4 = (int) motionEvent.getY();
            int x3 = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y4 < childAt.getTop() - scrollY || y4 >= childAt.getBottom() - scrollY || x3 < childAt.getLeft() || x3 >= childAt.getRight()) {
                    if (!v(motionEvent) && this.f491d.isFinished()) {
                        z4 = false;
                    }
                    this.f497k = z4;
                    velocityTracker = this.f498l;
                    if (velocityTracker != null) {
                        velocityTracker.recycle();
                        this.f498l = null;
                    }
                } else {
                    this.f493g = y4;
                    this.f504r = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker3 = this.f498l;
                    if (velocityTracker3 == null) {
                        this.f498l = VelocityTracker.obtain();
                    } else {
                        velocityTracker3.clear();
                    }
                    this.f498l.addMovement(motionEvent);
                    this.f491d.computeScrollOffset();
                    if (!v(motionEvent) && this.f491d.isFinished()) {
                        z4 = false;
                    }
                    this.f497k = z4;
                    this.f511y.g(2, 0);
                }
            } else {
                if (!v(motionEvent)) {
                    z4 = false;
                }
                this.f497k = z4;
                velocityTracker = this.f498l;
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    this.f498l = null;
                }
            }
        } else if (i3 == 1) {
            this.f497k = false;
            this.f504r = -1;
            velocityTracker2 = this.f498l;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f498l = null;
            }
            if (this.f491d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i3 == 2) {
            int i4 = this.f504r;
            if (i4 != -1 && (iFindPointerIndex = motionEvent.findPointerIndex(i4)) != -1) {
                int y5 = (int) motionEvent.getY(iFindPointerIndex);
                if (Math.abs(y5 - this.f493g) > this.f501o && (2 & getNestedScrollAxes()) == 0) {
                    this.f497k = true;
                    this.f493g = y5;
                    if (this.f498l == null) {
                        this.f498l = VelocityTracker.obtain();
                    }
                    this.f498l.addMovement(motionEvent);
                    this.f507u = 0;
                    ViewParent parent = getParent();
                    if (parent != null) {
                        parent.requestDisallowInterceptTouchEvent(true);
                    }
                }
            }
        } else if (i3 == 3) {
            this.f497k = false;
            this.f504r = -1;
            velocityTracker2 = this.f498l;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f498l = null;
            }
            if (this.f491d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i3 == 6) {
            o(motionEvent);
        }
        return this.f497k;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        int measuredHeight;
        super.onLayout(z4, i3, i4, i5, i6);
        int i7 = 0;
        this.f494h = false;
        View view = this.f496j;
        if (view != null && l(view, this)) {
            View view2 = this.f496j;
            Rect rect = this.f490c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iH = h(rect);
            if (iH != 0) {
                scrollBy(0, iH);
            }
        }
        this.f496j = null;
        if (!this.f495i) {
            if (this.f509w != null) {
                scrollTo(getScrollX(), this.f509w.f3788a);
                this.f509w = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                measuredHeight = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                measuredHeight = 0;
            }
            int paddingTop = ((i6 - i4) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < measuredHeight && scrollY >= 0) {
                i7 = paddingTop + scrollY > measuredHeight ? measuredHeight - paddingTop : scrollY;
            }
            if (i7 != scrollY) {
                scrollTo(getScrollX(), i7);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f495i = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i3, int i4) {
        super.onMeasure(i3, i4);
        if (this.f499m && View.MeasureSpec.getMode(i4) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i3, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f4, boolean z4) {
        if (z4) {
            return false;
        }
        dispatchNestedFling(0.0f, f4, true);
        j((int) f4);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f4) {
        return this.f511y.b(f, f4);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i3, int i4, int[] iArr) {
        this.f511y.c(i3, i4, 0, iArr, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i3, int i4, int i5, int i6) {
        n(i6, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i3) {
        d(view, view2, i3, 0);
    }

    @Override // android.view.View
    public final void onOverScrolled(int i3, int i4, boolean z4, boolean z5) {
        super.scrollTo(i3, i4);
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i3, Rect rect) {
        if (i3 == 2) {
            i3 = 130;
        } else if (i3 == 1) {
            i3 = 33;
        }
        View viewFindNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i3) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i3);
        if (viewFindNextFocus != null && m(viewFindNextFocus, 0, getHeight())) {
            return viewFindNextFocus.requestFocus(i3, rect);
        }
        return false;
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof r0.g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        r0.g gVar = (r0.g) parcelable;
        super.onRestoreInstanceState(gVar.getSuperState());
        this.f509w = gVar;
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        r0.g gVar = new r0.g(super.onSaveInstanceState());
        gVar.f3788a = getScrollY();
        return gVar;
    }

    @Override // android.view.View
    public final void onScrollChanged(int i3, int i4, int i5, int i6) {
        super.onScrollChanged(i3, i4, i5, i6);
        f fVar = this.A;
        if (fVar != null) {
            androidx.emoji2.text.q qVar = (androidx.emoji2.text.q) fVar;
            e.j.a(this, (View) qVar.f551b, (View) qVar.f552c);
        }
    }

    @Override // android.view.View
    public final void onSizeChanged(int i3, int i4, int i5, int i6) {
        super.onSizeChanged(i3, i4, i5, i6);
        View viewFindFocus = findFocus();
        if (viewFindFocus == null || this == viewFindFocus || !m(viewFindFocus, 0, i6)) {
            return;
        }
        Rect rect = this.f490c;
        viewFindFocus.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(viewFindFocus, rect);
        int iH = h(rect);
        if (iH != 0) {
            if (this.f500n) {
                u(0, iH, false);
            } else {
                scrollBy(0, iH);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i3) {
        return c(view, view2, i3, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        e(view, 0);
    }

    /* JADX WARN: Code duplicated, block: B:49:0x0107  */
    /* JADX WARN: Code duplicated, block: B:56:0x011d  */
    /* JADX WARN: Code duplicated, block: B:59:0x0124  */
    /* JADX WARN: Code duplicated, block: B:60:0x0128  */
    /* JADX WARN: Code duplicated, block: B:63:0x012f  */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        float fO;
        int iRound;
        int i3;
        ViewParent parent2;
        if (this.f498l == null) {
            this.f498l = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f507u = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        float f = 0.0f;
        motionEventObtain.offsetLocation(0.0f, this.f507u);
        j jVar = this.f511y;
        if (actionMasked != 0) {
            EdgeEffect edgeEffect = this.f492e;
            EdgeEffect edgeEffect2 = this.f;
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.f498l;
                velocityTracker.computeCurrentVelocity(1000, this.f503q);
                int yVelocity = (int) velocityTracker.getYVelocity(this.f504r);
                if (Math.abs(yVelocity) >= this.f502p) {
                    if (q1.b.s(edgeEffect) != 0.0f) {
                        if (t(edgeEffect, yVelocity)) {
                            edgeEffect.onAbsorb(yVelocity);
                        } else {
                            j(-yVelocity);
                        }
                    } else if (q1.b.s(edgeEffect2) != 0.0f) {
                        int i4 = -yVelocity;
                        if (t(edgeEffect2, i4)) {
                            edgeEffect2.onAbsorb(i4);
                        } else {
                            j(i4);
                        }
                    } else {
                        int i5 = -yVelocity;
                        float f4 = i5;
                        if (!jVar.b(0.0f, f4)) {
                            dispatchNestedFling(0.0f, f4, true);
                            j(i5);
                        }
                    }
                } else if (this.f491d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.f504r = -1;
                this.f497k = false;
                VelocityTracker velocityTracker2 = this.f498l;
                if (velocityTracker2 != null) {
                    velocityTracker2.recycle();
                    this.f498l = null;
                }
                w(0);
                edgeEffect.onRelease();
                edgeEffect2.onRelease();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f504r);
                if (iFindPointerIndex != -1) {
                    int y4 = (int) motionEvent.getY(iFindPointerIndex);
                    int i6 = this.f493g - y4;
                    float x3 = motionEvent.getX(iFindPointerIndex) / getWidth();
                    float height = i6 / getHeight();
                    if (q1.b.s(edgeEffect) != 0.0f) {
                        fO = -q1.b.O(edgeEffect, -height, x3);
                        if (q1.b.s(edgeEffect) == 0.0f) {
                            edgeEffect.onRelease();
                        }
                    } else if (q1.b.s(edgeEffect2) != 0.0f) {
                        fO = q1.b.O(edgeEffect2, height, 1.0f - x3);
                        if (q1.b.s(edgeEffect2) == 0.0f) {
                            edgeEffect2.onRelease();
                        }
                    } else {
                        iRound = Math.round(f * getHeight());
                        if (iRound != 0) {
                            invalidate();
                        }
                        i3 = i6 - iRound;
                        if (!this.f497k && Math.abs(i3) > this.f501o) {
                            parent2 = getParent();
                            if (parent2 != null) {
                                parent2.requestDisallowInterceptTouchEvent(true);
                            }
                            this.f497k = true;
                            if (i3 > 0) {
                                i3 -= this.f501o;
                            } else {
                                i3 += this.f501o;
                            }
                        }
                        if (this.f497k) {
                            int iS = s(i3, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                            this.f493g = y4 - iS;
                            this.f507u += iS;
                        }
                    }
                    f = fO;
                    iRound = Math.round(f * getHeight());
                    if (iRound != 0) {
                        invalidate();
                    }
                    i3 = i6 - iRound;
                    if (!this.f497k) {
                        parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.f497k = true;
                        if (i3 > 0) {
                            i3 -= this.f501o;
                        } else {
                            i3 += this.f501o;
                        }
                    }
                    if (this.f497k) {
                        int iS2 = s(i3, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                        this.f493g = y4 - iS2;
                        this.f507u += iS2;
                    }
                }
            } else if (actionMasked == 3) {
                if (this.f497k && getChildCount() > 0) {
                    if (this.f491d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                        postInvalidateOnAnimation();
                    }
                }
                this.f504r = -1;
                this.f497k = false;
                VelocityTracker velocityTracker3 = this.f498l;
                if (velocityTracker3 != null) {
                    velocityTracker3.recycle();
                    this.f498l = null;
                }
                w(0);
                edgeEffect.onRelease();
                edgeEffect2.onRelease();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                this.f493g = (int) motionEvent.getY(actionIndex);
                this.f504r = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                o(motionEvent);
                this.f493g = (int) motionEvent.getY(motionEvent.findPointerIndex(this.f504r));
            }
        } else {
            if (getChildCount() == 0) {
                return false;
            }
            if (this.f497k && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.f491d.isFinished()) {
                this.f491d.abortAnimation();
                w(1);
            }
            int y5 = (int) motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            this.f493g = y5;
            this.f504r = pointerId;
            jVar.g(2, 0);
        }
        VelocityTracker velocityTracker4 = this.f498l;
        if (velocityTracker4 != null) {
            velocityTracker4.addMovement(motionEventObtain);
        }
        motionEventObtain.recycle();
        return true;
    }

    public final boolean p(int i3, int i4, int i5, int i6) {
        int i7;
        boolean z4;
        int i8;
        boolean z5;
        getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        int i9 = i5 + i3;
        if (i4 <= 0 && i4 >= 0) {
            i7 = i4;
            z4 = false;
        } else {
            z4 = true;
            i7 = 0;
        }
        if (i9 > i6) {
            i8 = i6;
            z5 = true;
        } else if (i9 < 0) {
            z5 = true;
            i8 = 0;
        } else {
            i8 = i9;
            z5 = false;
        }
        if (z5 && !this.f511y.f(1)) {
            this.f491d.springBack(i7, i8, 0, 0, 0, getScrollRange());
        }
        super.scrollTo(i7, i8);
        return z4 || z5;
    }

    public final void q(int i3) {
        boolean z4 = i3 == 130;
        int height = getHeight();
        Rect rect = this.f490c;
        if (z4) {
            rect.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
                if (rect.top + height > paddingBottom) {
                    rect.top = paddingBottom - height;
                }
            }
        } else {
            int scrollY = getScrollY() - height;
            rect.top = scrollY;
            if (scrollY < 0) {
                rect.top = 0;
            }
        }
        int i4 = rect.top;
        int i5 = height + i4;
        rect.bottom = i5;
        r(i3, i4, i5);
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0068  */
    public final boolean r(int i3, int i4, int i5) {
        boolean z4;
        int height = getHeight();
        int scrollY = getScrollY();
        int i6 = height + scrollY;
        boolean z5 = i3 == 33;
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z6 = false;
        for (int i7 = 0; i7 < size; i7++) {
            View view2 = focusables.get(i7);
            int top2 = view2.getTop();
            int bottom = view2.getBottom();
            if (i4 < bottom && top2 < i5) {
                boolean z7 = i4 < top2 && bottom < i5;
                if (view == null) {
                    view = view2;
                    z6 = z7;
                } else {
                    boolean z8 = (z5 && top2 < view.getTop()) || (!z5 && bottom > view.getBottom());
                    if (z6) {
                        if (z7 && z8) {
                            view = view2;
                        }
                    } else if (z7) {
                        view = view2;
                        z6 = true;
                    } else if (z8) {
                        view = view2;
                    }
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i4 < scrollY || i5 > i6) {
            s(z5 ? i4 - scrollY : i5 - i6, 0, 1, true);
            z4 = true;
        } else {
            z4 = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i3);
        }
        return z4;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        if (this.f494h) {
            this.f496j = view2;
        } else {
            Rect rect = this.f490c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iH = h(rect);
            if (iH != 0) {
                scrollBy(0, iH);
            }
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z4) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int iH = h(rect);
        boolean z5 = iH != 0;
        if (z5) {
            if (z4) {
                scrollBy(0, iH);
                return z5;
            }
            u(0, iH, false);
        }
        return z5;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z4) {
        VelocityTracker velocityTracker;
        if (z4 && (velocityTracker = this.f498l) != null) {
            velocityTracker.recycle();
            this.f498l = null;
        }
        super.requestDisallowInterceptTouchEvent(z4);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.f494h = true;
        super.requestLayout();
    }

    public final int s(int i3, int i4, int i5, boolean z4) {
        int i6;
        int i7;
        boolean z5;
        VelocityTracker velocityTracker;
        j jVar = this.f511y;
        if (i5 == 1) {
            jVar.g(2, i5);
        }
        boolean zC = this.f511y.c(0, i3, i5, this.f506t, this.f505s);
        int[] iArr = this.f505s;
        int[] iArr2 = this.f506t;
        if (zC) {
            i6 = i3 - iArr2[1];
            i7 = iArr[1];
        } else {
            i6 = i3;
            i7 = 0;
        }
        int scrollY = getScrollY();
        int scrollRange = getScrollRange();
        int overScrollMode = getOverScrollMode();
        boolean z6 = (overScrollMode == 0 || (overScrollMode == 1 && getScrollRange() > 0)) && !z4;
        boolean z7 = p(i6, 0, scrollY, scrollRange) && !jVar.f(i5);
        int scrollY2 = getScrollY() - scrollY;
        iArr2[1] = 0;
        this.f511y.d(0, scrollY2, 0, i6 - scrollY2, this.f505s, i5, iArr2);
        int i8 = i7 + iArr[1];
        int i9 = i6 - iArr2[1];
        int i10 = scrollY + i9;
        EdgeEffect edgeEffect = this.f;
        EdgeEffect edgeEffect2 = this.f492e;
        if (i10 < 0) {
            if (z6) {
                q1.b.O(edgeEffect2, (-i9) / getHeight(), i4 / getWidth());
                if (!edgeEffect.isFinished()) {
                    edgeEffect.onRelease();
                }
            }
        } else if (i10 > scrollRange && z6) {
            q1.b.O(edgeEffect, i9 / getHeight(), 1.0f - (i4 / getWidth()));
            if (!edgeEffect2.isFinished()) {
                edgeEffect2.onRelease();
            }
        }
        if (edgeEffect2.isFinished() && edgeEffect.isFinished()) {
            z5 = z7;
        } else {
            postInvalidateOnAnimation();
            z5 = false;
        }
        if (z5 && i5 == 0 && (velocityTracker = this.f498l) != null) {
            velocityTracker.clear();
        }
        if (i5 == 1) {
            w(i5);
            edgeEffect2.onRelease();
            edgeEffect.onRelease();
        }
        return i8;
    }

    @Override // android.view.View
    public final void scrollTo(int i3, int i4) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width >= width2 || i3 < 0) {
                i3 = 0;
            } else if (width + i3 > width2) {
                i3 = width2 - width;
            }
            if (height >= height2 || i4 < 0) {
                i4 = 0;
            } else if (height + i4 > height2) {
                i4 = height2 - height;
            }
            if (i3 == getScrollX() && i4 == getScrollY()) {
                return;
            }
            super.scrollTo(i3, i4);
        }
    }

    public void setFillViewport(boolean z4) {
        if (z4 != this.f499m) {
            this.f499m = z4;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z4) {
        j jVar = this.f511y;
        if (jVar.f3568d) {
            ViewGroup viewGroup = jVar.f3567c;
            WeakHashMap weakHashMap = h0.f3558a;
            z.o(viewGroup);
        }
        jVar.f3568d = z4;
    }

    public void setOnScrollChangeListener(f fVar) {
        this.A = fVar;
    }

    public void setSmoothScrollingEnabled(boolean z4) {
        this.f500n = z4;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i3) {
        return this.f511y.g(i3, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        w(0);
    }

    public final boolean t(EdgeEffect edgeEffect, int i3) {
        if (i3 > 0) {
            return true;
        }
        float fS = q1.b.s(edgeEffect) * getHeight();
        float fAbs = Math.abs(-i3) * 0.35f;
        float f = this.f488a * 0.015f;
        double dLog = Math.log(fAbs / f);
        double d4 = C;
        return ((float) (Math.exp((d4 / (d4 - 1.0d)) * dLog) * ((double) f))) < fS;
    }

    public final void u(int i3, int i4, boolean z4) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.f489b > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int iMax = Math.max(0, Math.min(i4 + scrollY, Math.max(0, height - height2))) - scrollY;
            this.f491d.startScroll(getScrollX(), scrollY, 0, iMax, 250);
            if (z4) {
                this.f511y.g(2, 1);
            } else {
                w(1);
            }
            this.f508v = getScrollY();
            postInvalidateOnAnimation();
        } else {
            if (!this.f491d.isFinished()) {
                this.f491d.abortAnimation();
                w(1);
            }
            scrollBy(i3, i4);
        }
        this.f489b = AnimationUtils.currentAnimationTimeMillis();
    }

    public final boolean v(MotionEvent motionEvent) {
        boolean z4;
        EdgeEffect edgeEffect = this.f492e;
        if (q1.b.s(edgeEffect) != 0.0f) {
            q1.b.O(edgeEffect, 0.0f, motionEvent.getX() / getWidth());
            z4 = true;
        } else {
            z4 = false;
        }
        EdgeEffect edgeEffect2 = this.f;
        if (q1.b.s(edgeEffect2) == 0.0f) {
            return z4;
        }
        q1.b.O(edgeEffect2, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
        return true;
    }

    public final void w(int i3) {
        this.f511y.h(i3);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i3) {
        if (getChildCount() <= 0) {
            super.addView(view, i3);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i3, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i3, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }
}
