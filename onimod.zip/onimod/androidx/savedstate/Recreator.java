package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.Lifecycle$Event;
import androidx.lifecycle.SavedStateHandleController;
import androidx.lifecycle.i0;
import androidx.lifecycle.j;
import androidx.lifecycle.l0;
import androidx.lifecycle.m0;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import androidx.lifecycle.s;
import e.l;
import f1.b;
import f1.e;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import kotlin.jvm.internal.d;

/* JADX INFO: loaded from: classes.dex */
public final class Recreator implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e f983a;

    public Recreator(e eVar) {
        this.f983a = eVar;
    }

    @Override // androidx.lifecycle.o
    public final void a(q qVar, Lifecycle$Event lifecycle$Event) {
        boolean z4;
        if (lifecycle$Event != Lifecycle$Event.ON_CREATE) {
            throw new AssertionError("Next event must be ON_CREATE");
        }
        qVar.e().f(this);
        e eVar = this.f983a;
        Bundle bundleC = eVar.c().c("androidx.savedstate.Restarter");
        if (bundleC == null) {
            return;
        }
        ArrayList<String> stringArrayList = bundleC.getStringArrayList("classes_to_restore");
        if (stringArrayList == null) {
            throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
        }
        int size = stringArrayList.size();
        int i3 = 0;
        while (i3 < size) {
            String str = stringArrayList.get(i3);
            i3++;
            String str2 = str;
            try {
                Class<? extends U> clsAsSubclass = Class.forName(str2, false, Recreator.class.getClassLoader()).asSubclass(b.class);
                d.e(clsAsSubclass, "{\n                Class.…class.java)\n            }");
                try {
                    Constructor declaredConstructor = clsAsSubclass.getDeclaredConstructor(null);
                    declaredConstructor.setAccessible(true);
                    try {
                        Object objNewInstance = declaredConstructor.newInstance(null);
                        d.e(objNewInstance, "{\n                constr…wInstance()\n            }");
                        if (!(eVar instanceof m0)) {
                            throw new IllegalStateException("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner");
                        }
                        l0 l0VarB = ((m0) eVar).b();
                        f1.d registry = eVar.c();
                        l0VarB.getClass();
                        LinkedHashMap linkedHashMap = l0VarB.f873a;
                        for (String key : new HashSet(linkedHashMap.keySet())) {
                            d.f(key, "key");
                            i0 i0Var = (i0) linkedHashMap.get(key);
                            d.c(i0Var);
                            s lifecycle = eVar.e();
                            d.f(registry, "registry");
                            d.f(lifecycle, "lifecycle");
                            SavedStateHandleController savedStateHandleController = (SavedStateHandleController) i0Var.b("androidx.lifecycle.savedstate.vm.tag");
                            if (savedStateHandleController != null && !(z4 = savedStateHandleController.f838a)) {
                                if (z4) {
                                    throw new IllegalStateException("Already attached to lifecycleOwner");
                                }
                                savedStateHandleController.f838a = true;
                                lifecycle.a(savedStateHandleController);
                                throw null;
                            }
                        }
                        if (!new HashSet(linkedHashMap.keySet()).isEmpty()) {
                            if (!registry.f2229c) {
                                throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
                            }
                            l lVar = (l) registry.f;
                            if (lVar == null) {
                                lVar = new l(registry);
                            }
                            registry.f = lVar;
                            try {
                                j.class.getDeclaredConstructor(null);
                                l lVar2 = (l) registry.f;
                                if (lVar2 != null) {
                                    ((LinkedHashSet) lVar2.f1764b).add(j.class.getName());
                                }
                            } catch (NoSuchMethodException e4) {
                                throw new IllegalArgumentException("Class " + j.class.getSimpleName() + " must have default constructor in order to be automatically recreated", e4);
                            }
                        }
                    } catch (Exception e5) {
                        throw new RuntimeException(g0.e.h("Failed to instantiate ", str2), e5);
                    }
                } catch (NoSuchMethodException e6) {
                    throw new IllegalStateException("Class " + clsAsSubclass.getSimpleName() + " must have default constructor in order to be automatically recreated", e6);
                }
            } catch (ClassNotFoundException e7) {
                throw new RuntimeException(g0.e.d("Class ", str2, " wasn't found"), e7);
            }
        }
    }
}
