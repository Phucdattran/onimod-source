package androidx.coordinatorlayout.widget;

import a0.b;
import a0.c;
import a0.e;
import a0.f;
import a0.g;
import a0.j;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import e1.t0;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.WeakHashMap;
import n0.d;
import o0.f1;
import o0.h0;
import o0.k;
import o0.l;
import o0.x;
import o0.z;
import q.i;
import top.niunaijun.blackbox.R;
import z.a;

/* JADX INFO: loaded from: classes.dex */
public class CoordinatorLayout extends ViewGroup implements k, l {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final String f445t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final Class[] f446u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final ThreadLocal f447v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final j f448w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final d f449x;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f450a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a0.k f451b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f452c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f453d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int[] f454e;
    public final int[] f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f455g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f456h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int[] f457i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public View f458j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public View f459k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public g f460l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f461m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public f1 f462n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f463o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Drawable f464p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public ViewGroup.OnHierarchyChangeListener f465q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public b f466r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final t0 f467s;

    static {
        Package r1 = CoordinatorLayout.class.getPackage();
        f445t = r1 != null ? r1.getName() : null;
        f448w = new j(0);
        f446u = new Class[]{Context.class, AttributeSet.class};
        f447v = new ThreadLocal();
        f449x = new d();
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.coordinatorLayoutStyle);
        this.f450a = new ArrayList();
        this.f451b = new a0.k(0);
        this.f452c = new ArrayList();
        this.f453d = new ArrayList();
        this.f454e = new int[2];
        this.f = new int[2];
        this.f467s = new t0();
        int[] iArr = a.f4955a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, R.attr.coordinatorLayoutStyle, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            saveAttributeDataForStyleable(context, iArr, attributeSet, typedArrayObtainStyledAttributes, R.attr.coordinatorLayoutStyle, 0);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            int[] intArray = resources.getIntArray(resourceId);
            this.f457i = intArray;
            float f = resources.getDisplayMetrics().density;
            int length = intArray.length;
            for (int i3 = 0; i3 < length; i3++) {
                int[] iArr2 = this.f457i;
                iArr2[i3] = (int) (iArr2[i3] * f);
            }
        }
        this.f464p = typedArrayObtainStyledAttributes.getDrawable(1);
        typedArrayObtainStyledAttributes.recycle();
        v();
        super.setOnHierarchyChangeListener(new e(this));
        WeakHashMap weakHashMap = h0.f3558a;
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
    }

    public static Rect g() {
        Rect rect = (Rect) f449x.a();
        return rect == null ? new Rect() : rect;
    }

    public static void l(int i3, Rect rect, Rect rect2, f fVar, int i4, int i5) {
        int iWidth;
        int iHeight;
        int i6 = fVar.f7c;
        if (i6 == 0) {
            i6 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i6, i3);
        int i7 = fVar.f8d;
        if ((i7 & 7) == 0) {
            i7 |= 8388611;
        }
        if ((i7 & 112) == 0) {
            i7 |= 48;
        }
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i7, i3);
        int i8 = absoluteGravity & 7;
        int i9 = absoluteGravity & 112;
        int i10 = absoluteGravity2 & 7;
        int i11 = absoluteGravity2 & 112;
        if (i10 != 1) {
            iWidth = i10 != 5 ? rect.left : rect.right;
        } else {
            iWidth = rect.left + (rect.width() / 2);
        }
        if (i11 != 16) {
            iHeight = i11 != 80 ? rect.top : rect.bottom;
        } else {
            iHeight = rect.top + (rect.height() / 2);
        }
        if (i8 == 1) {
            iWidth -= i4 / 2;
        } else if (i8 != 5) {
            iWidth -= i4;
        }
        if (i9 == 16) {
            iHeight -= i5 / 2;
        } else if (i9 != 80) {
            iHeight -= i5;
        }
        rect2.set(iWidth, iHeight, i4 + iWidth, i5 + iHeight);
    }

    public static f m(View view) {
        f fVar = (f) view.getLayoutParams();
        if (!fVar.f6b) {
            a0.d dVar = null;
            for (Class<?> superclass = view.getClass(); superclass != null; superclass = superclass.getSuperclass()) {
                dVar = (a0.d) superclass.getAnnotation(a0.d.class);
                if (dVar != null) {
                    break;
                }
            }
            if (dVar != null) {
                try {
                    c cVar = (c) dVar.value().getDeclaredConstructor(null).newInstance(null);
                    c cVar2 = fVar.f5a;
                    if (cVar2 != cVar) {
                        if (cVar2 != null) {
                            cVar2.e();
                        }
                        fVar.f5a = cVar;
                        fVar.f6b = true;
                        if (cVar != null) {
                            cVar.c(fVar);
                        }
                    }
                } catch (Exception unused) {
                    dVar.value().getClass();
                }
            }
            fVar.f6b = true;
        }
        return fVar;
    }

    public static void t(View view, int i3) {
        f fVar = (f) view.getLayoutParams();
        int i4 = fVar.f12i;
        if (i4 != i3) {
            h0.j(view, i3 - i4);
            fVar.f12i = i3;
        }
    }

    public static void u(View view, int i3) {
        f fVar = (f) view.getLayoutParams();
        int i4 = fVar.f13j;
        if (i4 != i3) {
            h0.k(view, i3 - i4);
            fVar.f13j = i3;
        }
    }

    @Override // o0.l
    public final void a(View view, int i3, int i4, int i5, int i6, int i7, int[] iArr) {
        c cVar;
        int childCount = getChildCount();
        int iMax = 0;
        int iMax2 = 0;
        boolean z4 = false;
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                f fVar = (f) childAt.getLayoutParams();
                if (fVar.a(i7) && (cVar = fVar.f5a) != null) {
                    int[] iArr2 = this.f454e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    cVar.k(this, childAt, i4, i5, i6, iArr2);
                    iMax = i5 > 0 ? Math.max(iMax, iArr2[0]) : Math.min(iMax, iArr2[0]);
                    iMax2 = i6 > 0 ? Math.max(iMax2, iArr2[1]) : Math.min(iMax2, iArr2[1]);
                    z4 = true;
                }
            }
        }
        iArr[0] = iArr[0] + iMax;
        iArr[1] = iArr[1] + iMax2;
        if (z4) {
            o(1);
        }
    }

    @Override // o0.k
    public final void b(View view, int i3, int i4, int i5, int i6, int i7) {
        a(view, i3, i4, i5, i6, 0, this.f);
    }

    @Override // o0.k
    public final boolean c(View view, View view2, int i3, int i4) {
        int childCount = getChildCount();
        boolean z4 = false;
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                f fVar = (f) childAt.getLayoutParams();
                c cVar = fVar.f5a;
                if (cVar != null) {
                    boolean zO = cVar.o(childAt, i3, i4);
                    z4 |= zO;
                    if (i4 == 0) {
                        fVar.f16m = zO;
                    } else if (i4 == 1) {
                        fVar.f17n = zO;
                    }
                } else if (i4 == 0) {
                    fVar.f16m = false;
                } else if (i4 == 1) {
                    fVar.f17n = false;
                }
            }
        }
        return z4;
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof f) && super.checkLayoutParams(layoutParams);
    }

    @Override // o0.k
    public final void d(View view, View view2, int i3, int i4) {
        t0 t0Var = this.f467s;
        if (i4 == 1) {
            t0Var.f2069b = i3;
        } else {
            t0Var.f2068a = i3;
        }
        this.f459k = view2;
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            ((f) getChildAt(i5).getLayoutParams()).getClass();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j4) {
        c cVar = ((f) view.getLayoutParams()).f5a;
        if (cVar != null) {
            cVar.getClass();
        }
        return super.drawChild(canvas, view, j4);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f464p;
        if ((drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState)) {
            invalidate();
        }
    }

    @Override // o0.k
    public final void e(View view, int i3) {
        t0 t0Var = this.f467s;
        if (i3 == 1) {
            t0Var.f2069b = 0;
        } else {
            t0Var.f2068a = 0;
        }
        int childCount = getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt = getChildAt(i4);
            f fVar = (f) childAt.getLayoutParams();
            if (fVar.a(i3)) {
                c cVar = fVar.f5a;
                if (cVar != null) {
                    cVar.p(childAt, view, i3);
                }
                if (i3 == 0) {
                    fVar.f16m = false;
                } else if (i3 == 1) {
                    fVar.f17n = false;
                }
            }
        }
        this.f459k = null;
    }

    @Override // o0.k
    public final void f(View view, int i3, int i4, int[] iArr, int i5) {
        c cVar;
        int childCount = getChildCount();
        boolean z4 = false;
        int iMax = 0;
        int iMax2 = 0;
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                f fVar = (f) childAt.getLayoutParams();
                if (fVar.a(i5) && (cVar = fVar.f5a) != null) {
                    int[] iArr2 = this.f454e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    cVar.j(this, childAt, view, i3, i4, iArr2, i5);
                    iMax = i3 > 0 ? Math.max(iMax, iArr2[0]) : Math.min(iMax, iArr2[0]);
                    iMax2 = i4 > 0 ? Math.max(iMax2, iArr2[1]) : Math.min(iMax2, iArr2[1]);
                    z4 = true;
                }
            }
        }
        iArr[0] = iMax;
        iArr[1] = iMax2;
        if (z4) {
            o(1);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new f();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new f(getContext(), attributeSet);
    }

    public final List<View> getDependencySortedChildren() {
        r();
        return Collections.unmodifiableList(this.f450a);
    }

    public final f1 getLastWindowInsets() {
        return this.f462n;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        t0 t0Var = this.f467s;
        return t0Var.f2069b | t0Var.f2068a;
    }

    public Drawable getStatusBarBackground() {
        return this.f464p;
    }

    @Override // android.view.View
    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    @Override // android.view.View
    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    public final void h(f fVar, Rect rect, int i3, int i4) {
        int width = getWidth();
        int height = getHeight();
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) fVar).leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i3) - ((ViewGroup.MarginLayoutParams) fVar).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) fVar).topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i4) - ((ViewGroup.MarginLayoutParams) fVar).bottomMargin));
        rect.set(iMax, iMax2, i3 + iMax, i4 + iMax2);
    }

    public final void i(View view, Rect rect, boolean z4) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z4) {
            k(rect, view);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public final ArrayList j(View view) {
        i iVar = (i) this.f451b.f24b;
        int i3 = iVar.f3742c;
        ArrayList arrayList = null;
        for (int i4 = 0; i4 < i3; i4++) {
            ArrayList arrayList2 = (ArrayList) iVar.i(i4);
            if (arrayList2 != null && arrayList2.contains(view)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(iVar.f(i4));
            }
        }
        ArrayList arrayList3 = this.f453d;
        arrayList3.clear();
        if (arrayList != null) {
            arrayList3.addAll(arrayList);
        }
        return arrayList3;
    }

    public final void k(Rect rect, View view) {
        ThreadLocal threadLocal = a0.l.f27a;
        rect.set(0, 0, view.getWidth(), view.getHeight());
        ThreadLocal threadLocal2 = a0.l.f27a;
        Matrix matrix = (Matrix) threadLocal2.get();
        if (matrix == null) {
            matrix = new Matrix();
            threadLocal2.set(matrix);
        } else {
            matrix.reset();
        }
        a0.l.a(this, view, matrix);
        ThreadLocal threadLocal3 = a0.l.f28b;
        RectF rectF = (RectF) threadLocal3.get();
        if (rectF == null) {
            rectF = new RectF();
            threadLocal3.set(rectF);
        }
        rectF.set(rect);
        matrix.mapRect(rectF);
        rect.set((int) (rectF.left + 0.5f), (int) (rectF.top + 0.5f), (int) (rectF.right + 0.5f), (int) (rectF.bottom + 0.5f));
    }

    public final boolean n(View view, int i3, int i4) {
        d dVar = f449x;
        Rect rectG = g();
        k(rectG, view);
        try {
            return rectG.contains(i3, i4);
        } finally {
            rectG.setEmpty();
            dVar.c(rectG);
        }
    }

    /* JADX WARN: Code duplicated, block: B:104:0x0268  */
    /* JADX WARN: Code duplicated, block: B:33:0x00da  */
    public final void o(int i3) {
        int i4;
        Rect rect;
        int i5;
        ArrayList arrayList;
        boolean z4;
        boolean z5;
        int width;
        int i6;
        int i7;
        int i8;
        int height;
        int i9;
        int i10;
        int i11;
        f fVar;
        int i12;
        View view;
        c cVar;
        WeakHashMap weakHashMap = h0.f3558a;
        int layoutDirection = getLayoutDirection();
        ArrayList arrayList2 = this.f450a;
        int size = arrayList2.size();
        Rect rectG = g();
        Rect rectG2 = g();
        Rect rectG3 = g();
        int i13 = 0;
        while (true) {
            d dVar = f449x;
            if (i13 >= size) {
                Rect rect2 = rectG3;
                rectG.setEmpty();
                dVar.c(rectG);
                rectG2.setEmpty();
                dVar.c(rectG2);
                rect2.setEmpty();
                dVar.c(rect2);
                return;
            }
            View view2 = (View) arrayList2.get(i13);
            f fVar2 = (f) view2.getLayoutParams();
            if (i3 == 0 && view2.getVisibility() == 8) {
                arrayList = arrayList2;
                i5 = size;
                rect = rectG3;
                i4 = i13;
            } else {
                int i14 = 0;
                while (i14 < i13) {
                    if (fVar2.f15l == ((View) arrayList2.get(i14))) {
                        f fVar3 = (f) view2.getLayoutParams();
                        if (fVar3.f14k != null) {
                            Rect rectG4 = g();
                            Rect rectG5 = g();
                            f fVar4 = fVar2;
                            Rect rectG6 = g();
                            k(rectG4, fVar3.f14k);
                            i(view2, rectG5, false);
                            int measuredWidth = view2.getMeasuredWidth();
                            View view3 = view2;
                            int measuredHeight = view3.getMeasuredHeight();
                            fVar = fVar4;
                            i12 = i14;
                            layoutDirection = layoutDirection;
                            view = view3;
                            l(layoutDirection, rectG4, rectG6, fVar3, measuredWidth, measuredHeight);
                            boolean z6 = (rectG6.left == rectG5.left && rectG6.top == rectG5.top) ? false : true;
                            h(fVar3, rectG6, measuredWidth, measuredHeight);
                            int i15 = rectG6.left - rectG5.left;
                            int i16 = rectG6.top - rectG5.top;
                            if (i15 != 0) {
                                h0.j(view, i15);
                            }
                            if (i16 != 0) {
                                h0.k(view, i16);
                            }
                            if (z6 && (cVar = fVar3.f5a) != null) {
                                cVar.d(this, view, fVar3.f14k);
                            }
                            rectG4.setEmpty();
                            dVar.c(rectG4);
                            rectG5.setEmpty();
                            dVar.c(rectG5);
                            rectG6.setEmpty();
                            dVar.c(rectG6);
                        } else {
                            fVar = fVar2;
                            i12 = i14;
                            view = view2;
                        }
                    } else {
                        fVar = fVar2;
                        i12 = i14;
                        view = view2;
                    }
                    i14 = i12 + 1;
                    fVar2 = fVar;
                    view2 = view;
                    arrayList2 = arrayList2;
                    size = size;
                    i13 = i13;
                    rectG3 = rectG3;
                }
                ArrayList arrayList3 = arrayList2;
                f fVar5 = fVar2;
                int i17 = size;
                Rect rect3 = rectG3;
                i4 = i13;
                View view4 = view2;
                i(view4, rectG2, true);
                if (fVar5.f10g != 0 && !rectG2.isEmpty()) {
                    int absoluteGravity = Gravity.getAbsoluteGravity(fVar5.f10g, layoutDirection);
                    int i18 = absoluteGravity & 112;
                    if (i18 == 48) {
                        rectG.top = Math.max(rectG.top, rectG2.bottom);
                    } else if (i18 == 80) {
                        rectG.bottom = Math.max(rectG.bottom, getHeight() - rectG2.top);
                    }
                    int i19 = absoluteGravity & 7;
                    if (i19 == 3) {
                        rectG.left = Math.max(rectG.left, rectG2.right);
                    } else if (i19 == 5) {
                        rectG.right = Math.max(rectG.right, getWidth() - rectG2.left);
                    }
                }
                if (fVar5.f11h != 0 && view4.getVisibility() == 0) {
                    WeakHashMap weakHashMap2 = h0.f3558a;
                    if (view4.isLaidOut() && view4.getWidth() > 0 && view4.getHeight() > 0) {
                        f fVar6 = (f) view4.getLayoutParams();
                        c cVar2 = fVar6.f5a;
                        Rect rectG7 = g();
                        Rect rectG8 = g();
                        rectG8.set(view4.getLeft(), view4.getTop(), view4.getRight(), view4.getBottom());
                        if (cVar2 == null || !cVar2.a(view4)) {
                            rectG7.set(rectG8);
                        } else if (!rectG8.contains(rectG7)) {
                            throw new IllegalArgumentException("Rect should be within the child's bounds. Rect:" + rectG7.toShortString() + " | Bounds:" + rectG8.toShortString());
                        }
                        rectG8.setEmpty();
                        dVar.c(rectG8);
                        if (rectG7.isEmpty()) {
                            rectG7.setEmpty();
                            dVar.c(rectG7);
                        } else {
                            int absoluteGravity2 = Gravity.getAbsoluteGravity(fVar6.f11h, layoutDirection);
                            if ((absoluteGravity2 & 48) != 48 || (i10 = (rectG7.top - ((ViewGroup.MarginLayoutParams) fVar6).topMargin) - fVar6.f13j) >= (i11 = rectG.top)) {
                                z4 = false;
                            } else {
                                u(view4, i11 - i10);
                                z4 = true;
                            }
                            if ((absoluteGravity2 & 80) == 80 && (height = ((getHeight() - rectG7.bottom) - ((ViewGroup.MarginLayoutParams) fVar6).bottomMargin) + fVar6.f13j) < (i9 = rectG.bottom)) {
                                u(view4, height - i9);
                                z4 = true;
                            }
                            if (!z4) {
                                u(view4, 0);
                            }
                            if ((absoluteGravity2 & 3) != 3 || (i7 = (rectG7.left - ((ViewGroup.MarginLayoutParams) fVar6).leftMargin) - fVar6.f12i) >= (i8 = rectG.left)) {
                                z5 = false;
                            } else {
                                t(view4, i8 - i7);
                                z5 = true;
                            }
                            if ((absoluteGravity2 & 5) == 5 && (width = ((getWidth() - rectG7.right) - ((ViewGroup.MarginLayoutParams) fVar6).rightMargin) + fVar6.f12i) < (i6 = rectG.right)) {
                                t(view4, width - i6);
                                z5 = true;
                            }
                            if (!z5) {
                                t(view4, 0);
                            }
                            rectG7.setEmpty();
                            dVar.c(rectG7);
                        }
                    }
                }
                if (i3 != 2) {
                    rect = rect3;
                    rect.set(((f) view4.getLayoutParams()).f18o);
                    if (rect.equals(rectG2)) {
                        arrayList = arrayList3;
                        i5 = i17;
                    } else {
                        ((f) view4.getLayoutParams()).f18o.set(rectG2);
                    }
                } else {
                    rect = rect3;
                }
                int i20 = i4 + 1;
                i5 = i17;
                while (true) {
                    arrayList = arrayList3;
                    if (i20 < i5) {
                        View view5 = (View) arrayList.get(i20);
                        c cVar3 = ((f) view5.getLayoutParams()).f5a;
                        if (cVar3 != null) {
                            cVar3.b(view5);
                        }
                        i20++;
                        arrayList3 = arrayList;
                    }
                }
            }
            i13 = i4 + 1;
            size = i5;
            rectG3 = rect;
            arrayList2 = arrayList;
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        s(false);
        if (this.f461m) {
            if (this.f460l == null) {
                this.f460l = new g(this);
            }
            getViewTreeObserver().addOnPreDrawListener(this.f460l);
        }
        if (this.f462n == null) {
            WeakHashMap weakHashMap = h0.f3558a;
            if (getFitsSystemWindows()) {
                x.c(this);
            }
        }
        this.f456h = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        s(false);
        if (this.f461m && this.f460l != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f460l);
        }
        View view = this.f459k;
        if (view != null) {
            e(view, 0);
        }
        this.f456h = false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.f463o || this.f464p == null) {
            return;
        }
        f1 f1Var = this.f462n;
        int iD = f1Var != null ? f1Var.d() : 0;
        if (iD > 0) {
            this.f464p.setBounds(0, 0, getWidth(), iD);
            this.f464p.draw(canvas);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            s(true);
        }
        boolean zQ = q(motionEvent, 0);
        if (actionMasked != 1 && actionMasked != 3) {
            return zQ;
        }
        s(true);
        return zQ;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z4, int i3, int i4, int i5, int i6) {
        c cVar;
        WeakHashMap weakHashMap = h0.f3558a;
        int layoutDirection = getLayoutDirection();
        ArrayList arrayList = this.f450a;
        int size = arrayList.size();
        for (int i7 = 0; i7 < size; i7++) {
            View view = (View) arrayList.get(i7);
            if (view.getVisibility() != 8 && ((cVar = ((f) view.getLayoutParams()).f5a) == null || !cVar.g(this, view, layoutDirection))) {
                p(view, layoutDirection);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:62:0x0106  */
    /* JADX WARN: Code duplicated, block: B:71:0x0126 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:72:0x0128  */
    /* JADX WARN: Code duplicated, block: B:80:0x013f  */
    /* JADX WARN: Code duplicated, block: B:83:0x016f  */
    /* JADX WARN: Code duplicated, block: B:86:0x0177  */
    /* JADX WARN: Code duplicated, block: B:89:0x019e  */
    /* JADX WARN: Code duplicated, block: B:90:0x01a1  */
    @Override // android.view.View
    public final void onMeasure(int i3, int i4) {
        boolean z4;
        int i5;
        ArrayList arrayList;
        int iMax;
        int iMakeMeasureSpec;
        int iMakeMeasureSpec2;
        c cVar;
        int i6;
        View view;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        boolean zH;
        int i13;
        int i14;
        int absoluteGravity;
        CoordinatorLayout coordinatorLayout = this;
        coordinatorLayout.r();
        int childCount = coordinatorLayout.getChildCount();
        int i15 = 0;
        loop0: while (true) {
            if (i15 >= childCount) {
                z4 = false;
                break;
            }
            View childAt = coordinatorLayout.getChildAt(i15);
            i iVar = (i) coordinatorLayout.f451b.f24b;
            int i16 = iVar.f3742c;
            for (int i17 = 0; i17 < i16; i17++) {
                ArrayList arrayList2 = (ArrayList) iVar.i(i17);
                if (arrayList2 != null && arrayList2.contains(childAt)) {
                    z4 = true;
                    break loop0;
                }
            }
            i15++;
        }
        if (z4 != coordinatorLayout.f461m) {
            if (z4) {
                if (coordinatorLayout.f456h) {
                    if (coordinatorLayout.f460l == null) {
                        coordinatorLayout.f460l = new g(coordinatorLayout);
                    }
                    coordinatorLayout.getViewTreeObserver().addOnPreDrawListener(coordinatorLayout.f460l);
                }
                coordinatorLayout.f461m = true;
            } else {
                if (coordinatorLayout.f456h && coordinatorLayout.f460l != null) {
                    coordinatorLayout.getViewTreeObserver().removeOnPreDrawListener(coordinatorLayout.f460l);
                }
                coordinatorLayout.f461m = false;
            }
        }
        int paddingLeft = coordinatorLayout.getPaddingLeft();
        int paddingTop = coordinatorLayout.getPaddingTop();
        int paddingRight = coordinatorLayout.getPaddingRight();
        int paddingBottom = coordinatorLayout.getPaddingBottom();
        WeakHashMap weakHashMap = h0.f3558a;
        int layoutDirection = coordinatorLayout.getLayoutDirection();
        boolean z5 = layoutDirection == 1;
        int mode = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i3);
        int mode2 = View.MeasureSpec.getMode(i4);
        int size2 = View.MeasureSpec.getSize(i4);
        int i18 = paddingLeft + paddingRight;
        int i19 = paddingTop + paddingBottom;
        int suggestedMinimumWidth = coordinatorLayout.getSuggestedMinimumWidth();
        int suggestedMinimumHeight = coordinatorLayout.getSuggestedMinimumHeight();
        boolean z6 = coordinatorLayout.f462n != null && coordinatorLayout.getFitsSystemWindows();
        ArrayList arrayList3 = coordinatorLayout.f450a;
        int size3 = arrayList3.size();
        int i20 = 0;
        int iCombineMeasuredStates = 0;
        while (i20 < size3) {
            View view2 = (View) arrayList3.get(i20);
            int i21 = suggestedMinimumWidth;
            if (view2.getVisibility() == 8) {
                arrayList = arrayList3;
                i7 = size3;
                i12 = i20;
                i10 = paddingRight;
                suggestedMinimumWidth = i21;
                i8 = paddingLeft;
            } else {
                f fVar = (f) view2.getLayoutParams();
                int i22 = fVar.f9e;
                if (i22 < 0 || mode == 0) {
                    i5 = suggestedMinimumHeight;
                    arrayList = arrayList3;
                } else {
                    i5 = suggestedMinimumHeight;
                    int[] iArr = coordinatorLayout.f457i;
                    if (iArr == null) {
                        coordinatorLayout.toString();
                        arrayList = arrayList3;
                    } else {
                        arrayList = arrayList3;
                        if (i22 < 0 || i22 >= iArr.length) {
                            coordinatorLayout.toString();
                        } else {
                            i13 = iArr[i22];
                        }
                        i14 = fVar.f7c;
                        if (i14 == 0) {
                            i14 = 8388661;
                        }
                        absoluteGravity = Gravity.getAbsoluteGravity(i14, layoutDirection) & 7;
                        if (!(absoluteGravity == 3 || z5) || (absoluteGravity == 5 && z5)) {
                            iMax = Math.max(0, (size - paddingRight) - i13);
                        } else if ((absoluteGravity != 5 && !z5) || (absoluteGravity == 3 && z5)) {
                            iMax = Math.max(0, i13 - paddingLeft);
                        }
                        if (z6 || view2.getFitsSystemWindows()) {
                            iMakeMeasureSpec = i3;
                            iMakeMeasureSpec2 = i4;
                        } else {
                            int iC = coordinatorLayout.f462n.c() + coordinatorLayout.f462n.b();
                            int iA = coordinatorLayout.f462n.a() + coordinatorLayout.f462n.d();
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(size - iC, mode);
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(size2 - iA, mode2);
                        }
                        cVar = fVar.f5a;
                        if (cVar != null) {
                            int i23 = iMax;
                            int i24 = iMakeMeasureSpec;
                            i7 = size3;
                            i8 = paddingLeft;
                            i9 = i21;
                            int i25 = i5;
                            i10 = paddingRight;
                            i11 = i25;
                            i12 = i20;
                            int i26 = iMakeMeasureSpec2;
                            zH = cVar.h(this, view2, i24, i23, i26);
                            view = view2;
                            iMakeMeasureSpec = i24;
                            iMax = i23;
                            i6 = i26;
                            if (zH) {
                                coordinatorLayout = this;
                            }
                            int iMax2 = Math.max(i9, view.getMeasuredWidth() + i18 + ((ViewGroup.MarginLayoutParams) fVar).leftMargin + ((ViewGroup.MarginLayoutParams) fVar).rightMargin);
                            int iMax3 = Math.max(i11, view.getMeasuredHeight() + i19 + ((ViewGroup.MarginLayoutParams) fVar).topMargin + ((ViewGroup.MarginLayoutParams) fVar).bottomMargin);
                            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                            suggestedMinimumWidth = iMax2;
                            suggestedMinimumHeight = iMax3;
                        } else {
                            int i27 = size3;
                            i6 = iMakeMeasureSpec2;
                            view = view2;
                            i7 = i27;
                            i8 = paddingLeft;
                            i9 = i21;
                            int i28 = i5;
                            i10 = paddingRight;
                            i11 = i28;
                            i12 = i20;
                        }
                        coordinatorLayout = this;
                        coordinatorLayout.measureChildWithMargins(view, iMakeMeasureSpec, iMax, i6, 0);
                        int iMax4 = Math.max(i9, view.getMeasuredWidth() + i18 + ((ViewGroup.MarginLayoutParams) fVar).leftMargin + ((ViewGroup.MarginLayoutParams) fVar).rightMargin);
                        int iMax5 = Math.max(i11, view.getMeasuredHeight() + i19 + ((ViewGroup.MarginLayoutParams) fVar).topMargin + ((ViewGroup.MarginLayoutParams) fVar).bottomMargin);
                        iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                        suggestedMinimumWidth = iMax4;
                        suggestedMinimumHeight = iMax5;
                    }
                    i13 = 0;
                    i14 = fVar.f7c;
                    if (i14 == 0) {
                        i14 = 8388661;
                    }
                    absoluteGravity = Gravity.getAbsoluteGravity(i14, layoutDirection) & 7;
                    if (absoluteGravity == 3) {
                        if (absoluteGravity != 5) {
                        }
                    } else if (absoluteGravity != 5) {
                    }
                    if (z6) {
                        iMakeMeasureSpec = i3;
                        iMakeMeasureSpec2 = i4;
                    } else {
                        iMakeMeasureSpec = i3;
                        iMakeMeasureSpec2 = i4;
                    }
                    cVar = fVar.f5a;
                    if (cVar != null) {
                        int i29 = iMax;
                        int i210 = iMakeMeasureSpec;
                        i7 = size3;
                        i8 = paddingLeft;
                        i9 = i21;
                        int i211 = i5;
                        i10 = paddingRight;
                        i11 = i211;
                        i12 = i20;
                        int i212 = iMakeMeasureSpec2;
                        zH = cVar.h(this, view2, i210, i29, i212);
                        view = view2;
                        iMakeMeasureSpec = i210;
                        iMax = i29;
                        i6 = i212;
                        if (zH) {
                            coordinatorLayout = this;
                        }
                        int iMax6 = Math.max(i9, view.getMeasuredWidth() + i18 + ((ViewGroup.MarginLayoutParams) fVar).leftMargin + ((ViewGroup.MarginLayoutParams) fVar).rightMargin);
                        int iMax7 = Math.max(i11, view.getMeasuredHeight() + i19 + ((ViewGroup.MarginLayoutParams) fVar).topMargin + ((ViewGroup.MarginLayoutParams) fVar).bottomMargin);
                        iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                        suggestedMinimumWidth = iMax6;
                        suggestedMinimumHeight = iMax7;
                    } else {
                        int i213 = size3;
                        i6 = iMakeMeasureSpec2;
                        view = view2;
                        i7 = i213;
                        i8 = paddingLeft;
                        i9 = i21;
                        int i214 = i5;
                        i10 = paddingRight;
                        i11 = i214;
                        i12 = i20;
                    }
                    coordinatorLayout = this;
                    coordinatorLayout.measureChildWithMargins(view, iMakeMeasureSpec, iMax, i6, 0);
                    int iMax8 = Math.max(i9, view.getMeasuredWidth() + i18 + ((ViewGroup.MarginLayoutParams) fVar).leftMargin + ((ViewGroup.MarginLayoutParams) fVar).rightMargin);
                    int iMax9 = Math.max(i11, view.getMeasuredHeight() + i19 + ((ViewGroup.MarginLayoutParams) fVar).topMargin + ((ViewGroup.MarginLayoutParams) fVar).bottomMargin);
                    iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                    suggestedMinimumWidth = iMax8;
                    suggestedMinimumHeight = iMax9;
                }
                iMax = 0;
                if (z6) {
                    iMakeMeasureSpec = i3;
                    iMakeMeasureSpec2 = i4;
                } else {
                    iMakeMeasureSpec = i3;
                    iMakeMeasureSpec2 = i4;
                }
                cVar = fVar.f5a;
                if (cVar != null) {
                    int i215 = iMax;
                    int i216 = iMakeMeasureSpec;
                    i7 = size3;
                    i8 = paddingLeft;
                    i9 = i21;
                    int i217 = i5;
                    i10 = paddingRight;
                    i11 = i217;
                    i12 = i20;
                    int i218 = iMakeMeasureSpec2;
                    zH = cVar.h(this, view2, i216, i215, i218);
                    view = view2;
                    iMakeMeasureSpec = i216;
                    iMax = i215;
                    i6 = i218;
                    if (zH) {
                        coordinatorLayout = this;
                    }
                    int iMax10 = Math.max(i9, view.getMeasuredWidth() + i18 + ((ViewGroup.MarginLayoutParams) fVar).leftMargin + ((ViewGroup.MarginLayoutParams) fVar).rightMargin);
                    int iMax11 = Math.max(i11, view.getMeasuredHeight() + i19 + ((ViewGroup.MarginLayoutParams) fVar).topMargin + ((ViewGroup.MarginLayoutParams) fVar).bottomMargin);
                    iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                    suggestedMinimumWidth = iMax10;
                    suggestedMinimumHeight = iMax11;
                } else {
                    int i219 = size3;
                    i6 = iMakeMeasureSpec2;
                    view = view2;
                    i7 = i219;
                    i8 = paddingLeft;
                    i9 = i21;
                    int i2110 = i5;
                    i10 = paddingRight;
                    i11 = i2110;
                    i12 = i20;
                }
                coordinatorLayout = this;
                coordinatorLayout.measureChildWithMargins(view, iMakeMeasureSpec, iMax, i6, 0);
                int iMax12 = Math.max(i9, view.getMeasuredWidth() + i18 + ((ViewGroup.MarginLayoutParams) fVar).leftMargin + ((ViewGroup.MarginLayoutParams) fVar).rightMargin);
                int iMax13 = Math.max(i11, view.getMeasuredHeight() + i19 + ((ViewGroup.MarginLayoutParams) fVar).topMargin + ((ViewGroup.MarginLayoutParams) fVar).bottomMargin);
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                suggestedMinimumWidth = iMax12;
                suggestedMinimumHeight = iMax13;
            }
            i20 = i12 + 1;
            size3 = i7;
            paddingLeft = i8;
            paddingRight = i10;
            arrayList3 = arrayList;
        }
        int i30 = iCombineMeasuredStates;
        coordinatorLayout.setMeasuredDimension(View.resolveSizeAndState(suggestedMinimumWidth, i3, (-16777216) & i30), View.resolveSizeAndState(suggestedMinimumHeight, i4, i30 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f4, boolean z4) {
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8) {
                f fVar = (f) childAt.getLayoutParams();
                if (fVar.a(0)) {
                    c cVar = fVar.f5a;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f4) {
        c cVar;
        int childCount = getChildCount();
        boolean zI = false;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8) {
                f fVar = (f) childAt.getLayoutParams();
                if (fVar.a(0) && (cVar = fVar.f5a) != null) {
                    zI |= cVar.i(view);
                }
            }
        }
        return zI;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i3, int i4, int[] iArr) {
        f(view, i3, i4, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i3, int i4, int i5, int i6) {
        b(view, i3, i4, i5, i6, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i3) {
        d(view, view2, i3, 0);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof a0.i)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        a0.i iVar = (a0.i) parcelable;
        super.onRestoreInstanceState(iVar.f3827a);
        SparseArray sparseArray = iVar.f21c;
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            int id = childAt.getId();
            c cVar = m(childAt).f5a;
            if (id != -1 && cVar != null && (parcelable2 = (Parcelable) sparseArray.get(id)) != null) {
                cVar.m(childAt, parcelable2);
            }
        }
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        Parcelable parcelableN;
        a0.i iVar = new a0.i(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            int id = childAt.getId();
            c cVar = ((f) childAt.getLayoutParams()).f5a;
            if (id != -1 && cVar != null && (parcelableN = cVar.n(childAt)) != null) {
                sparseArray.append(id, parcelableN);
            }
        }
        iVar.f21c = sparseArray;
        return iVar;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i3) {
        return c(view, view2, i3, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        e(view, 0);
    }

    /* JADX WARN: Code duplicated, block: B:14:0x002f  */
    /* JADX WARN: Code duplicated, block: B:15:0x0035 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:16:0x0037  */
    /* JADX WARN: Code duplicated, block: B:18:0x004a  */
    /* JADX WARN: Code duplicated, block: B:7:0x0015 A[PHI: r3
  0x0015: PHI (r3v4 boolean) = (r3v2 boolean), (r3v5 boolean) binds: [B:10:0x0022, B:5:0x0012] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean zQ;
        boolean zQ2;
        MotionEvent motionEventObtain;
        int actionMasked = motionEvent.getActionMasked();
        if (this.f458j == null) {
            zQ = q(motionEvent, 1);
            if (!zQ) {
                zQ2 = false;
            }
            motionEventObtain = null;
            if (this.f458j == null) {
                zQ2 |= super.onTouchEvent(motionEvent);
            } else if (zQ) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                super.onTouchEvent(motionEventObtain);
            }
            if (motionEventObtain != null) {
                motionEventObtain.recycle();
            }
            if (actionMasked == 1 && actionMasked != 3) {
                return zQ2;
            }
            s(false);
            return zQ2;
        }
        zQ = false;
        c cVar = ((f) this.f458j.getLayoutParams()).f5a;
        if (cVar != null) {
            zQ2 = cVar.q(this.f458j, motionEvent);
        } else {
            zQ2 = false;
        }
        motionEventObtain = null;
        if (this.f458j == null) {
            zQ2 |= super.onTouchEvent(motionEvent);
        } else if (zQ) {
            long jUptimeMillis2 = SystemClock.uptimeMillis();
            motionEventObtain = MotionEvent.obtain(jUptimeMillis2, jUptimeMillis2, 3, 0.0f, 0.0f, 0);
            super.onTouchEvent(motionEventObtain);
        }
        if (motionEventObtain != null) {
            motionEventObtain.recycle();
        }
        if (actionMasked == 1) {
        }
        s(false);
        return zQ2;
    }

    public final void p(View view, int i3) {
        int i4;
        f fVar = (f) view.getLayoutParams();
        View view2 = fVar.f14k;
        if (view2 == null && fVar.f != -1) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
        d dVar = f449x;
        if (view2 != null) {
            Rect rectG = g();
            Rect rectG2 = g();
            try {
                k(rectG, view2);
                f fVar2 = (f) view.getLayoutParams();
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                l(i3, rectG, rectG2, fVar2, measuredWidth, measuredHeight);
                h(fVar2, rectG2, measuredWidth, measuredHeight);
                view.layout(rectG2.left, rectG2.top, rectG2.right, rectG2.bottom);
                return;
            } finally {
                rectG.setEmpty();
                dVar.c(rectG);
                rectG2.setEmpty();
                dVar.c(rectG2);
            }
        }
        int i5 = fVar.f9e;
        if (i5 < 0) {
            f fVar3 = (f) view.getLayoutParams();
            Rect rectG3 = g();
            rectG3.set(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) fVar3).leftMargin, getPaddingTop() + ((ViewGroup.MarginLayoutParams) fVar3).topMargin, (getWidth() - getPaddingRight()) - ((ViewGroup.MarginLayoutParams) fVar3).rightMargin, (getHeight() - getPaddingBottom()) - ((ViewGroup.MarginLayoutParams) fVar3).bottomMargin);
            if (this.f462n != null) {
                WeakHashMap weakHashMap = h0.f3558a;
                if (getFitsSystemWindows() && !view.getFitsSystemWindows()) {
                    rectG3.left = this.f462n.b() + rectG3.left;
                    rectG3.top = this.f462n.d() + rectG3.top;
                    rectG3.right -= this.f462n.c();
                    rectG3.bottom -= this.f462n.a();
                }
            }
            Rect rectG4 = g();
            int i6 = fVar3.f7c;
            if ((i6 & 7) == 0) {
                i6 |= 8388611;
            }
            if ((i6 & 112) == 0) {
                i6 |= 48;
            }
            Gravity.apply(i6, view.getMeasuredWidth(), view.getMeasuredHeight(), rectG3, rectG4, i3);
            view.layout(rectG4.left, rectG4.top, rectG4.right, rectG4.bottom);
            rectG3.setEmpty();
            dVar.c(rectG3);
            rectG4.setEmpty();
            dVar.c(rectG4);
            return;
        }
        f fVar4 = (f) view.getLayoutParams();
        int i7 = fVar4.f7c;
        if (i7 == 0) {
            i7 = 8388661;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i7, i3);
        int i8 = absoluteGravity & 7;
        int i9 = absoluteGravity & 112;
        int width = getWidth();
        int height = getHeight();
        int measuredWidth2 = view.getMeasuredWidth();
        int measuredHeight2 = view.getMeasuredHeight();
        if (i3 == 1) {
            i5 = width - i5;
        }
        int i10 = 0;
        int[] iArr = this.f457i;
        if (iArr != null && i5 >= 0 && i5 < iArr.length) {
            i4 = iArr[i5];
        } else {
            toString();
            i4 = 0;
        }
        int i11 = i4 - measuredWidth2;
        if (i8 == 1) {
            i11 += measuredWidth2 / 2;
        } else if (i8 == 5) {
            i11 += measuredWidth2;
        }
        if (i9 == 16) {
            i10 = measuredHeight2 / 2;
        } else if (i9 == 80) {
            i10 = measuredHeight2;
        }
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) fVar4).leftMargin, Math.min(i11, ((width - getPaddingRight()) - measuredWidth2) - ((ViewGroup.MarginLayoutParams) fVar4).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) fVar4).topMargin, Math.min(i10, ((height - getPaddingBottom()) - measuredHeight2) - ((ViewGroup.MarginLayoutParams) fVar4).bottomMargin));
        view.layout(iMax, iMax2, measuredWidth2 + iMax, measuredHeight2 + iMax2);
    }

    public final boolean q(MotionEvent motionEvent, int i3) {
        int actionMasked = motionEvent.getActionMasked();
        ArrayList arrayList = this.f452c;
        arrayList.clear();
        boolean zIsChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i4 = childCount - 1; i4 >= 0; i4--) {
            arrayList.add(getChildAt(zIsChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i4) : i4));
        }
        j jVar = f448w;
        if (jVar != null) {
            Collections.sort(arrayList, jVar);
        }
        int size = arrayList.size();
        MotionEvent motionEventObtain = null;
        boolean zF = false;
        for (int i5 = 0; i5 < size; i5++) {
            View view = (View) arrayList.get(i5);
            c cVar = ((f) view.getLayoutParams()).f5a;
            if (zF && actionMasked != 0) {
                if (cVar != null) {
                    if (motionEventObtain == null) {
                        long jUptimeMillis = SystemClock.uptimeMillis();
                        motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                    }
                    if (i3 == 0) {
                        cVar.f(this, view, motionEventObtain);
                    } else if (i3 == 1) {
                        cVar.q(view, motionEventObtain);
                    }
                }
            } else if (!zF && cVar != null) {
                if (i3 == 0) {
                    zF = cVar.f(this, view, motionEvent);
                } else if (i3 == 1) {
                    zF = cVar.q(view, motionEvent);
                }
                if (zF) {
                    this.f458j = view;
                }
            }
        }
        arrayList.clear();
        return zF;
    }

    /* JADX WARN: Code duplicated, block: B:102:0x0089 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:31:0x007c A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:32:0x007e  */
    /* JADX WARN: Code duplicated, block: B:34:0x0084  */
    /* JADX WARN: Code duplicated, block: B:37:0x0091  */
    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Not found exit edge by exit block: B:38:0x0095
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.checkLoopExits(LoopRegionMaker.java:272)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.makeLoopRegion(LoopRegionMaker.java:237)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(LoopRegionMaker.java:80)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:92)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:117)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:111)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:111)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:111)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.makeEndlessLoop(LoopRegionMaker.java:590)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(LoopRegionMaker.java:82)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:92)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:117)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:117)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(LoopRegionMaker.java:162)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:92)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeMthRegion(RegionMaker.java:49)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:25)
        */
    public final void r() {
        /*
            Method dump skipped, instruction units count: 400
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.r():void");
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z4) {
        c cVar = ((f) view.getLayoutParams()).f5a;
        if (cVar != null) {
            cVar.l(this, view);
        }
        return super.requestChildRectangleOnScreen(view, rect, z4);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z4) {
        super.requestDisallowInterceptTouchEvent(z4);
        if (!z4 || this.f455g) {
            return;
        }
        s(false);
        this.f455g = true;
    }

    public final void s(boolean z4) {
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            c cVar = ((f) childAt.getLayoutParams()).f5a;
            if (cVar != null) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z4) {
                    cVar.f(this, childAt, motionEventObtain);
                } else {
                    cVar.q(childAt, motionEventObtain);
                }
                motionEventObtain.recycle();
            }
        }
        for (int i4 = 0; i4 < childCount; i4++) {
            ((f) getChildAt(i4).getLayoutParams()).getClass();
        }
        this.f458j = null;
        this.f455g = false;
    }

    @Override // android.view.View
    public void setFitsSystemWindows(boolean z4) {
        super.setFitsSystemWindows(z4);
        v();
    }

    @Override // android.view.ViewGroup
    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f465q = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f464p;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            Drawable drawableMutate = drawable != null ? drawable.mutate() : null;
            this.f464p = drawableMutate;
            if (drawableMutate != null) {
                if (drawableMutate.isStateful()) {
                    this.f464p.setState(getDrawableState());
                }
                Drawable drawable3 = this.f464p;
                WeakHashMap weakHashMap = h0.f3558a;
                a3.a.e0(drawable3, getLayoutDirection());
                this.f464p.setVisible(getVisibility() == 0, false);
                this.f464p.setCallback(this);
            }
            WeakHashMap weakHashMap2 = h0.f3558a;
            postInvalidateOnAnimation();
        }
    }

    public void setStatusBarBackgroundColor(int i3) {
        setStatusBarBackground(new ColorDrawable(i3));
    }

    public void setStatusBarBackgroundResource(int i3) {
        setStatusBarBackground(i3 != 0 ? getContext().getDrawable(i3) : null);
    }

    @Override // android.view.View
    public void setVisibility(int i3) {
        super.setVisibility(i3);
        boolean z4 = i3 == 0;
        Drawable drawable = this.f464p;
        if (drawable == null || drawable.isVisible() == z4) {
            return;
        }
        this.f464p.setVisible(z4, false);
    }

    public final void v() {
        WeakHashMap weakHashMap = h0.f3558a;
        if (!getFitsSystemWindows()) {
            z.m(this, null);
            return;
        }
        if (this.f466r == null) {
            this.f466r = new b(0, this);
        }
        z.m(this, this.f466r);
        setSystemUiVisibility(1280);
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f464p;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof f) {
            return new f((f) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new f((ViewGroup.MarginLayoutParams) layoutParams) : new f(layoutParams);
    }
}
