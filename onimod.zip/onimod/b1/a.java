package b1;

import androidx.lifecycle.i0;
import q.j;
import s2.e;

/* JADX INFO: loaded from: classes.dex */
public class a extends i0 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final e f1036e = new e(7);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final j f1037d = new j();

    @Override // androidx.lifecycle.i0
    public final void c() {
        j jVar = this.f1037d;
        int i3 = jVar.f3745c;
        if (i3 > 0) {
            jVar.f3744b[0].getClass();
            throw new ClassCastException();
        }
        Object[] objArr = jVar.f3744b;
        for (int i4 = 0; i4 < i3; i4++) {
            objArr[i4] = null;
        }
        jVar.f3745c = 0;
    }
}
