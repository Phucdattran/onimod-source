package black.android.accounts;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIAccountManagerStub {
    public static IAccountManagerStubStatic get() {
        return (IAccountManagerStubStatic) BlackReflection.create(IAccountManagerStubStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IAccountManagerStubContext.class);
    }

    public static IAccountManagerStubStatic getWithException() {
        return (IAccountManagerStubStatic) BlackReflection.create(IAccountManagerStubStatic.class, null, true);
    }

    public static IAccountManagerStubContext get(Object obj) {
        return (IAccountManagerStubContext) BlackReflection.create(IAccountManagerStubContext.class, obj, false);
    }

    public static IAccountManagerStubContext getWithException(Object obj) {
        return (IAccountManagerStubContext) BlackReflection.create(IAccountManagerStubContext.class, obj, true);
    }
}
