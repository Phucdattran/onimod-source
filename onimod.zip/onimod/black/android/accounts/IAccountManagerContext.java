package black.android.accounts;

import top.niunaijun.blackreflection.annotation.BClassNameNotProcess;

/* JADX INFO: loaded from: classes.dex */
@BClassNameNotProcess("android.accounts.IAccountManager")
public interface IAccountManagerContext {
}
