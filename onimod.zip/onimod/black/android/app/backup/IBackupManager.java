package black.android.app.backup;

import android.os.IBinder;
import android.os.IInterface;
import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BStaticMethod;

/* JADX INFO: loaded from: classes.dex */
@BClassName("android.app.backup.IBackupManager")
public interface IBackupManager {

    @BClassName("android.app.backup.IBackupManager$Stub")
    public interface Stub {
        @BStaticMethod
        IInterface asInterface(IBinder iBinder);
    }
}
