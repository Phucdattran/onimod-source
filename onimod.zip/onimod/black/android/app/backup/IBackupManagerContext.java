package black.android.app.backup;

import top.niunaijun.blackreflection.annotation.BClassNameNotProcess;

/* JADX INFO: loaded from: classes.dex */
@BClassNameNotProcess("android.app.backup.IBackupManager")
public interface IBackupManagerContext {
}
