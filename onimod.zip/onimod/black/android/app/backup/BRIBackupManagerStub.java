package black.android.app.backup;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIBackupManagerStub {
    public static IBackupManagerStubStatic get() {
        return (IBackupManagerStubStatic) BlackReflection.create(IBackupManagerStubStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IBackupManagerStubContext.class);
    }

    public static IBackupManagerStubStatic getWithException() {
        return (IBackupManagerStubStatic) BlackReflection.create(IBackupManagerStubStatic.class, null, true);
    }

    public static IBackupManagerStubContext get(Object obj) {
        return (IBackupManagerStubContext) BlackReflection.create(IBackupManagerStubContext.class, obj, false);
    }

    public static IBackupManagerStubContext getWithException(Object obj) {
        return (IBackupManagerStubContext) BlackReflection.create(IBackupManagerStubContext.class, obj, true);
    }
}
