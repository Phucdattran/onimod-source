package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRNotificationO {
    public static NotificationOStatic get() {
        return (NotificationOStatic) BlackReflection.create(NotificationOStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) NotificationOContext.class);
    }

    public static NotificationOStatic getWithException() {
        return (NotificationOStatic) BlackReflection.create(NotificationOStatic.class, null, true);
    }

    public static NotificationOContext get(Object obj) {
        return (NotificationOContext) BlackReflection.create(NotificationOContext.class, obj, false);
    }

    public static NotificationOContext getWithException(Object obj) {
        return (NotificationOContext) BlackReflection.create(NotificationOContext.class, obj, true);
    }
}
