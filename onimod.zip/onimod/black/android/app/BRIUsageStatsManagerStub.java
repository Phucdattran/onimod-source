package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIUsageStatsManagerStub {
    public static IUsageStatsManagerStubStatic get() {
        return (IUsageStatsManagerStubStatic) BlackReflection.create(IUsageStatsManagerStubStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IUsageStatsManagerStubContext.class);
    }

    public static IUsageStatsManagerStubStatic getWithException() {
        return (IUsageStatsManagerStubStatic) BlackReflection.create(IUsageStatsManagerStubStatic.class, null, true);
    }

    public static IUsageStatsManagerStubContext get(Object obj) {
        return (IUsageStatsManagerStubContext) BlackReflection.create(IUsageStatsManagerStubContext.class, obj, false);
    }

    public static IUsageStatsManagerStubContext getWithException(Object obj) {
        return (IUsageStatsManagerStubContext) BlackReflection.create(IUsageStatsManagerStubContext.class, obj, true);
    }
}
