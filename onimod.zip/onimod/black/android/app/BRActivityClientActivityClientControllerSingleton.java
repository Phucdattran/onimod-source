package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityClientActivityClientControllerSingleton {
    public static ActivityClientActivityClientControllerSingletonStatic get() {
        return (ActivityClientActivityClientControllerSingletonStatic) BlackReflection.create(ActivityClientActivityClientControllerSingletonStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityClientActivityClientControllerSingletonContext.class);
    }

    public static ActivityClientActivityClientControllerSingletonStatic getWithException() {
        return (ActivityClientActivityClientControllerSingletonStatic) BlackReflection.create(ActivityClientActivityClientControllerSingletonStatic.class, null, true);
    }

    public static ActivityClientActivityClientControllerSingletonContext get(Object obj) {
        return (ActivityClientActivityClientControllerSingletonContext) BlackReflection.create(ActivityClientActivityClientControllerSingletonContext.class, obj, false);
    }

    public static ActivityClientActivityClientControllerSingletonContext getWithException(Object obj) {
        return (ActivityClientActivityClientControllerSingletonContext) BlackReflection.create(ActivityClientActivityClientControllerSingletonContext.class, obj, true);
    }
}
