package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRLoadedApkReceiverDispatcherInnerReceiver {
    public static LoadedApkReceiverDispatcherInnerReceiverStatic get() {
        return (LoadedApkReceiverDispatcherInnerReceiverStatic) BlackReflection.create(LoadedApkReceiverDispatcherInnerReceiverStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) LoadedApkReceiverDispatcherInnerReceiverContext.class);
    }

    public static LoadedApkReceiverDispatcherInnerReceiverStatic getWithException() {
        return (LoadedApkReceiverDispatcherInnerReceiverStatic) BlackReflection.create(LoadedApkReceiverDispatcherInnerReceiverStatic.class, null, true);
    }

    public static LoadedApkReceiverDispatcherInnerReceiverContext get(Object obj) {
        return (LoadedApkReceiverDispatcherInnerReceiverContext) BlackReflection.create(LoadedApkReceiverDispatcherInnerReceiverContext.class, obj, false);
    }

    public static LoadedApkReceiverDispatcherInnerReceiverContext getWithException(Object obj) {
        return (LoadedApkReceiverDispatcherInnerReceiverContext) BlackReflection.create(LoadedApkReceiverDispatcherInnerReceiverContext.class, obj, true);
    }
}
