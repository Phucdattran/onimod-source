package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityManager {
    public static ActivityManagerStatic get() {
        return (ActivityManagerStatic) BlackReflection.create(ActivityManagerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityManagerContext.class);
    }

    public static ActivityManagerStatic getWithException() {
        return (ActivityManagerStatic) BlackReflection.create(ActivityManagerStatic.class, null, true);
    }

    public static ActivityManagerContext get(Object obj) {
        return (ActivityManagerContext) BlackReflection.create(ActivityManagerContext.class, obj, false);
    }

    public static ActivityManagerContext getWithException(Object obj) {
        return (ActivityManagerContext) BlackReflection.create(ActivityManagerContext.class, obj, true);
    }
}
