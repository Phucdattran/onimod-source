package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIActivityManagerN {
    public static IActivityManagerNStatic get() {
        return (IActivityManagerNStatic) BlackReflection.create(IActivityManagerNStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IActivityManagerNContext.class);
    }

    public static IActivityManagerNStatic getWithException() {
        return (IActivityManagerNStatic) BlackReflection.create(IActivityManagerNStatic.class, null, true);
    }

    public static IActivityManagerNContext get(Object obj) {
        return (IActivityManagerNContext) BlackReflection.create(IActivityManagerNContext.class, obj, false);
    }

    public static IActivityManagerNContext getWithException(Object obj) {
        return (IActivityManagerNContext) BlackReflection.create(IActivityManagerNContext.class, obj, true);
    }
}
