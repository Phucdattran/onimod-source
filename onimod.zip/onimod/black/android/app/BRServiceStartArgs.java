package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRServiceStartArgs {
    public static ServiceStartArgsStatic get() {
        return (ServiceStartArgsStatic) BlackReflection.create(ServiceStartArgsStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ServiceStartArgsContext.class);
    }

    public static ServiceStartArgsStatic getWithException() {
        return (ServiceStartArgsStatic) BlackReflection.create(ServiceStartArgsStatic.class, null, true);
    }

    public static ServiceStartArgsContext get(Object obj) {
        return (ServiceStartArgsContext) BlackReflection.create(ServiceStartArgsContext.class, obj, false);
    }

    public static ServiceStartArgsContext getWithException(Object obj) {
        return (ServiceStartArgsContext) BlackReflection.create(ServiceStartArgsContext.class, obj, true);
    }
}
