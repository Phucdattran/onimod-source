package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityThreadProviderClientRecordP {
    public static ActivityThreadProviderClientRecordPStatic get() {
        return (ActivityThreadProviderClientRecordPStatic) BlackReflection.create(ActivityThreadProviderClientRecordPStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityThreadProviderClientRecordPContext.class);
    }

    public static ActivityThreadProviderClientRecordPStatic getWithException() {
        return (ActivityThreadProviderClientRecordPStatic) BlackReflection.create(ActivityThreadProviderClientRecordPStatic.class, null, true);
    }

    public static ActivityThreadProviderClientRecordPContext get(Object obj) {
        return (ActivityThreadProviderClientRecordPContext) BlackReflection.create(ActivityThreadProviderClientRecordPContext.class, obj, false);
    }

    public static ActivityThreadProviderClientRecordPContext getWithException(Object obj) {
        return (ActivityThreadProviderClientRecordPContext) BlackReflection.create(ActivityThreadProviderClientRecordPContext.class, obj, true);
    }
}
