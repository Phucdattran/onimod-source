package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIActivityTaskManager {
    public static IActivityTaskManagerStatic get() {
        return (IActivityTaskManagerStatic) BlackReflection.create(IActivityTaskManagerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IActivityTaskManagerContext.class);
    }

    public static IActivityTaskManagerStatic getWithException() {
        return (IActivityTaskManagerStatic) BlackReflection.create(IActivityTaskManagerStatic.class, null, true);
    }

    public static IActivityTaskManagerContext get(Object obj) {
        return (IActivityTaskManagerContext) BlackReflection.create(IActivityTaskManagerContext.class, obj, false);
    }

    public static IActivityTaskManagerContext getWithException(Object obj) {
        return (IActivityTaskManagerContext) BlackReflection.create(IActivityTaskManagerContext.class, obj, true);
    }
}
