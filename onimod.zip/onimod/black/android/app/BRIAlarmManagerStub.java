package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIAlarmManagerStub {
    public static IAlarmManagerStubStatic get() {
        return (IAlarmManagerStubStatic) BlackReflection.create(IAlarmManagerStubStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IAlarmManagerStubContext.class);
    }

    public static IAlarmManagerStubStatic getWithException() {
        return (IAlarmManagerStubStatic) BlackReflection.create(IAlarmManagerStubStatic.class, null, true);
    }

    public static IAlarmManagerStubContext get(Object obj) {
        return (IAlarmManagerStubContext) BlackReflection.create(IAlarmManagerStubContext.class, obj, false);
    }

    public static IAlarmManagerStubContext getWithException(Object obj) {
        return (IAlarmManagerStubContext) BlackReflection.create(IAlarmManagerStubContext.class, obj, true);
    }
}
