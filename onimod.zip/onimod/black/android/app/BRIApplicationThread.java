package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIApplicationThread {
    public static IApplicationThreadStatic get() {
        return (IApplicationThreadStatic) BlackReflection.create(IApplicationThreadStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IApplicationThreadContext.class);
    }

    public static IApplicationThreadStatic getWithException() {
        return (IApplicationThreadStatic) BlackReflection.create(IApplicationThreadStatic.class, null, true);
    }

    public static IApplicationThreadContext get(Object obj) {
        return (IApplicationThreadContext) BlackReflection.create(IApplicationThreadContext.class, obj, false);
    }

    public static IApplicationThreadContext getWithException(Object obj) {
        return (IApplicationThreadContext) BlackReflection.create(IApplicationThreadContext.class, obj, true);
    }
}
