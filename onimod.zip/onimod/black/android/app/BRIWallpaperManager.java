package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIWallpaperManager {
    public static IWallpaperManagerStatic get() {
        return (IWallpaperManagerStatic) BlackReflection.create(IWallpaperManagerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IWallpaperManagerContext.class);
    }

    public static IWallpaperManagerStatic getWithException() {
        return (IWallpaperManagerStatic) BlackReflection.create(IWallpaperManagerStatic.class, null, true);
    }

    public static IWallpaperManagerContext get(Object obj) {
        return (IWallpaperManagerContext) BlackReflection.create(IWallpaperManagerContext.class, obj, false);
    }

    public static IWallpaperManagerContext getWithException(Object obj) {
        return (IWallpaperManagerContext) BlackReflection.create(IWallpaperManagerContext.class, obj, true);
    }
}
