package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityThreadProviderClientRecordJB {
    public static ActivityThreadProviderClientRecordJBStatic get() {
        return (ActivityThreadProviderClientRecordJBStatic) BlackReflection.create(ActivityThreadProviderClientRecordJBStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityThreadProviderClientRecordJBContext.class);
    }

    public static ActivityThreadProviderClientRecordJBStatic getWithException() {
        return (ActivityThreadProviderClientRecordJBStatic) BlackReflection.create(ActivityThreadProviderClientRecordJBStatic.class, null, true);
    }

    public static ActivityThreadProviderClientRecordJBContext get(Object obj) {
        return (ActivityThreadProviderClientRecordJBContext) BlackReflection.create(ActivityThreadProviderClientRecordJBContext.class, obj, false);
    }

    public static ActivityThreadProviderClientRecordJBContext getWithException(Object obj) {
        return (ActivityThreadProviderClientRecordJBContext) BlackReflection.create(ActivityThreadProviderClientRecordJBContext.class, obj, true);
    }
}
