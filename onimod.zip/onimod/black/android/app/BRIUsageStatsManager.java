package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIUsageStatsManager {
    public static IUsageStatsManagerStatic get() {
        return (IUsageStatsManagerStatic) BlackReflection.create(IUsageStatsManagerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IUsageStatsManagerContext.class);
    }

    public static IUsageStatsManagerStatic getWithException() {
        return (IUsageStatsManagerStatic) BlackReflection.create(IUsageStatsManagerStatic.class, null, true);
    }

    public static IUsageStatsManagerContext get(Object obj) {
        return (IUsageStatsManagerContext) BlackReflection.create(IUsageStatsManagerContext.class, obj, false);
    }

    public static IUsageStatsManagerContext getWithException(Object obj) {
        return (IUsageStatsManagerContext) BlackReflection.create(IUsageStatsManagerContext.class, obj, true);
    }
}
