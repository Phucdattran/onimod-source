package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRWallpaperManagerGlobals {
    public static WallpaperManagerGlobalsStatic get() {
        return (WallpaperManagerGlobalsStatic) BlackReflection.create(WallpaperManagerGlobalsStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) WallpaperManagerGlobalsContext.class);
    }

    public static WallpaperManagerGlobalsStatic getWithException() {
        return (WallpaperManagerGlobalsStatic) BlackReflection.create(WallpaperManagerGlobalsStatic.class, null, true);
    }

    public static WallpaperManagerGlobalsContext get(Object obj) {
        return (WallpaperManagerGlobalsContext) BlackReflection.create(WallpaperManagerGlobalsContext.class, obj, false);
    }

    public static WallpaperManagerGlobalsContext getWithException(Object obj) {
        return (WallpaperManagerGlobalsContext) BlackReflection.create(WallpaperManagerGlobalsContext.class, obj, true);
    }
}
