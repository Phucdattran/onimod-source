package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityThreadCreateServiceData {
    public static ActivityThreadCreateServiceDataStatic get() {
        return (ActivityThreadCreateServiceDataStatic) BlackReflection.create(ActivityThreadCreateServiceDataStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityThreadCreateServiceDataContext.class);
    }

    public static ActivityThreadCreateServiceDataStatic getWithException() {
        return (ActivityThreadCreateServiceDataStatic) BlackReflection.create(ActivityThreadCreateServiceDataStatic.class, null, true);
    }

    public static ActivityThreadCreateServiceDataContext get(Object obj) {
        return (ActivityThreadCreateServiceDataContext) BlackReflection.create(ActivityThreadCreateServiceDataContext.class, obj, false);
    }

    public static ActivityThreadCreateServiceDataContext getWithException(Object obj) {
        return (ActivityThreadCreateServiceDataContext) BlackReflection.create(ActivityThreadCreateServiceDataContext.class, obj, true);
    }
}
