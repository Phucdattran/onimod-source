package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityThreadAppBindData {
    public static ActivityThreadAppBindDataStatic get() {
        return (ActivityThreadAppBindDataStatic) BlackReflection.create(ActivityThreadAppBindDataStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityThreadAppBindDataContext.class);
    }

    public static ActivityThreadAppBindDataStatic getWithException() {
        return (ActivityThreadAppBindDataStatic) BlackReflection.create(ActivityThreadAppBindDataStatic.class, null, true);
    }

    public static ActivityThreadAppBindDataContext get(Object obj) {
        return (ActivityThreadAppBindDataContext) BlackReflection.create(ActivityThreadAppBindDataContext.class, obj, false);
    }

    public static ActivityThreadAppBindDataContext getWithException(Object obj) {
        return (ActivityThreadAppBindDataContext) BlackReflection.create(ActivityThreadAppBindDataContext.class, obj, true);
    }
}
