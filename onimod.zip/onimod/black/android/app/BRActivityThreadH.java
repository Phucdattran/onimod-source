package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityThreadH {
    public static ActivityThreadHStatic get() {
        return (ActivityThreadHStatic) BlackReflection.create(ActivityThreadHStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityThreadHContext.class);
    }

    public static ActivityThreadHStatic getWithException() {
        return (ActivityThreadHStatic) BlackReflection.create(ActivityThreadHStatic.class, null, true);
    }

    public static ActivityThreadHContext get(Object obj) {
        return (ActivityThreadHContext) BlackReflection.create(ActivityThreadHContext.class, obj, false);
    }

    public static ActivityThreadHContext getWithException(Object obj) {
        return (ActivityThreadHContext) BlackReflection.create(ActivityThreadHContext.class, obj, true);
    }
}
