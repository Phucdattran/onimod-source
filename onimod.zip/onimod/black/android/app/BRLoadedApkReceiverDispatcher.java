package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRLoadedApkReceiverDispatcher {
    public static LoadedApkReceiverDispatcherStatic get() {
        return (LoadedApkReceiverDispatcherStatic) BlackReflection.create(LoadedApkReceiverDispatcherStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) LoadedApkReceiverDispatcherContext.class);
    }

    public static LoadedApkReceiverDispatcherStatic getWithException() {
        return (LoadedApkReceiverDispatcherStatic) BlackReflection.create(LoadedApkReceiverDispatcherStatic.class, null, true);
    }

    public static LoadedApkReceiverDispatcherContext get(Object obj) {
        return (LoadedApkReceiverDispatcherContext) BlackReflection.create(LoadedApkReceiverDispatcherContext.class, obj, false);
    }

    public static LoadedApkReceiverDispatcherContext getWithException(Object obj) {
        return (LoadedApkReceiverDispatcherContext) BlackReflection.create(LoadedApkReceiverDispatcherContext.class, obj, true);
    }
}
