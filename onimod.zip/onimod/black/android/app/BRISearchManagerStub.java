package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRISearchManagerStub {
    public static ISearchManagerStubStatic get() {
        return (ISearchManagerStubStatic) BlackReflection.create(ISearchManagerStubStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ISearchManagerStubContext.class);
    }

    public static ISearchManagerStubStatic getWithException() {
        return (ISearchManagerStubStatic) BlackReflection.create(ISearchManagerStubStatic.class, null, true);
    }

    public static ISearchManagerStubContext get(Object obj) {
        return (ISearchManagerStubContext) BlackReflection.create(ISearchManagerStubContext.class, obj, false);
    }

    public static ISearchManagerStubContext getWithException(Object obj) {
        return (ISearchManagerStubContext) BlackReflection.create(ISearchManagerStubContext.class, obj, true);
    }
}
