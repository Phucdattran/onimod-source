package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRLoadedApk {
    public static LoadedApkStatic get() {
        return (LoadedApkStatic) BlackReflection.create(LoadedApkStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) LoadedApkContext.class);
    }

    public static LoadedApkStatic getWithException() {
        return (LoadedApkStatic) BlackReflection.create(LoadedApkStatic.class, null, true);
    }

    public static LoadedApkContext get(Object obj) {
        return (LoadedApkContext) BlackReflection.create(LoadedApkContext.class, obj, false);
    }

    public static LoadedApkContext getWithException(Object obj) {
        return (LoadedApkContext) BlackReflection.create(LoadedApkContext.class, obj, true);
    }
}
