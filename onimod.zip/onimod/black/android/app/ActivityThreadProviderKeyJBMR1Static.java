package black.android.app;

import top.niunaijun.blackreflection.annotation.BClassNameNotProcess;
import top.niunaijun.blackreflection.annotation.BConstructorNotProcess;

/* JADX INFO: loaded from: classes.dex */
@BClassNameNotProcess("android.app.ActivityThread$ProviderKey")
public interface ActivityThreadProviderKeyJBMR1Static {
    @BConstructorNotProcess
    ActivityThread.ProviderKeyJBMR1 _new(String str, int i3);
}
