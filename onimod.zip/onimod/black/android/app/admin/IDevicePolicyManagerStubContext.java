package black.android.app.admin;

import top.niunaijun.blackreflection.annotation.BClassNameNotProcess;

/* JADX INFO: loaded from: classes.dex */
@BClassNameNotProcess("android.app.admin.IDevicePolicyManager$Stub")
public interface IDevicePolicyManagerStubContext {
}
