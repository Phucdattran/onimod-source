package black.android.app.admin;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIDevicePolicyManager {
    public static IDevicePolicyManagerStatic get() {
        return (IDevicePolicyManagerStatic) BlackReflection.create(IDevicePolicyManagerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IDevicePolicyManagerContext.class);
    }

    public static IDevicePolicyManagerStatic getWithException() {
        return (IDevicePolicyManagerStatic) BlackReflection.create(IDevicePolicyManagerStatic.class, null, true);
    }

    public static IDevicePolicyManagerContext get(Object obj) {
        return (IDevicePolicyManagerContext) BlackReflection.create(IDevicePolicyManagerContext.class, obj, false);
    }

    public static IDevicePolicyManagerContext getWithException(Object obj) {
        return (IDevicePolicyManagerContext) BlackReflection.create(IDevicePolicyManagerContext.class, obj, true);
    }
}
