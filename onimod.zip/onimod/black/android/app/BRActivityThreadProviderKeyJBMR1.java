package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityThreadProviderKeyJBMR1 {
    public static ActivityThreadProviderKeyJBMR1Static get() {
        return (ActivityThreadProviderKeyJBMR1Static) BlackReflection.create(ActivityThreadProviderKeyJBMR1Static.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityThreadProviderKeyJBMR1Context.class);
    }

    public static ActivityThreadProviderKeyJBMR1Static getWithException() {
        return (ActivityThreadProviderKeyJBMR1Static) BlackReflection.create(ActivityThreadProviderKeyJBMR1Static.class, null, true);
    }

    public static ActivityThreadProviderKeyJBMR1Context get(Object obj) {
        return (ActivityThreadProviderKeyJBMR1Context) BlackReflection.create(ActivityThreadProviderKeyJBMR1Context.class, obj, false);
    }

    public static ActivityThreadProviderKeyJBMR1Context getWithException(Object obj) {
        return (ActivityThreadProviderKeyJBMR1Context) BlackReflection.create(ActivityThreadProviderKeyJBMR1Context.class, obj, true);
    }
}
