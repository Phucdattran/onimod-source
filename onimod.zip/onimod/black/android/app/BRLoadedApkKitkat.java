package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRLoadedApkKitkat {
    public static LoadedApkKitkatStatic get() {
        return (LoadedApkKitkatStatic) BlackReflection.create(LoadedApkKitkatStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) LoadedApkKitkatContext.class);
    }

    public static LoadedApkKitkatStatic getWithException() {
        return (LoadedApkKitkatStatic) BlackReflection.create(LoadedApkKitkatStatic.class, null, true);
    }

    public static LoadedApkKitkatContext get(Object obj) {
        return (LoadedApkKitkatContext) BlackReflection.create(LoadedApkKitkatContext.class, obj, false);
    }

    public static LoadedApkKitkatContext getWithException(Object obj) {
        return (LoadedApkKitkatContext) BlackReflection.create(LoadedApkKitkatContext.class, obj, true);
    }
}
