package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRLoadedApkServiceDispatcherInnerConnection {
    public static LoadedApkServiceDispatcherInnerConnectionStatic get() {
        return (LoadedApkServiceDispatcherInnerConnectionStatic) BlackReflection.create(LoadedApkServiceDispatcherInnerConnectionStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) LoadedApkServiceDispatcherInnerConnectionContext.class);
    }

    public static LoadedApkServiceDispatcherInnerConnectionStatic getWithException() {
        return (LoadedApkServiceDispatcherInnerConnectionStatic) BlackReflection.create(LoadedApkServiceDispatcherInnerConnectionStatic.class, null, true);
    }

    public static LoadedApkServiceDispatcherInnerConnectionContext get(Object obj) {
        return (LoadedApkServiceDispatcherInnerConnectionContext) BlackReflection.create(LoadedApkServiceDispatcherInnerConnectionContext.class, obj, false);
    }

    public static LoadedApkServiceDispatcherInnerConnectionContext getWithException(Object obj) {
        return (LoadedApkServiceDispatcherInnerConnectionContext) BlackReflection.create(LoadedApkServiceDispatcherInnerConnectionContext.class, obj, true);
    }
}
