package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIActivityManager {
    public static IActivityManagerStatic get() {
        return (IActivityManagerStatic) BlackReflection.create(IActivityManagerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IActivityManagerContext.class);
    }

    public static IActivityManagerStatic getWithException() {
        return (IActivityManagerStatic) BlackReflection.create(IActivityManagerStatic.class, null, true);
    }

    public static IActivityManagerContext get(Object obj) {
        return (IActivityManagerContext) BlackReflection.create(IActivityManagerContext.class, obj, false);
    }

    public static IActivityManagerContext getWithException(Object obj) {
        return (IActivityManagerContext) BlackReflection.create(IActivityManagerContext.class, obj, true);
    }
}
