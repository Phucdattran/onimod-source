package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRNotificationManager {
    public static NotificationManagerStatic get() {
        return (NotificationManagerStatic) BlackReflection.create(NotificationManagerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) NotificationManagerContext.class);
    }

    public static NotificationManagerStatic getWithException() {
        return (NotificationManagerStatic) BlackReflection.create(NotificationManagerStatic.class, null, true);
    }

    public static NotificationManagerContext get(Object obj) {
        return (NotificationManagerContext) BlackReflection.create(NotificationManagerContext.class, obj, false);
    }

    public static NotificationManagerContext getWithException(Object obj) {
        return (NotificationManagerContext) BlackReflection.create(NotificationManagerContext.class, obj, true);
    }
}
