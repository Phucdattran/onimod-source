package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIActivityManagerContentProviderHolder {
    public static IActivityManagerContentProviderHolderStatic get() {
        return (IActivityManagerContentProviderHolderStatic) BlackReflection.create(IActivityManagerContentProviderHolderStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IActivityManagerContentProviderHolderContext.class);
    }

    public static IActivityManagerContentProviderHolderStatic getWithException() {
        return (IActivityManagerContentProviderHolderStatic) BlackReflection.create(IActivityManagerContentProviderHolderStatic.class, null, true);
    }

    public static IActivityManagerContentProviderHolderContext get(Object obj) {
        return (IActivityManagerContentProviderHolderContext) BlackReflection.create(IActivityManagerContentProviderHolderContext.class, obj, false);
    }

    public static IActivityManagerContentProviderHolderContext getWithException(Object obj) {
        return (IActivityManagerContentProviderHolderContext) BlackReflection.create(IActivityManagerContentProviderHolderContext.class, obj, true);
    }
}
