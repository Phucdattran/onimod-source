package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIServiceConnectionO {
    public static IServiceConnectionOStatic get() {
        return (IServiceConnectionOStatic) BlackReflection.create(IServiceConnectionOStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IServiceConnectionOContext.class);
    }

    public static IServiceConnectionOStatic getWithException() {
        return (IServiceConnectionOStatic) BlackReflection.create(IServiceConnectionOStatic.class, null, true);
    }

    public static IServiceConnectionOContext get(Object obj) {
        return (IServiceConnectionOContext) BlackReflection.create(IServiceConnectionOContext.class, obj, false);
    }

    public static IServiceConnectionOContext getWithException(Object obj) {
        return (IServiceConnectionOContext) BlackReflection.create(IServiceConnectionOContext.class, obj, true);
    }
}
