package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIAlarmManager {
    public static IAlarmManagerStatic get() {
        return (IAlarmManagerStatic) BlackReflection.create(IAlarmManagerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IAlarmManagerContext.class);
    }

    public static IAlarmManagerStatic getWithException() {
        return (IAlarmManagerStatic) BlackReflection.create(IAlarmManagerStatic.class, null, true);
    }

    public static IAlarmManagerContext get(Object obj) {
        return (IAlarmManagerContext) BlackReflection.create(IAlarmManagerContext.class, obj, false);
    }

    public static IAlarmManagerContext getWithException(Object obj) {
        return (IAlarmManagerContext) BlackReflection.create(IAlarmManagerContext.class, obj, true);
    }
}
