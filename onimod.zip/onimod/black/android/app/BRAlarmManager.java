package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRAlarmManager {
    public static AlarmManagerStatic get() {
        return (AlarmManagerStatic) BlackReflection.create(AlarmManagerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) AlarmManagerContext.class);
    }

    public static AlarmManagerStatic getWithException() {
        return (AlarmManagerStatic) BlackReflection.create(AlarmManagerStatic.class, null, true);
    }

    public static AlarmManagerContext get(Object obj) {
        return (AlarmManagerContext) BlackReflection.create(AlarmManagerContext.class, obj, false);
    }

    public static AlarmManagerContext getWithException(Object obj) {
        return (AlarmManagerContext) BlackReflection.create(AlarmManagerContext.class, obj, true);
    }
}
