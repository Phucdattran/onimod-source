package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityClient {
    public static ActivityClientStatic get() {
        return (ActivityClientStatic) BlackReflection.create(ActivityClientStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityClientContext.class);
    }

    public static ActivityClientStatic getWithException() {
        return (ActivityClientStatic) BlackReflection.create(ActivityClientStatic.class, null, true);
    }

    public static ActivityClientContext get(Object obj) {
        return (ActivityClientContext) BlackReflection.create(ActivityClientContext.class, obj, false);
    }

    public static ActivityClientContext getWithException(Object obj) {
        return (ActivityClientContext) BlackReflection.create(ActivityClientContext.class, obj, true);
    }
}
