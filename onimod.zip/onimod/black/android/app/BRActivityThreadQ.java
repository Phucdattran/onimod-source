package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityThreadQ {
    public static ActivityThreadQStatic get() {
        return (ActivityThreadQStatic) BlackReflection.create(ActivityThreadQStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityThreadQContext.class);
    }

    public static ActivityThreadQStatic getWithException() {
        return (ActivityThreadQStatic) BlackReflection.create(ActivityThreadQStatic.class, null, true);
    }

    public static ActivityThreadQContext get(Object obj) {
        return (ActivityThreadQContext) BlackReflection.create(ActivityThreadQContext.class, obj, false);
    }

    public static ActivityThreadQContext getWithException(Object obj) {
        return (ActivityThreadQContext) BlackReflection.create(ActivityThreadQContext.class, obj, true);
    }
}
