package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityThread {
    public static ActivityThreadStatic get() {
        return (ActivityThreadStatic) BlackReflection.create(ActivityThreadStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityThreadContext.class);
    }

    public static ActivityThreadStatic getWithException() {
        return (ActivityThreadStatic) BlackReflection.create(ActivityThreadStatic.class, null, true);
    }

    public static ActivityThreadContext get(Object obj) {
        return (ActivityThreadContext) BlackReflection.create(ActivityThreadContext.class, obj, false);
    }

    public static ActivityThreadContext getWithException(Object obj) {
        return (ActivityThreadContext) BlackReflection.create(ActivityThreadContext.class, obj, true);
    }
}
