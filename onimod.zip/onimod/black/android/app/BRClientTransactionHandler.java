package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRClientTransactionHandler {
    public static ClientTransactionHandlerStatic get() {
        return (ClientTransactionHandlerStatic) BlackReflection.create(ClientTransactionHandlerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ClientTransactionHandlerContext.class);
    }

    public static ClientTransactionHandlerStatic getWithException() {
        return (ClientTransactionHandlerStatic) BlackReflection.create(ClientTransactionHandlerStatic.class, null, true);
    }

    public static ClientTransactionHandlerContext get(Object obj) {
        return (ClientTransactionHandlerContext) BlackReflection.create(ClientTransactionHandlerContext.class, obj, false);
    }

    public static ClientTransactionHandlerContext getWithException(Object obj) {
        return (ClientTransactionHandlerContext) BlackReflection.create(ClientTransactionHandlerContext.class, obj, true);
    }
}
