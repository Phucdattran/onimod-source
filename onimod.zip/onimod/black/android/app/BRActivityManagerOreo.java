package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityManagerOreo {
    public static ActivityManagerOreoStatic get() {
        return (ActivityManagerOreoStatic) BlackReflection.create(ActivityManagerOreoStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityManagerOreoContext.class);
    }

    public static ActivityManagerOreoStatic getWithException() {
        return (ActivityManagerOreoStatic) BlackReflection.create(ActivityManagerOreoStatic.class, null, true);
    }

    public static ActivityManagerOreoContext get(Object obj) {
        return (ActivityManagerOreoContext) BlackReflection.create(ActivityManagerOreoContext.class, obj, false);
    }

    public static ActivityManagerOreoContext getWithException(Object obj) {
        return (ActivityManagerOreoContext) BlackReflection.create(ActivityManagerOreoContext.class, obj, true);
    }
}
