package black.android.app;

import android.content.Intent;
import android.content.pm.ProviderInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BField;
import top.niunaijun.blackreflection.annotation.BMethod;
import top.niunaijun.blackreflection.annotation.BParamClassName;

/* JADX INFO: loaded from: classes.dex */
@BClassName("android.app.IActivityManager")
public interface IActivityManager {

    @BClassName("android.app.IActivityManager$ContentProviderHolder")
    public interface ContentProviderHolder {
        @BField
        ProviderInfo info();

        @BField
        boolean noReleaseNeeded();

        @BField
        IInterface provider();
    }

    @BClassName("android.app.IActivityManager$ContentProviderHolder")
    public interface ContentProviderHolderMIUI {
        @BField
        ProviderInfo info();

        @BField
        boolean noReleaseNeeded();

        @BField
        IInterface provider();

        @BField
        boolean waitProcessStart();
    }

    @BMethod
    Integer getTaskForActivity(IBinder iBinder, boolean z4);

    @BMethod
    void overridePendingTransition(IBinder iBinder, String str, int i3, int i4);

    @BMethod
    void setRequestedOrientation(IBinder iBinder, int i3);

    @BMethod
    Integer startActivities();

    @BMethod
    Integer startActivity(@BParamClassName("android.app.IApplicationThread") Object obj, String str, Intent intent, String str2, IBinder iBinder, String str3, int i3, int i4, @BParamClassName("android.app.ProfilerInfo") Object obj2, Bundle bundle);
}
