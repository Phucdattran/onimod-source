package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRSharedPreferencesImpl {
    public static SharedPreferencesImplStatic get() {
        return (SharedPreferencesImplStatic) BlackReflection.create(SharedPreferencesImplStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) SharedPreferencesImplContext.class);
    }

    public static SharedPreferencesImplStatic getWithException() {
        return (SharedPreferencesImplStatic) BlackReflection.create(SharedPreferencesImplStatic.class, null, true);
    }

    public static SharedPreferencesImplContext get(Object obj) {
        return (SharedPreferencesImplContext) BlackReflection.create(SharedPreferencesImplContext.class, obj, false);
    }

    public static SharedPreferencesImplContext getWithException(Object obj) {
        return (SharedPreferencesImplContext) BlackReflection.create(SharedPreferencesImplContext.class, obj, true);
    }
}
