package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRNotificationL {
    public static NotificationLStatic get() {
        return (NotificationLStatic) BlackReflection.create(NotificationLStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) NotificationLContext.class);
    }

    public static NotificationLStatic getWithException() {
        return (NotificationLStatic) BlackReflection.create(NotificationLStatic.class, null, true);
    }

    public static NotificationLContext get(Object obj) {
        return (NotificationLContext) BlackReflection.create(NotificationLContext.class, obj, false);
    }

    public static NotificationLContext getWithException(Object obj) {
        return (NotificationLContext) BlackReflection.create(NotificationLContext.class, obj, true);
    }
}
