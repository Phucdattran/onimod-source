package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityThreadActivityClientRecord {
    public static ActivityThreadActivityClientRecordStatic get() {
        return (ActivityThreadActivityClientRecordStatic) BlackReflection.create(ActivityThreadActivityClientRecordStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityThreadActivityClientRecordContext.class);
    }

    public static ActivityThreadActivityClientRecordStatic getWithException() {
        return (ActivityThreadActivityClientRecordStatic) BlackReflection.create(ActivityThreadActivityClientRecordStatic.class, null, true);
    }

    public static ActivityThreadActivityClientRecordContext get(Object obj) {
        return (ActivityThreadActivityClientRecordContext) BlackReflection.create(ActivityThreadActivityClientRecordContext.class, obj, false);
    }

    public static ActivityThreadActivityClientRecordContext getWithException(Object obj) {
        return (ActivityThreadActivityClientRecordContext) BlackReflection.create(ActivityThreadActivityClientRecordContext.class, obj, true);
    }
}
