package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRApplicationThreadNative {
    public static ApplicationThreadNativeStatic get() {
        return (ApplicationThreadNativeStatic) BlackReflection.create(ApplicationThreadNativeStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ApplicationThreadNativeContext.class);
    }

    public static ApplicationThreadNativeStatic getWithException() {
        return (ApplicationThreadNativeStatic) BlackReflection.create(ApplicationThreadNativeStatic.class, null, true);
    }

    public static ApplicationThreadNativeContext get(Object obj) {
        return (ApplicationThreadNativeContext) BlackReflection.create(ApplicationThreadNativeContext.class, obj, false);
    }

    public static ApplicationThreadNativeContext getWithException(Object obj) {
        return (ApplicationThreadNativeContext) BlackReflection.create(ApplicationThreadNativeContext.class, obj, true);
    }
}
