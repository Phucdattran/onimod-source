package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRWallpaperManager {
    public static WallpaperManagerStatic get() {
        return (WallpaperManagerStatic) BlackReflection.create(WallpaperManagerStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) WallpaperManagerContext.class);
    }

    public static WallpaperManagerStatic getWithException() {
        return (WallpaperManagerStatic) BlackReflection.create(WallpaperManagerStatic.class, null, true);
    }

    public static WallpaperManagerContext get(Object obj) {
        return (WallpaperManagerContext) BlackReflection.create(WallpaperManagerContext.class, obj, false);
    }

    public static WallpaperManagerContext getWithException(Object obj) {
        return (WallpaperManagerContext) BlackReflection.create(WallpaperManagerContext.class, obj, true);
    }
}
