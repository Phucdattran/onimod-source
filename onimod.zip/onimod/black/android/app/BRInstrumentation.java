package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRInstrumentation {
    public static InstrumentationStatic get() {
        return (InstrumentationStatic) BlackReflection.create(InstrumentationStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) InstrumentationContext.class);
    }

    public static InstrumentationStatic getWithException() {
        return (InstrumentationStatic) BlackReflection.create(InstrumentationStatic.class, null, true);
    }

    public static InstrumentationContext get(Object obj) {
        return (InstrumentationContext) BlackReflection.create(InstrumentationContext.class, obj, false);
    }

    public static InstrumentationContext getWithException(Object obj) {
        return (InstrumentationContext) BlackReflection.create(InstrumentationContext.class, obj, true);
    }
}
