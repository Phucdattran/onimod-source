package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRContextImplICS {
    public static ContextImplICSStatic get() {
        return (ContextImplICSStatic) BlackReflection.create(ContextImplICSStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ContextImplICSContext.class);
    }

    public static ContextImplICSStatic getWithException() {
        return (ContextImplICSStatic) BlackReflection.create(ContextImplICSStatic.class, null, true);
    }

    public static ContextImplICSContext get(Object obj) {
        return (ContextImplICSContext) BlackReflection.create(ContextImplICSContext.class, obj, false);
    }

    public static ContextImplICSContext getWithException(Object obj) {
        return (ContextImplICSContext) BlackReflection.create(ContextImplICSContext.class, obj, true);
    }
}
