package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityThreadNMR1 {
    public static ActivityThreadNMR1Static get() {
        return (ActivityThreadNMR1Static) BlackReflection.create(ActivityThreadNMR1Static.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityThreadNMR1Context.class);
    }

    public static ActivityThreadNMR1Static getWithException() {
        return (ActivityThreadNMR1Static) BlackReflection.create(ActivityThreadNMR1Static.class, null, true);
    }

    public static ActivityThreadNMR1Context get(Object obj) {
        return (ActivityThreadNMR1Context) BlackReflection.create(ActivityThreadNMR1Context.class, obj, false);
    }

    public static ActivityThreadNMR1Context getWithException(Object obj) {
        return (ActivityThreadNMR1Context) BlackReflection.create(ActivityThreadNMR1Context.class, obj, true);
    }
}
