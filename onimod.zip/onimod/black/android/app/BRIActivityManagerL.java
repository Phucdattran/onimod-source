package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRIActivityManagerL {
    public static IActivityManagerLStatic get() {
        return (IActivityManagerLStatic) BlackReflection.create(IActivityManagerLStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) IActivityManagerLContext.class);
    }

    public static IActivityManagerLStatic getWithException() {
        return (IActivityManagerLStatic) BlackReflection.create(IActivityManagerLStatic.class, null, true);
    }

    public static IActivityManagerLContext get(Object obj) {
        return (IActivityManagerLContext) BlackReflection.create(IActivityManagerLContext.class, obj, false);
    }

    public static IActivityManagerLContext getWithException(Object obj) {
        return (IActivityManagerLContext) BlackReflection.create(IActivityManagerLContext.class, obj, true);
    }
}
