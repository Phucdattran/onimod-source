package black.android.app;

import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BStaticField;
import top.niunaijun.blackreflection.annotation.BStaticMethod;

/* JADX INFO: loaded from: classes.dex */
@BClassName("android.app.ActivityTaskManager")
public interface ActivityTaskManager {
    @BStaticField
    Object IActivityTaskManagerSingleton();

    @BStaticMethod
    Object getService();
}
