package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRService {
    public static ServiceStatic get() {
        return (ServiceStatic) BlackReflection.create(ServiceStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ServiceContext.class);
    }

    public static ServiceStatic getWithException() {
        return (ServiceStatic) BlackReflection.create(ServiceStatic.class, null, true);
    }

    public static ServiceContext get(Object obj) {
        return (ServiceContext) BlackReflection.create(ServiceContext.class, obj, false);
    }

    public static ServiceContext getWithException(Object obj) {
        return (ServiceContext) BlackReflection.create(ServiceContext.class, obj, true);
    }
}
