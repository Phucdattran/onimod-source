package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivityManagerNative {
    public static ActivityManagerNativeStatic get() {
        return (ActivityManagerNativeStatic) BlackReflection.create(ActivityManagerNativeStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityManagerNativeContext.class);
    }

    public static ActivityManagerNativeStatic getWithException() {
        return (ActivityManagerNativeStatic) BlackReflection.create(ActivityManagerNativeStatic.class, null, true);
    }

    public static ActivityManagerNativeContext get(Object obj) {
        return (ActivityManagerNativeContext) BlackReflection.create(ActivityManagerNativeContext.class, obj, false);
    }

    public static ActivityManagerNativeContext getWithException(Object obj) {
        return (ActivityManagerNativeContext) BlackReflection.create(ActivityManagerNativeContext.class, obj, true);
    }
}
