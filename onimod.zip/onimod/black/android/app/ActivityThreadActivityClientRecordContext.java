package black.android.app;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.IBinder;
import android.view.Window;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import top.niunaijun.blackreflection.annotation.BClassNameNotProcess;
import top.niunaijun.blackreflection.annotation.BFieldCheckNotProcess;
import top.niunaijun.blackreflection.annotation.BFieldNotProcess;
import top.niunaijun.blackreflection.annotation.BFieldSetNotProcess;
import top.niunaijun.blackreflection.annotation.BMethodCheckNotProcess;

/* JADX INFO: loaded from: classes.dex */
@BClassNameNotProcess("android.app.ActivityThread$ActivityClientRecord")
public interface ActivityThreadActivityClientRecordContext {
    @BFieldCheckNotProcess
    Field _check_activity();

    @BFieldCheckNotProcess
    Field _check_activityInfo();

    @BFieldCheckNotProcess
    Field _check_intent();

    @BFieldCheckNotProcess
    Field _check_isTopResumedActivity();

    @BFieldCheckNotProcess
    Field _check_mPreserveWindow();

    @BFieldCheckNotProcess
    Field _check_packageInfo();

    @BMethodCheckNotProcess
    Method _check_toString();

    @BFieldCheckNotProcess
    Field _check_token();

    @BFieldCheckNotProcess
    Field _check_window();

    @BFieldSetNotProcess
    void _set_activity(Object obj);

    @BFieldSetNotProcess
    void _set_activityInfo(Object obj);

    @BFieldSetNotProcess
    void _set_intent(Object obj);

    @BFieldSetNotProcess
    void _set_isTopResumedActivity(Object obj);

    @BFieldSetNotProcess
    void _set_mPreserveWindow(Object obj);

    @BFieldSetNotProcess
    void _set_packageInfo(Object obj);

    @BFieldSetNotProcess
    void _set_token(Object obj);

    @BFieldSetNotProcess
    void _set_window(Object obj);

    @BFieldNotProcess
    android.app.Activity activity();

    @BFieldNotProcess
    ActivityInfo activityInfo();

    @BFieldNotProcess
    Intent intent();

    @BFieldNotProcess
    Boolean isTopResumedActivity();

    @BFieldNotProcess
    Boolean mPreserveWindow();

    @BFieldNotProcess
    Object packageInfo();

    String toString();

    @BFieldNotProcess
    IBinder token();

    @BFieldNotProcess
    Window window();
}
