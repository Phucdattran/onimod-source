package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRContextImplKitkat {
    public static ContextImplKitkatStatic get() {
        return (ContextImplKitkatStatic) BlackReflection.create(ContextImplKitkatStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ContextImplKitkatContext.class);
    }

    public static ContextImplKitkatStatic getWithException() {
        return (ContextImplKitkatStatic) BlackReflection.create(ContextImplKitkatStatic.class, null, true);
    }

    public static ContextImplKitkatContext get(Object obj) {
        return (ContextImplKitkatContext) BlackReflection.create(ContextImplKitkatContext.class, obj, false);
    }

    public static ContextImplKitkatContext getWithException(Object obj) {
        return (ContextImplKitkatContext) BlackReflection.create(ContextImplKitkatContext.class, obj, true);
    }
}
