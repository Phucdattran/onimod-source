package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRNotificationChannel {
    public static NotificationChannelStatic get() {
        return (NotificationChannelStatic) BlackReflection.create(NotificationChannelStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) NotificationChannelContext.class);
    }

    public static NotificationChannelStatic getWithException() {
        return (NotificationChannelStatic) BlackReflection.create(NotificationChannelStatic.class, null, true);
    }

    public static NotificationChannelContext get(Object obj) {
        return (NotificationChannelContext) BlackReflection.create(NotificationChannelContext.class, obj, false);
    }

    public static NotificationChannelContext getWithException(Object obj) {
        return (NotificationChannelContext) BlackReflection.create(NotificationChannelContext.class, obj, true);
    }
}
