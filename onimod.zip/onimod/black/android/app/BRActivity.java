package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRActivity {
    public static ActivityStatic get() {
        return (ActivityStatic) BlackReflection.create(ActivityStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) ActivityContext.class);
    }

    public static ActivityStatic getWithException() {
        return (ActivityStatic) BlackReflection.create(ActivityStatic.class, null, true);
    }

    public static ActivityContext get(Object obj) {
        return (ActivityContext) BlackReflection.create(ActivityContext.class, obj, false);
    }

    public static ActivityContext getWithException(Object obj) {
        return (ActivityContext) BlackReflection.create(ActivityContext.class, obj, true);
    }
}
