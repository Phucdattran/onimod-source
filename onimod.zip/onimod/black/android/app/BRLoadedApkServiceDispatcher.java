package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRLoadedApkServiceDispatcher {
    public static LoadedApkServiceDispatcherStatic get() {
        return (LoadedApkServiceDispatcherStatic) BlackReflection.create(LoadedApkServiceDispatcherStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) LoadedApkServiceDispatcherContext.class);
    }

    public static LoadedApkServiceDispatcherStatic getWithException() {
        return (LoadedApkServiceDispatcherStatic) BlackReflection.create(LoadedApkServiceDispatcherStatic.class, null, true);
    }

    public static LoadedApkServiceDispatcherContext get(Object obj) {
        return (LoadedApkServiceDispatcherContext) BlackReflection.create(LoadedApkServiceDispatcherContext.class, obj, false);
    }

    public static LoadedApkServiceDispatcherContext getWithException(Object obj) {
        return (LoadedApkServiceDispatcherContext) BlackReflection.create(LoadedApkServiceDispatcherContext.class, obj, true);
    }
}
