package black.android.app;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import java.io.File;
import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BField;
import top.niunaijun.blackreflection.annotation.BMethod;
import top.niunaijun.blackreflection.annotation.BStaticMethod;

/* JADX INFO: loaded from: classes.dex */
@BClassName("android.app.ContextImpl")
public interface ContextImpl {
    @BStaticMethod
    Object createAppContext();

    @BMethod
    Object getAttributionSource();

    @BMethod
    PackageManager getPackageManager();

    @BMethod
    Context getReceiverRestrictedContext();

    @BField
    String mBasePackageName();

    @BField
    ContentResolver mContentResolver();

    @BField
    File mFilesDir();

    @BField
    Object mPackageInfo();

    @BField
    PackageManager mPackageManager();

    @BMethod
    void setOuterContext(Context context);
}
