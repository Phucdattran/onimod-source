package black.android.app;

import top.niunaijun.blackreflection.BlackReflection;
import top.niunaijun.blackreflection.utils.ClassUtil;

/* JADX INFO: loaded from: classes.dex */
public class BRNotification {
    public static NotificationStatic get() {
        return (NotificationStatic) BlackReflection.create(NotificationStatic.class, null, false);
    }

    public static Class getRealClass() {
        return ClassUtil.classReady((Class<?>) NotificationContext.class);
    }

    public static NotificationStatic getWithException() {
        return (NotificationStatic) BlackReflection.create(NotificationStatic.class, null, true);
    }

    public static NotificationContext get(Object obj) {
        return (NotificationContext) BlackReflection.create(NotificationContext.class, obj, false);
    }

    public static NotificationContext getWithException(Object obj) {
        return (NotificationContext) BlackReflection.create(NotificationContext.class, obj, true);
    }
}
