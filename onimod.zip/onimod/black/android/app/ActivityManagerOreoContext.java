package black.android.app;

import top.niunaijun.blackreflection.annotation.BClassNameNotProcess;

/* JADX INFO: loaded from: classes.dex */
@BClassNameNotProcess("android.app.ActivityManager")
public interface ActivityManagerOreoContext {
}
